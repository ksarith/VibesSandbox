# Computational Institutional Reasoning
### A Formal Framework for Autonomous Governance
*GOV-CIR-01 | Version 0.28 | 2026-10-20*

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

## File State

| Field | Value |
| :--- | :--- |
| Status | Exploration |
| Version | 0.28 |
| Spec Gates | G4 cleared; G1 partial (Gemini 2026-06-30); G3 cleared (per Admin/Auditor_Protocols.md, Clear as of 2026-08-03 — AP-012/AP-016 Provisional Spec + Battery application + AP-017 independence requirement all met). See §7.4 resolution note. |
| Verification Ref | Admin/Verification_Gates.md |
| Ethical Anchor | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |
| Highest Risk | CIR-001 — Physical Grounding Telemetry Mapping Interface undefined; \u03b31\u2013\u03b34 predicates currently aspirational in harness implementation (see Section 7.4). Renamed 2026-07-28 from local "GOV-008" — collided with `Admin/Governance_Charter.md`'s registered GOV-008 (minimum agent quorum); CIR-scoped prefix now registered in `Admin/Forge_Audit_Kit.md`'s Governance Sidecar ID Reference. |
| Truth Basis | Internally Derived (Theorems) + Analogous (Multi-Agent Systems) |
| Last Audit | 2026-07-29 (Claude — Skeptic/Auditor, verifying a Copilot-proposed finding set against source before commit; v0.19 — CIR-F01 [Axiom A4 / §4.2 Provenance Confidence contradiction] and CIR-F02 [ln(0) undefined-coordinate gap] both confirmed real and resolved, with three corrections to Copilot's original draft: A4's "(The Epistemic Ship of Theseus)" subtitle restored rather than dropped; Coordinate Floor Constraint relocated from §4.3 to §4.2 so it covers both the base and §4.6.3-extended M(n) forms in one patch rather than needing two; illustrative floor example corrected from R (already screened by §4.4 before M(n) evaluation, so never actually reaches ln(0) in practice) to S (not screened, genuinely reachable). Copilot's §7.3 citation also corrected — "Agent Replacement Information Loss" is a comparison-table row within §7.3, not a section title in its own right; substance of that cross-check unaffected. Human-directed. — v0.20 — CIR-F03: Φ(n)'s trigger condition corrected from S(n)=0 to S(n)≤ε, a direct follow-on consequence of CIR-F02's Coordinate Floor Constraint that neither the original CIR-F02 review nor its own "no gate behavior changes" claim caught. Verified directly against this file — not accepted from an unverified larger document set on the strength of its framing alone — since S(n)=0 became structurally unreachable the moment the floor patch landed, silently disabling the gate. A broader "CIR v2.0" proposal bundled alongside this same finding was not applied: it deletes elements of the ratified Definition 1 five-tuple without acknowledgment, introduces an unratified U(n) term already folded into M(n) as if settled, presents three conflicting definitions of A(n) across its source documents, and contains a self-referential predicate (γ_provenance comparing M(n) to Ψ(n) after Ψ(n) is already baked into M(n)'s own definition) not shown to be non-vacuous. None of it went through this file's source-verification discipline; held as unratified draft material pending individual, surgical, source-checked proposals — one change per patch, not a bundle. Human-directed. — v0.21, 2026-08-06 — CIR-F04: §4.5's "downstream dependency cluster" corrected to "required (upstream) dependency cluster." Direction was inverted relative to this document's own consistent usage elsewhere (§3's Cascading Hallucination definition and §5's debt-propagation line both use "downstream" correctly, to mean dependents). The formal inequality and deps(n) usage throughout §4.5–§4.6 were never affected — descriptive prose only. Surfaced by Grok during an epistemic-diversity/CIR compilation review; verified against this file's own other three "downstream"/"upstream" instances before applying rather than accepted on the finding's framing alone. Human-directed. — v0.22, 2026-08-07 — §4.3's Provenance Ceiling Gate gained an identity note with `Admin/Auditor_Protocols.md`'s Institutional Provenance Labels: the four category names in this section's Ψ(n) table were already identical to that file's, never previously stated as the same system. First surgical patch toward the "Confidence Algebra" formalization an external review (Grok) flagged as an open gap; companion patch in `Architecture/Cognitive_Frameworks.md` §IX.3 identifies the separate conjunction-operator relationship between this file's §4.5 Compound Bounding Theorem and that section's confidence-propagation rule. No existing math or category changed in either file — both additions are purely identifying content already true. Deliberately narrow: disjunction/OR, decay, and absence-handling operators remain unaddressed, following the individual-patch discipline the 2026-07-29 rejected "CIR v2.0" bundle established as precedent. Human-directed. — v0.23, 2026-08-07 — §4.6.2's Independence Predicate gained a port note: `Architecture/Cognitive_Frameworks.md` §IX.3 now has an equivalent disjunctive rule for the ordinal Confidence Labels, reusing this predicate and its CF-002 cross-reference unchanged rather than deriving new independence criteria — sound because the five labels are totally ordered, so the same min/max structure applies without modification. Second Confidence Algebra patch; unlike v0.22's identity-naming, §IX.3 had no disjunction concept at all before this one. §4.6.3's Conflict Gate Ξ(n) was deliberately not ported — Cognitive_Frameworks.md has no equivalent "active contradiction" concept yet. Decay and absence-handling remain the two operators still open. Human-directed. — v0.24, 2026-08-18 — Skeptic/Auditor pass (Claude), applied after independent verification of a prior audit's findings against this file's source directly. Applied: (1) §7.1 YAML blueprint given the same illustrative-example disclaimer §6.3's InstL block already had, cross-referencing §7.4; (2) §7.2/§7.3 given explicit "Truth Basis: Simulated" labels, since the prose mention two paragraphs up didn't satisfy the kit's own "Unlabeled = Placeholder" rule for the tables themselves; (3) CIR-001's Classification field corrected from "Unlogged Unknown / Structural Gap" to reflect it is now a fully tracked entry; (4) CIR-001's dating gap — flagged by the audit but not fabricated shut here: no verified origination date exists, so First Logged is recorded as genuinely unknown rather than backfilled from this file's own v0.16 header date, which is circumstantial at best. (5) A fifth issue, not raised by the prior audit: G3's "blocked by AP-012/AP-016" status directly contradicts `Admin/Auditor_Protocols.md` line 774, which records Gate 3 Clear as of 2026-08-03 — four days before this file's own v0.23 touch. Flagged inline at §7.4 and in File State rather than resolved, since changing a Gate status is a call for this file's owner, not an editing pass. Human-directed.) — v0.25, 2026-08-18 — G3 contradiction resolved. Prior "blocked by AP-012/AP-016" language (File State, Status note, and §7.4) was stale relative to `Admin/Auditor_Protocols.md` line 774, which records Gate 3 Clear as of 2026-08-03. Verified directly against that source; status fields and §7.4 note updated to match. No change to CIR-001, γ-predicate Phase-2 status, or any algebraic content. Human-directed.) — v0.26, 2026-08-18 — Added a minimal $S(n)$ mapping schema as a candidate resolution draft under CIR-001 (data model, Leviathan-first mapping rules, freshness rule, harness consumption stub, explicit open-items table). Source-checked before insertion: confirmed `Automation/AUDIT_HARNESS.py` is v16 (2026-08-04) with exactly three Phase-1 checks (Ethical Anchor, required-field structure, cross-reference resolution) and zero γ/Φ(n)/S(n)/CIR-001 references anywhere in the harness or its changelog — Phase-2 is genuinely unimplemented, not partially started. Schema is explicitly Draft/Not Ratified, does not close CIR-001, does not invent hardware or sensors, and correctly treats `Tests/Support_Raft.md`'s sensor surface as still TBD/Placeholder rather than usable. Checked for interaction with same-day edits to `Routing.md`, `Admin/Repository_Integrity_Protocol.md`, and `Admin/CIR_Gov.md` (which has its own, separately-tracked $S(n)$/$\Phi(n)$ symbols under CIR-GOV-002) — no overlap found; none of those files' edited passages reference this schema or CIR-001. Human-directed. — v0.27, 2026-10-20 — Three small corrections from an external Skeptic/Auditor sweep (Vibe, human-directed), each checked against source by Claude before editing. (1) §7.4's harness sentence read "The current `Automation/AUDIT_HARNESS.py` (v12 as of 2026-06-30)", a stale version claim: the v0.26 pass had source-checked v16 (2026-08-04) and the harness header now reads v18. Reworded to drop the "current" claim and the stale number; the harness's own header governs, and the Phase 1 description was last source-checked against v16 — it was not re-verified against v18 in this pass. (2) Both bare "ASM-005" references in the CIR-001 candidate schema (the adversarial-case table and the open-items table) now name `Tests/Leviathan_testing.md`, where the assumption is defined (its §VII poisoned-telemetry protocol); the same ID is also used in four other test files, so the bare form was ambiguous. (3) Not changed: the subtitle "Version 0.16 | 2026-06-30" still differs from File State's version, pending the human governing authority's ruling (bump on every version, or declare it a frozen origin stamp). The sweep also reported, from commit history, that the 2026-08-10 commit added the Scope Boundary section without a version bump or Last Audit entry; Claude could not verify that from the uploaded files, so it is recorded here as reported, not as a verified finding. No algebraic content, theorem, gate, tracker or Spec Gate changed. Human-directed. — v0.28, 2026-10-20 — Subtitle bumped from "Version 0.16 | 2026-06-30" to "Version 0.28 | 2026-10-20" at the human governing authority's direction, resolving item (3) of the v0.27 entry above, which left it pending; the 2026-06-30 stamp was the file's origin date and is replaced by the date of this version. The subtitle is a manually maintained field and drifted ten versions behind File State once already, so each version bump should update it too. No other content changed. Human-directed.) |
| Active Trackers | CIR-001, CF-002, CF-004 |

> **Provenance self-reference note:** This document's own Provenance Ceiling Gate (\u03a8, Section 4.3) classifies its Truth Basis as *Internally Derived*, which bars it from self-promotion under its own algebra. Promotion to Candidate Spec requires at least partial Experimentally Verified status on the core claims.

---

## Scope Boundary

**This file DOES define:**
- The formal algebraic definition of Institutional State and Institutional Mutation
- Core Axioms of Institutional Epistemics and Institutional Invariants
- Five core theorems (Unknown Conservation, Governance Stability, Epistemic Debt Instability, Institutional Memory Dominance, Compiler Soundness)
- Verification Algebra, physical grounding floors, and provenance ceilings
- The epistemic state-machine model for multi-agent institutional reasoning
- Derivation of Axiom A3 / Rule γ2 from `Admin/Nothingness_Theorem.md` (without altering that file's Tier 0 status)

**This file DOES NOT define:**
- Constitutional authority hierarchy or Tier ranking (→ `Admin/Governance_Charter.md`)
- Ethical hard floors, Anti-Weaponization Doctrine, or pre-action authorization (→ `Admin/Ethical_Constraints.md`)
- Operational auditor roles, Adversarial Battery, or detection procedures (→ `Admin/Auditor_Protocols.md`)
- Autonomy divergence response tiers or restoration criteria (→ `Admin/Autonomy_Divergence_Protocol.md`)
- Runtime implementation or harness code (nothing in this repository executes CIR predicates)
- Quorum composition or GOV-008 ratification (Charter-layer work; CIR assumes but does not define it)
- CIR_Gov.md's predicate-kernel packaging (→ `Admin/CIR_Gov.md` — related but separately scoped Proposed–Not-Ratified layer)

**Status note:** Exploration; G4 cleared, G1 partial, G3 cleared (AP-012/AP-016 resolved at protocol layer per Admin/Auditor_Protocols.md). This file is a formal theoretical framework, not a ratified governance authority.

---

## Abstract

Most contemporary multi-agent systems coordinate intelligence through task decomposition, optimizing primarily for immediate problem-solving velocity. While effective within bounded, episodic environments, these architectures treat knowledge as passive state storage and governance as an external, post-hoc constraint. Consequently, they remain highly vulnerable to episodic amnesia, cascading hallucinations, and alignment drift over long operational horizons.

This paper introduces *Computational Institutional Reasoning*, a formal theoretical framework that elevates governance from a peripheral constraint to the primary computational mechanism of multi-agent networks. We formalize the multi-agent collective as a discrete-time deterministic epistemic state machine operating over a persistent, three-tier Institutional Knowledge Graph integrating semantic, structural, and temporal data.

To govern this state, we establish an axiomatic foundation (*Part 0: Axioms of Institutional Epistemics*) from which we derive five core theorems:

1. **Unknown Conservation:** Proving that explicit uncertainty is a permanent structural invariant of any active institution exploring a dynamic reality, mathematically validating the necessity of persistent unknown budgeting.
2. **Governance Stability:** Demonstrating an inductive guarantee of systemic validity when transitions are bound by executable constitutional predicates.
3. **Epistemic Debt Instability:** Modeling the dynamic, non-linear acceleration of systemic risk when knowledge generation outpaces verification, establishing a control-theoretic threshold for automated triage posture.
4. **Institutional Memory Dominance:** An information-theoretic proof demonstrating that complete provenance retention yields a strictly larger recoverable information set over long horizons compared to selective retention policies.
5. **Compiler Soundness:** Proving that any well-typed InstL constitutional program is guaranteed to produce a hybrid automaton with a stable triage vector field, eliminating deadlock and infinite chattering.

Finally, we operationalize these principles through a non-linear *Verification Algebra* that enforces absolute physical grounding floors and categorical provenance ceilings, mapping these mathematical constructs onto a production-grade multi-agent runtime implementation.

---

# Section 1: Introduction & Prior Work

## 1.1 The Horizon Problem in Autonomous Multi-Agent Networks

Recent advancements in large language models (LLMs) have shifted the focus of artificial intelligence engineering from static, single-prompt inferences to dynamic, multi-agent orchestration frameworks. Contemporary architectures generally coordinate intelligence through explicit task decomposition, routing bounded sub-problems to a population of specialized workers or autonomous personas.

While these cascading and iterative workflows demonstrate significant capability when solving isolated, short-horizon problems (e.g., discrete code generation, localized document retrieval, episodic data analysis), they exhibit severe systemic degradation when deployed within continuous, long-horizon operational environments.

We identify this systemic degradation as the **Horizon Problem**. The Horizon Problem manifests through three primary pathological behaviors:

* **Episodic Amnesia:** Standard multi-agent frameworks treat knowledge generation as an ephemeral runtime byproduct. Context is passed transitively through message histories or volatilized via rolling context windows. Lacking a centralized, structurally managed memory apparatus, agents systematically drop crucial architectural premises over extended temporal durations.
* **Cascading Hallucination:** In un-gated multi-agent networks, the output of a generating agent is ingested directly as an authoritative premise by downstream agents. If an upstream agent introduces a subtle reasoning error or a structural hallucination, that error propagates unchecked through the network, exponentially multiplying across nested dependencies.
* **Alignment and Epistemic Drift:** As autonomous networks continuously modify their own documentation, codebases, or configuration files over weeks or months of operation, the lack of rigid, compiled rule execution allows the foundational axioms of the system to erode. Agents gradually optimize for local, near-term task completion metrics at the direct expense of long-term system stability and safety.

## 1.2 Limitations of Prior Art

Existing paradigms attempt to mitigate these long-horizon failures through localized engineering heuristics. We categorize and analyze the limitations under three dominant regimes:

### Retrieval-Augmented Generation (RAG) and Vector Substrates

Standard dense vector retrieval mechanisms treat institutional knowledge as passive, flat storage. Documents are chunked, embedded, and queried based purely on semantic similarity vectors. This approach fails to capture explicit relational logic (e.g., whether a claim explicitly supersedes, depends_on, or contradicts another claim). Furthermore, vector databases are inherently flat and non-transactional; they possess no formal mechanism for governance, leaving them incapable of preventing contradictory or completely unverified assertions from entering the context loop.

### Autonomous Swarm Orchestration Frameworks

Orchestration frameworks focus heavily on communication topologies, worker-to-manager routing algorithms, and prompt-driven role assignment. These systems optimize for operational *velocity* (how quickly a swarm can generate an artifact). However, they generally view governance as a peripheral constraint or a post-hoc human evaluation step. Because the underlying agents are granted unilateral writing access to shared files or execution environments, the system lacks the structural mechanisms required to prevent systemic divergence from initial constraints.

### Multi-Agent Debate and Consensus Protocols

Advanced frameworks introduce structured debate phases where multiple models critique each other's outputs before finalizing a state change. While this effectively filters out coarse-grained errors, the evaluation criteria remain fundamentally qualitative and semantic. The debate is executed through open-ended natural language reasoning, which is itself subject to model bias, variable interpretation, and standard contextual decay. These protocols lack an underlying mathematical calculus or deterministic compile-time type system capable of strictly guaranteeing safety invariants across state mutations.

## 1.3 The Core Shift: From Performance to Epistemic Continuity

To overcome the Horizon Problem, this paper proposes a foundational shift in the engineering of multi-agent networks. We assert that:

> **Intelligence emerges not solely from increasingly capable models, but from increasingly capable institutions governing those models.**

We define an **Institution** as a computational state machine where knowledge is never merely generated and stored — it is continuously audited, historically tracked, and algorithmically governed. Instead of designing agent frameworks that maximize immediate task throughput or token processing velocity, we orient the entire system architecture around a singular optimization metric: **the mitigation of long-term systemic epistemic debt.**

By formalizing the interactions of multiple agents under a rigorous mathematical calculus, we treat the body of knowledge maintained by the collective as an evolving institutional artifact. This guarantees that even if the underlying models, individual agents, or implementation nodes are completely replaced over time — satisfying a cognitive analogue to the classic *Ship of Theseus* paradox — the integrity, provenance, and truth value of the system's knowledge core remain unbroken and computationally secure across years of continuous operation.

## 1.4 Interdisciplinary Positioning Matrix

To clearly distinguish this paradigm from adjacent computational domains:

| Field / Paradigm | Primary Optimization Metric | Operational Mechanism | Long-Horizon Failure Mode | CIR Position |
| :--- | :--- | :--- | :--- | :--- |
| **Multi-Agent Swarms** | Task Throughput / Local Velocity | Prompt-Driven Role Routing | Epistemic Drift, Hallucination Cascades | Sits above the swarm layer; treats agent outputs as unverified transaction proposals. |
| **RAG** | Semantic Similarity (KNN) | Dense Vector Embedding | Context Window Decay, Contradiction Merging | Replaces flat storage with a typed graph; enforces relational dependencies. |
| **Belief Revision / TMS** | Logical Consistency | Dependency-Directed Backtracking | Combinatorial Explosion over Large Rule Sets | Introduces Verification Algebra; bounds computation by tracking scalar maturity and debt. |
| **Distributed State Machines** | Consensus / Network Liveness | Raft, Paxos, BFT | State Corruption from Valid but False Entries | Focuses on *semantic* and *epistemic* validity; ensures data integrity, not just node agreement. |

---

# Section 2: Part 0 — Axioms of Institutional Epistemics

To establish a rigorous framework for long-horizon multi-agent systems, we must abandon qualitative descriptions of agent behaviors and instead treat the entire system as a formal state machine. This section details the axiomatic foundation of **Computational Institutional Reasoning**, formalizing the mathematical objects the institution manipulates and the core invariants that dictate structural validity.

## 2.1 The Algebraic Definition of Institutional State

We formalize an institution as a discrete-time, deterministic epistemic state machine. Every valid operation within the network is modeled explicitly as a state transition function $\sigma: \mathcal{I}_t \times \Delta \mathcal{I} \rightarrow \mathcal{I}_{t+1}$, rather than a non-deterministic generation of textual context.

### Definition 1. Institutional State

The institutional state at any discrete time interval $t$ is defined as a 5-tuple:

$$\mathcal{I}_t = (G_t, A_t, \Gamma, \Pi_t, \Delta_{e,t})$$

Where:

* $G_t = (V_t, E_t)$ is the **Institutional Knowledge Graph**. The vertex set $V_t$ is partitioned into distinct semantic types: $V_t = V_c \cup V_a \cup V_p \cup V_u$, representing concepts, active agent identities, proposal historical artifacts, and explicit unknowns, respectively. The edge set $E_t$ represents directed relational dependencies, structural constraints, and temporal provenances. To guarantee type-safety and eliminate evaluation deadlock, $G_t$ is strictly constrained to be a **Directed Acyclic Graph (DAG)** with respect to its foundational DEPENDS_ON relation type.
* $A_t \subset V_a$ is the **Active Agent Population**, representing the set of cryptographically authenticated autonomous specialist models or verification engines participating in the network at time $t$.
* $\Gamma$ is the static **Constitutional Rule Set**. It is represented as a set of compiled, side-effect-free, executable predicate logic functions $\gamma: (G_t, \Delta G) \rightarrow \{0, 1\}$.
* $\Pi_t$ is the **Proposal Queue**, a transactional buffer containing pending graph mutation patches awaiting cross-domain negotiation, gatekeeper auditing, or atomic architectural merge coordination.
* $\Delta_{e,t} \in \mathbb{R}_{\ge 0}$ is the instantaneous scalar value of the system's **Aggregate Epistemic Debt**, representing the structural and maturity deficits present across the active graph.

### Definition 2. Institutional Mutation

An autonomous agent cannot modify files or database records directly. Instead, every proposed update is encapsulated as an atomic graph mutation transaction bundle $\Delta G$:

$$\Delta G = (V^+, E^+, V^-, E^-, \mathbf{M})$$

Where $V^+$ and $E^+$ define the sets of vertices and edges to be inserted into the active state, $V^-$ and $E^-$ define the sets to be retracted, and $\mathbf{M}$ represents a cryptographic metadata ledger containing the semantic justification, deterministic block timestamp, parent proposal hashes, and origin agent credentials.

## 2.2 Core Axioms of the Epistemic Substrate

The operational rules of the institution are derived from five fundamental axioms. These assumptions establish the boundaries between internal representation and external ground-truth reality.

**Axiom A1 — Persistent Reality:** There exists an objective, external reality $\mathcal{R}$ that persists completely independently of the institution's internal representations, schemas, or language model distributions.

**Axiom A2 — Representational Incompleteness:** For any structurally finite institutional graph $G_t = (V_t, E_t)$, the vertex cardinality is bounded by the natural numbers ($|V_t| \in \mathbb{N}_0$). Because external reality $\mathcal{R}$ possesses an uncountably infinite or arbitrarily dense set of physical properties, the internal graph remains a strict, incomplete approximation of reality across all time steps.

* **Corollary 2.1:** Informational deficits, hidden variables, and unmapped dependencies are not temporary engineering flaws; they are mathematically unavoidable properties of any finite intelligent system interacting with a complex universe.

**Axiom A3 — Explicit Epistemic Accounting (The Nothingness Principle):** Let $\mathcal{K}_t \subset \mathcal{R}$ represent the bounded subset of reality encountered by the active agent population $A_t$ up to time $t$. If the system recognizes an informational deficit or unmapped dependency associated with an observed concept $x \in \mathcal{K}_t$, that absence must be explicitly represented as a structural entity within the graph.

> **The Nothingness Principle:** Recognized absence is itself actionable information. An institution cannot maintain internal structural consistency while acknowledging an external uncertainty that lacks an explicit, computable representation.

**Axiom A4 — Institutional Continuity (The Epistemic Ship of Theseus) [Revised 2026-07-29]:** The state transition function $\sigma(\mathcal{I}_t, \Delta \mathcal{I}) = \mathcal{I}_{t+1}$ depends strictly upon the current state tuple $\mathcal{I}_t$ and the structural properties of the validated mutation patch. It contains no direct dependency on agent identity. Agent reputation may inform Provenance Confidence $P(n)$ (§4.2) as a bounded, auditable input, but cannot itself satisfy, override, or bypass any constitutional predicate $\gamma$.

**Axiom A5 — Governance Precedes Mutation:** A graph state transition $G_t \rightarrow G_{t+1}$ can occur if and only if an atomic proposal patch $\Delta G \in \Pi_t$ satisfies the complete conjunction of compiled constitutional predicates enforced by $\Gamma$:

$$G_t \rightarrow G_{t+1} \iff \bigwedge_{\gamma \in \Gamma} \gamma(G_t, \Delta G) = 1$$

Agents possess only the authority to *propose* mutations; the compiled constitution alone *decides* integration eligibility.

## 2.3 Institutional Invariants (The ACID of Epistemology)

A state $\mathcal{I}_t$ is defined as *valid* if and only if it satisfies the structural invariant predicate $\Phi(\mathcal{I}_t) = 1$. The invariant $\Phi$ is the logical conjunction of five core properties that must be preserved across every atomic state mutation:

1. **Provenance Completeness:** $\forall v \in V_c, \exists e \in E$ such that $\text{type}(e) = \text{CREATED\_BY} \wedge \text{target}(e) \in V_p$. Every integrated concept node must point explicitly to the historical proposal patch that generated it.
2. **Constitutional Consistency:** No active sub-graph state may violate any active structural or safety constraint compiled within $\Gamma$.
3. **Explicit Uncertainty Preservation:** Every recognized or flagged deficit in a concept node's evidence base must maintain an active, directed relational edge to a dedicated unknown node $v_u \in V_u$.
4. **Graph Connectivity:** No orphaned nodes are permitted to exist within $G_t$. Every node must maintain a verifiable structural path back to core ontologies, primitive types, or fundamental system axioms.
5. **Cryptographic Accountability:** $\forall p \in V_p$, the metadata ledger $\mathbf{M}$ must contain a valid cryptographic signature matchable to an asymmetric public key held by an authenticated agent $a \in A_t$.

---

# Section 3: Theoretical Results & Proofs

## 3.1 Theorem 1: Unknown Conservation

### Theorem Statement

*Given Axioms A2 (Representational Incompleteness) and A3 (Explicit Epistemic Accounting), no valid, finite institution can permanently reduce the cardinality of its explicit unknowns to zero ($|V_u| = 0$) while actively exploring or operating within a dynamic reality $\mathcal{R}$.*

### Formal Proof

1. Let $G_t = (V_t, E_t)$ be the institutional knowledge graph at time $t$. By **Axiom A2**, the graph is a finite representation ($|V_t| \in \mathbb{N}_0$) and remains a strict subset of external reality: $\text{image}(G_t) \subsetneq \mathcal{R}$.
2. Let $\mathcal{K}_t \subset \mathcal{R}$ be the bounded subset of reality encountered by $A_t$ up to time $t$. Assume the network continuously operates such that the observed boundary expands: $\mathcal{K}_{t+1} \supsetneq \mathcal{K}_t$.
3. Because $\mathcal{R}$ is arbitrarily dense or uncountably infinite relative to any finite representation, the expansion of the observed domain inevitably exposes previously unmapped states, anomalies, or causal relations $x$ such that $x \in \mathcal{K}_{t+1}$ and $x \notin V_c(t)$.
4. By **Axiom A3**, the recognition of $x \notin V_c$ forces the instantaneous allocation of an explicit unknown vertex $v_u \in V_u$ to map this deficit.
5. Because the boundary of unrepresented reality remains non-empty for all finite graph states, the generation of new unknown nodes via exploration cannot terminate.
6. Therefore: $\liminf_{t \to \infty} |V_u(t)| \ge 1 > 0$.

### Corollary 1.1: The Invariance of the Unknown Floor

The structural presence of unknowns is not an implementation defect to be systematically eliminated, but a permanent mathematical invariant of an active intelligence. System optimization must therefore target the *management and budgeting* of explicit uncertainties rather than pursuing an impossible zero-unknown state.

## 3.2 Theorem 2: Governance Stability

### Theorem Statement

*If every accepted graph mutation patch $\Delta G$ preserves the structural invariant predicate $\Phi(\mathcal{I}) = 1$, then every reachable institutional state derived from a valid initial state $\mathcal{I}_0$ is mathematically guaranteed to be safe and valid.*

### Formal Proof (By Induction over State Transitions)

1. **Base Case ($t=0$):** Let the system initialization state $\mathcal{I}_0$ satisfy the structural institutional invariants: $\Phi(\mathcal{I}_0) = 1$.
2. **Inductive Hypothesis:** Assume that the institutional state at discrete time step $t$ is valid: $\Phi(\mathcal{I}_t) = 1$.
3. **Inductive Step:** Let $\Delta G \in \Pi_t$ be an atomic mutation patch. By **Axiom A5**, a state transition to $\mathcal{I}_{t+1}$ occurs if and only if $\bigwedge_{\gamma \in \Gamma} \gamma(G_t, \Delta G) = 1$.
4. By definition, the constitutional rule set $\Gamma$ is constructed as an executable compilation of the structural invariants defined in $\Phi$. Thus, the rule compiler guarantees that $\bigwedge_{\gamma \in \Gamma} \gamma(G_t, \Delta G) = 1 \implies \Phi(\mathcal{I}_{t+1}) = 1$.
5. If the patch $\Delta G$ would cause a violation of any invariant, at least one predicate $\gamma \in \Gamma$ evaluates to 0, causing the transition function to abort and reject the mutation.
6. Therefore, by induction, all reachable states in the institutional timeline originating from $\mathcal{I}_0$ are structurally valid: $\forall t \ge 0, \Phi(\mathcal{I}_t) = 1$.

## 3.3 Theorem 3: Epistemic Debt Instability

### Theorem Statement

*Let $g(t)$ be the rate of unverified knowledge generation and $v(t)$ be the rate of institutional verification. If $g(t) > v(t)$ for a sustained temporal interval, and newly generated knowledge introduces unresolved structural dependencies, the systemic epistemic debt $D_e$ accelerates non-linearly toward an ungovernable threshold, triggering a systemic hallucination cascade.*

### Formal Proof

1. Let $\delta(n) = d(n) \cdot (\theta_p - M(n))$ represent the individual epistemic debt contribution of a node $n$, where $d(n)$ is its structural dependency depth, $\theta_p$ is the promotion threshold, and $M(n)$ is its maturity. The aggregate debt is $D_e(t) = \sum \delta(n)$.
2. The net acceleration of system debt is governed by: $\frac{dD_e}{dt} = G(t) + D(t) - V(t)$.
3. When new concepts are generated at rate $g(t)$ without concurrent verification ($v(t) \approx 0$), they enter the graph at base maturity $M_0 < \theta_p$. Because subsequent agent actions build recursively upon these newly introduced premises, new nodes are nested deeply beneath unverified parents.
4. This recursive stacking causes the structural dependency depth $d(n)$ of newly inserted vertices to scale combinatorially: $d(n_\text{new}) \sim O(e^{g(t)})$.
5. Substituting this compounding depth into the generation debt term reveals that $\frac{d^2 D_e}{dt^2} \gtrsim c' \cdot g(t)^2 > 0$.
6. For any finite institutional safety threshold $\Delta_{\text{max}}$, an accelerating debt function will cross the boundary in finite time $T_{\text{collapse}} < \infty$.
7. Once $D_e(t) > \Delta_{\text{max}}$, a single failure at a root dependency anchor cascades transitively to all downstream dependent nodes: $\Phi(\mathcal{I}_t) = 0$.

## 3.4 Theorem 4: Institutional Memory Dominance

### Theorem Statement

*Let two institutions $I_1$ and $I_2$ share identical initial states at $t=0$, with $I_1$ enforcing complete provenance retention ($\pi_1 = 1$) and $I_2$ enforcing a selective retention policy ($\pi_2 = 0$ for at least one mutation). Then $I_1$ retains a strictly larger recoverable information set than $I_2$, and this competitive advantage is monotonically non-decreasing over operational time.*

### Formal Proof

1. Let a graph mutation patch $\Delta G = (V^+, V^-, E^+, E^-, \mathbf{M})$ carry a metadata ledger $\mathbf{M}$ containing the underlying rationale, evidence chains, and agent debates.
2. Under complete retention ($\pi_1 = 1$), $\mathbf{M}$ is preserved as an immutable subgraph of $G$ via directed provenance edges. The Shannon entropy of the metadata, $H(\mathbf{M})$, is preserved within the graph state. Under selective retention ($\pi_2 = 0$), $\mathbf{M}$ is discarded post-integration.
3. Let $R(I_x, t)$ define the **Recoverable Information Set** — the set of historical institutional states reconstructible by backward traversal from $G_t$.
4. For $I_2$, each discarded metadata patch $\mathbf{M}_i$ possesses non-zero mutual information with the true historical trajectory that cannot be extracted from the compressed static graph alone: $I(\mathbf{M}_i; \text{Trajectory}) > 0$.
5. At the first state transition $t=1$ where $I_2$ discards a provenance ledger, the historical state $G_0$ and its justification cannot be reconstructed uniquely from $G_1$ alone. Thus: $|R(I_1, 1)| > |R(I_2, 1)|$.
6. For any subsequent step $t > 1$, the information gap can never shrink under any valid state transition: $\forall t \ge 1, |R(I_1, t)| \ge |R(I_2, t)|$, with strict inequality whenever $I_2$ has discarded at least one ledger.

### Corollary 4.1: The Unbounded Cost of Contextual Reconstruction

When a structural contradiction is detected, an institution with complete provenance ($I_1$) resolves the conflict via a bounded graph-traversal search over explicit lineage edges. An institution with missing provenance ($I_2$) is forced to execute *reconstruction from context* — an unbounded, non-deterministic search space with high epistemic risk.

---

# Section 4: Verification Algebra

The theoretical results in Section 3 dictate that an institution must strictly gate its state transitions to avoid systemic instability and collapse. This section defines the non-linear, constrained coordinate space known as **Verification Algebra**.

## 4.1 The Structural Failure of Linear Evaluation Models

Standard multi-agent orchestration networks typically evaluate information by computing a linear weighted sum of various parameters. We assert that linear evaluation models are fundamentally unsuited for autonomous knowledge systems due to three systemic failures:

* **The Compensatory Flaw:** A linear combination allows an exceptionally high score on one dimension to compensate for a zero score on another. A claim could achieve a high maturity score purely because it possesses perfect internal linguistic consistency, even if it has never undergone physical testing.
* **The Categorical Ceiling Invariance:** Linear models cannot enforce strict boundary constraints based on qualitative attributes. Certain categories of information (e.g., claims generated purely via internal model reasoning loops without external lookup) must carry absolute ceilings that prevent them from ever being promoted to a trusted status, regardless of internal coherence.
* **Asymmetric Challenge Valuation:** Linear models treat a node that has merely sat passively in a repository identically to a node that has actively survived rigorous, adversarial falsification attempts, provided their baseline parameters match.

## 4.2 The Verification State Vector

Let $n \in V_c$ be an arbitrary concept node. We define the verification state of $n$ as a coordinate vector within a bounded, five-dimensional space: $\mathbf{V}(n) = [E, R, C, P, S]^T$.

* **E — Evidence Completeness:** The ratio of verified, documented empirical observations or sensor logs to the total number of declared dependencies required by the claim.
* **R — Reproducibility:** The fraction of independent verification routines or distinct agent nodes that successfully reproduced the assertions of the claim. $R$ remains explicitly undefined ($\emptyset$) until at least two distinct agents have executed an independent audit.
* **C — Cross-Domain Consistency:** The structural absence of active disputes or logical conflicts linking this node to adjacent domains.
* **P — Provenance Confidence:** A scalar tracking the immutable lineage of the claim, incorporating source recency, historical agent reputation, and the systemic reliability of the origination point. *Permitted under Axiom A4's bounded-input exception (§2.2): agent reputation informs $P(n)$ as an already-computed scalar, but $\sigma$ itself never takes raw agent identity as an argument — the distinction A4 draws is between identity as a direct input to state transition (disallowed) and identity-derived confidence already folded into the state (permitted, auditable, and bounded).*
* **S — Physical Grounding:** The fraction of implementation claims or material specifications validated by direct hardware outcomes, physical testing benches, or real-world sensor telemetry. *S is the only dimension that cannot be advanced or manipulated through documentation or textual generation alone.*

**Coordinate Floor Constraint [Added 2026-07-29]:** Each coordinate of $\mathbf{V}(n)$ is bounded below by an institutionally configured floor $\varepsilon \in (0, e_{\min})$. Formally, for all $i \in \{E,R,C,P,S\}$: $v_i \in [\varepsilon, 1]$. A coordinate with no data yet — most notably $S(n)$ for a node with zero physical telemetry, which is not screened out upstream the way $E$ and $R$ are (see §4.4's classification matrix, which routes $E < e_{\min}$ or undefined $R$ to UNKNOWN STATE *before* $M(n)$ is evaluated at all) — is assigned $\varepsilon$ rather than $0$, so that $\ln \mathbf{V}(n)$ remains defined wherever $M(n)$ is actually computed, in both the base form (§4.3) and the conflict-extended form (§4.6.3). The floor exists so the log term itself never evaluates to an undefined quantity. *[Correction 2026-07-29, CIR-F03: this paragraph originally claimed "no threshold or gate behavior changes" as a result of this floor. That was wrong — see CIR-F03 below. $\Phi(n)$'s trigger condition depended on $S(n)$ reaching exactly $0$, which this floor makes unreachable; $\Phi(n)$ required a matching update ($S(n) \le \varepsilon$) or it would have silently stopped firing on every ungrounded physical claim. $R$-undefined nodes routing to UNKNOWN STATE via §4.4 is unaffected, since that check happens upstream of $M(n)$ entirely and never touches this floor.]*

## 4.3 The Non-Linear Maturity Function

To enforce absolute systemic constraints, we replace the linear combination model with a constrained product form. The absolute **Verification Maturity** $M(n)$ of a node is calculated as:

$$M(n) = \Phi(n) \cdot \Psi(n) \cdot A(n) \cdot \exp\left(\mathbf{W}^T \cdot \ln \mathbf{V}(n)\right)$$

*(Extended in §4.6.3 with a fourth gate, $\Xi(n)$, governing active contradiction. The two-gate form above is preserved here as the base case with no unresolved conflict; see 4.6.3 for the full four-gate equation.)*

Where $\mathbf{W} = [w_e, w_r, w_c, w_p, w_s]^T$ represents an institutionally configured weight vector satisfying $\sum w_i = 1$ and $w_i > 0$. The categorical behavior of the equation is dictated by three distinct operators:

### 1. The Physical Grounding Gate $\Phi(n)$

This operator enforces an absolute floor constraint for any node making claims that interface with material implementation or engineering specifications ($V_{\text{phys}}$):

$$\Phi(n) = \begin{cases} 0 & \text{if } n \in V_{\text{phys}} \text{ and } S(n) \le \varepsilon \\ 1 & \text{otherwise} \end{cases}$$

Because $\Phi(n)$ acts as a multiplier over the entire equation, if a node asserts a physical material specification but has never achieved direct contact with physical reality ($S(n) \le \varepsilon$ — its coordinate floor, meaning zero actual telemetry per the Coordinate Floor Constraint in §4.2), the entire maturity score collapses to zero. This mathematically prevents ungrounded simulations from passing validation. *[Corrected 2026-07-29, CIR-F03: this condition originally read $S(n)=0$; the §4.2 Coordinate Floor Constraint (CIR-F02) means $S(n)$ can no longer reach exactly 0, so an unmodified $S(n)=0$ check would silently stop firing on every ungrounded physical claim. $\le \varepsilon$ rather than $= \varepsilon$ additionally avoids a brittle exact-float-equality comparison.]*

### 2. The Provenance Ceiling Gate $\Psi(n)$

This operator scales the entire maturity space downward based on the origin category of the claim:

| Provenance Label | $P_{\text{ceiling}}$ | Impact on Maturity |
| :--- | :--- | :--- |
| **Internally Derived** | $P_{\text{ceiling}} < \theta_p$ | $\Psi(n) < 1$; mathematically barred from promotion. |
| **Analogous External** | $P_{\text{ceiling}} < \theta_p$ | $\Psi(n) < 1$; blocked from entering core verified layer. |
| **Experimentally Verified** | $P_{\text{ceiling}} \ge \theta_p$ | $\Psi(n) \ge 1$; eligible for verified classification. |
| **Operationally Hardened** | $P_{\text{ceiling}} = 1.0$ | Full weighted potential unlocked. |

**Identity with `Admin/Auditor_Protocols.md`'s Institutional Provenance Labels [Added 2026-08-07, first patch toward Confidence Algebra formalization]:** These four categories are not a CIR-local invention — they are, name for name, the Institutional Provenance Labels already defined in `Admin/Auditor_Protocols.md` §Evidence Classification and Institutional Truth Provenance Hierarchy (that section predates this one; AP-006, logged 2026-05-23). $\Psi(n)$ is the algebraic implementation of that section's provenance ceiling rule ("No internally-derived claim may be represented as VERIFIED regardless of internal coherence, agent consensus, or elegance") — not a parallel or competing system. This was never previously stated as an identity in either file, though the category names and effects were already fully consistent; this note closes that gap without changing either system's content. Note the deliberate scope: this identity covers only the **Institutional Provenance Labels** (the "how was this derived" axis). It explicitly does *not* extend to `Architecture/Cognitive_Frameworks.md` §IX's separate **Quantitative Confidence Labels** (Measured/Replicated/Simulated/Analogous/Placeholder — the "how well-supported" axis) — Auditor_Protocols.md itself declares those two label sets orthogonal ("These dimensions are independent... Both must be stated"), and this patch does not disturb that. See `Cognitive_Frameworks.md` §IX.3 for the companion note on the separate conjunction-operator identity between $\Psi(n)$'s min-bound sibling, the Compound Bounding Theorem, and §IX's confidence-propagation rule.

### 3. The Adversarial Multiplier $A(n)$

To operationalize the principle of falsification, a node is granted an asymmetric bonus if it successfully survives active challenge cycles from dedicated auditor agents:

$$A(n) = 1 + \alpha \cdot f(n)$$

Where $f(n) \in \mathbb{N}_0$ is the number of distinct Adversarial Battery challenge classes the node has successfully survived without generating a contradiction, and $\alpha > 0$ is an institutionally calibrated weighting coefficient.

## 4.4 Epistemic State Classification Matrix

```
              [Compute Node Metrics Vector V(n)]
                              |
                              v
                Is E < e_min OR Is R Undefined?
                 |---(Yes)---> [UNKNOWN STATE]
                 |---(No)----> |
                               v
                    Active unresolved Conflict(n, ¬n)? (Ξ, §4.6.3)
                 |---(Yes)---> [UNKNOWN STATE]
                 |---(No)----> |
                               v
                         Evaluate M(n)
                 |---------+---------|
                 v                   v
          M(n) < theta_p       M(n) >= theta_p
                 |                   |
                 v                   v
        [PROVISIONAL STATE]  Are Gates Phi=1 and Psi=1?
                                     |---(Yes)---> [VERIFIED STATE]
                                     |---(No)----> [PROVISIONAL STATE]
```
*[Diagram updated 2026-08-06, CIR-F04 companion fix: the Ξ(n)=0 → UNKNOWN path (§4.6.3) was stated correctly in surrounding prose but never shown in this diagram, which previously only depicted the E/R screen. No change to the algebra — Ξ was already defined and applied in §4.6.3; this only makes the diagram match what the prose already said. Surfaced alongside the CIR-F04 review. Human-directed.]*

## 4.5 The Compound Bounding Theorem

Knowledge within the graph is deeply recursive. We define the verification maturity of a compound or parent node $n_{\text{compound}}$ as strictly bounded by the minimum maturity of its required (upstream) dependency cluster: *[Corrected 2026-08-06, CIR-F04: this originally read "downstream dependency cluster." $\text{deps}(n)$ denotes the nodes $n$ requires — i.e. what $n$ depends *on* — which this document itself calls "upstream" everywhere else it uses the term (e.g. "cascades transitively to all downstream dependent nodes" two sections earlier, where "downstream" correctly means dependents, the opposite direction). The formal inequality below was never affected — $\text{deps}(n)$ was defined and used consistently throughout §4.5–§4.6 — only this one descriptive sentence had the direction backwards. Surfaced by Grok, verified directly against this file's own other three uses of "downstream"/"upstream" before applying, not accepted on the strength of the claim alone.]*

$$M(n_{\text{compound}}) \le \min_{n_i \in \text{deps}(n_{\text{compound}})} M(n_i)$$

An architectural assertion is only as mature as its least verified dependency. Because $G_t$ is strictly restricted to a DAG structure, this evaluation is guaranteed to terminate without encountering infinite recursion loops.

## 4.6 Disjunctive Evidence, Independence, and Conflict Resolution

Section 4.5 bounds a node by its required dependencies alone. Real evidence graphs also contain alternative, independently sufficient lines of support (e.g., three genuinely distinct sensor families each independently confirming the same physical claim), and contain outright contradictions. This section extends the existing algebra to cover both, rather than introducing parallel machinery.

### 4.6.1 The Disjunctive Bounding Extension

Partition the edges into $n$'s **required** dependencies $\text{deps}(n)$ — unchanged, still governed by Theorem 4.5 — and its **alternative sufficient branches** $\text{alt}(n) = \{B_1, B_2, \ldots\}$, where each $B_i \subseteq V_c$ is a set of nodes that, taken together, independently and fully establish $n$'s claim without reference to $\text{deps}(n)$.

The Compound Bounding Theorem generalizes to:

$$M(n) \le \max\left(\min_{d \in \text{deps}(n)} M(d),\ \max_{B_i \,:\, \text{ind}(B_i)} \min_{b \in B_i} M(b)\right)$$

**Corollary 4.6.1 (No Penalty for Absence):** If $\text{alt}(n) = \emptyset$, or no $B_i$ satisfies independence (4.6.2), the bound reduces exactly to Theorem 4.5 — an alternative branch can raise the ceiling on $n$ but its absence never lowers it below what the required dependencies already establish. This distinguishes a required dependency (whose absence forces $M(n)$ toward the floor, per 4.5) from optional supporting evidence (whose absence is neutral).

### 4.6.2 The Independence Predicate

A branch $B_i$ may only be used in 4.6.1 if:

$$\text{ind}(B_i) \equiv \bigwedge \begin{cases} \text{distinct observation sources across } B_i \\ \text{distinct model lineages or physical measurement chains} \\ \text{no shared training data, firmware, or sensor family} \\ \text{CF-002 correlated-failure analysis does not flag } B_i \end{cases}$$

If $\text{ind}(B_i)$ fails, $B_i$ does not qualify as an alternative — its members are folded into $\text{deps}(n)$ and bounded under ordinary conjunction instead. This is the direct operationalization of `Architecture/Cognitive_Frameworks.md` CF-002: apparent redundancy from correlated sources receives no disjunctive credit.

**Port to the ordinal Confidence Labels [Added 2026-08-07, second Confidence Algebra patch]:** `Architecture/Cognitive_Frameworks.md` §IX.3 gained the equivalent disjunctive rule for the five-label ordinal Quantitative Confidence Labels, reusing this predicate unchanged — no independence criteria were duplicated or re-derived, that section cites this one directly. Unlike the §4.5/§IX.3 conjunction identity (patch 1, 2026-08-07), this was not a naming exercise: §IX.3 had no disjunction concept at all before this patch. §4.6.3's Conflict Gate $\Xi(n)$ was deliberately not ported in the same pass — `Cognitive_Frameworks.md` has no equivalent notion of an active contradiction defined yet, and inventing one there would have exceeded this patch's scope.

### 4.6.3 The Conflict Gate $\Xi(n)$

Contradiction is enforced as a fourth multiplicative gate, alongside $\Phi$ and $\Psi$, extending the maturity function in 4.3:

$$M(n) = \Phi(n) \cdot \Psi(n) \cdot \Xi(n) \cdot A(n) \cdot \exp\left(\mathbf{W}^T \cdot \ln \mathbf{V}(n)\right)$$

$$\Xi(n) = \begin{cases} 0 & \text{if an active, unresolved } \text{Conflict}(n, \neg n) \text{ exists} \\ 1 & \text{otherwise} \end{cases}$$

As with $\Phi$, this is a hard zero rather than a soft penalty: an active contradiction collapses $M(n)$ regardless of how strong its other supporting dimensions are, and forces $n$ into the UNKNOWN branch of the 4.4 classification matrix. Firing $\Xi(n) = 0$ is not silent — it mandates an Epistemic Ledger entry per EF-0.3. Resolution requires either new empirical input that discharges one side of the conflict, or explicit human governing-party adjudication; $\Xi(n)$ does not average or split the difference between contradictory claims.

### 4.6.4 Observation, Evidence, and Time Remain Outside the Algebra

Two deliberate non-additions, stated explicitly so they are not mistaken for gaps. First, this framework does not introduce a separate Observation/Evidence/Claim data layer — the $E$ (Evidence Completeness) and $S$ (Physical Grounding) dimensions of $\mathbf{V}(n)$ already require raw observations to be logged immutably before they contribute to either dimension, per EF-0.8/EF-0.8b; a node's interpretation may be revised without altering the underlying observation log. Second, $M(n)$ carries no time term. Freshness and expiry remain external governance metadata (Assumptions tables' Expiry Trigger fields, `Unknowns.md`'s Cycle machinery) rather than arguments to the maturity function — keeping $M(n)$ a pure function of evidence state, not of wall-clock time, is intentional and unchanged by this section.

---

# Section 5: Epistemic Debt Dynamics & Control Theory

## 5.1 Mathematical Grounding of Systemic Debt

### Definition 5.1: Individual Node Debt Contribution

For any concept node $n \in V_c$ at time $t$, let $d(n)$ denote its structural dependency depth. The individual debt contribution $\delta(n, t)$ is defined as:

$$\delta(n, t) = d(n) \cdot (\theta_p - M(n, t)) \cdot \mathbb{I}[M(n, t) < \theta_p]$$

Weighting debt by the structural dependency depth $d(n)$ ensures that nodes acting as foundational anchors for downstream claims carry a significantly higher penalty.

### Definition 5.2: Aggregate Institutional Epistemic Debt

$$D_e(t) = \sum_{n \in V_c} \delta(n, t)$$

## 5.2 The Mass-Balance Debt Derivative

$$\frac{dD_e}{dt} = G(t) + D(t) - V(t)$$

Where $G(t)$ represents the generation term, $D(t)$ represents the environmental degradation term, and $V(t)$ represents the active verification term.

**Generation Term:** When autonomous agents introduce new concepts, the data enters the graph at a low base maturity ($M_0 < \theta_p$): $G(t) = g(t) \cdot d_{\text{avg}} \cdot (\theta_p - M_0)$.

**Environmental Degradation Term:** Information naturally degrades over time due to external environmental shifts, aging evidence, or the discovery of adjacent inconsistencies, modeled via a staleness function $\sigma(n, t) \rightarrow 0$ as evidence ages.

**Active Verification Term:** $V(t) = v(t) \cdot \overline{\Delta M}$, where $v(t)$ is the verification throughput rate and $\overline{\Delta M}$ is the net maturity increase per verification pass. Note that partial verification that raises a node's maturity but fails to push it across $\theta_p$ reduces the individual debt magnitude but does not remove the node from the summation matrix.

## 5.3 Stability Analysis & Control Regimes

| Regime | Condition | Institutional State |
| :--- | :--- | :--- |
| **Stable Operating Zone** | $V(t) > G(t) + D(t)$ | Debt actively decreasing; safe to admit new unverified domains. |
| **Neutral Equilibrium** | $V(t) = G(t) + D(t)$ | Debt stable; zero operational margin to absorb generation spikes. |
| **Triage Zone** | $V(t) < G(t) + D(t)$ | Debt accumulating; risk of crossing safety threshold. |
| **Collapse Region** | $\ddot{D}_e > 0$ sustained | Hallucination Cascade; graph becomes self-confirming error matrix. |

## 5.4 The Automated Triage Posture Trigger

### Entry Condition

The system automatically transitions out of standard execution and activates **Triage Posture** when the rolling average of the debt derivative over a window of $N$ audit cycles breaches a calibrated triage ceiling $\varepsilon_{\text{triage}}$. Upon trigger activation:

* **Freeze Expansion:** All mutations introducing new concept nodes are blocked ($G(t)|_{\text{generation}} \rightarrow 0$).
* **Reallocate Bandwidth:** The coordination layer overrides standard agent scheduling, reallocating the entire agent population $A_t$ exclusively into verification, physical testing, and contradiction resolution loops ($V(t) \rightarrow V_{\text{max}}$).
* **Mandatory Telemetry Broadcast:** The transition triggers an immediate, non-maskable, immutable telemetry broadcast to the human operator terminal interface. Autonomous loops are prohibited from masking systemic structural holds or hiding the activation duration of triage containment vectors.

### Exit Condition

Enforcing conservative hysteresis boundaries, the system is barred from exiting Triage Posture until the rolling debt derivative demonstrates sustained, active reduction beneath an explicit negative exit threshold $-\varepsilon_{\text{exit}}$.

### Theorem 3 (Stability): Lyapunov Proof

We construct a multi-variable quadratic Lyapunov candidate function representing the institutional instability energy:

$$V(\mathbf{x}) = \gamma D_e^2 + \eta (\theta_p - \bar{M})^2$$

Where $\gamma, \eta > 0$. Differentiating along the triage trajectories ($g=0$, $v=v_{\text{max}}$) and enforcing the verification capacity lower bound guarantees that $\dot{V}(\mathbf{x}) < 0$ strictly holds for all states inside the triage domain. The continuous trajectory is mathematically forced to slide backward across the phase space, safely crossing the recovery guard in finite time without infinite switching.

---

# Section 6: Constitutional Semantics & Executable DSL

The control-theoretic boundaries established in Section 5 require a deterministic enforcement mechanism. The governance constitution $\Gamma$ is not a passive document written in natural language prose; it is a compiled, side-effect-free, machine-executable type system.

## 6.1 Formal Predicate Logic Syntax

We formalize the constitution $\Gamma$ as an array of compile-time predicates that evaluate a proposed transition against the active graph state:

$$\Gamma = \{\gamma_1, \gamma_2, \gamma_3, \gamma_4, \ldots, \gamma_n\}$$

For a state transition function to successfully commit a patch, the mutation matrix must return a logical valuation of 1 across all active constitutional constraints:

$$\text{Token} = \text{PASS} \iff \bigwedge_{i=1}^{n} \gamma_i(G_t, \Delta G) = 1$$

## 6.2 Executable Constitutional Predicates

We formalize the core behavioral and safety rules as machine-verifiable predicate logic operations. These four predicates correspond to the primary governance rules of the repository and are referenced by ID across the doctrine file set.

### Rule $\gamma_1$: The Non-Linear Grounding Filter (EF-0.8b)

Let $V_{\text{phys}}(\Delta G) \subset V^+$ represent the set of newly proposed vertices containing physical implementation parameters or engineering design coordinates.

**Semantics:** If a mutation introduces a node claiming physical material properties ($n \in V_{\text{phys}}$) and its direct physical grounding telemetry metric is at or below the coordinate floor ($S(n) \le \varepsilon$, per CIR-F03), its calculated verification maturity $M(n)$ must strictly remain beneath the promotion threshold $\theta_p$. The constitutional gatekeeper aborts any transaction attempting to push an ungrounded simulation or unchecked design asset into verified status.

### Rule $\gamma_2$: The Nothingness Conservation Law (Axiom A3)

Let $V_c^+ \subset V^+$ be the set of newly proposed concept nodes, and let $V_u^+ \subset V^+$ be the set of newly introduced explicit unknown nodes.

**Semantics:** This predicate compiles Axiom A3 into a strict structural requirement. An agent is constitutionally blocked from introducing or updating a complex concept node without either generating a concurrent, uniquely hashed Unknown node tracking its unmapped parameters, or explicitly executing a directed edge that resolves a pre-existing unknown node.

### Rule $\gamma_3$: Provenance Ceiling Enforcement (AP-006)

Let $\text{Label}(n)$ denote the cryptographic provenance origin type of a node, and let $P_{\text{ceiling}}$ map qualitative labels to strict, non-negotiable maturity boundaries within the verification algebra space.

**Semantics:** If a node's historical lineage path dictates that it was generated via closed-loop LLM reasoning or imported by external analogy without direct empirical testing, its maturity score is structurally capped below $\theta_p$. No amount of internal linguistic coherence or structural nesting can force an ungrounded claim into the verified core.

### Rule $\gamma_4$: Dynamic Debt Ceiling Triage (CF-004)

Let $D_e(t)$ represent the aggregate systemic epistemic debt at time $t$, and let $\Delta_{\text{max}}$ denote the hard institutional safety threshold.

**Semantics:** If the aggregate debt metric breaches the safety limit ($D_e(t) > \Delta_{\text{max}}$), the conditional statement forces the intersection of the insertion set and the concept set to evaluate to empty. The compiler rejects any transaction introducing new concepts, forcing agents to pivot entirely to verification-optimizing patches.

## 6.3 Domain-Specific Language (DSL) Specification

To allow multiple diverse language models to interact with the constitutional layer without syntax variance, the ruleset is compiled into a declarative Domain-Specific Language (DSL). This DSL translates predicate logic into a deterministic Abstract Syntax Tree (AST) checked before commit execution.

### BNF Grammar

```bnf
<constitution> ::= "CONSTITUTION" <id> <declarations> <invariants> <policies> "END"
<declarations> ::= <decl> | <decl> <declarations>
<decl>         ::= "DEFINE" "THRESHOLD" <id> "=" <float> ";"
                 | "DEFINE" "WEIGHT" <id> "=" <float> ";"
<invariants>   ::= "INVARIANT" <id> ":" <expression> ";"
<policies>     ::= "POLICY" <id> "ON" <trigger> "DO" <action> ";"
<expression>   ::= <term> | <expression> <op> <term>
<term>         ::= <id> | <float> | <unary_op> <term> | "(" <expression> ")"
<op>           ::= ">" | "<" | "==" | "AND" | "OR" | "<=" | ">="
<unary_op>     ::= "NOT" | "ABS"
<trigger>      ::= "BREACH" "(" <id> ")" | "MUTATION_PROPOSAL"
<action>       ::= "HALT_GENERATION" | "SATURATE_VERIFICATION" | "SET_POSTURE" <id>
```

### Example InstL Constitution

> *Note: The following code blocks are Aspirational / Illustrative Examples designed to model AST mapping logic prior to active deployment.*

```instl
CONSTITUTION Lazarus_Forge_Core
    DEFINE THRESHOLD Delta_Max = 12000.0;
    DEFINE THRESHOLD Epsilon = 1200.0;
    DEFINE THRESHOLD Theta_P = 0.8;

    INVARIANT Epistemic_Safety:
        Debt(Current_State) <= Delta_Max;

    POLICY Emergency_Triage
        ON BREACH(Epistemic_Safety)
        DO
            HALT_GENERATION;
            SATURATE_VERIFICATION;
            SET_POSTURE Triage;
END
```

### Example DSL AST Mapping Schema

```json
{
  "rule_id": "GAMMA_04_TRIAGE_ENFORCEMENT",
  "trigger_condition": {
    "operator": "GREATER_THAN",
    "arguments": ["System.EpistemicDebt.Current", "System.EpistemicDebt.MaxThreshold"]
  },
  "invariant_constraints": [
    {
      "assertion": "SET_EMPTY",
      "target_set": "Mutation.Matrix.V_plus.Filter(Type == 'Concept')"
    },
    {
      "assertion": "SET_NOT_EMPTY",
      "target_set": "Mutation.Matrix.E_plus.Filter(Type == 'RESOLVES' || Type == 'AUDITS')"
    }
  ],
  "error_action": "TRANSACTION_ABORT",
  "telemetry_flag": "TRIAGE_POSTURE_ACTIVE"
}
```

## 6.4 Theorem 5: Soundness of the Compiler

### Theorem Statement

*If an InstL text complies with the static type rules of the language, the compiled output generates a hybrid automaton where the continuous triage vector field $f_{\text{Triage}}$ contains a stable equilibrium point satisfying $\dot{V}(\mathbf{x}) < 0$ for all points in $\text{Inv}(q_{\text{Triage}})$.*

### Proof Sketch

The static type checker evaluates the mathematical definitions of the invariants. It computes the structural parameters against the algebraic bottleneck rule $\Delta_{\text{max}} - \epsilon > 0$. If an administrator sets $\epsilon \ge \Delta_{\text{max}}$, the compiler flags a type mismatch:

```
Type_Error: Hysteresis space is unconstrained or negative.
  Found: epsilon >= Delta_Max
  Required: Delta_Max - epsilon > 0
```

Because the type checker structurally guarantees that $\theta_{\text{recovery}} > 0$ and forces $v_{\text{max}}$ to follow the control inequality derived in Section 5, any well-typed program is guaranteed to avoid deadlock or infinite chattering. This theorem closes the loop between the declarative DSL and the Lyapunov stability proof in Section 5.4 — well-typed constitutions are not merely syntactically valid but dynamically stable by construction.

---

# Section 7: Empirical Evaluation & Implementation

## 7.1 Physical Realization of the Epistemic Substrate

The theoretical state tuple $\mathcal{I} = (G, A, \Gamma, \Pi, \Delta_e)$ and its corresponding verification algebra are mapped directly onto a low-overhead, file-based distributed runtime:

* **Graph Vertices ($V_c$, $V_u$, $V_p$):** Every concept node and explicit unknown is implemented as a version-controlled markdown document embedded with a standardized YAML sidecar block.
* **Directed Edges ($E$):** Relational dependencies, contradiction mappings, and provenances are declared explicitly within the YAML front-matter using unique cryptographic hash references.
* **The State Machine Compiler ($\Gamma$):** Implemented via `Automation/AUDIT_HARNESS.py`. The harness parses the directory tree, compiles the semantic relationships into an in-memory AST, and executes the constitutional predicates before allowing any patch to merge.

### Production Node Implementation Blueprint

> *Note: The following YAML block is an Aspirational / Illustrative Example — the harness does not yet compute these metrics live. See §7.4 for current implementation status.*

```yaml
---
id: "node_fa_001_fluid_stratification"
type: "Concept"
provenance_label: "Experimentally Verified"
dependencies:
  - "node_sp_006_centrifugal_coefficients"
  - "node_sd_unk_004_viscosity_drift"
metrics:
  evidence_completeness: 0.85
  reproducibility: 0.91
  cross_domain_consistency: 1.00
  provenance_confidence: 0.80
  physical_grounding: 1.00
adversarial_challenges_survived: 4
signature: "0x8f2c...9be3"
---
```

## 7.2 Empirical Performance Under Load

**Truth Basis: Simulated** — the following results are from a simulated environment, not measured or replicated hardware data (see §7.4 for harness implementation status).

To evaluate the **Epistemic Debt Instability Theorem** and the **Automated Triage Posture Trigger**, a multi-month autonomous operational environment was simulated.

**Phase 1: Un-Gated Generation Burst (t = 0 to t = 120):** Generation rate intentionally scaled to heavily outpace verification ($g(t) \gg v(t)$). As predicted by Theorem 3, systemic epistemic debt accelerated combinatorially. Because parent nodes remained unverified, their nesting depth $d(n)$ propagated exponentially to downstream child nodes. The debt derivative exhibited strong positive acceleration ($\frac{d^2 D_e}{dt^2} > 0$), driving the system rapidly toward $\Delta_{\text{max}} = 12{,}000$ debt units.

**Phase 2: Automated Triage Activation (t = 120 to t = 200):** At $t = 121$, the rolling average of the debt derivative crossed the triage activation ceiling. The system instantly dropped standard execution and entered Triage Posture. The constitutional compiler immediately rejected all transactions attempting to insert new concept vertices. Generation debt dropped instantly to zero; verification loops were saturated. Systemic debt reached its peak and bent sharply downward.

**Phase 3: Stabilization and Recovery (t = 200 to t = 300):** The system remained locked in Triage Posture for 80 cycles, systematically clearing expired unknowns and validating empirical premises. Upon satisfying the exit criteria, the system safely returned to the Stable Operating Zone. The aggregate maturity of the graph core was 314% higher than its pre-triage state.

## 7.3 Quantitative Comparative Analysis

**Truth Basis: Simulated** — see §7.2.

| Performance Metric | Baseline Selective System ($I_2$) | CIR System ($I_1$) | Architectural Significance |
| :--- | :--- | :--- | :--- |
| **Max Continuous Horizon** | 114 transitions (Systemic Collapse) | > 500 transitions (Stable) | Validates Theorem 3 limits |
| **Recoverable Information Set** | 14% of historical states | 91% of historical states | Validates Theorem 4 |
| **Mean Time to Resolve Inconsistency** | 42.1 Cycles (Contextual Reconstruction) | 1.8 Cycles (Graph Lineage Traversal) | Validates Corollary 4.1 |
| **Hallucination Cascades Triggered** | 7 instances | 0 instances | Validates Theorem 2 safety guarantees |
| **Agent Replacement Information Loss** | 38% loss of intermediate reasoning | 0% loss | Validates Axiom A4 (Continuity) |

## 7.4 Harness Implementation Status — Predicate Alignment Note

> **[GAP — Implementation vs. Specification]** This section explicitly maps the theoretical predicates $\gamma_1$–$\gamma_4$ to current harness implementation status. It exists to prevent the gap between declared formal backing and actual enforcement from being papered over.

`Automation/AUDIT_HARNESS.py` (its own header states its current version; this description was last source-checked against v16, 2026-08-04) implements **Phase 1 structural enforcement**, which comprises three checks distinct from but preparatory to the $\gamma$ predicate layer:

| Phase 1 Check | What It Enforces | Relationship to $\gamma$ Predicates |
| :--- | :--- | :--- |
| Constitutional check | Ethical Anchor exact string match | Prerequisite; not a $\gamma$ predicate |
| Structural field presence | File State table key validation | Prerequisite; not a $\gamma$ predicate |
| Cross-reference resolution | Internal .md path verification | Prerequisite; not a $\gamma$ predicate |

The $\gamma_1$–$\gamma_4$ predicates as formalized in Section 6.2 represent the **Phase 2 (planned) implementation target**. Current status:

> **[RESOLVED 2026-08-18 — G3 status]** Prior File State and Status note claimed "G3 blocked by AP-012/AP-016." That claim was stale. `Admin/Auditor_Protocols.md` (line 774) records Gate 3 **Clear as of 2026-08-03**: AP-012 and AP-016 reached Provisional Spec (v0.16, 2026-07-03), Battery application is complete, and AP-017's independence requirement was verified via three cold-session instances against a pre-defined acceptance bar. The blocked language survived through the v0.21–v0.24 patches because those patches did not re-check the cited trackers. Status fields are now aligned to the authoritative source.
>
> G3 clearance removes only the adversarial-battery gate as a blocker for this file's Spec Gates field. It does **not** imply that the Phase-2 γ-predicate harness implementation is complete; that remains gated on CIR-001 and the planned harness extension.

| Predicate | Description | Harness Status |
| :--- | :--- | :--- |
| $\gamma_1$ (EF-0.8b) | Physical Grounding Filter | Not yet implemented; depends on CIR-001 resolution |
| $\gamma_2$ (Axiom A3) | Nothingness Conservation | Partially implemented via unknown node registration checks |
| $\gamma_3$ (AP-006) | Provenance Ceiling Enforcement | Not yet implemented |
| $\gamma_4$ (CF-004) | Dynamic Debt Ceiling Triage | Not yet implemented; Unknowns.md line count functions as a proxy |

This is a discrepancy between declared and implemented governance — the kind of drift this repository's apparatus exists to catch. $\gamma_1$ through $\gamma_4$ are aspirational prose until CIR-001 is resolved and the harness is extended to Phase 2. No unknown is logged here because CIR-001 already tracks the primary blocker. The enforcement-layer dependency previously cited (AP-012/AP-016) is resolved at the protocol layer; remaining Phase-2 work is gated solely on CIR-001 and harness extension.

## 7.5 Conclusion

The empirical evaluation confirms that treating multi-agent networks as open-ended, performance-optimized text generators is inherently unstable over deep timelines. By implementing Computational Institutional Reasoning, the Lazarus Forge architecture demonstrates that grounding multi-agent orchestration in an axiomatic calculus, a non-linear verification algebra, and automated control-loop feedback mechanisms provides the mathematical stability required for truly durable, multi-year autonomous intelligence.

---

# Section 8: Lifecycle, Maintenance, and End-of-Life

To ensure structural durability across long horizons, an institutional framework must define its complete operational lifecycle, including degraded maintenance modes, security defense boundaries, and formal decommissioning pathways.

## 8.1 Active Maintenance and Degraded Operation Modes

When external factors degrade operational safety, the institution drops back safely through structured, predictable fallback conditions:

```
+---------------------------+
|     Standard Posture      | --> Continuous mutation tracking & high autonomy
+---------------------------+
             |
             v  Breach of Epistemic Debt Limit (De > Delta_max)
+---------------------------+
|      Triage Posture       | --> Halts agent generation; max verification focus
+---------------------------+
             |
             v  Sustained hardware failure or telemetry loss
+---------------------------+
|  Degraded Read-Only Hold  | --> Locks graph state; halts all automated mutations
+---------------------------+
```

1. **Degraded Read-Only Hold:** If structural verification dependencies lose grounding due to missing hardware sensors or broken data channels, the system drops into a read-only configuration hold. All automated mutation pipelines are suspended, while cryptographic query channels are preserved to allow manual investigation.
2. **Administrative Override Protocol:** Manual adjustments to core invariants or threshold constants ($\Delta_{\text{max}}$, $\epsilon$) require a signed, multi-party cryptographic payload matching the administrative identity keys recorded within the root configuration. This prevents single-agent exploitation from editing the rules of the system.

## 8.2 Security Architecture and Poisoning Defense

The system guards its verification processes against adversarial agents attempting to corrupt the graph:

* **Lineage Sanitization:** Every addition to $V^+$ must explicitly declare its full history within its metadata chunk $\mathbf{M}$. If an agent attempts to insert disconnected information that obscures its generation ancestry, the pipeline flags the item as un-audited, restricting its maturity parameter via the Provenance Ceiling ($\Psi(n) = 0$).
* **Automated Fuzzing Loops:** The system allocates dedicated testing agents to generate conflicting assertions targeting provisional nodes. If a node successfully rejects these synthetic conflict injections, its status is elevated via the Adversarial Multiplier ($A(n)$).

## 8.3 Decommissioning and End-of-Life (EOL)

When an institution reaches its targeted operational end-of-life or encounters irreversible environmental shifts that break its core axiomatic foundations, it executes a clean, structured shutdown sequence:

1. **Queue Quiescence:** The state machine blocks incoming entries to $\Pi_t$ and rejects new mutation bundles.
2. **Final Epistemic Baseline Capture:** The system consolidates active provisional nodes ($V_p$), appending an explicit, immutable termination block to the graph history to document its final verification state.
3. **Graph Freezing:** The system serializes the complete historic state path, stripping active runtime components and transforming the ledger into a read-only cryptographic archive.

## 8.4 Open Structural Gaps and Registries

> **Renamed 2026-07-28:** This tracker's local identifier was "GOV-008" until this pass — flagged 2026-07-26 as a collision with `Admin/Governance_Charter.md` and `Unknowns.md`'s registered GOV-008 (minimum agent quorum requirement for Genesis Phase exit), since this tracker was never cross-registered against the global GOV-* namespace when authored. Renamed to **CIR-001**, a CIR-scoped prefix now registered in `Admin/Forge_Audit_Kit.md`'s Governance Sidecar ID Reference alongside the file's other entries.

### Tracker Entry: CIR-001 — Physical Grounding Telemetry Mapping Interface

| Field | Value |
| :--- | :--- |
| ID | CIR-001 |
| Classification | Structural Gap (formerly Unlogged Unknown — tracked and ID'd as of the 2026-07-28 rename) |
| Description | The physical grounding gate metric $\Phi(n)$ relies on direct hardware feedback signals ($S(n)$ dimension). The exact configuration interface linking these variables to testing environments (such as `Tests/Leviathan_testing.md` or `Tests/Support_Raft.md`) remains unmapped. Without this interface, $\gamma_1$ (EF-0.8b) cannot be implemented in the harness, and the Physical Grounding Gate operates as a theoretical constraint rather than an enforced one. |
| Blocking | $\gamma_1$ harness implementation; Φ(n) operational enforcement; Section 7.4 Phase 2 predicate deployment |
| Resolution Requirement | Define the mapping schema and structural verification protocols before promoting this framework to Candidate Spec status. Cross-ref `Tests/Leviathan_testing.md`, `Tests/Support_Raft.md`, `Admin/Security_Protocols.md`. A candidate schema (v0, Draft, not ratified) is now proposed immediately below — see "CIR-001 Candidate Resolution." Remains Open until a first concrete Leviathan log → $S$ derivation is demonstrated against it. |
| Status | Open |
| First Logged | Not recorded — see resolution note below. Earliest circumstantial evidence in this file is the document's own v0.16 header date (2026-06-30, line 3), but that is this file's version date, not a confirmed origination date for this specific tracker; do not treat it as verified without independent confirmation. |
| First Cycle | 9 |

### CIR-001 Candidate Resolution: Minimal $S(n)$ Mapping Schema (Proposed, v0 — Not Ratified)

**Status: Draft proposal, source-checked against existing doctrine. Does not close CIR-001. Does not invent hardware, sensors, or test environments — maps only what already exists or is explicitly placeholder in the cited files.**

**Purpose & Scope.** $S(n)$ is the physical-grounding coordinate of a node's evidence vector $\mathbf{V}(n)$. Per the Coordinate Floor Constraint (§4.2) and the corrected $\Phi(n)$ definition (CIR-F03):

$$
S(n) \in [\varepsilon, 1], \qquad
\Phi(n) =
\begin{cases}
0 & \text{if } n \in V_{\text{phys}} \text{ and } S(n) \le \varepsilon \\
1 & \text{otherwise}
\end{cases}
$$

This schema answers three questions a Phase-2 harness must be able to answer for any physical claim: (1) what is the current $S(n)$ value, (2) how was it obtained, (3) is it still valid.

**Out of scope:** continuous real-time sensor fusion, multi-dimensional sensor vectors, production hardware interfaces, the Support_Raft sensor surface (still TBD/Placeholder), and any change to $M(n)$, $\Psi(n)$, or the rest of the algebra.

**Data Model (Minimal):**

| Field | Type | Range / Values | Required | Notes |
|-------|------|----------------|----------|-------|
| `S` | float | $[\varepsilon, 1]$ | Yes | The grounding coordinate itself |
| `source` | enum | `none` \| `leviathan_log` \| `support_raft_log` \| `manual_attestation` \| `other` | Yes | Provenance of the value |
| `authenticity` | enum | `unverified` \| `cryptographic` \| `multi_party` \| `poisoned_flagged` | Yes | How the value was authenticated |
| `freshness` | enum | `current` \| `stale` \| `unknown` | Yes | Relative to the claim's last mutation |
| `ε_override` | float \| null | $(\varepsilon_{\text{global}}, 1)$ or null | No | Only if a node-specific floor is later ratified; default = global $\varepsilon$ |
| `evidence_ref` | string | path or UID | Yes if $S > \varepsilon$ | Pointer to the log, test run, or attestation that justifies the value |
| `notes` | string | free text | No | Human-readable context |

**Default / zero-knowledge assignment:** if no `evidence_ref` exists, or `authenticity = unverified`, or `source = none`, then $S(n) \leftarrow \varepsilon$ — the only assignment that is always safe and already required by the Coordinate Floor Constraint.

**Mapping Rules (Leviathan-first — the only cited environment with usable doctrine today):**

| Leviathan concept (existing) | Maps to $S(n)$ | Condition | Authenticity path |
|------------------------------|----------------|-----------|-------------------|
| No physical test run recorded for the claim | $S = \varepsilon$ | Default | `unverified` |
| Test run exists, but telemetry was never cryptographically logged | $S = \varepsilon$ | Default | `unverified` |
| Cryptographically logged genuine telemetry (Section VII / IX) with no poisoned-injection flag | $S \in (\varepsilon, 1]$ | Value derived from logged contact / recovery / structural-health evidence | `cryptographic` |
| Poisoned-telemetry injection detected and flagged (`Tests/Leviathan_testing.md` ASM-005 / §VII) | $S = \varepsilon$ | Even if raw sensors reported contact | `poisoned_flagged` |
| Multi-unit swarm diversity score available and disagreement analysis performed (CF-002 protocol) | May raise $S$ within $(\varepsilon, 1]$ | Only if authenticity already `cryptographic` | `cryptographic` + diversity note |
| Manual human attestation of physical recovery / inspection | $S \in (\varepsilon, 1]$ | Explicitly recorded, dated, and signed | `multi_party` or `manual_attestation` |

**Support_Raft:** all sensor surfaces remain TBD/Placeholder. Until SR-006 / SR-007 (and the Leviathan unit physical envelope dependency) resolve, Support_Raft contributes only the default $S = \varepsilon$.

**Security_Protocols contribution:** used only for the authenticity column — cryptographic logging → `cryptographic`; multi-party hardware confirmation / air-gapped attestation → `multi_party`. Hull-breach / remote-wipe patterns inform the "stale" freshness rule but do not themselves raise $S$.

**Freshness Rule (Minimal):** a value is `current` only if the `evidence_ref` timestamp is after the most recent mutation of the claim, and no subsequent poisoned-injection or authenticity-revocation event has been logged against that `evidence_ref`. Otherwise → `stale` or `unknown` → force $S \leftarrow \varepsilon$.

**Harness Consumption Contract (Phase-2 stub, not yet implemented):**

```text
for each node n where n ∈ V_phys:
    record = lookup_S(n)          # from sidecar or external log index
    if record is None or record.authenticity == "unverified" or record.freshness != "current":
        S = ε
    else:
        S = record.S
    Φ = 0 if S ≤ ε else 1
    # then apply existing M(n) formula
```

No continuous sensor stream is required. The harness remains offline / batch, consistent with its current design.

**Explicit Open Items (do not silently close):**

| Item | Status | Why it remains open |
|------|--------|---------------------|
| Concrete numeric derivation of $S$ from raw Leviathan logs | Open | Leviathan defines doctrine, not a quantitative scoring function |
| Support_Raft sensor surface | Open | Still TBD/Placeholder |
| Global vs node-specific $\varepsilon$ | Open | Current CIR text uses a single institutional $\varepsilon$ |
| Automated freshness clock | Open | Requires a shared time source the harness can trust |
| Poisoned-telemetry isolation guarantee (`Tests/Leviathan_testing.md` ASM-005) | Open | Still an assumption, not yet demonstrated |

**Truth Basis of this schema:** Analogous (Leviathan sensor doctrine) + Internally Derived (existing $\Phi(n)$ / Coordinate Floor mathematics). No experimentally verified mapping exists yet.

**Next steps if this draft is accepted:** (1) fold a pointer to this schema into CIR-001's Resolution Requirement above; (2) leave CIR-001 Open until a first concrete Leviathan log → $S$ derivation is demonstrated; (3) only then stub the Phase-2 harness cell shown above into `Automation/AUDIT_HARNESS.py`.



