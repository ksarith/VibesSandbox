# Lazarus Forge — v0 Operational Flow

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

> ⚠️ **Operational Safety Advisory**
> This document governs decision logic that leads to irreversible
> actions. Reduction sits at R4 — the flow's highest-consequence
> boundary — once an item is shredded or milled, it cannot be
> recovered as a discrete object. Gate logic errors at any stage
> can accelerate material toward reduction prematurely.
>
> Approach gate decisions thoughtfully. When uncertain, the
> system is designed to hold — not to proceed. Refusal and
> deferral are first-class outputs at every gate. Human
> judgment overrides automation at any point. The cost of
> a missed recovery is permanent.

---

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Exploration                                                         |
| Body Stability   | Transitional                                                        |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | Admin/Verification_Gates.md                                      |
| Last Audit       | 2026-10-29 — Vibe (Repo Custodian, delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A): X3 mechanical citation retrofit (Architecture pass) — 3 bare colliding-prefix citations in operative body text qualified with their owning File.md per PKC-003 (Kit v1.30 Governance Sidecar ID Reference; per-ID grounding from the Unknowns active index). Citation-form-only; no content change; frozen history untouched; no gate advanced; Open Unknowns unchanged. Prior: 2026-10-20 — external Skeptic/Auditor sweep (Vibe) verified file size, counts and cross-references; Claude (human-directed) corrected the HP-001 contradiction in two places, annotated dead UNK references, fixed the FL-006 §1.3 pointer, renamed DS-001 to FL-DS-001, and logged retroactively the FL-006, FL-008–FL-012 and 2026-10-02 changes (this field had not moved since 2026-09-10 although the log and sidecars record changes through 2026-10-02); prior: 2026-09-10 — ChatGPT ran a full multi-phase audit (Phases 1-6: structural validation, scope validation, assumption extraction, internal coherence, cross-module consistency, evidence validation) under Auditor_Protocols.md v0.41; Claude verified every substantive claim against live source before acting. Six mechanical fixes applied directly (Lessons Learned heading restored over a pre-existing orphaned table, stale Gate Correspondence Oversight row corrected, FL-003 self-contradiction fixed, "Eight sequential decision gates" reworded, §1.3 bare filenames fully-qualified, illustrative example values labeled non-measured). Six new Unknowns registered (FL-008 through FL-013); FL-007 strengthened with cross-file evidence. One new finding beyond the audit itself: FL-001's Resolution Path cites a Gate_02_Triage.md worked example that doesn't exist (FL-009). One error caught in the audit's own output (EV-011 misattributed a quote's section). Prior: 2026-09-08/09 — fifteen resolution-log passes across two days: R0-R4 taxonomy (HP-001, propagated to Gate_03_Reduction.md), Oversight multi-exit formalization (HP-002), Flow Invariants §1.1 (HP-003), Gate D polarity rewrite (HP-004), boundary-case Examples 4-7 (HP-005 partial), cross-layer reconciliation spinning off FL-003/FL-004 (HP-006), Tooling_Inventory.md creation (HP-007), per-deployment wording + Deployment Localization Doctrine, Gate B Secondary Test + FL-005, Gate Decision Contracts §1.2 + explicit UNKNOWN transitions + re-entry contract (HP-008/009/015), terminal-state distinction (HP-014). Prior: 2026-08-08 |
| Auditor          | Vibe — Repo Custodian, 2026-10-29 X3 mechanical citation retrofit (Architecture pass; delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A); prior: Claude — Retrofit/Auditor (2026-10-20 corrections, human-directed, from an external Vibe sweep) |
| Open Unknowns    | 6 — corrected 2026-10-02 (was 7; FL-001–006 are Open/In Progress, FL-007–013 are all Resolved, giving 6, not 7) |
| Active Disputes  | 1                                                                   |
| Highest Risk     | Medium                                                              |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

---

## Scope Boundary

**This file DOES define:**
- Minimal viable operational logic of the Lazarus Forge v0
- Reference standard for shared vocabulary across the repository —
  terms defined here carry their meaning into all other documents
  unless explicitly noted otherwise. `Admin/Canonical_Terms.md`
  covers a separate, broader vocabulary layer; where the two
  overlap, this file is authoritative for operational routing
  semantics, and `Canonical_Terms.md` itself defers to this file
  on that point.
- v0 scope, inputs, and explicit non-goals
- Defined Terms for all shared operational vocabulary
- Ten sequential processing stages (Intake through Utilization),
  of which five are actual decision points — Decision Points A–D and
  Oversight State. Distinct from Operations/Gate_01 through
  Gate_07 (operational modules) and from Verification Gates 1-6
  (document audit/promotion gates) — corrected 2026-09-10
  (ChatGPT audit, P5-012/S2-007) from "Eight sequential decision
  gates," which conflated this file's own decision-gate count
  with the unrelated operational-module numbering
- Gate Correspondence table mapping triage outcomes to gates
- Outcome paths and reversibility notes for each path
- Fabrication priority order and want/need policy
- Feedback and learning doctrine for v0
- Primary KPI definition (value recovered per kWh consumed)
- Termination conditions for items exiting the system
- Oversight State logic and want/need policy
- Purification stage definition — governs FL-DS-001 terminology dispute
- Self-replication architecture or loop closure logic, as pointed
  to from `Operations/Gate_05_Separation_Thermal.md` (pending —
  see FL-003)

**This file DOES NOT define:**
- Detailed hardware specifications for any module
  (→ `Operations/Gate_04_Separation_Mechanical.md`,
  `Operations/Gate_05_Separation_Thermal.md`, etc.)
- Reduction module specification
  (→ `Operations/Gate_03_Reduction.md` — FL-002)
- Component triage station workflow detail
  (→ `Operations/Gate_02_Triage.md`)
- Energy accounting and power demand
  (→ `Operations/Energy.md`)
- Autonomous operation logic or AI trust architecture
  (→ `Architecture/Cognitive_Frameworks.md`,
  `Admin/Ethical_Constraints.md`)
- Version roadmap and exit conditions
  (→ `Admin/Trajectories.md`)
- Cross-module unknowns global index
  (→ `Unknowns.md`)
- Facility siting or area-of-operation requirements
  (→ `Architecture/Facilities.md`)
- Fabrication output specifications or wire qualification
  (→ `Architecture/Geck_forge_seed.md`, UNK-008 — ownership reassigned 2026-07-19)

---

## File Purpose

This document defines the minimal viable operational logic of the
Lazarus Forge and serves as the reference standard for shared
vocabulary across the entire repository. Terms defined or used
here carry their meaning into all other documents unless
explicitly noted otherwise. It is the intended governing document
for operational decisions and the authoritative source for
gate logic, outcome paths, and the want/need policy that
prevents both hoarding and premature destruction — but these
claims are aspirational at Exploration stage. Promotion to
Specification requires FL-001 resolution and full gate clearance
before the governing role is binding rather than directional.

The flow is intentionally conservative. Irreversibility is
delayed as long as possible. Human judgment is explicit at
every gate. Automation is optional, not assumed. The system
is designed to hold when uncertain — not to proceed.

This document is not a claim of full automation or a promise
of specific recovery rates. It is a falsifiable flow that
can be executed manually, semi-automatically, or automated
later. If this file disappeared, the repository would lose
its shared vocabulary standard and governing decision logic —
every module would be making gate decisions against different
definitions of the same terms.

---

## Assumptions

| ID      | Assumption | Basis | Confidence | Expiry Trigger |
|---------|------------|-------|------------|----------------|
| ASM-001 | Items entering the system have been safety-screened before gate logic applies — hazards, pressure, and charge assessed at Intake | Intake section — screening listed but prerequisites not defined | Medium | Intake safety screening formally specified |
| ASM-002 | Human operator is available and capable of overriding gate decisions at any point in the flow | Oversight State — override assumed available | Medium | Autonomous operation validated and human override formally optional |
| ASM-003 | The Forge's current tooling inventory is known, maintained, and available as a live reference for Decision Point B evaluation | Decision Point B — "within current tooling capability" requires known tooling state | Medium | Tooling inventory specification and maintenance doctrine assigned to an owning file |
| ASM-004 | A Component Library exists and is maintained to receive and track Decision Point A outputs | Outcome Paths — Component Library assumed to exist as a functional system | Medium | Component Library specification assigned to an owning file |
| ASM-005 | Feedback from operational runs reaches classification rules in a timely enough cycle to improve gate decisions | Section 7 — learning assumed to close the loop | Low | Learning cycle time defined and validated against operational cadence |
| ASM-006 | Value in the primary KPI is eventually definable in measurable units — directional validity assumed until then | KPI section — explicitly Placeholder | Low | KPI definition resolved per Operations/Energy.md and operational baseline |
| ASM-007 | Gate logic applies to discrete items, not fixed assemblies. Assemblies may be disassembled — each resulting component re-enters the gate sequence independently at Decision Point A. Disassembly is itself a Decision Point C or Decision Point D decision on the assembly, not a bypass of sequential order | Gate logic architecture; fan/motor worked example | Medium | Parallel or non-sequential gate processing validated as superior at scale |

*ASM-005 and ASM-006 are Low confidence — both depend on operational
data that does not yet exist. ASM-003 and ASM-004 identify ownerless
dependencies that should be assigned before first operational run.
ASM-007 clarifies the scope of sequential gate logic and partially
informs FL-001 resolution.*

---

## v0 Scope and Assumptions

**Input (v0):**
- Small appliances
- Tools
- Mechanical/electromechanical assemblies
- Mixed metals with attached components

**Explicit Non-Goals (v0):**
- Fully autonomous operation
- Zero external inputs
- Net-positive energy claims without measurement
- Perfect material purity

---

## Defined Terms

**"Gate" / Decision Point / Oversight State (updated 2026-09-14 rename pass)** — Four distinct senses remain, two of which are now renamed in this file for clarity:
(1) operational modules **Gate_01–Gate_07** (unchanged),
(2) **Decision Points A–D** (formerly "Decision Gates A–D" / "Gate A–D"),
(3) **Oversight State** (formerly "Human/AI Oversight Gate"),
(4) **Verification Gates 1–6** (unchanged; document audit/promotion, `Admin/Verification_Gates.md`).
Prefer qualified forms where ambiguity is possible (e.g. `Operations/Gate_03_Reduction.md`, Decision Point D, Verification Gate 3). See also `Admin/Canonical_Terms.md`'s
"Disambiguation: Uses of 'Gate'" section for the repository-wide
canonical version of this entry.

**Functional** — Performs a useful role in a specific application
context. An item is functional at Decision Point A if it works in its
original application. An item is functional at Decision Point C if it
can work in a reduced application.

**Equivalent function (Decision Point A)** — Performing the same task as
the original in the same application context. If function is
only achievable in a different or reduced application, the item
does not pass Decision Point A — it routes to Decision Point C.

**Within tooling capability (Decision Point B)** — Evaluated against the
Forge's current tooling inventory, not projected future
capability. Requires a known, maintained tooling inventory —
see ASM-003.

**Contamination level** — Type and degree of contamination
sufficient to affect downstream processing or operator safety.
Relevant categories at v0:

- Chemical — heavy metals (lead, cadmium, mercury), solvents,
  coatings, flux residues. Present in consumer products often
  without visible indication. Cross-reference `Operations/Air_Scrubber.md`.
- Biological/organic — oils, fluids, biological matter,
  organic coatings that off-gas under heat or rotation
- Embedded materials — fasteners, inserts, or components
  requiring separation before reduction or purification
- Energetic — batteries, capacitors, compressed gas vessels.
  Must be identified and discharged at Intake before any
  gate logic applies
- Physical/radiological — radiation-emitting materials.
  Rare but unacceptable in any processing stream. Triggers
  immediate Oversight State escalation (Oversight
  exit: **Escalate**)

*This list is not exhaustive. Unforeseen contamination
categories are expected over operational lifetime. When
a new contamination type is encountered that does not fit
existing categories, it routes to the Oversight State
and a new category is logged (Oversight exit:
**Reclassify**). The system is designed
to learn from what it cannot yet classify.*

**Inert waste** — Material with no remaining functional,
structural, or material recovery value, sorted for
conventional disposal.

**Want vs. Need (policy term)** — A want becomes a need when
its absence limits a higher-priority function. This distinction
governs the Oversight State and Fabrication priority
order.

**Irreversibility Levels** — Added 2026-09-08 to replace a flat
irreversible/not-irreversible split with graded consequence.
This taxonomy governs Forge_flow.md's own reversibility notes
below, and was applied to Operations/Gate_03_Reduction.md's R4
safety-doctrine language on 2026-09-08 (HP-001, Closed — see that
file's Resolution Log). Extension to any other file is a separate
decision; no open Held Proposal covers it.

| Level | Meaning |
|---|---|
| R0 | Fully reversible — no material consequence |
| R1 | Reversible with labor or reassembly |
| R2 | Recoverable but altered (e.g. calibration/tolerance drift) |
| R3 | Discrete-object identity lost (disassembly into components) |
| R4 | Material transformation — Reduction and beyond |

*R4 remains the flow's highest-consequence boundary and the*
*point past which Oversight cannot recover a discrete item —*
*that governing role is unchanged by this taxonomy, only made*
*gradable below it.*

---

## Gate Correspondence

Triage station outcomes map to these gates. See
`Operations/Gate_02_Triage.md` for the full mapping table.

| Gate | Test | Routes to |
|---|---|---|
| A | Original function in original context? | Component Library |
| B | Repairable within current tooling? | Repair & Learn |
| C | Useful in reduced/different application? | Repurpose |
| D | Is Reduction the correct residual path? | Reduction |
| Oversight | Any credible active need? | Return to Flow / Hold / Reclassify / Escalate / Terminate — see Oversight State section and §1.2 for the full contract (row corrected 2026-09-10, ChatGPT audit IC-004/P5-013 — previously read "Hold or Reduction," stale since HP-002 formalized five exits) |

---

## Flow State / Transition Model

*Added 2026-09-08. This section is a structural consolidation, not new*
*doctrine — every state and transition below is already established*
*elsewhere in this document (Gate Correspondence, ASM-007, the Outcome*
*Paths, and the Oversight State section). It exists so the flow*
*can be read as a state-transition system, not only as a linear*
*checklist.*

**States:** Intake → Classification → Decision Point A → Decision Point B → Decision Point C →
Decision Point D → Oversight State → {Component Library, Repair & Learn,
Repurpose, Reduction, Purification} → Fabrication → Utilization →
Feedback

**Primary sequence:** Intake → Classification → Decision Point A → Decision Point B →
Decision Point C → Decision Point D → Oversight (on Decision Point D failure) → an Outcome Path →
Fabrication → Utilization → Feedback

**Lifecycle loop (added 2026-09-09, HP-013 — framing only, no new
routing rule).** The primary sequence above reads as a line because
it describes one item's single pass through the flow. The Forge
itself does not terminate there. Fabrication's own text already
states it is "not terminal" (§5); what that means concretely is that
fabricated items enter Utilization, and — per
`Operations/Gate_02_Triage.md`'s existing re-triage doctrine —
"components that fail in Forge service re-enter triage at Station 0"
just as any other salvaged item would. The actual lifecycle is a
loop, not a line:

Salvage → [this flow's gates] → Components / Material → Fabrication
→ New Item → Utilization → (eventual failure) → Future Salvage → ...

Feedback (§7) closes the *doctrine* loop — it updates classification
rules, repair heuristics, tolerance thresholds, and tooling
priorities for future decisions. Re-triage closes the *material*
loop — it's what actually brings a specific fabricated item's
components back through Decision Point A once that item eventually fails.
These are two different mechanisms that together make the whole
system circular rather than terminating at Fabrication or
Utilization. Neither mechanism is new here; this note only names the
loop they jointly form.

**Per-gate transitions, UNKNOWN made explicit (added 2026-09-08,
HP-009 partial — this makes FI-2 mechanically visible at every gate
rather than relying on the reader to apply the invariant; gate body
text and decision logic are unchanged, see 1.2 Decision Point
Contracts):**
- Decision Point A — PASS → Component Library · FAIL → Decision Point B · UNKNOWN → Hold
- Decision Point B — PASS → Repair & Learn · FAIL → Decision Point C · UNKNOWN → Hold
  (or Primary defaults to FAIL under the stale-tooling degraded rule)
- Decision Point C — PASS → Repurpose · FAIL → Decision Point D · UNKNOWN → Hold
- Decision Point D — PASS → Reduction · FAIL (alt. pathway may exist) →
  Oversight · UNKNOWN → Hold
- Oversight — see the five named exits below; default under
  uncertainty is Hold

**Re-entry transitions (per ASM-007):**
- Disassembly at Decision Point C or Decision Point D spawns independent components, each
  of which re-enters at **Decision Point A** — not a bypass of gate order, a
  restart of it per component.

**Re-entry contract (added 2026-09-08, HP-015).** ASM-007 and FI-3
already establish that components re-enter at Decision Point A; this makes
what "re-enter" requires explicit:
1. A new item identity is assigned to the component.
2. Parent (source assembly) provenance is retained.
3. The material/component relationship to the parent is recorded.
4. Prior gate history — of the parent assembly — is retained for
   audit, but is historical record only.
5. **The parent assembly's prior assessment does not automatically
   carry forward.** A component extracted from a failed assembly
   does not inherit the assembly's failure state.
6. A fresh Decision Point A assessment is performed on the component itself,
   using its own function evidence — not the parent's.
Point 5 is the one this document previously implied but never
stated outright; a motor pulled from a non-functional fan is
evaluated as a motor, not as "part of a failed fan."

**Exception transitions (per Degraded Operation & Failure Modes):**
- Jammed triage → Unknown Bulk hold (not Reduction)
- Sensor drift → tightened thresholds / increased Unknown Bulk routing
- Mid-process contamination discovery → stop, escalate to Oversight
- Stale tooling inventory → Decision Point B defaults to NO (routes to Decision Point C)
- Operator unavailable → hold pending Oversight review
- Component Library full/unmaintained → treated as Decision Point C items
- Pattern-triggered escalation (e.g., five consecutive unresolved
  unknowns at Intake per `Operations/Gate_01_Intake.md`) triggers a
  process-level Oversight review; affected items remain individually
  held until the process exception is resolved (added 2026-09-14,
  FL-010 — this is one Oversight mechanism reached two ways,
  item-level and process-level, not two mechanisms)

**Oversight State exits (formalized 2026-09-08, HP-002 — see the
Oversight State section for the full mapping):**
- Return to Flow — exception resolved, re-enters normal routing
- Hold — deferred with a defined review point
- Reclassify — new category logged, re-enters via that classification
- Escalate — exceeds this flow's own decision authority
- Terminate — no genuine need confirmed, Reduction proceeds

**Feedback loop:** Utilization → Feedback targets Classification
rules, repair heuristics, tolerance thresholds, and tooling
priorities — i.e., feedback alters future routing at Classification
and Decision Point B, not a literal re-entry of the same item.

**Terminal states (refined 2026-09-08, HP-014):** This document
distinguishes two senses of "terminal" that the Outcome Paths section
below previously left implicit:
- **Terminal for current processing** — exits this pass through the
  flow, but remains eligible for future re-entry. Covers active use,
  stored stock (Oversight Hold), and the Component Library. Nothing
  about these states forecloses the item or its material recovering
  further value later.
- **Terminal for recovery** — no further recovery pathway exists
  under current Forge capability. Covers only inert waste, the state
  reached after Reduction (R4) and, where applicable, Purification.
This resolves the prior tension between the Outcome Paths section
(which describes Component Library and Repurpose as feeding
Fabrication, i.e. not really endpoints) and this line's older,
flatter "active use, stored stock, inert waste" list, which did not
distinguish the two senses.

---

## 1.1 Flow Invariants
<!-- STATUS: Candidate doctrine — consolidates existing scattered
principles into testable statements; not a new mechanism layer.
Pattern matches Architecture/Forge_Net.md §1.1 Network Invariants. -->

These invariants are **constraints on any future mechanism**, not
a second copy of the sections that already state them. A proposed
gate-logic change or new outcome path that violates an invariant is
out of scope for this architecture unless the invariant is amended
through ordinary review. Each statement points at the existing home
of the rule; do not invent parallel rules here.

| ID | Invariant | Mechanism home |
|----|-----------|-----------------|
| **FI-1** | **The KPI does not govern.** The KPI measures what the system does; the gates govern what the system should do. Irreversibility doctrine overrides efficiency optimization at all times. | v0 Key Performance Indicator — KPI subordination note |
| **FI-2** | **Uncertainty defaults to Hold. An explicitly defined degraded-mode exception may permit a non-R4 transition, but that transition does not itself constitute authorization for R4 action. Any later R4 decision requires its own applicable evidence and decision contract.** The system is designed to absorb uncertainty, not resolve it through Reduction or any other R4 action except through that action's own proper authorization. | Degraded Operation & Failure Modes — standing rule (narrowed 2026-09-14, FL-008 — see Decision Point B's Secondary Test note for the parallel statement of this same principle) |
| **FI-3** | **Gate logic applies to discrete items only.** No fixed assembly is gated as a permanent unit; disassembly is itself a Decision Point C or Decision Point D decision, and every resulting component re-enters at Decision Point A independently. | ASM-007; Flow State/Transition Model re-entry transitions |
| **FI-4** | **Reduction is the residual path, not the default path.** R4 is the flow's highest-consequence boundary — reached only when every higher-value path (Gates A-C) has failed. | Operational Safety Advisory; Reduction outcome path |

HP-003 (Held Proposals) proposed elevating the KPI sentence alone;
adopted 2026-09-08 as FI-1 within this broader four-invariant table
rather than in isolation, following Forge_Net.md's own precedent of
consolidating several existing scattered principles at once rather
than naming just one.

---

## 1.2 Decision Point Contracts

*Added 2026-09-08 (HP-008). Formalization of existing gate logic*
*only (Decision Points A–D + Oversight, Gate Correspondence, Defined Terms,*
*FI-2, ASM-003/007, and the provisional notes on Decision Point B). No new*
*decision rules or outcome paths are introduced. Uncertainty always*
*defaults to Hold (FI-2) and is never interpreted as a failed gate.*

| Gate | Required Inputs | Decision Question | Permitted Outputs | Uncertainty Output |
|------|-----------------|-------------------|-------------------|--------------------|
| **A** | Function evidence in the original (or equivalent) application context | Does the item still perform its original function, or an equivalent function, in the same application context? | **YES** → Component Library (R0)<br>**NO** → Decision Point B | Insufficient function evidence → **Hold**. Never treat "unknown function" as NO. |
| **B** | Failure localization + accessibility evidence + live Tooling Inventory state (ASM-003 / FL-004) | **Primary (all three required):** Is the failure localized **and** accessible **and** within current tooling capability?<br>**Secondary (only if Primary passes):** Is estimated repair effort justified by recovered functional value **or** learning value **or** measured scarcity/strategic value? | **Primary FAIL** (any condition) → Decision Point C<br>**Primary PASS + Secondary YES** → Repair & Learn (R2)<br>**Primary PASS + Secondary NO** → Decision Point C | Missing Primary input, or Secondary judgment that cannot be justified with logged rationale → **Hold**. Under the explicit stale-tooling degraded-operation rule, Primary defaults to FAIL (routes to Decision Point C). Secondary Test is provisional, qualitative, and must be logged (FL-005); it never routes directly to Reduction. |
| **C** | Application / use evidence for a different or reduced function | Can the item (or a portion of it) serve a useful function in a different or reduced application? | **YES** → Repurpose as Lower-Precision Component<br>**NO** → Decision Point D<br>(Disassembly of an assembly is permitted; each resulting component re-enters at Decision Point A per ASM-007 / FI-3) | Insufficient evidence of any useful reduced function → **Hold**. Indeterminate material identity is **not** a Decision Point C failure. |
| **D** | Material integrity + recovery-pathway evidence under current Forge capability | Is Reduction the correct residual path for material recovery (all higher-value paths exhausted, and size-reduction followed by Separation / Purification is the only remaining viable route)? | **YES** → Reduction (R4)<br>**NO** (alternative recovery path may still exist, or recovery is genuinely impossible / prohibited) → Oversight State | Insufficient material or recovery evidence → **Hold**. True edge cases (hazard, conflicting evidence, genuine impossibility) → Oversight, never forced Reduction. |
| **Oversight** | Exception evidence (mid-process contamination, radiological/hazard category, operator unavailability, Decision Point D want/need evaluation, unforeseen contamination category, etc.) | Does a credible active need exist, and is the exception within this flow's decision authority? | **Return to Flow**<br>**Hold** (with defined review point)<br>**Reclassify**<br>**Escalate**<br>**Terminate** (→ Reduction authorized) | Default under uncertainty is **Hold**. Escalate only when authority is exceeded. Terminate authorizes Reduction independently of Decision Point D YES (Reading A, adopted 2026-09-12); execution still requires Gate_03 readiness checks. |

*Notes*
- Decision Point B Secondary Test remains Exploration-grade and unvalidated
  (FL-005); every decision must carry operator rationale until
  operational data exists.
- "Indeterminate evidence MUST NOT be interpreted as a failed gate"
  is the operative reading of FI-2 for all rows.
- This table does not alter the sequential order, the five Oversight
  exits, the R0-R4 taxonomy, or any Outcome Path.
- **Terminate authorization (2026-09-12):** Routing ≠ authorization ≠
  execution readiness. Decision Point D YES and Oversight Terminate are both
  valid independent authorizations for Reduction; Gate_03 owns
  execution readiness. See Oversight section for bounded discretion.

---

## 1.3 Transition Ownership

*Added 2026-09-08 (HP-011). Scoped to the four main gates + Oversight*
*per the held-proposal sequencing. Distinguishes who owns what for*
*each transition: this file owns the routing decision; other files*
*own the procedure that produces the evidence a decision consumes,*
*or the procedure a routing outcome triggers downstream. Verified*
*against existing cross-references rather than newly assigned —*
*two real gaps found and logged rather than guessed at (below).*

| Transition | Flow owns (routing decision) | Operations owns (evidence-gathering / downstream procedure) | Architecture/Admin owns (invariant or authority) |
|------------|-------------------------------|----------------------------------------------------------------|----------------------------------------------------|
| Decision Point A | This file — function test, PASS/FAIL/UNKNOWN routing | `Operations/Gate_02_Triage.md` — triage station assessment producing function evidence (Gate Correspondence) | — |
| Decision Point B | This file — Primary/Secondary test, routing | `Operations/Gate_02_Triage.md` — failure localization/accessibility evidence; `Operations/Tooling_Inventory.md` — live tooling-capability state (this file's ASM-003 / FL-004, not that file's own ASM-003) | ASM-003 (this file) — the tooling-known assumption itself |
| Decision Point C | This file — reduced-application test, routing; disassembly decision | `Operations/Gate_02_Triage.md` — reduced-application evidence | ASM-007/FI-3 (this file) — re-entry contract governs what happens after |
| Decision Point D | This file — residual-path test, routing | `Operations/Gate_02_Triage.md` — material/recovery evidence gathering for the decision itself; `Operations/Gate_03_Reduction.md` — the Reduction procedure once Decision Point D routes YES | FL-002 (this file) — Reduction↔Gate_04 output envelope cross-validation, still pending |
| Oversight | This file — five-exit resolution, want/need criteria | **`Operations/Exception_Evidence.md`** — evidence-**control** specification and index for episodic exception packages (from Gate_01/02/other escalation) and standing-reference **pointers** (tool availability → `Tooling_Inventory.md`; scarcity/dependency/failure-rates → deployment-local records). Upstream gates deposit packets; they do not own the Oversight evidence portfolio. Operational maintainer pending. Does not own routing or Escalate authority — that is half B (below). *(FL-006 half A — structural owner named 2026-09-18; population and maintenance still open; FL-006 remains Open.)* | **Authority half resolved 2026-09-14 (FL-006):** until an Admin-owned authority structure is explicitly defined, Escalate is a Hold-safe transition requiring designated human/oversight judgment under the existing Human Escalation Protocol (`Admin/Ethical_Constraints.md` EC-003 — its Recipient and Logging rows already are the case-record mechanism this needs; no new structure invented). Ethical_Constraints.md remains the ethical-constraint source, not a case-specific authority registry. **Re-verification note (2026-09-14):** EC-003 (`Admin/Ethical_Constraints.md`)'s Recipient row identifies the recipient as whoever is "currently on record" for the unit/site, but the mechanism that establishes and authenticates who is on record is a separate, still-open Charter-level gap (`Admin/Governance_Charter.md`'s Human Override Doctrine: "Override authenticity validation mechanisms remain unresolved (GOV-006 (`Admin/Governance_Charter.md`)) and must not be implicitly assumed"). This resolution correctly describes the escalation *procedure*; it does not resolve, and should not be read as resolving, the underlying identity-authentication question — that remains GOV-006 (`Admin/Governance_Charter.md`)'s open scope. **Evidence-ownership half remains Open — see FL-006.** |

Decision Point D's row is the subtlest: `Operations/Gate_02_Triage.md` gathers the
evidence Decision Point D's test consumes; `Operations/Gate_03_Reduction.md` owns what
happens physically once that test routes to Reduction. These are
different responsibilities that the pre-existing cross-references
already kept separate — this table only makes the separation
visible.

**Embedded Value Preservation (added 2026-09-14, FL-011):**
`Operations/Gate_02_Triage.md` Principle 9 defines a procedure applied
after a unit has already failed triage and before full Reduction —
separable high-value sub-components are extracted and preserved
intact first. This is an Operations execution-stage preservation
requirement, applied within the "material/recovery evidence
gathering" cell above; it is not an additional Gate-D decision
predicate, and this table's Decision Point D row remains complete without
listing it as a required input.

---

## 1. Intake

**Purpose:** Introduce salvage items into the system with
minimal preprocessing.

**Actions:**
- Visual inspection
- Basic safety screening (hazards, pressure, charge)
- Energetic materials — batteries, capacitors, compressed
  gas — must be identified and discharged before proceeding
- Tagging (manual or digital)

**Outputs:** Item enters Classification

---

## 2. Classification & Triage

**Purpose:** Determine the highest-value path before
irreversible action.

**Classification Attributes (v0):**
- Mechanical integrity
- Electrical continuity
- Contamination level (see Defined Terms)
- Known failure modes

Classification may be **overridden by human operator**.

---

## 3. Decision Points (Ordered, Mandatory)

*Gate logic applies to discrete items, not fixed assemblies.
Assemblies may be disassembled at Decision Point C or Decision Point D — each
resulting component re-enters the gate sequence independently
at Decision Point A. Disassembly is a Decision Point C decision on the assembly
as a whole, not a bypass of sequential gate order. See ASM-007.*

### Decision Point A — Still Functional?
**Test:** Performs original function, or equivalent function
in the same application context
**If YES →** Component Library
**If NO →** Decision Point B

### Decision Point B — Repairable?

> ⚠️ **Provisional — Exploration-grade, unvalidated against real
> operation.** Unlike this file's other 2026-09-08 changes, this one
> is *new logic*, not a rename or consolidation of existing
> behavior. Before this addition, any item passing the three
> conditions below went to Repair & Learn — full stop. Now, some of
> those same items will route to Decision Point C instead. That is a genuine
> behavior change, and it has not been tested against a single real
> item. Treat every Secondary Test outcome as suspect until the
> first operational cycle either confirms or contradicts it.

**Primary Test (all three required):**
- Failure is localized
- Failure is accessible
- Repair is within current tooling capability (see ASM-003 and the
  live Tooling Inventory — FL-004, not yet populated)

**If any primary condition fails →** Decision Point C

**Secondary Test (only if primary passes):**
Is the estimated repair effort justified by at least one of:
- Recovered functional value (item returns to Component Library or
  active use)
- Learning value (failure mode is novel or high-frequency and the
  repair will improve future heuristics)
- Scarcity or strategic value (measured, not assumed)

**If YES →** Repair & Learn
**If NO →** Decision Point C (technically possible but not justified)

*At Exploration stage the secondary test is qualitative and
operator-judged — there is no scoring formula, no effort threshold
in minutes or hours, and no calibration data. Every secondary-test
decision must be logged with the operator's rationale, both to
build the missing data and so a future audit can catch systematic
bias (e.g. one operator's threshold differing sharply from
another's). Before Specification the secondary test must become
testable (effort bands, measured scarcity thresholds, or an
equivalent simple score) — until it is, FL-001 cannot claim Decision Point B
determinism regardless of how clean this wording reads. The
secondary test never routes an item directly to Reduction; Decision Point C
remains the next sequential step, so the irreversibility doctrine is
unaffected even if this heuristic proves wrong in practice (this is
the same principle FI-2 states as the standing rule — see §1.1). See
also Queue Economics in Operations/Gate_02_Triage.md for
prioritization inside the Repair & Learn queue.*

### Decision Point C — Graceful Downgrade Possible?
**Test:** Can the item serve a useful function in a different
or reduced application?
**If YES →** Repurpose as Lower-Precision Component
**If NO →** Decision Point D

*Note: Decision Point C tests functional downgrade potential. Decision Point D
tests material integrity. These are distinct tests.
Assemblies that cannot function as a whole may be disassembled
here — each component re-enters at Decision Point A independently.*

### Decision Point D — Material Recovery Viability
**Test:** Is Reduction the correct residual path for material recovery
under current Forge capability?
(i.e., all functional, repair, and repurpose paths have been exhausted,
and the only remaining viable recovery route is size-reduction followed
by Separation / Purification.)
**If YES →** Reduction
**If NO (a non-Reduction recovery path may still exist, or recovery is
genuinely impossible / prohibited) →** Oversight State

*Rewritten 2026-09-08 to resolve the polarity ambiguity flagged in
HP-004. The prior compound test mixed functional exhaustion with a
negative claim about Purification recoverability, creating a circular
reading (Reduction both "no pathway remains" and the necessary first
step of the primary pathway). The new positive framing matches actual
doctrine: Reduction is the residual R4 path that feeds Separation /
Purification. Oversight remains the correct exit for true edge cases.
Renamed from "Truly Exhausted?" to "Material Recovery Viability"
earlier the same day for testability — that rename is unaffected.*

### Oversight State — Exception-Resolution State

*Reframed 2026-09-08 (HP-002). This section formalizes exit states*
*that were already scattered across this document's contamination,*
*degraded-operation, and Decision Point D logic — no routing behavior below*
*is new. Each exit cites where its behavior already existed prior*
*to this reframe.*

The Oversight State is entered from multiple triggers, not only
Decision Point D failure: contamination discovered mid-process, radiological
or other unforeseen hazard categories, operator unavailability,
and Decision Point D's want/need evaluation. It resolves to one of five
named exits:

- **Return to Flow** — the exception is resolved and the item
  re-enters normal gate routing (e.g. sensor drift corrected and
  classification resumes; see Degraded Operation)
- **Hold** — deferred pending a future condition, with a defined
  review point (genuine need confirmed at Decision Point D; operator
  unavailable pending return; contamination pending
  characterization — see Degraded Operation)
- **Reclassify** — a new category is logged and the item re-enters
  via that classification (unforeseen contamination category — see
  Contamination Categories)
- **Escalate** — the decision exceeds this flow's own authority
  (radiological or other hazard requiring external protocol — see
  Contamination Categories)
- **Terminate** — no genuine need confirmed; Reduction is
  **authorized** and proceeds (Decision Point D want/need evaluation,
  below). Under Reading A (adopted 2026-09-12), Terminate is an
  independent authorization path for R4, parallel to Decision Point D YES —
  not merely a timing release of a prior Decision Point D determination.

This gate prevents both hoarding and premature destruction.

**Routing ≠ authorization ≠ execution readiness (adopted 2026-09-12):**
Three distinct concepts must not be collapsed:
1. **Routing** — the item belongs on the Reduction pathway.
2. **Authorization** — Reduction is authorized to begin.
3. **Execution readiness** — physical prerequisites are satisfied
   (owned by `Operations/Gate_03_Reduction.md`: Air Scrubber
   verified, human present, no energetics, no active contamination).

Decision Point D YES is one valid authorization for Reduction. Oversight
Terminate is a second, independent authorization when no genuine
need is confirmed. Neither decision itself executes Reduction;
Gate_03 still enforces execution readiness. This reading confirms
Gate_03's existing dual entry corridor ("failed A–D, or explicitly
routed by Oversight") rather than narrowing it.

**Bounded discretion (ideological flexibility):**
Oversight retains bounded discretion to authorize Reduction in
additional exception circumstances not fully anticipated by the
current criteria, provided the decision is logged with rationale,
remains consistent with the want/need policy and
`Admin/Ethical_Constraints.md`, and does not bypass Gate_03's
execution-readiness checks. Such uses are expected to be rare;
repeated or patterned exceptions are themselves grounds for review
of the criteria. No exhaustive exception catalogue is maintained.

**Decision Point D want/need evaluation (Hold vs. Terminate exits):**
Review items that failed Decision Points A–D but where reduction feels
premature. Evaluate against active needs only — not
hypothetical future uses. Apply the want/need policy
(see Defined Terms).

- If a genuine need exists: **Hold** — assign with a defined review date
- If no genuine need exists: **Terminate** — Reduction is authorized
  and proceeds (independent authorization path; see above)

**Minimum criteria for "genuine need" (Exploration-level
heuristics — must become testable before Specification):**

A need is credible if at least one of the following applies:
- Linked to an active fabrication queue item
- Addresses a current tooling deficiency with no available
  substitute
- Replacement lead-time exceeds operational tolerance
- Component scarcity is measured, not assumed
- Failure-rate evidence suggests imminent need
- Dependency chain importance is documented

A want is not a need if:
- The justification is speculative future use
- No active queue item depends on it
- A functional substitute already exists
- The retention decision is driven by emotional value
  rather than operational necessity

*These criteria are heuristic at Exploration stage.
Operator judgment remains valid. The purpose is to make
the judgment auditable, not to remove it.*

---

## 4. Outcome Paths

### Component Library
- Catalog reusable parts
- Track provenance and test results
- Feeds Fabrication directly
- Requires maintained Component Library — see ASM-004
- *Reversibility: R0 — components remain individually recoverable*
- *Terminal for current processing, not for recovery — eligible for*
  *re-entry via Fabrication or future assessment (HP-014).*

### Repair & Learn
- Attempt repair
- Log failure mode and fix
- Update heuristics
- Outputs to Component Library or Repurpose
- *Reversibility: R2 — disassembly may affect calibration or
  tolerances — log pre-repair state*

### Repurpose (Lower Precision)
- Assign to reduced-spec use cases
- Examples: jigs, fixtures, structural members
- Feeds Fabrication
- *Terminal for current processing, not for recovery — feeds*
  *Fabrication rather than ending the item's usable life (HP-014).*

### Reduction
**R4 — point of no return for the item as a discrete object**
- Shredding, cutting, or milling
- Size reduction only (no melting yet)
- Reduction module specification owned by
  Operations/Gate_03_Reduction.md — see FL-002 (output-envelope
  cross-validation; drift logged as GR-009 / MG-009)
- *Reversibility: R4 — the flow's highest-consequence boundary.*
  *Operations/Gate_03_Reduction.md's safety doctrine (that file's GR-005, ASM-001,*
  *ASM-006) was aligned to this R4 language on 2026-09-08; see HP-001*
  *(Closed) in Held Proposals and that file's Resolution Log.*
- *Terminal for recovery in the sense that matters most — R4 is the*
  *point past which the item cannot be recovered as a discrete*
  *object. The material itself continues to Separation/Purification*
  *and only reaches the actual "inert waste" terminal-for-recovery*
  *state afterward, once nothing further is extractable (HP-014).*

**Operations/Gate_03_Reduction.md exists and carries constraints-first
doctrine (contamination shutdown, prohibited inputs, output envelope,
dust handling, emergency shutdown).** Its output envelope has not yet
been cross-validated against the provisional feedstock envelope in
Operations/Gate_04_Separation_Mechanical.md Inputs section — that
cross-validation is FL-002's remaining scope. Until it closes:
- Do not assume feedstock homogeneity after reduction
- Do not assume automated reliability of any reduction method
- Do not assume dust, fines, or contamination are handled
  without explicit doctrine
- Contamination discovered during reduction triggers
  immediate stop and Oversight State escalation
- Emergency shutdown leaves material in whatever state
  it is in — no assumption of safe intermediate states
- The provisional feedstock envelope in
  Operations/Gate_04_Separation_Mechanical.md Inputs section remains
  the best available downstream constraint until
  Operations/Gate_03_Reduction.md's output envelope is cross-validated
  against it

### Purification
- Spin Chamber or any mechanism achieving comparable
  separation output — including the Material Separation
  Gate as upstream mechanical diversion
- Pass / fail logic
- Fallback to powder or bulk stock if needed
- *Stage definition governs FL-DS-001 terminology dispute —
  see Active Disputes and Auditor Notes*
- *Equivalence criteria defined in
  `Operations/Gate_05_Separation_Thermal.md`*

---

## 5. Fabrication / Assembly

**Inputs:** Salvaged components, purified stock,
repurposed parts

**Outputs:** Tools, fixtures, replacement components,
infrastructure for future Forge growth

Fabrication is **not terminal**. See the Flow State/Transition
Model's Lifecycle loop note — fabricated items eventually re-enter
this flow's gates via `Operations/Gate_02_Triage.md`'s existing
re-triage doctrine, closing the loop rather than ending at Utilization.

Priority order:
1. Tools or components the Forge currently lacks
2. Infrastructure that expands Forge capability
3. Output for external use or exchange

Priority is evaluated using the want/need policy
(see Defined Terms).

---

## 6. Utilization

**Purpose:** Test real-world performance.

**Metrics Captured:** Runtime, failure modes, load
tolerance, maintenance frequency

---

## 7. Feedback & Learning

**Feedback Targets:** Classification rules, repair
heuristics, tolerance thresholds, tooling priorities

**Learning Mode (v0):** Human-readable logs, simple
rule updates, no ML required

---

## v0 Key Performance Indicator (KPI)

**Primary KPI:** Value recovered per kWh consumed

If this metric is not competitive at small scale,
scaling is invalid.

*KPI definition is Placeholder pending: (a) definition
of "value" in measurable units; (b) accounting method
for different recovery paths; (c) demand baseline from
`Operations/Energy.md`. See this file's ASM-006.*

**KPI subordination note:**
The KPI is a efficiency metric, not a governing principle.
It is subordinate to irreversibility doctrine at all times.
A system optimizing only this metric may prematurely reduce
difficult repairs, reject rare low-energy components, or
destroy high-complexity salvage to preserve throughput
efficiency. These outcomes violate the core recovery
philosophy even if they improve the KPI score.

Irreversibility doctrine overrides efficiency optimization.
Long-tail scarcity and strategic component value may justify
low immediate energy efficiency. The KPI measures what the
system does — the gates govern what the system should do.

---

## Termination Conditions

An item exits the system only when:
- It is in active use
- It is stored as stock
- It is reduced to inert waste after all prior gates
  fail (see Defined Terms)

---

## Degraded Operation & Failure Modes

The gate system does not assume ideal conditions.
The following failure modes are expected over operational
lifetime and must not cause silent routing errors:

**Jammed triage** — Input backlog exceeds classification
capacity. Resolution: route excess to Unknown Bulk hold,
not to Reduction. Throughput pressure must never override
gate logic. Log backlog rate as diagnostic signal.

**Sensor drift** — Classification confidence degrades
without obvious cause. Resolution: tighten thresholds,
increase Unknown Bulk routing, identify and correct
sensor issue before resuming normal operation (Oversight
exit: **Return to Flow**). Mirrors
`Operations/Gate_04_Separation_Mechanical.md` degraded
mode doctrine.

**Contamination discovery mid-process** — Contamination
identified after gate routing has begun. Resolution:
stop processing, escalate to Oversight State,
log new contamination category if not previously defined
(Oversight exit: **Hold**, or **Reclassify** if a new
category is logged).
Do not continue routing contaminated material downstream.

**Tooling inventory stale** — Decision Point B evaluations become
unreliable if tooling inventory is not maintained.
Resolution: Decision Point B defaults to NO (routes to Decision Point C)
when tooling inventory is uncertain. Conservative
routing under uncertainty. See ASM-003.

**Operator unavailable** — Oversight State
requires human presence. Resolution: hold items pending
Oversight State review (Oversight exit: **Hold**). Do not route to Reduction in
operator absence unless automated shutdown doctrine
explicitly permits it.

**Oversight itself unavailable or saturated** — added
2026-09-10, FL-013, closing the loop with
`Operations/Gate_01_Intake.md`'s existing provisional
guidance rather than restating it. Distinct from "Operator
unavailable" above (a single momentary absence) — this
covers the Oversight State as a destination running behind
or backlogged. Resolution: items awaiting Oversight review
remain in hold and do not route forward while waiting; if
the Oversight queue exceeds a defined threshold, new
escalations are logged and queued, safety-critical first,
then age of hold *(threshold itself — Placeholder, defined
operationally)*; held items do not expire — a correctly
held item is always better than a prematurely routed one.
See `Operations/Gate_01_Intake.md`'s "Oversight State
escalation capacity" for the full provisional doctrine this
entry adopts by reference.

**Component Library full or unmaintained** — Decision Point A
outputs have no reliable destination. Resolution:
treat as Decision Point C items until library capacity is restored.
Do not route to Reduction because the library is full.

*Degraded operation doctrine: when in doubt, hold.
The system is designed to absorb uncertainty, not
to resolve it through irreversible action.*

---

## Notes

This flow is intentionally conservative. Irreversibility
is delayed. Human judgment is explicit. Automation is
optional, not assumed.

The Defined Terms section is the most stable element
of this document — treat changes to it with extra care.
Any term redefinition propagates across every file that
inherits the definition.

**Unknown ID naming convention:**
This document uses two identifier systems — they are not
interchangeable:
- **Local sidecar IDs** (FL-001, FL-002) — module-level
  unknowns with full detail in this file's sidecar
- **Cross-module unknowns** — repository-level navigation only,
  indexed in `Unknowns.md` under their owning-file prefixes. Early
  references to UNK-007 and UNK-012 are retired IDs with no current
  entry; UNK-008 (weld-wire qualification) is still in use and is
  indexed in `Unknowns.md`.

When referencing an unknown, use the local sidecar ID as
primary. Use UNK-* only when the unknown has been formally
escalated to cross-module status in Unknowns.md.
Legacy UNK-* identifiers are preserved as aliases only.

---

## G1 Fallacy Checklist — Applied 2026-09-10

*Per Admin/Auditor_Protocols.md's Fallacy Checklist. Applied*
*against this file's current content, not asserted from the*
*Resolution Log's historical reasoning checks — those record*
*individual findings, not a documented full-battery pass. This is*
*that pass. Disposition per item, findings routed to existing*
*Unknowns where applicable rather than duplicated here.*

1. **Magic Energy** — PASS. This file makes no energy-availability
   claims; defers to Operations/Energy.md throughout. KPI is
   explicitly Placeholder, doesn't assume a demand baseline exists.
2. **Friction Blindness** — PASS / not applicable at this layer.
   This is a routing/decision document, not a mechanical spec;
   friction, wear, and thermal losses are Operations-layer concerns
   (Gate_03/04/05), correctly deferred.
3. **Energy Density Paradox** — PASS. No quantified recovery-vs-cost
   claim is made anywhere in this file to violate.
4. **Semantic Drift** — REVISE. Spec Gates (0/6) has never been
   silently advanced; no unknown has been marked Resolved without
   basis. But this file is repo-wide overloaded terminology's
   epicenter — see FL-012 ("Gate" meaning four different things).
   Also worth naming: this file is itself named as the Semantic
   Drift reference standard other files get checked against
   (Fallacy Checklist item 4's own text) — a heavier-than-usual
   obligation to stay internally consistent, several instances of
   which needed correction this session (FL-003, Gate
   Correspondence, "eight sequential gates" — all now fixed).
5. **Scope Creep Disguised as Refinement** — PASS. New capability
   (Decision Point B's Secondary Test) was explicitly labeled as new logic
   with a Provisional warning, not framed as mere consolidation.
   Every other 2026-09-08/09/10 addition was verified against
   existing content before being framed as formalization.
6. **Hallucinated Files or Cross-References** — REVISE. All
   Operations/Admin cross-references checked this session resolve
   to real files — except one: FL-009 (a claimed
   `Gate_02_Triage.md` worked example that doesn't exist).
7. **Confidence Without Basis** — REVISE, minor. The KPI is properly
   Placeholder. But Examples 4/5's illustrative values (45 min,
   1.2 m) were labeled "illustrative, not measured" rather than
   with one of the five canonical labels (Measured / Replicated /
   Simulated / Analogous / Placeholder) — per this item's own rule,
   unlabeled numbers default to Placeholder, and constructed example
   inputs for a worked scenario don't cleanly fit any of the five
   existing categories. Treat as Placeholder by default; the
   five-label taxonomy may need a sixth category for illustrative
   scenario inputs, but that's a repo-wide Admin/Auditor_Protocols.md
   question, not something to invent locally here.
8. **Lifecycle Truncation** — PASS, with a caveat. Degraded
   Operation & Failure Modes exists as its own section. End-of-Life
   is covered via the Lifecycle loop (HP-013) and Termination
   Conditions. "Maintenance Access" has no literal matching section,
   but is functionally satisfied by the Resolution Log and Drift
   Indicators, which serve that role for a document rather than a
   physical module.
9. **Incomplete by Omission** — REVISE. Already-logged omissions:
   Oversight's evidence/authority ownership (FL-006), the Gate
   D/Oversight authority boundary (FL-007), Embedded Value
   Preservation's ownership (FL-011). No new omission found beyond
   what's already captured.
10. **The Turd Problem** — REVISE. Stripped to one sentence: "An item
    that fails Decision Points A–D and has no genuine retained-use need gets
    reduced to feedstock; every other outcome preserves it at the
    highest value level a gate can confirm." That sentence does not
    yet fully survive adversarial reduction — it depends on
    unresolved authority semantics (does Oversight's need-evaluation
    genuinely gate Reduction, or can it be bypassed/overridden per
    FL-007, and does FI-2's Hold guarantee actually hold under the
    stale-tooling exception per FL-008). The foundation is sound;
    the sentence isn't yet fully defensible word-for-word.

**G1 disposition: REVISE.** No fallacy found that isn't already
captured by an existing Unknown (FL-006, FL-007, FL-008, FL-009,
FL-012) except item 7's minor labeling-taxonomy gap, noted above but
not escalated to a new Unknown — it's a five-label-system question
for Admin/Auditor_Protocols.md, not a Forge_flow.md defect.

---

## Boundary-Case Worked Examples

These examples exist to resolve FL-001 — gate logic must
produce deterministic routing, not operator-dependent
outcomes. Each example shows the correct route and why.

**Example 1 — Functional motor in non-functional assembly**
Item: Cordless drill. Housing cracked, battery unsafe,
chuck worn, but motor functional and copper windings intact.
- Decision Point A: Drill as a whole — fails. Cannot perform original
  function safely.
- Decision Point C: Drill as a whole — disassembly warranted. Motor
  is useful in reduced application. Housing and battery
  route to Decision Point D.
- Decision Point D: Housing — structural damage, no functional use,
  material recoverable. Routes to Reduction.
- Decision Point D: Battery — unsafe, not recoverable through
  standard purification. Routes to contamination handling.
- Decision Point A (re-entry): Motor — functional as a component.
  Routes to Component Library.
- Decision Point A (re-entry): Copper windings — functional as
  material stock. Routes to Component Library or Repurpose.
*Key principle: assemblies disassemble at Decision Point C.
Components re-enter independently at Decision Point A.*

**Example 2 — No function but recoverable material (Decision Point C/D boundary)**
Item: Shattered cast iron pan. No functional use in any
application. Material is cast iron — recoverable through
Purification.
- Decision Point A: Fails — no original function possible.
- Decision Point B: Fails — not repairable.
- Decision Point C: Fails — no useful function in reduced application.
  A shattered pan cannot serve as a jig, fixture, or
  structural member.
- Decision Point D: Passes — material recovery value remains.
  Cast iron routes to Reduction then Purification.
*Key principle: Decision Point C tests function, Decision Point D tests
material. An item can fail Decision Point C and pass Decision Point D.*

**Example 3 — Ambiguous Oversight State (want vs. need)**
Item: Vintage oscilloscope. Functional but obsolete.
No active fabrication queue item requires it. A newer
digital equivalent exists in the Component Library.
- Gates A through D: All pass technically — item is
  functional, repairable, repurposable, and material
  is recoverable. *(Clarified 2026-09-10, ChatGPT audit*
  *EV-011: this describes the item's properties*
  *hypothetically satisfying each gate's test in isolation,*
  *for the purpose of this example's premise — not a claim*
  *that gate routing is cumulative. In actual routing, Gate*
  *A alone would pass this item straight to Component*
  *Library; Gates B-D are never reached. This example*
  *exists specifically to set up the Oversight want/need*
  *question, not to describe normal sequential flow.)*
- Oversight State: Is there a genuine need?
  Apply minimum criteria — no active queue dependency,
  substitute exists, no measured scarcity, no failure
  rate evidence. Retention is a want, not a need.
- Route: Repurpose or Reduction depending on Component
  Library capacity.
*Key principle: Oversight State evaluates need against
active operational requirements, not hypothetical value.*

---

**Example 4 — Repairable but not worth it**
*(Illustrative scenario input — 45 min is a constructed*
*example value, not a measured shop-floor result. Labeled*
*2026-09-10, ChatGPT audit EV-006.)*
Item: Bench grinder. Motor still spins, one grinding
wheel is missing, the second is cracked, switch
intermittent. Replacement wheels and switch are
available in the Component Library; total repair
labor is estimated at 45 minutes.
- Decision Point A: Fails as a complete unit — original function
  is compromised (missing/cracked wheels, unreliable
  switch).
- Decision Point B Primary Test: Passes — the failures are
  localized, accessible, and repair is within current
  tooling capability.
- Decision Point B Secondary Test: Repair effort (45 min, common
  parts) is justified by recovered functional value —
  the grinder returns to active use. Passes.
- Route: Repair & Learn. The intermittent switch and
  cracked wheel become documented repair cases.
- If an operator instead judges the Secondary Test as
  NO (e.g. no active need for a grinder and no learning
  value — this failure mode is already well documented):
  routes to Decision Point C instead, with the operator's rationale
  logged per Decision Point B's Secondary Test doctrine.
*Key principle: Decision Point B's Primary Test is purely
technical; its Secondary Test makes the "not worth it"
judgment an explicit, logged gate decision rather than
an unlogged queue-priority opinion. This example predates
the Secondary Test's 2026-09-08 addition — updated the
same day to match; see the Provisional notice on Decision Point B
itself.*

---

**Example 5 — Repurpose vs. material recovery tension**
*(Illustrative scenario input — 1.2 m is a constructed example*
*dimension, not a Forge-tested limit. Labeled 2026-09-10,*
*ChatGPT audit EV-007.)*
Item: Aluminum extrusion, 1.2 m long, one end crushed,
rest undamaged. Could serve as structural stock or jig
material (Decision Point C), or be reduced to clean aluminum
feedstock (Decision Point D → Reduction → Purification).
- Decision Point A: Fails — original function is gone.
- Decision Point B: Fails — crush damage is not repairable to
  original geometry within current tooling.
- Decision Point C: Passes — the undamaged length is immediately
  useful as lower-precision stock or fixture material.
- Route: Repurpose. The crushed end may be cut and sent
  to Reduction; the good length enters the Component
  Library as usable stock.
- If no current fabrication need exists for aluminum
  stock of that section: still route to Repurpose, or
  Oversight Hold with a defined review date — not
  immediate Reduction. Functional stock outranks pure
  material recovery while it exists.
*Key principle: Decision Point C functional value outranks
material recovery when both are viable. Reduction is
the residual path (see Decision Point D), not the preferred one.*

---

**Example 6 — Unknown or incompletely identified material**
Item: Mixed plastic-metal assembly. Housing material is
unmarked, no datasheet, no clear polymer identification;
metal inserts of unknown alloy.
- Gates A–C: Indeterminate — original function and
  reduced-application potential cannot be assessed
  without material identity.
- Decision Point D: Also indeterminate — an unidentified polymer
  or alloy could contaminate downstream Purification, so
  whether Reduction is the correct residual path cannot
  be answered yet.
- Route: Unknown Bulk hold (or Oversight State,
  exit: Hold). Do not guess. Log the identification gap.
  Item stays held until material characterization is
  performed or, if provenance allows, returned to source.
- Only after positive identification: re-enter the full
  gate sequence from Decision Point A.
*Key principle: Incomplete evidence produces a hold,
never a forced gate decision. Determinism requires known
inputs, not assumed ones.*

---

**Example 7 — Incomplete evidence / conflicting operator assessments**
Item: Hydraulic pump. One operator reports the seals as
failed and the unit as scrap; a second reports the seals
serviceable and recommends Repair. No pressure test has
been performed — visual inspection only.
- Decision Point B: Cannot be evaluated deterministically — the
  failure state itself is disputed and unmeasured.
- Response: Escalate to Oversight State (exit:
  Hold), or Unknown Bulk hold. Perform the minimal
  diagnostic (pressure test or controlled seal
  inspection) before any gate decision.
- After diagnostic: re-enter at the appropriate gate
  with the measured state.
- If diagnostic capacity does not exist: hold. Do not
  default to Reduction under uncertainty.
*Key principle: Conflicting assessments or missing
measurements produce a hold plus a diagnostic action —
never a majority vote or a forced gate outcome.*

---

## Adversarial Routing Scenarios

These scenarios test gate logic under pressure conditions.
A gate system that only works under cooperative conditions
is not a gate system — it is a suggestion.

**Scenario 1 — Throughput pressure**
Situation: Input backlog is high. Operator is tempted to
route ambiguous items directly to Reduction to clear the
queue faster.
Correct response: Route to Unknown Bulk hold. Log backlog
rate. Throughput pressure is not a gate condition.
Reduction requires gate failure, not queue management.

**Scenario 2 — Emotionally valuable item**
Situation: A family heirloom tool arrives in salvage.
Functional but outside the Forge's current needs.
Operator wants to retain it indefinitely.
Correct response: Apply want/need criteria. If no active
need exists, assign a defined review date. If review date
passes without a need emerging, route to Reduction or
return to owner if provenance allows. Emotional value
does not override gate logic — but it is a legitimate
signal to escalate to the Oversight State rather than
auto-routing.

**Scenario 3 — Contaminated high-value material**
Situation: A large copper component arrives with suspected
lead contamination (visible surface oxidation, unknown
provenance). High material value tempts bypass of
contamination screening.
Correct response: Route to contamination assessment before
any gate logic applies. If contamination is confirmed,
route to `Operations/Air_Scrubber.md` protocol and controlled
processing. High value does not override contamination
doctrine. The Air Scrubber exists precisely for this case.

**Scenario 4 — Partially functional assembly under scarcity**
Situation: A rare motor controller arrives. One channel
is failed, two are functional. No substitute exists in
the Component Library. Scarcity is real and measured.
Correct response: Decision Point C — disassemble. Functional
channels route to Component Library. Failed channel
routes to Decision Point D. Scarcity justifies careful disassembly
over bulk Reduction. Document scarcity evidence in
the Component Library entry.

**Scenario 5 — Operator disputes gate outcome**
Situation: Two operators disagree about whether an item
passes Decision Point C. One argues it has reduced-application
value; the other argues it does not.
Correct response: Escalate to Oversight State.
Log the disagreement and the resolution rationale.
If the dispute reveals a genuine boundary ambiguity,
log a new boundary-case worked example. Gate disputes
are data — they feed FL-001 resolution.

---

## G3 Adversarial Challenge Battery — Class Mapping (2026-09-10)

*Per Admin/Auditor_Protocols.md: "Partial application (selected*
*challenge classes) is acceptable for Exploration-stage documents.*
*Document which classes were applied and why others were deferred."*
*This is that documentation — mapping the five scenarios above and*
*this file's other adversarial content against the ten defined*
*classes, rather than treating five authored scenarios as if they*
*were a comprehensive battery.*

**Applied (3 of 10):**
- **Class 3 — Incentive Corruption:** Scenario 1 (throughput
  pressure) directly matches this class's own named example
  ("throughput over safety"). Countermeasure named: route to
  Unknown Bulk hold, log backlog rate, throughput is not a gate
  condition.
- **Class 4 — Semantic Drift Attacks:** FL-008 is the concrete
  scenario — FI-2's "never to irreversible action" wording supports
  two operator-legitimate readings against the stale-tooling
  exception. Logged as an unknown rather than silently resolved,
  per this class's own minimum requirement.
- **Class 5 — Unknown Unknown Pressure Tests:** Example 6 (Boundary-
  Case Worked Examples — unidentified plastic-metal assembly)
  directly covers this: routes to Unknown Bulk hold rather than
  guessing or routing an unknown forward as a known.

**Deferred (7 of 10) — Exploration-stage, not yet exercised:**
- **Class 1 — Assumption Inversion** (name three hidden assumptions,
  what happens when each fails) — not yet exercised as a dedicated
  scenario; Phase 3's "hidden assumptions" pass (A3-001 through
  A3-007) is adjacent but wasn't structured against this class's
  specific minimum requirement.
- **Class 2 — Failure Amplification** (trace one failure through two
  downstream consequences) — not yet exercised.
- **Class 6 — Recursive Justification Loops** (what external reality
  check exists beyond self-reference) — not yet exercised. Worth
  naming: this is a live risk for the audit process itself, not just
  the document — an audit that only checks documents against other
  documents in the same repository is exactly the loop this class
  warns about. This file's claims are ultimately checked against
  physical reality only once real Decision Point B data and Reduction method
  selection exist (FL-005, FL-002) — until then, internal consistency
  is the strongest test available, not a substitute for it.
- **Class 7 — Human Fatigue and Cognitive Erosion** (12-hour
  repetition, shift handoff, normalization of deviance) — not yet
  exercised; requires real operational conditions this Exploration-
  stage document has no basis to model.
- **Class 8 — Malicious Actor Simulation** (intentional abuse by a
  knowledgeable actor) — not yet exercised.
- **Class 9 — Epistemic Corruption** (systematic degradation through
  well-intentioned but incorrect contributions) — not yet exercised
  within this file's own content, though notable: the *audit
  process* around this file has been actively managing exactly this
  risk (independent source-verification of every agent claim this
  session, catching several confident-but-wrong claims) — the
  countermeasure exists at the process level, not yet documented as
  a property of the specification itself.
- **Class 10 — Systemic Coupling and Cascade** (if this module fails,
  what fails with it, second, third) — not yet exercised.

**G3 disposition: REVISE.** Three classes genuinely applied with
concrete scenarios meeting their stated minimum requirements; seven
honestly deferred rather than claimed via the five existing
scenarios stretched to fit. No new Unknowns created for the deferred
classes — per the protocol's own caution against overproducing
governance artifacts, and because "not yet exercised" is an honest
Exploration-stage status, not itself a defect requiring a tracked
Unknown until a concrete gap is found within a class.

---

## Lessons Learned

*Section heading added 2026-09-10 (F1-001, ChatGPT audit). The*
*table below already existed with real content — it was orphaned*
*without its own heading, sitting directly under Adversarial*
*Routing Scenarios. No content changed, only the missing structural*
*element (required by Admin/File_Template.md §7).*

| Date | Evidence Type | What Was Tried | What Failed | What Was Learned | Confidence | Revalidation Needed |
|------|---------------|----------------|-------------|------------------|------------|---------------------|
| May 2026 | Audit Review | Gate A "equivalent function" left undefined | Created overlap with Gate C — same item could route to either | Gate A requires function in original application context; Gate C handles all reduced or different applications. Definitions must be mutually exclusive at every boundary | Analogous | No — definition is stable |
| May 2026 | Audit Review | Gate C and Gate D described with near-identical language | Boundary between them was ambiguous — items could satisfy both or neither | Gate C = functional downgrade test; Gate D = material integrity test. Explicitly distinct. Gate C asks can it do something useful; Gate D asks is the material itself recoverable | Analogous | No — distinction is stable |
| 2026-05-15 | Audit Review | Gate logic assumed to apply to assemblies as fixed units | Created ambiguity about disassembly — pulling a motor from a fan before reduction felt like a gate bypass | Gate logic applies to discrete items not fixed assemblies. Disassembly is a Gate C decision on the assembly — each resulting component re-enters at Gate A independently. Sequential order is preserved at the component level. See ASM-007 | Analogous | Yes — worked examples needed for complex multi-component assemblies |

---

## Active Disputes

| ID | Dispute Summary | Positions in Conflict | Risk | Status | Owner |
|----|-----------------|-----------------------|------|--------|-------|
| FL-DS-001 | "Purification stage" terminology may cause semantic overlap with `Operations/Gate_05_Separation_Thermal.md` and misrepresent `Operations/Gate_04_Separation_Mechanical.md`'s function | Position A: Purification is correctly defined broadly — "Spin chamber or any mechanism achieving comparable separation output" — the Gate fits this definition and no rename is needed. Position B: The Gate does not purify in metallurgical terms; calling its stage Purification creates confusion about what the module does and risks semantic drift across the repository | Low | Open | Architecture/Forge_flow.md |

*FL-DS-001 originates from ChatGPT audit of Operations/Gate_04_Separation_Mechanical.md
(2026-05-15) and is logged there as a cross-reference. Resolution
belongs here — if the Purification stage definition is revised,
Operations/Gate_04_Separation_Mechanical.md File Purpose and position statement
must be updated to match, and Unknowns.md notified.
Position A is the current standing definition. Position B requires
a terminology change with repository-wide propagation.
Recommended trigger for revisit: when a second mechanical separation
module enters scope.*

---

## Auditor Notes & Unknowns

### FL-001 — Gate logic determinism unverified at boundary cases

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | In Progress                                      |
| Risk          | Medium                                           |
| Priority      | Major                                            |
| Type          | Technical                                        |
| Blocking      | Yes — blocks promotion to Specification          |
| Owner         | Architecture/Forge_flow.md                         |
| First Logged  | May 2026                                         |
| Last Reviewed | 2026-09-08                                       |

**Description:** Whether gate logic (A→B→C→D) produces
deterministic routing for all item types at boundary cases
has not been verified.

**Why It Matters:** Non-deterministic gate logic means
identical items could route differently depending on
operator interpretation. This undermines the flow
document's role as a reliable decision standard and
creates inconsistency across forge instances.

**Resolution Path:**
- Gate Correspondence table added — partial resolution.
- Motor worked example added to Operations/Gate_02_Triage.md
  (65% torque → Decision Point A fail, Decision Point C pass) — partial
  resolution. **Historical claim:** this entry stated a worked
  example existed in Operations/Gate_02_Triage.md. **Current
  verification (2026-09-10, ChatGPT audit EV-008, extended by
  Claude):** cannot be confirmed — no "torque" or "65%" content
  exists anywhere in Operations/Gate_02_Triage.md as of that date
  or since. **Current disposition (2026-09-14, FL-009):** the claim
  is withdrawn as evidence of resolution. A short, labeled
  illustrative example may be added later if still useful, as a
  separate, optional action. See FL-009.
- Assembly disassembly clarification added 2026-05-15 —
  Gate C decision on assembly spawns independent Gate A
  evaluations per component. See ASM-007 and Lessons
  Learned entry 2026-05-15.
- Five boundary-case worked examples added 2026-05-16 —
  functional motor in broken assembly, shattered cast iron
  (Gate C/D boundary), ambiguous Oversight Gate want/need,
  adversarial throughput pressure, operator dispute
  escalation. See Boundary-Case Worked Examples section.
- Five adversarial routing scenarios added 2026-05-16 —
  throughput pressure, emotional value, contaminated
  high-value material, scarcity under partial function,
  operator dispute. See Adversarial Routing Scenarios section.
- "Genuine need" minimum criteria added to Oversight Gate
  2026-05-16 — linked fabrication queue, tooling deficiency,
  lead-time, scarcity evidence, failure-rate, dependency chain.
- Remaining: Gate C/D boundary worked example covers
  shattered cast iron — additional complex assembly examples
  may be needed before full determinism is claimed.
- 2026-09-08: Examples 4-7 added (repairable-not-worth-it,
  repurpose-vs-recovery tension, unknown material,
  incomplete/conflicting evidence) — closes four of the
  gap cells identified under HP-005. Complex
  multi-component assemblies beyond Example 1's drill case
  remain the one uncovered cell — see HP-005.
- Remaining: Adversarial scenarios cover five cases —
  real-world operation will surface new boundary conditions
  that must be logged and resolved.
- Decision Point D renamed "Material Recovery Viability" 2026-09-08 for
  testability, then rewritten same day (HP-004, Option A) to a
  single positive test — the compound-test polarity ambiguity
  is resolved. Routing outcomes unchanged throughout.
- Last Reviewed field corrected 2026-09-08 — had drifted stale
  against this file's own Resolution Log, which recorded
  substantive audits (2026-08-08, 2026-08-10) after the field's
  prior 2026-05-16 value.
- Payment via Specification — once all boundary cases
  have worked examples producing deterministic outcomes
  across multiple operators, move validated gate logic
  to Body as Measured.
- Cross-module reference: UNK-012 — a retired ID with no current
  entry in `Unknowns.md`; the original target is not recorded, so
  the reference is kept for provenance only.

---

### FL-002 — Reduction output envelope cross-validation pending

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | Medium                                           |
| Priority      | Major                                            |
| Type          | Technical / Architectural                        |
| Blocking      | No                                               |
| Owner         | Architecture/Forge_flow.md                         |
| First Logged  | 2026-05-15                                       |
| Last Reviewed | 2026-08-17                                       |

**Description:** Operations/Gate_03_Reduction.md now exists and
specifies constraints-first Reduction doctrine (contamination
shutdown, prohibited inputs, output envelope, dust handling,
emergency shutdown). Its output envelope has not yet been
cross-validated against Operations/Gate_04_Separation_Mechanical.md's
provisional feedstock envelope (Inputs section).

**Why It Matters:** Reduction sits at R4, the flow's highest-
consequence boundary. It is also the upstream dependency
for the Material Separation Gate — the Gate's provisional
feedstock envelope, RPM bands, sensor calibration, and jam
risk all depend on knowing what Reduction actually produces.
An uncross-validated envelope means the Gate is still operating
against an unconfirmed input.

**Resolution Path:**
- Cross-validate Operations/Gate_03_Reduction.md's output envelope
  (max dimension, max mass, prohibited geometries, moisture and
  contamination handling) against Operations/Gate_04_Separation_Mechanical.md
  Inputs section once a Reduction method is selected.
- Until cross-validated, Operations/Gate_04_Separation_Mechanical.md's
  provisional feedstock envelope (Inputs section) stands as the
  best available constraint.
- Cross-module references: GR-009 (Operations/Gate_03_Reduction.md)
  and MG-009 (Operations/Gate_04_Separation_Mechanical.md) — the
  logged envelope drift. An earlier UNK-007 / MG-007 pointer here
  predates the current IDs: UNK-007 has no entry in `Unknowns.md`
  today, and MG-007 is the rotor-jam unknown, not the envelope.
- **2026-09-09:** scoped this entry — confirmed still blocked on
  Reduction method selection (GR-002, not yet resolved). Found the
  two provisional envelope tables that stand in for the real
  cross-validation have themselves drifted from each other; logged
  as GR-009 / MG-009 rather than fixed, since both are placeholders
  regardless. Not a step toward closing FL-002 itself.
- Payment via Specification — once the output envelope is
  cross-validated against Operations/Gate_04_Separation_Mechanical.md
  Inputs section.

---

### FL-003 — Self-replication architecture ownership assigned but incomplete

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                              |
| Risk          | Low                                               |
| Priority      | Minor                                             |
| Type          | Architectural / Cross-Module                      |
| Blocking      | No                                                |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-08                                        |
| Last Reviewed | 2026-09-08                                        |

**Description:** `Operations/Gate_05_Separation_Thermal.md`'s Scope
Boundary points self-replication architecture and loop closure
logic to this file (jointly with Geck_forge_seed.md). **Update
2026-09-10 (ChatGPT audit, S2-002/P5-007):** this file's Scope
Boundary was updated during the original HP-006 pass to acknowledge
the pending ownership claim (see "Self-replication architecture or
loop closure logic... (pending — see FL-003)") — this Description
was never updated to match and had drifted into direct
self-contradiction, still saying the Scope Boundary "never claims
that ownership" when it explicitly does, with a pending qualifier.
The real state is: ownership is now claimed, but not yet
operationally meaningful — the Scope Boundary stub is an
acknowledgment, not an architectural definition. Found during HP-006
cross-layer reconciliation; contradiction found during the
2026-09-10 ChatGPT audit.

**Why It Matters:** Self-replication is referenced as a downstream
goal from at least one operational file, but nothing in the
architecture layer currently owns defining what that architecture
actually is — an orphaned handoff.

**Resolution Path** (sharpened 2026-09-10, ChatGPT Phase 9 — the
original path implicitly framed this as "find an owner," which is
now done; the residual path is different):
1. Ownership is assigned (this file + Geck_forge_seed.md) — done.
2. Define required architecture boundaries: input/output boundaries,
   dependency boundaries, safety constraints, relationship to the
   material loop, relationship to Fabrication, re-entry/seed
   semantics.
3. Reconcile Forge_flow.md against Geck_forge_seed.md — determine
   which file owns which piece rather than assuming both own
   everything jointly.
4. Identify missing implementation contracts.
5. Close when the architecture is sufficiently specified against
   the boundaries named in step 2 — not merely when a paragraph
   exists.
Do not treat "ownership named" as equivalent to "architecture
defined." Those are different closure conditions, and only the
first is currently satisfied.

---

### FL-004 — Tooling inventory owned but unpopulated — not yet usable as Decision Point B evidence

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                              |
| Risk          | Medium                                            |
| Priority      | Major                                             |
| Type          | Operational / Cross-Module                        |
| Blocking      | No (but blocks full FL-001 / Decision Point B determinism)  |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-08                                        |
| Last Reviewed | 2026-09-08                                        |

**Description:** ASM-003's Expiry Trigger requires tooling inventory
specification and maintenance doctrine to be "assigned to an owning
file." Checked `Architecture/Components.md` as the candidate — it is
a system-component taxonomy (Critical/Useful/Bootstrap), not a live
tool list, contains no tooling-inventory content, and doesn't claim
this ownership. No file currently does. Found while reviewing a
proposal to draft `Operations/Tooling_Inventory.md` for this purpose
(see Held Proposals HP-007). **Update 2026-09-08 (second entry):**
`Operations/Tooling_Inventory.md` created (Grok-drafted from the
HP-007 skeleton, Claude-reviewed and template-corrected). Ownership
question is now answered; inventory tables remain unpopulated (see
that file's TI-001) — this entry stays Open until first population.

**Why It Matters:** Decision Point B's "within current tooling capability" test
cannot be fully deterministic without a real, owned, maintained
inventory to evaluate against — this is a live gap in FL-001's own
determinism claim, not just a documentation nicety.

**Resolution Path** (strengthened 2026-09-10, ChatGPT Phase 9 —
population alone is not a sufficient closure condition):
- ~~Decide ownership~~ Done 2026-09-08 —
  `Operations/Tooling_Inventory.md` created.
- Closure requires all of, not just population:
  1. Inventory populated with real tools.
  2. A named human owner (still `[to be assigned]` as of 2026-09-10
     — see that file's TI-001).
  3. A maintenance/update mechanism established and actually
     followed, not merely stated.
  4. The inventory demonstrated usable as live Decision Point B evidence — a
     populated table that's stale, disputed, or disconnected from
     actual equipment doesn't satisfy ASM-003's "known and
     maintained" requirement even if every row has a value.
- Update ASM-003's Expiry Trigger once all four are satisfied — for
  that deployment's own copy of these files. This repository is
  shared across independent Forge builds; no single population of
  the inventory closes this for anyone but the instance that
  performed it (see Tooling_Inventory.md's File Purpose and TI-001).

---

### FL-005 — Decision Point B Secondary Test unvalidated against real operation

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                              |
| Risk          | Medium                                            |
| Priority      | Major                                             |
| Type          | Gate Logic                                        |
| Blocking      | Yes — blocks FL-001 Decision Point B determinism claim      |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-08                                        |
| Last Reviewed | 2026-09-08                                        |

**Description:** Decision Point B's Secondary Test (justified-effort
evaluation, added 2026-09-08) is new gate logic, not a
documentation consolidation like this file's other 2026-09-08
changes. It has not been exercised against a single real item.
The judgment criteria (recovered value / learning value / scarcity)
are qualitative and operator-judged, with no scoring formula or
threshold yet — see the Provisional notice on Decision Point B itself.

**Why It Matters:** Two operators could reasonably reach different
Secondary Test outcomes for the same item, which is exactly the
non-determinism FL-001 exists to close. Adding the test closes one
documentation gap (Example 4 previously claimed no such test
existed) but opens a new determinism question that did not exist
before this pass.

**Resolution Path:**
- Log every Secondary Test decision with operator rationale from
  first use (per Decision Point B's own instruction). **2026-09-09: the log
  format itself now exists** — `Operations/Gate_02_Triage.md` §XII.1b
  extends the existing TIL v0 Log Specification with Gate-B-specific
  fields, rather than a new standalone schema.
- After a meaningful sample of real decisions, check for
  operator-to-operator divergence *within a single deployment*.
  This is about the same Forge's operators reaching consistent
  outcomes on the same evidence — it is not a call for uniformity
  across different sites, whose tooling, scarcity conditions, and
  active needs genuinely differ (see Tooling_Inventory.md's File
  Purpose). Cross-site divergence in Secondary Test outcomes is
  expected and not itself evidence of a determinism problem.
- Before Specification: convert to a testable threshold (effort
  bands, measured scarcity cutoffs, or equivalent) per Decision Point B's own
  provisional note.
- Cross-module reference: HP-005 in Held Proposals.

---

### FL-006 — Oversight has no assigned Operations or authority owner

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open — authority half (B) re-verified 2026-09-14: procedure confirmed sound (EC-003's Recipient/Logging rows), but re-verification surfaced an unstated dependency on GOV-006 (operator-identity authentication), now cross-referenced in §1.3. Not Resolved — the GOV-006 dependency means this is a documented partial resolution, not a closeable one, until GOV-006 or an explicit scope decision addresses it. Evidence-ownership half (A) remains fully Open, untouched. |
| Risk          | Medium (raised from Low 2026-09-10 — ChatGPT Phase 8: the Escalate exit invokes an authority structure this repository has not named, which is a separation-of-powers interface gap, not an administrative filing problem) |
| Priority      | Major (raised from Minor 2026-09-10)               |
| Type          | Cross-Module / Governance                          |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-08                                        |
| Last Reviewed | 2026-09-18 — half A structural owner named (see below); half B unchanged |

**Description:** Found while building §1.3 Transition Ownership
(HP-011). Decision Points A–D each have a clear Operations owner for their
evidence-gathering procedure (`Operations/Gate_02_Triage.md`, plus
`Operations/Tooling_Inventory.md` for Decision Point B). Oversight does not — no
Operations file is named as the owner of gathering exception
evidence (contamination reports, scarcity data, etc.), and no
Admin file is named as the owner of the authority structure that
Oversight's Escalate exit implicitly assumes ("exceeds this flow's
own decision authority" — exceeds *whose* authority is not stated).

**Why It Matters:** This is a real ownership gap, not a documentation
nicety — Oversight is the gate closest to human judgment and highest
consequence besides Reduction itself, and it currently has no
operational or governance home outside this file.

**Resolution Path** (split 2026-09-10, ChatGPT Phase 9 — the
original single path risked solving the easier half while leaving
the more consequential half looking resolved):

*A. Evidence ownership* (who gathers/maintains queue state,
substitute availability, scarcity evidence, failure-rate evidence,
dependency information):
- Determine whether an existing Operations file already implicitly
  covers this and simply hasn't been cross-referenced here.
- If not, this may need its own lightweight Operations file, similar
  in spirit to how HP-007 resolved FL-004.

*B. Authority ownership* (who is actually authorized to decide when
this flow's own authority ends — what Escalate invokes):
- Determine whether an existing Admin file (Governance_Charter.md,
  Safety_Protocols.md, or similar) already implicitly covers operator
  decision authority and simply hasn't been cross-referenced here.
- This is the more consequential half and directly intersects FL-007
  — resolving A without B would leave Oversight looking staffed
  while its actual decision authority remains unnamed.

Whether A and B become separate Unknown IDs once resolved is a
governance decision, not something to split unilaterally here.

**Proposed Resolution — Authority half only (drafted 2026-09-13 in
`LazarusForge-1_Alpha_14_working_2026-09-13a.zip`; skeptical pass by
ChatGPT 2026-09-13 — Revise materially — cross-checked by Grok,
verified by Claude, confirmed against Ethical_Constraints.md's own
text on owning-file test pass 2026-09-14):**
Until an Admin-owned authority structure is explicitly defined,
Escalate remains a Hold-safe transition requiring designated
human/oversight judgment under the existing Human Escalation
Protocol (`Admin/Ethical_Constraints.md` EC-003). The case record
carries the applicable authority and decision basis for that
specific Escalate instance — this is not a new mechanism: EC-003's
own table already defines a Recipient row ("the designated human
operator or oversight role currently on record") and a Logging row
(every escalation event logged with trigger, timestamp, epistemic
state, human response, and final disposition). `Ethical_Constraints.md`
remains the governing *ethical constraint source*, not the
case-specific authority registry — the case record lives in that
existing Logging mechanism, not in a new file or a new field. No new
authority structure is invented by this note. Evidence-ownership
half (A) remains fully Open. Status of FL-006 remains Open until
both halves have skeptical confirmation.

**Proposed Resolution — Evidence half (A) (2026-09-18; Grok drafted gap analysis + initial owner proposal; ChatGPT skeptical pass REVISE not reject — four changes accepted; Grok revised to incorporate; Claude source-verified before filing):**
`Operations/Exception_Evidence.md` created as the evidence-control specification and index for Oversight's evidence portfolio. Four ChatGPT corrections accepted over the initial draft: (1) file ≠ operator — the file is the repository home / control spec; the operational maintainer is a designated Operations role, pending; (2) control spec ≠ warehouse — episodic packet bodies live in the operational records the file points to, not inside it; (3) evidence ≠ decision — explicit anti-policy rule added: "Evidence MUST NOT be treated as a decision, authorization, routing instruction, or policy merely because it appears in or is referenced by this file"; (4) standing data as distributed references — Exception_Evidence.md maps what Oversight needs and where to find it (Tooling_Inventory for capability, deployment-local records for scarcity, etc.), rather than centralizing all standing data into one ledger. HP-011's Oversight Operations cell updated to name the new file. **Status of half A: structural owner named; operational population and demonstrated maintenance still open. FL-006 overall remains Open — half B (authority/GOV-006 dependency) untouched.**
**Revision note:** the original draft said Escalate judgment is
"recorded against `Admin/Ethical_Constraints.md`" — flagged on
skeptical pass as architecturally unclean. That file's own text
(line 48) explicitly disclaims owning escalation-channel
*implementation*, pointing instead to the Human Escalation Protocol
it defines (EC-003) for behavior and to `Tests/Leviathan_testing.md`
for transport. Making it the case-specific authority record risked
conflating three distinct things: ethical authority, operational
authority, and case-specific human disposition. The revised language
keeps Ethical_Constraints.md as the ethical-constraint source while
letting the case record — not this file — carry the actual authority
and decision basis for any given Escalate. The owning-file test pass
confirmed this "case record" isn't hypothetical — EC-003's existing
Recipient and Logging rows already are that mechanism, so this
resolution requires no new field or file, only the explicit
cross-reference above.

---

### FL-007 — Decision Point D/Oversight authority boundary is unstated

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved** — Reading A adopted 2026-09-12 (Payment via Specification) |
| Risk          | Medium (historical; raised from Low 2026-09-10)  |
| Priority      | Major (historical; raised from Minor 2026-09-10) |
| Type          | Architectural / Ethical Interface                  |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-12                                        |

**Closure (2026-09-12):** Reading A adopted. Oversight Terminate is an
independent authorization path for Reduction (R4), parallel to Decision Point D
YES. Routing ≠ authorization ≠ execution readiness stated explicitly
in the Oversight section and Decision Contract notes. Gate_03's dual
entry corridor is confirmed rather than narrowed. Bounded discretion
proviso added for unanticipated exceptions (logged, rare, Ethical_Constraints-
consistent, no bypass of Gate_03 readiness). Escalate ownership (FL-006
authority half) remains open and is not required to close this entry.
Removed from Active Index on next Unknowns pass per Size Management Rule 2.

**Description (historical):** Raised by ChatGPT reviewing the 2026-09-10 working
tree, verified against live text. The Oversight Gate's "Gate D
want/need evaluation" is explicitly scoped to items that already
*passed* Gate D — i.e. Gate D already determined Reduction is the
correct residual path for material recovery. Oversight is then asked
to potentially override that outcome via the Hold exit, using a
completely different judgment axis: whether a genuine retained-use
need exists, not whether material recovery is viable. The text never
states whether Oversight has authority to override Gate D's
material-recovery determination, or only authority to delay
execution of a determination it doesn't contest. "No genuine need
confirmed" (Oversight's Terminate criterion) and "Reduction is the
correct residual path" (Gate D's own criterion) are conceptually
different judgments that the current text allows to look
interchangeable at the Terminate exit.

**Why It Matters:** If Oversight is silently assumed to have
override authority over Gate D's material-recovery determination,
that's a real gap in what Gate D's own "YES" outcome actually means
— it would no longer be a final material-recovery determination, only
a recommendation Oversight can freely second-guess on unrelated
grounds. If Oversight does NOT have that authority, the current
Hold/Terminate framing needs to be read strictly as "when to execute
Reduction," never as "whether to execute it" — worth stating
explicitly rather than leaving implicit.

**Resolution Path:**
- Do not resolve by editing gate logic yet — this needs a decision
  about what authority Oversight actually has, not a wording fix.
- Candidate framing to evaluate: Oversight's Hold/Terminate choice at
  this entry point is a *timing* decision only (when Reduction
  executes), not a *reversal* of Gate D's material-recovery
  determination — Gate D already said Reduction is correct; Oversight
  only decides whether execution happens now or after a review
  period. If that framing is adopted, "no genuine need confirmed →
  Terminate" should be reworded to make clear it triggers previously-
  determined Reduction, not a fresh material-recovery judgment.
- Related to FL-006 (Oversight's authority structure has no named
  owner at all) — resolving that first may clarify this too.
- **Update 2026-09-10 (ChatGPT audit, IC-002/IC-003/IC-007/P5-004/**
  **P5-017):** this question is now confirmed to propagate across
  three files, not just this one. `Operations/Gate_03_Reduction.md`
  explicitly permits Reduction via two separate entry conditions —
  "the item passed Decision Points A–D and failed all four... or has been
  explicitly routed by the Oversight State" — meaning the
  downstream execution file already encodes Oversight as an
  independent Reduction-authorizing path, not merely a timing
  decision on Decision Point D's determination. That's evidence toward
  reading B (Oversight has real override/authorization authority),
  not reading A, though this file's own text still doesn't confirm
  which was intended. Also newly relevant: `Admin/Ethical_Constraints.md`
  requires explicit authorization (not inferred) for irreversible
  material action, and rates it High-Risk requiring VERIFIED status
  — meaning this isn't purely an internal architecture question
  anymore. Three concepts need to be kept distinct going forward:
  routing ("this item belongs on the Reduction pathway"),
  authorization ("Reduction may begin"), and execution readiness
  (`Gate_03_Reduction.md`'s own hard prerequisites — human presence,
  no active contamination, etc., which are well-specified). This
  file currently only clearly specifies the third.
- **Closure sequence (added 2026-09-10, ChatGPT Phase 9 — the prior**
  **framing above was correct in spirit but not stated as an**
  **explicit, ordered closure test):**
  1. Define Decision Point D's authority (does YES mean a final determination,
     or a recommendation?).
  2. Define Oversight's authority (can it independently authorize
     Reduction, or only control timing/exceptions around a
     determination Decision Point D already made?).
  3. Define whether Oversight can create an alternate Reduction
     route distinct from the normal A→B→C→D route — the evidence in
     `Gate_03_Reduction.md`'s dual entry conditions suggests it
     currently can, whether or not that was deliberate.
  4. Define the authorization boundary explicitly: routing ≠
     authorization ≠ execution readiness, and state which of the
     three this file's own language actually establishes at each
     step.
  5. Reconcile `Operations/Gate_03_Reduction.md` against whatever
     answer steps 1-4 produce.
  6. Reconcile `Admin/Ethical_Constraints.md`'s explicit-authorization
     requirement against the answer.
  7. Update the Flow State/Transition Model and Gate Correspondence
     table to match — only after 1-6, not before.
  Only close FL-007 once all seven are satisfied. Partial progress
  (e.g. answering 1-2 without 5-6) should not be recorded as closure.

---

### FL-008 — FI-2's "never to irreversible action" scope is ambiguous against the stale-tooling exception

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved** — FI-2 narrowed, Decision Point D independence re-verified 2026-09-14 (Ratified by James) |
| Risk          | Medium                                            |
| Priority      | Major                                             |
| Type          | Architectural / Invariant                          |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-14                                        |

**Description:** Raised by ChatGPT (IC-001), verified against live
text. FI-2 states "uncertainty defaults to hold, never to
irreversible action." The Degraded Operation section's stale-tooling
rule instead converts UNKNOWN into a defined FAIL (routing to Gate
C, not Hold). Under a narrow, literal reading of FI-2 ("never to
irreversible action"), this doesn't actually violate the invariant —
Decision Point C is not R4/irreversible, so the specific guarantee FI-2 makes
is technically preserved. But a natural, equally available reading
treats "defaults to hold" as the substantive promise, in which case
the stale-tooling rule is a live exception to a stated invariant
that claims to have none. The text does not disambiguate which
reading is intended.

**Why It Matters:** An invariant whose own wording supports two
different readings is a real defect independent of which reading
turns out correct — a careful reader (this audit) reached the
stricter reading and flagged a contradiction that may or may not
actually exist depending on interpretation. That ambiguity itself
should not survive in a document aiming to be a testable
state-transition specification.

**Resolution Path:**
- Decide which reading is intended and tighten FI-2's wording to
  make it unambiguous — either narrow it explicitly ("never routes
  directly to Reduction or other R4 action" — permitting non-Hold,
  non-irreversible exceptions like Decision Point C), or tighten the
  stale-tooling rule to route to Hold instead of Decision Point
  C-via-FAIL if the stricter reading is intended.
- Do not resolve by silently picking one reading — this changes
  what the invariant actually promises and should be a deliberate
  choice, not a documentation cleanup.

**Proposed Resolution (drafted 2026-09-13 in
`LazarusForge-1_Alpha_14_working_2026-09-13a.zip`; skeptical pass by
ChatGPT 2026-09-13, revised per that pass, cross-checked by Grok,
verified by Claude, tested against Decision Point B/FI-2 text on owning-file
test pass 2026-09-14 — confirmed compatible):**
Narrow FI-2 to: "Uncertainty defaults to Hold. An explicitly defined
degraded-mode exception may permit a non-R4 transition, but that
transition does not itself constitute authorization for R4 action.
Any later R4 decision requires its own applicable evidence and
decision contract." Keep the stale-tooling degraded rule as written
(Primary defaults to FAIL → Decision Point C). Add explicit notes under FI-2
and the Decision Point B Decision Contract to this effect.
**Revision note:** the original draft's closing clause — "it does
not authorize Reduction" — was rejected on skeptical pass. Decision Point C is
not R4, but Decision Point C can lead to Decision Point D, and Decision Point D can authorize
Reduction; claiming the stale-tooling path "does not authorize
Reduction" would be a false safety guarantee, since a stale-tooling
entry could still participate in a path that later reaches R4
through its own proper authorization. The revised language above
preserves the degraded-mode exception without immunizing anything
downstream. Status remains Open until this wording is tested against
the live FI-2/Decision Point B text, not merely reviewed in isolation.
**Owning-file test pass (2026-09-14):** confirmed compatible. The
existing Decision Point B "Repairable?" section (Secondary Test) already
carries closely related language: "the secondary test never routes
an item directly to Reduction; Decision Point C remains the next sequential
step, so the irreversibility doctrine is unaffected even if this
heuristic proves wrong in practice." That sentence makes the same
narrow claim as the revised FI-2 language above — a routing decision
into Decision Point C is not itself an R4 authorization — without the rejected
draft's broader "does not authorize Reduction" overclaim. The two
should be cross-referenced when applied, not left as two independent
statements of the same principle.

---

### FL-009 — Cross-reference to a Gate_02_Triage.md worked example may be broken

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved** — historical claim annotated (both locations) rather than deleted, disposition withdrawn 2026-09-14 (Ratified by James) |
| Risk          | Low                                               |
| Priority      | Minor                                             |
| Type          | Cross-Module / G5 Cross-reference Integrity        |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-14                                        |

**Description:** FL-001's own Resolution Path (twice) states a
"motor worked example added to Operations/Gate_02_Triage.md (65%
torque → Decision Point A fail, Decision Point C pass)." Verified: no occurrence of
"torque" or "65%" exists anywhere in the current
`Operations/Gate_02_Triage.md`. Found while checking ChatGPT's
EV-008 finding (which only flagged the value as needing an
illustrative label) — the deeper issue is the referenced content
may not exist at all, or may have existed and been removed without
this cross-reference being updated.

**Why It Matters:** This file's own Resolution Log is treated as a
trustworthy historical record throughout this repository's audit
practice. A confirmed-false "this was added" claim, sitting
un-caught since presumably 2026-05-15, undermines that trust exactly
where it matters — in the record used to establish what evidence
actually exists.

**Resolution Path:**
- Check `Operations/Gate_02_Triage.md`'s own history/resolution log
  for whether this example was ever actually added and later
  removed, or never added despite the claim.
- If never added: either add it now (if still useful) or correct
  the Resolution Path text to stop claiming it exists.
- If it existed and was removed: note when/why in both files.

**Proposed Resolution (drafted 2026-09-13 in
`LazarusForge-1_Alpha_14_working_2026-09-13a.zip`; skeptical pass by
ChatGPT 2026-09-13 — Accept — cross-checked by Grok, verified by
Claude, tested against FL-001's actual Resolution Log text on
owning-file test pass 2026-09-14 — two locations identified):**
Do not silently strike the "65% torque" claim from FL-001's
Resolution Log. Instead, annotate it in three parts: (1) historical
claim — the prior entry stated a worked example existed in
`Operations/Gate_02_Triage.md`; (2) current verification — this
cannot be confirmed; zero matches for "torque" in that file as of
2026-09-13; (3) current disposition — the claim is withdrawn as
evidence of resolution. A short, labeled illustrative example may be
added later if still useful, as a separate, optional action. Status
remains Open until this annotation is applied and verified.
**Revision note:** the original draft proposed striking the claim
outright. Skeptical pass preferred preservation — deleting it would
erase the audit trail of what a prior pass believed to be true,
which is itself useful history distinct from present fact.
**Owning-file test pass (2026-09-14):** found two locations, not
one. FL-001's own Resolution Path already carries a partial fix — a
2026-09-10 discrepancy note (added when FL-009 was first raised)
states the claim can't be confirmed and points here. What's missing
there is only the explicit three-part structure and the "withdrawn"
disposition language. The second location — this file's historical
Resolution Log entry ("May 2026: FL-001 — Motor worked example
added... Partial resolution — boundary cases remain") — has never
been touched and still states the claim flatly with no annotation at
all. Applying this resolution means both locations, not just one.

---

### FL-010 — Pattern-triggered Oversight escalation has no state-machine representation

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved** — process-level Oversight trigger added, three-way consistency re-verified 2026-09-14 (Ratified by James) |
| Risk          | Low                                               |
| Priority      | Minor                                             |
| Type          | Architectural / Cross-Module                       |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-14                                        |

**Description:** Raised by ChatGPT (P5-001a). `Operations/Gate_01_Intake.md`
allows five consecutive unresolved unknown items to trigger
Oversight regardless of individual item status — a sensible
escalation mechanism, but one this file's formal Oversight model
(entered from Decision Point D failure or specific per-item exception
triggers) doesn't represent. Unclear whether this creates an
Oversight state for the affected items, for the operator/process, or
both — the state machine as currently written is item-level only.

**Why It Matters:** Not a contradiction, but a real gap between what
the formal model represents and a real escalation path that already
exists downstream.

**Resolution Path:**
- Decide whether pattern-triggered escalation needs its own entry
  in the Flow State/Transition Model or is better left as
  Gate_01-owned operational doctrine that feeds into the existing
  Oversight model without needing separate formal representation.

**Proposed Resolution (drafted 2026-09-13 in
`LazarusForge-1_Alpha_14_working_2026-09-13a.zip`; skeptical pass by
ChatGPT 2026-09-13 — Accept with wording tweak — cross-checked by
Grok, verified by Claude, tested against the live Exception
transitions text on owning-file test pass 2026-09-14 — confirmed
clean fit, insertion point identified):**
Add under Exception transitions / Oversight entry triggers:
"Pattern-triggered escalation (e.g., five consecutive unresolved
unknowns at Intake per `Operations/Gate_01_Intake.md`) triggers a
process-level Oversight review; affected items remain individually
held until the process exception is resolved." The "three consecutive
→ second review" and "five consecutive → Oversight escalation"
triggers are both confirmed present in substance in Gate_01_Intake.md
(paraphrased, not verbatim — that file reads "five consecutive
unknown items without resolution," this text reads "five
consecutive unresolved unknowns"; same trigger, different wording,
corrected 2026-09-14 after an earlier log entry overstated this as
"verbatim"). Status remains Open until the sentence is inserted and
cross-checked once more against any future changes to Gate_01's
trigger language.
**Revision note:** the original draft's phrase "enters Oversight as
a process-level exception" was revised to "triggers a process-level
Oversight review" — the original wording risked reading as a second,
parallel Oversight state machine distinct from the one Forge_flow
already defines. The revised phrasing keeps this as one Oversight
mechanism with two ways to reach it (item-level and process-level),
not two mechanisms.
**Owning-file test pass (2026-09-14):** confirmed clean. This file's
Exception transitions list (six bullets: jammed triage, sensor
drift, mid-process contamination, stale tooling, operator
unavailable, Component Library full) is entirely item-level, single-
cause triggers. FL-010's proposed bullet is a genuinely different
kind — a pattern across multiple items, not a single item's
condition — confirming the item-level/process-level distinction this
proposal draws is real, not invented. Fits as a 7th bullet in that
same list without altering any of the existing six.
**Re-verification (2026-09-14):** the "affected items remain
individually held" claim is genuinely supported, not assumed —
Gate_01's Unknown item sequence (step 7) explicitly forbids routing
an identification-unknown item to gate logic without at least
partial resolution, so items caught in a five-consecutive trigger
are categorically held from gate routing independent of their
hazard/FLAGGED status. All three elements ChatGPT asked to be
checked against each other (Gate_01's trigger, Forge_flow's
process-level trigger, individual-item Hold behavior) agree.

---

### FL-011 — Embedded Value Preservation checkpoint's ownership is unclear

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved** — EVP ownership assigned to Gate_02_Triage.md as an execution-stage requirement, 2026-09-14 (Ratified by James) |
| Risk          | Low                                               |
| Priority      | Minor                                             |
| Type          | Cross-Module / Interface                           |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-14                                        |

**Description:** Raised by ChatGPT (P5-003/IC-006). `Operations/Gate_02_Triage.md`
introduces an "Embedded Value Preservation" check before full
Reduction, which is sensible and aligned with salvage-first doctrine
— but this file's Decision Point D contract (§1.2) doesn't explicitly
incorporate it. Unclear whether this is an implementation detail
Gate_02/Gate_03 own internally, or a mandatory condition of Decision Point D's
own decision that this file has simply failed to represent.

**Why It Matters:** These are architecturally different answers —
one means Decision Point D's contract is complete and this is downstream
detail; the other means Decision Point D's contract is itself incomplete.

**Resolution Path:**
- Resolve during a dedicated Gate_02/Gate_03 audit rather than by
  guessing here — this file's Decision Point D language should not change
  until that ownership question is answered.

**Proposed Resolution (drafted 2026-09-13 in
`LazarusForge-1_Alpha_14_working_2026-09-13a.zip`; skeptical pass by
ChatGPT 2026-09-13 — Likely accept, strongly source-supported —
cross-checked by Grok, verified by Claude, target corrected by
Claude on owning-file test pass 2026-09-14):**
Assign ownership: Embedded Value Preservation is an Operations
execution-stage procedure owned by `Operations/Gate_02_Triage.md`
(its own text: Principle 9, applied after triage has already failed
a unit and before full Reduction, not reopening the pass/fail triage
decision; see that file's line ~215 for the accurate source
sentence, which needs no change). Add to *this* file's §1.2 Decision Point D
Decision Contract row: "Embedded Value Preservation
(`Operations/Gate_02_Triage.md` Principle 9) is an execution-stage
preservation requirement applied before full Reduction, not an
additional Gate-D decision predicate — Decision Point D's own contract remains
complete without it as a required input." Status remains Open until
Gate_02 confirms the assignment is accurate.
**Revision note:** the prior version of this block instructed
replacing "this file's current sentence" quoting the EVP sentence —
but the owning-file test pass (2026-09-14) found that exact sentence
is real and accurate, and lives in `Operations/Gate_02_Triage.md`
(confirmed at line 215), not in Forge_flow.md. Forge_flow.md has no
such sentence to replace; grepping this file for "Embedded Value"
turns up only FL-011's own Description, which correctly identifies
the actual problem as an *omission* — §1.2's Decision Point D row says nothing
about EVP at all. The fix is now framed as an addition to that row,
not a replacement of nonexistent text, and Gate_02_Triage.md is left
untouched since its sentence was never wrong.

---

### FL-012 — "Gate" terminology is overloaded across at least four distinct systems repository-wide

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved** — Gate terminology rename completed and fully swept 2026-09-14/15 (Ratified by James — "closed with much prejudice") |
| Risk          | Medium                                            |
| Priority      | Major                                             |
| Type          | Cross-Module / Terminology                         |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-15                                        |

**Description:** Raised by ChatGPT (P5-012), broader than the single
"Eight sequential decision gates" sentence already corrected in this
file's Scope Boundary. The repository uses "Gate" for four distinct
things: `Operations/Gate_01_Intake.md` through
`Operations/Gate_07_Utilization.md` (operational
modules), this file's Decision Point A–D (decision logic), the Human/AI
Oversight State (exception-resolution state), and Verification Gates
1-6 (document audit/promotion gates, defined in
`Admin/Verification_Gates.md`). `Verification_Gates.md` already
documents its own distinction carefully, but nothing repository-wide
ties all four usages together or warns a reader unfamiliar with the
convention.

**Why It Matters:** This is exactly the kind of collision that lets
an auditor (human or AI) answer the wrong question by matching the
wrong "Gate" system to a claim. The specific sentence in this file
that triggered this finding is fixed; the underlying repository-wide
overload is not.

**Resolution Path:**
- Consider whether `Admin/Canonical_Terms.md` should carry an
  explicit disambiguation entry for "Gate" the way it does for
  cross-reference path formatting — this is bigger than one file's
  fix and shouldn't be resolved unilaterally here.

**Proposed Resolution (drafted 2026-09-13 in
`LazarusForge-1_Alpha_14_working_2026-09-13a.zip`; skeptical pass by
ChatGPT 2026-09-13 — Accept — cross-checked by Grok, verified by
Claude, precedent confirmed against Canonical_Terms.md on owning-file
test pass 2026-09-14):**
Add a standing terminology note (Defined Terms or Scope Boundary
footer): "'Gate' is used in four distinct senses in this repository:
(1) operational modules Gate_01–Gate_07, (2) decision gates A–D
within this file, (3) the Oversight State, (4) Verification
Gates 1–6 (document audit/promotion, `Admin/Verification_Gates.md`).
Prefer qualified forms where ambiguity is possible (e.g.
`Operations/Gate_03_Reduction.md`, Decision Point D, Verification
Gate 3) — do not rely on surrounding context alone to disambiguate."
Recommend `Admin/Canonical_Terms.md` also carry the entry long-term
as a new "Disambiguation: Uses of 'Gate'" section, matching the
existing house style and placement of that file's "Disambiguation:
Uses of 'Canonical'" and "Disambiguation: Uses of 'Emergence' /
'Emergent Behavior'" sections (confirmed present, same format —
table of usage/meaning/example); this file can host the local note
without waiting. Status remains Open until the note is placed and
Canonical_Terms ownership is confirmed or explicitly deferred.
**Revision note:** "context or full path disambiguates" was replaced
with "prefer qualified forms where ambiguity is possible" — a bare
"Gate 3" is still ambiguous even when a paragraph reads as though
its meaning is obvious; qualified forms remove the ambiguity instead
of relying on a reader correctly inferring it.

---

### FL-013 — Oversight unavailability/saturation is not represented as a system-level degraded state

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | **Resolved — Payment via Specification, 2026-09-10** |
| Risk          | Low                                               |
| Priority      | Minor                                             |
| Type          | Architectural / Cross-Module                       |
| Blocking      | No                                                 |
| Owner         | Architecture/Forge_flow.md                          |
| First Logged  | 2026-09-10                                        |
| Last Reviewed | 2026-09-10                                        |

**Description:** Raised by ChatGPT (P5-014). `Operations/Gate_01_Intake.md`
recognizes that Oversight itself may be unavailable or saturated,
with a conservative fallback (remain held, do not route forward) —
consistent with this file's own doctrine. But this file currently
treats Oversight as though it's always an available state-transition
destination; the "Oversight unavailable → indefinite hold" case
isn't represented as its own degraded-mode entry the way stale
tooling, sensor drift, and other exception conditions are.

**Why It Matters:** Not a contradiction — Gate_01's fallback is
already conservative and correct — but a real gap between the
formal model and an operational reality the repository has already
anticipated elsewhere.

**Resolution Path:**
- Consider adding "Oversight unavailable" to the Degraded Operation
  & Failure Modes section's existing list, mirroring Gate_01's
  already-correct fallback.
- **Update 2026-09-10 (downstream audit pass, Gate_01_Intake.md):**
  confirmed and sharpened. Gate_01's own text explicitly states "No
  doctrine exists for Oversight saturation" and provides provisional
  guidance — items remain in hold, queue by priority (safety-critical
  first, then age), no expiration — correctly cross-referencing this
  file ("Architecture/Forge_flow.md Oversight State
  doctrine"). But the reference is one-directional: this file has
  nothing pointing back. The fix is now concrete, not speculative —
  add a Degraded Operation entry here that adopts Gate_01's
  provisional guidance by reference rather than restating it, closing
  the loop both files already half-built independently.

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | Low                                              |
| Priority      | Minor                                            |
| Type          | Architectural                                    |
| Blocking      | No                                               |
| Owner         | Architecture/Forge_flow.md                         |
| First Logged  | 2026-05-15                                       |
| Last Reviewed | 2026-05-15                                       |

**Description:** Whether "Purification stage" terminology
accurately represents the Material Separation Gate's
position in the flow, given that the Gate does not purify
in metallurgical terms.

**Why It Matters:** If the stage label causes semantic
drift or confusion as more mechanical separation modules
are added, repository-wide terminology propagation becomes
costly. Current standing definition is deliberately broad
and covers the Gate correctly — but the question is
deferred, not closed.

**Resolution Path:**
- Full dispute entry lives in Operations/Gate_04_Separation_Mechanical.md
  Active Disputes section.
- Resolution belongs here — if Purification stage
  definition is revised, Operations/Gate_04_Separation_Mechanical.md
  File Purpose and position statement must be updated
  to match.
- Recommended trigger for revisit: when a second
  mechanical separation module enters scope, at which
  point the stage label question becomes practically
  important.
- Discharge via Specification — once definition is
  confirmed stable or revised with repository-wide
  propagation.

---

### Resolution Log

- 2026-10-29: **X3 citation retrofit (mechanical, Architecture pass).** 3 bare colliding-prefix citations in operative body text qualified with their owning File.md per PKC-003, per the human-ruled Decision Brief 2026-10-29 item 4A (registry: `Admin/Forge_Audit_Kit.md` Governance Sidecar ID Reference, v1.30 edition; per-ID grounding: Unknowns active index). Citation-form-only; no ID renumbered; frozen history untouched; no gate advanced; Open Unknowns unchanged; flagged instances reported to the human (MAINT-17). (Vibe, Repo Custodian — delegated line.)

- 2026-10-25: **Cross-file assumption citations qualified (PKC-003 ruling; no doctrine change).** Three bare `ASM-` citations that sat beside another file's name, where that file also has an ASM with the same number, now say whose it is: the Decision Point B row of the Dependencies table (this file's ASM-003 / FL-004, not Tooling_Inventory's own ASM-003), the R4 note (Gate_03_Reduction's own GR-005, ASM-001, ASM-006), and the KPI Placeholder note (this file's ASM-006, not Energy's). No assumption, ID, Unknown, Spec Gate or Status changed. Human-directed.

- 2026-10-20: **Corrections and log catch-up from an external Skeptic/Auditor sweep (Vibe; human-directed; checked against source by Claude).** (1) *HP-001 contradiction fixed in two places.* Defined Terms said the Irreversibility Levels taxonomy was "not yet extended" to Gate_03 and that this "remains held"; the Reduction outcome path said Gate_03's "only irreversible step" language was "intentionally untouched pending separate review." Both were relics of the 2026-09-08 second pass; the third pass closed HP-001 the same day (Held Proposals row: Fully adopted, Closed) and Gate_03's current text uses R4 throughout. Both passages now say so. No safety intent changed. (2) *Dead references.* UNK-007 (FL-002, the Reduction outcome path and a Drift Indicator row) now points to GR-009 / MG-009, the logged envelope drift FL-002's own 2026-09-09 note describes; UNK-012 (FL-001) has no current counterpart and is annotated as retired with its target unrecorded; the generic Cross-module line is reworded (UNK-008 remains live). (3) *FL-006* status text pointed to §1.2 for the GOV-006 cross-reference; it lives in §1.3. (4) *FL-008–FL-012* Last Reviewed dates, which still read 2026-09-10, are set to their resolution dates. (5) *Logged retroactively* (previously recorded only in the sidecar entries and File State): FL-008 (FI-2 narrowed; Decision Point D independence re-verified; Ratified by James 2026-09-14); FL-009 (historical claim annotated in both locations rather than deleted; disposition withdrawn; Ratified 2026-09-14); FL-010 (process-level Oversight trigger added; three-way consistency re-verified; Ratified 2026-09-14); FL-011 (EVP ownership assigned to Gate_02_Triage.md as an execution-stage requirement; Ratified 2026-09-14); FL-012 (Gate terminology rename completed and fully swept 2026-09-14/15; Ratified by James); FL-006 (authority half B re-verified 2026-09-14 with the GOV-006 dependency cross-referenced; evidence half A structural owner named 2026-09-18 with `Operations/Exception_Evidence.md` created — still Open, not Resolved); and the 2026-10-02 Open Unknowns correction (7 → 6, as recorded in File State). (6) *File State* Last Audit and Auditor refreshed. Not changed: FL-009's diagnosis note — the sweep suggests the withdrawn claim may be a garbled memory of Gate_02's 64% motor worked example; that is unverified here, and the withdrawal stands either way. Human-directed.

- 2026-10-20: **Dispute ID disambiguated: DS-001 → FL-DS-001 (no content change to the dispute).** The bare ID "DS-001" was in use for four different disputes (the Auditor_Protocols dispute registered in `Unknowns.md`, this purification-stage terminology dispute, Gate_06's wire-sourcing dispute, and a closed naming dispute in `Tests/Trophic_Forge.md`). This dispute is now FL-DS-001 everywhere it is carried as live content (this file's Related Files and Defined Terms references, the Active Disputes row and its note, the Drift Indicator) and in its mirror in `Operations/Gate_04_Separation_Mechanical.md`; the row's two superseded names (a pre-rename Spin Chamber filename and "the Material Separation Gate") are updated to the current gate files. Earlier dated log entries below keep the bare "DS-001" as recorded — read them as this dispute. Bare `DS-001` now means only the Auditor_Protocols dispute. Raised by an external sweep (Vibe) and by Grok; checked against source by Claude. Human-directed.

- 2026-09-14 (rename pass, second tranche): **Gate_02_Triage.md operative body** renamed to Decision Point A–D / Oversight State; Lessons Learned and Auditor Notes left under historical names. Light pass on Gate_07, Tooling_Inventory, Discovery, Progress_Log, Electronics, Ops_Scope_Map. Canonical_Terms Disambiguation already updated in tranche 1. Archive/ untouched. FL-012 still Open pending final consistency sweep.

- 2026-09-14 (rename pass, first tranche): **Decision Gates A–D → Decision Points A–D; Human/AI Oversight Gate → Oversight State.** Operative body of this file updated; Resolution Log historical narrative left under original names (same discipline as FL-009 — do not rewrite history). Gate_01–Gate_07 and Verification Gates 1–6 unchanged. Defined Terms FL-012 note updated to reflect the rename. Cross-file follow-up still required (Gate_02, Gate_01, Gate_03, Canonical_Terms, Ethical_Constraints, Discovery). FL-012 remains Open until Canonical_Terms Disambiguation section matches. Human-directed.

- 2026-09-12 (twenty-fifth pass): **FL-007 resolved — Reading A adopted for Terminate authority.** Human directed that Oversight Terminate is an independent authorization path for Reduction (parallel to Gate D YES), with ideological flexibility for rare unanticipated exceptions rather than an exhaustive catalogue. Applied: (1) Terminate exit and Gate D want/need evaluation reworded to "Reduction is authorized"; (2) explicit "routing ≠ authorization ≠ execution readiness" doctrine added to Oversight section; (3) bounded-discretion proviso added (logged, Ethical_Constraints-consistent, no Gate_03 readiness bypass); (4) Decision Contract Oversight row and notes updated to match; (5) FL-007 marked Resolved (Payment via Specification). Gate_03 dual entry corridor confirmed rather than narrowed. FL-006 authority-ownership half remains Open (Escalate destination still unnamed). Open Unknowns 13→12. Human-directed.

- 2026-09-10 (twenty-fourth pass): **FL-013 resolved via downstream audit into Operations/Gate_01_Intake.md.** Per the ChatGPT audit's own recommendation to move downstream using this file's findings as baseline. Verified Gate_01's File State (Open Unknowns 5 correctly matches GI-001/002/003/005/007; GI-004/006 correctly Resolved), confirmed zero bare canonical-path violations there, and confirmed several of ChatGPT's Phase 5 claims (P5-001, P5-001a, P5-014) accurate against live text. Found that Gate_01 already has provisional "Oversight saturation" doctrine (items remain held, priority-queued, no expiration) that correctly cross-references this file — but nothing here pointed back. Added a new "Oversight itself unavailable or saturated" entry to the Degraded Operation & Failure Modes section, adopting Gate_01's doctrine by reference rather than restating it, closing FL-013. Removed from Active Index in Unknowns.md per Size Management Rule 2 (Resolved entries are removed, not marked in place — same discipline that caught RIP-003/RIP-010 earlier). Open Unknowns 14→13. Human-directed.

- 2026-09-10 (twenty-third pass): **ChatGPT's Phases 7-10 (Drift Detection, Unknown Classification, Resolution Pathway Assessment, Verification Gates) processed — largely stale on arrival.** This batch ran against the pre-twenty-second-pass snapshot; most of its "confirmed" findings (stale Last Audit, stale Gate Correspondence, "eight sequential decision gates," bare filenames/G5) were already fixed the prior pass — verified directly rather than assumed, including a full-file re-check confirming zero bare canonical-path violations remain anywhere, not just in the sections touched previously. Also caught a real arithmetic inconsistency in the audit's own Phase 10 scorecard: its prose claimed "2/6 PASS... 2 FAIL and 2 REVISE" while its own table showed 1 PASS/2 FAIL/3 REVISE (G1/G2/G6 REVISE, G3/G5 FAIL, G4 PASS) — Spec Gates left at 0/6 rather than propagating either count, since recording a formal G1-G6 tally is a governance action this pass didn't attempt. Genuinely new and actioned: FL-004's title corrected (was still "has no owning file" despite the file existing — now names the real residual question); FL-006's Risk/Priority raised Low/Minor→Medium/Major, matching FL-007's prior treatment, per Phase 8's argument that Oversight's authority gap is a separation-of-powers question, not filing; FL-003/FL-004/FL-006/FL-007's Resolution Paths all sharpened per Phase 9's stricter "would executing this path actually close the Unknown" test — FL-006 split into evidence-ownership vs authority-ownership sub-paths, FL-007 restructured into an explicit seven-step closure sequence. G1 Fallacy Checklist and G3 Adversarial Challenge Battery formally documented for the first time (new sections added) rather than left as historical Resolution-Log reasoning checks — both honestly REVISE, findings routed to FL-006/007/008/009/012 rather than duplicated; G3 applied 3 of 10 classes with concrete scenarios meeting their stated minimum requirements, deferred the other 7 rather than stretching existing scenarios to cover them. No Open Unknowns count change — this pass strengthened existing entries, didn't add new ones. Human-directed throughout.

- 2026-09-10 (twenty-second pass): **ChatGPT's six-phase audit (Phases 1-6, Auditor_Protocols.md v0.41) batch-processed.** Every substantive claim verified against live source before action — all checked out except one location error in the audit's own output (EV-011 misattributed a real, accurately-quoted sentence to "Termination Conditions"; it's actually in Example 3). Six mechanical/structural fixes applied directly: restored the missing `## Lessons Learned` heading over a table that already existed with real content but had been orphaned without one (F1-001); corrected the Gate Correspondence table's stale Oversight row, unchanged since before HP-002 formalized the five exits (IC-004/P5-013); fixed FL-003's Description, which had drifted into contradicting the Scope Boundary update made during HP-006 (S2-002); reworded "Eight sequential decision gates" to stop conflating this file's 5 decision gates with the unrelated Gate_01-07 operational modules (P5-012/S2-007); fully-qualified §1.3's bare filenames per Canonical_Terms.md (G5, Finding 9) — caught and fixed the identical violation appearing in my own new FL-012 entry while writing it; labeled Examples 4/5's illustrative values (45 min, 1.2 m) as non-measured (EV-006/007) and clarified Example 3's "all pass technically" phrasing (EV-011). FL-007 strengthened with cross-file evidence from `Gate_03_Reduction.md` and `Ethical_Constraints.md` (Risk Low→Medium, Priority Minor→Major). Six new Unknowns registered — FL-008 (FI-2's invariant wording is ambiguous against the stale-tooling exception), FL-009 (a genuinely new finding beyond the audit itself: FL-001's Resolution Path cites a `Gate_02_Triage.md` worked example that doesn't exist), FL-010 (pattern-triggered Oversight escalation unrepresented), FL-011 (Embedded Value Preservation ownership unclear), FL-012 (repo-wide "Gate" terminology overload), FL-013 (Oversight-unavailable degraded state unrepresented) — all mirrored in Unknowns.md v5.11. Open Unknowns 8→14. Human-directed throughout; explicit instruction to log rather than silently resolve the open architectural questions.

- 2026-09-10 (twenty-first pass): **FL-007 registered.** ChatGPT reviewed the 2026-09-10 working tree (verified: file size 108,850 bytes, all quoted passages accurate) and raised a real architectural ambiguity: Oversight's "Gate D want/need evaluation" is scoped to items that already passed Gate D's material-recovery determination, then can override that outcome via the Hold exit using a different judgment axis (retained-use need vs material-recovery viability) — the text never states whether this is override authority or only timing authority. Logged rather than resolved, per ChatGPT's own conservative recommendation and matching the standing practice of not editing gate logic to fix an unsettled authority question. Related to FL-006, cross-referenced both directions. Open Unknowns 7→8. Human-directed.

- 2026-09-09 (twentieth pass): **FL-002 scoped, not closed.** Confirmed still blocked on GR-002 (Reduction method not yet selected). Found the two provisional envelope tables standing in for real cross-validation (Gate_03's §4, Gate_04's Inputs section) have drifted from each other; logged as GR-009/MG-009 in both files' sidecars and Unknowns.md v5.08, per explicit human direction to log rather than fix. Also found and fixed, while placing MG-009: `Gate_04_Separation_Mechanical.md` had its entire Resolution Log duplicated into two diverged copies. Merged chronologically; first merge attempt placed the result at the wrong end of the file (matching a since-superseded assumption about section order) and was self-corrected after checking the confirmed-canonical order in three other files. Human-directed.

- 2026-09-09 (nineteenth pass): **HP-013 adopted.** Added a Lifecycle loop note to the Flow State/Transition Model, naming two mechanisms that already existed but were never connected: Feedback (§7, already in this file) closes the doctrine loop, and re-triage (already in `Gate_02_Triage.md` — "components that fail in Forge service re-enter triage at Station 0") closes the material loop. Together they make the system circular rather than terminating at Fabrication/Utilization, as ChatGPT's original HP-013 proposal argued. Strengthened §5's "Fabrication is not terminal" line with a pointer to the new note. Framing only — no new routing rule, no gate logic touched. Caught and fixed a self-introduced stray-asterisk formatting glitch (same class as the one fixed in an earlier pass) before finalizing. Human-directed.

- 2026-09-09 (eighteenth pass): **FL-005 observation log format now exists (not FL-005 closed).** Grok drafted a scoping analysis for Gate B Secondary Test observation data plus an inter-operator bias-pattern analysis (both correctly framed as prospective — no real data exists yet). Its own scoping question ("is there already a log format to extend?") went unchecked by its author; checked it here — `Operations/Gate_02_Triage.md` already has a TIL v0 Log Specification (§XII.1a) with substantial field overlap. Extended it as §XII.1b rather than creating a parallel schema. FL-005's Resolution Path updated with a pointer to the new spec. FL-005 itself remains Open — the log format existing is a prerequisite for closing it, not the closure. Human-directed.

- 2026-09-09 (seventeenth pass): **HP-011 adopted as §1.3 Transition Ownership.** Scoped to the four main gates + Oversight per Grok's own sequencing note. Built from existing cross-references — Gate Correspondence's "triage station outcomes map to these gates" pointer to `Gate_02_Triage.md`, Gate B's ASM-003/Tooling_Inventory.md dependency, Gate D's split between `Gate_02_Triage.md` (evidence) and `Gate_03_Reduction.md` (downstream procedure) — not newly invented. Found two real things while building it: (1) Oversight has no assigned Operations or Admin owner at all, registered as FL-006 (Open, Minor) both here and Unknowns.md v5.07; (2) FL-005's Resolution Path had a stray closing line that actually belonged to FL-004's topic, a leftover from an earlier insertion — removed. Open Unknowns count updated 6→7 to include FL-006. Human-directed.

- 2026-09-09 (sixteenth pass): **File State housekeeping.** Grok's status summary repeated the header's "Open Unknowns: 2" as fact without recounting — actual count of Open unknowns owned by this file is 6 (FL-001 through FL-005, all confirmed Status: Open, plus DS-001 in Active Disputes). Corrected. Also bumped Last Audit, stale since the original 2026-09-08 entry despite fifteen subsequent resolution-log passes the same two days — Grok's own report flagged this as "minor housekeeping" and it checked out. Active Disputes (1) and Spec Gates (0/6) verified accurate, no change needed there. Human-directed (review requested, not a specific instruction — findings actioned directly since both were simple factual corrections).

- 2026-09-08 (fifteenth pass): **HP-014 adopted.** Defined "terminal for current processing" (exits this pass through the flow, eligible for future re-entry) vs "terminal for recovery" (no further recovery pathway under current capability) in the Flow State/Transition Model's Terminal states line, replacing the flatter "active use, stored stock, inert waste" list. Tagged Component Library and Repurpose as terminal-for-current-processing; tagged Reduction as terminal-for-recovery, with a self-caught correction mid-edit — Reduction (R4) is the point past which the item can't be recovered as a discrete object, but the actual "inert waste" endpoint is reached after Purification, not at Reduction itself; the first draft of the tag overstated this and was fixed before finalizing. Human-directed.

- 2026-09-08 (fourteenth pass): **First implementation package from ChatGPT's Alpha 13 roadmap: HP-008, HP-009 (partial), HP-015.** Grok refined ChatGPT's 10-item roadmap into a risk-ranked sequence and recommended these three as a "mutually reinforcing, no new decision rules" first package. Verified Grok's draft decision-contract table against live Gate A-D/Oversight text before inserting — accurate, pure extraction. Added §1.2 Gate Decision Contracts after Flow Invariants (HP-008); added explicit PASS/FAIL/UNKNOWN per-gate transitions to the Flow State/Transition Model, gate body text untouched (HP-009, scoped slice only — full version stays open, tied to HP-010); added a numbered 6-point re-entry contract after the ASM-007 re-entry transitions bullet (HP-015) — only point 5 (no automatic inheritance of the parent assembly's failure state) was genuinely new specificity, the other five were already implied. Also fixed a pre-existing stray-asterisk markdown formatting glitch in the Oversight Gate exits bullet, encountered while editing that section. HP-010, HP-012, and the rest of the roadmap remain held per Grok's own sequencing (HP-010/HP-012 explicitly gated on Gate B observational data; HP-016 gated on this package plus HP-010/HP-012 being stable first). Human-directed.

- 2026-09-08 (thirteenth pass, on Alpha 13): **ChatGPT's Alpha 13 roadmap logged as HP-008 through HP-016, not actioned.** ChatGPT reviewed the released Alpha 13 tree and proposed ten changes toward making Forge_flow.md "a testable state-transition specification": a per-gate decision contract, explicit UNKNOWN transitions, three-valued gate logic with an evidence-sufficiency check, per-transition ownership, a Split primitive, lifecycle-loop strengthening, terminal-state distinctions, a formal re-entry contract, and a boundary matrix to eventually replace the growing example collection. Verified the file-size claim (82,271 bytes) and the specific claims about existing content (FI-1, R0-R4, five Oversight exits, Example 6) against the live file — all accurate. James chose to log the whole roadmap as held proposals rather than start any of it this session. Two items (three-valued logic, Split primitive) flagged as genuine new logic requiring the same caution as the Gate B Secondary Test; one item (boundary matrix) flagged as structurally bigger than it reads, likely requiring restructuring of Examples 1-7 rather than pure addition. ChatGPT's own "what I'd leave alone" list (don't expand KPI/FI-1, don't extend R0-R4 without Operations data, don't add more Oversight exits, don't make Gate B mathematical yet) already matches where this file stands — no action needed there. Human-directed.

- 2026-09-08 (twelfth pass): **Per-deployment clarification (human-raised).** James pointed out that this repository is shared and forked across independent Forge builds — his own real-world data (or any single session's) is not globally representative and must never be treated as canonical. Checked the repo for an existing named principle covering this — none found, though the concept appears scattered across a dozen files. James chose to fix the specific wording now (Tooling_Inventory.md, FL-004, FL-005) rather than formalize a new invariant. Clarified: FL-004's Resolution Path now states population closes the entry per-deployment, not globally; FL-005's Resolution Path now specifies operator-divergence checks are within-site, and cross-site divergence in Secondary Test outcomes is expected, not a determinism problem. Human-directed.

- 2026-09-08 (eleventh pass): **HP-003 adopted as a 4-invariant Flow Invariants section.** Checked File_Template.md for an existing "Invariant" convention — none exists in the template itself — but found real precedent in `Architecture/Forge_Net.md`'s §1.1 Network Invariants (NI-1 through NI-8, Grok-drafted, consolidation-only, Candidate-doctrine status marker), so this doesn't introduce an unprecedented category. Given the choice between the original narrow scope (just the KPI sentence) and matching Forge_Net's multi-invariant consolidation, human chose the latter. Added §1.1 Flow Invariants after the Flow State/Transition Model section: FI-1 (KPI subordination, the original HP-003 target), FI-2 (uncertainty defaults to hold — from Degraded Operation's standing rule), FI-3 (discrete items only — ASM-007), FI-4 (Reduction as residual path — Operational Safety Advisory). Each points at its existing mechanism home rather than restating the rule, matching Forge_Net's own discipline. Human-directed.

- 2026-09-08 (ninth pass): **Gate B Secondary Test adopted, flagged more heavily provisional than the source proposal (Grok's Option 1).** Unlike this file's other same-day changes, this is genuine new gate logic — items that previously passed Gate B unconditionally can now route to Gate C instead, based on a qualitative "justified effort" judgment. Applied Grok's exact Option 1 wording as the base, then added a stronger Provisional/unvalidated notice per explicit human direction ("apply, but flag it more heavily as Exploration-grade/provisional"). Updated Example 4, which had asserted Gate B does NOT test cost/effort — now stale given the new Secondary Test, rewritten to walk through Primary Test then Secondary Test explicitly. Registered FL-005 (Blocking) for the test's unvalidated status, both here and Unknowns.md v5.04. HP-005 updated to note the Gate B threshold moved from "unadopted" to "adopted but provisional." Human-directed; explicitly chose the more-cautious framing over applying the source draft as-is.

- 2026-09-08 (eighth pass): **HP-005 partially complete — Examples 4-7 added.** Grok drafted the case content (bench grinder/repairable-not-worth-it, aluminum extrusion/repurpose-vs-recovery, mixed plastic-metal/unknown material, hydraulic pump/incomplete-conflicting evidence), verified and adapted before insertion: fixed an internal inconsistency in the repair-cost example (its own Key Principle said cost/effort is a secondary signal, not a Gate B test, but the body draft had briefly implied otherwise — corrected to match); added HP-002's Oversight exit tags (Hold) where relevant for consistency with the formalized exit model. Inserted as Examples 4-7 after Example 3. FL-001 Resolution Path and HP-005 updated — remaining gap is complex multi-component assemblies beyond Example 1, and an optional (unadopted) Gate B cost/effort threshold. Human-directed.

- 2026-09-08 (seventh pass): **FL-004 and HP-007 logged (not actioned).** Verified Grok's ASM-003-vs-Components.md gap finding against source: Components.md is a system-component taxonomy (Critical/Useful/Bootstrap), contains no tooling-inventory content, and doesn't claim ASM-003's ownership. Registered the gap as FL-004 (Open) here and in Unknowns.md v5.03. Logged the drafted `Operations/Tooling_Inventory.md` skeleton as HP-007 in Held Proposals — file not created. Per James: "let's get it logged, for now" — deliberately a logging-only pass. Human-directed.

- 2026-09-08 (sixth pass): **HP-004 resolved (Grok-drafted Option A, Claude-verified before applying).** Rewrote Gate D from a double-negated compound test to a single positive question: "Is Reduction the correct residual path for material recovery under current Forge capability?" Routing outcomes unchanged. Checked both side effects Grok's own writeup flagged: Gate Correspondence table row updated to match ("Is Reduction the correct residual path?"); worked Examples 1 and 2 checked against the new framing and found already consistent — neither needed edits, since both already routed material to Reduction on the basis of "material recovery value remains," not the old inverted clause. FL-001 Resolution Path updated to reflect the rewrite. Human-directed.

- 2026-09-08 (fifth pass): **HP-002 adopted.** Reviewed the Oversight Gate section against every place it's actually invoked in the document (Gate D failure, contamination mid-process, radiological hazard, operator unavailable, unforeseen contamination category) and found the five proposed exits already existed as scattered, unnamed case-specific behavior — this was a naming/consolidation pass, not new gate logic, so it did not trigger the "gate logic modified without FL-001 resolution" concern originally flagged when this was held. Formalized as Return to Flow / Hold / Reclassify / Escalate / Terminate; tagged all five scattered instances with their exit name; the two previously-binary Gate D outcomes (assign-with-review-date, Reduction) are now explicitly Hold and Terminate respectively, with identical underlying logic. No routing rule changed. Flow State/Transition Model section updated to match. Human-directed.

- 2026-09-08 (fourth pass): **HP-006 first pass complete.** Cross-checked every "DOES NOT define → see X" pointer across Forge_flow.md, Gate_02/03/04/05, Energy.md, and Forge_Net.md against the receiving file's actual DOES-define claims and body text (not just Scope Boundary summaries). Most reconciled cleanly. Found four orphaned handoffs — a term used/pointed-to on one side with zero acknowledgment on the receiving side: "Unknown Bulk" (Gate_04→Gate_02), "Class C" (Gate_04→Gate_05), battery chemistry sorting (Energy.md→Gate_02), self-replication architecture (Gate_05→Forge_flow.md, this file). Registered as TS-009, TS-010, SC-010, FL-003 in each owning file's sidecar and in Unknowns.md v5.02; added one-line stub acknowledgments to each receiving file's Scope Boundary. Did not require HP-005 first — the dependency noted when HP-006 was logged applies to gate-determinism validation, not ownership cross-checking, which turned out to be a tractable independent pass since every file already had self-declared Scope Boundary sections. Human-directed.

- 2026-09-08 (third pass): **HP-001 closed.** Grok proposed the R4-aligned rewording for Gate_03_Reduction.md's GR-005/ASM-001 safety-doctrine language. Claude verified all 8 cited passages against the live file before applying (exact matches) and found one additional un-graded occurrence, ASM-006, not in Grok's original diff — same category, included. Applied to Gate_03_Reduction.md; see that file's own 2026-09-08 Resolution Log entry for the full list. No safety intent changed. HP-001 row updated to Closed.

- 2026-09-08 (second pass): **HP-001 partially adopted.** Added
  Irreversibility Levels taxonomy (R0-R4) to Defined Terms.
  Applied to Forge_flow.md only: tagged Component Library (R0)
  and Repair & Learn (R2) reversibility notes; reworded three
  descriptive "only fully irreversible step" occurrences (Safety
  Advisory, Reduction outcome path, FL-002 Why It Matters) to R4
  framing. Deliberately did NOT touch Operations/Gate_03_Reduction.md
  — GR-005 and ASM-001 there anchor human-presence safety
  requirements to the un-graded phrase, and that's a safety-doctrine
  edit requiring separate explicit review, not a vocabulary
  extension. HP-001 row updated to reflect partial status.

- 2026-09-08: **Refinement pass on ChatGPT proposal (Claude-verified
  subset only).** Added Flow State/Transition Model section —
  pure consolidation of existing states/transitions, no new logic.
  Gate D renamed "Truly Exhausted?" → "Material Recovery Viability"
  for testability; original routing polarity preserved exactly;
  a latent test-polarity ambiguity was noticed and logged (not
  fixed) as HP-004. FL-001 sidecar Last Reviewed corrected from
  stale 2026-05-16 to 2026-09-08 to match actual Resolution Log
  activity. Six other ChatGPT-proposed items (irreversibility
  levels R0-R4, Oversight multi-exit reframe, KPI-as-Flow-Invariant,
  Gate D polarity fix, FL-001 boundary matrix, cross-layer
  reconciliation pass) logged in new Held Proposals section below —
  not adopted, not started. Human-directed; ChatGPT's claims
  independently checked against source before any action (one
  overreach found: "contamination-handling actions could presumably
  alter material condition" was unsupported speculation, excluded
  from rationale).

- 2026-08-10: **Pseudo-audit (Grok, same limits).** Findings only; Spec Gates
  left locked at 0/6. (1) Open Unknowns **2** = FL-001, FL-002, matches local +
  `Unknowns.md`. (2) FL-001 correctly **Blocking Yes** (blocks promotion to
  Specification — Epistemic/Promo style, field already accurate). (3) FL-002
  Open/Major, Blocking No — Reduction module ownership is Gate_03, not a
  start-interlock here. (4) No FL-* closed. Human-directed.

- 2026-08-08: **Two Scope Boundary corrections, both surfaced by
  `Architecture/Arc_Scope_Map.md` (2026-08-08 folder-scope-map build):**
  (1) the UNK-008 fabrication/wire-qualification reference still said
  "no owner assigned" — stale since 2026-07-19, when ownership moved to
  `Architecture/Geck_forge_seed.md`; this session's own 2026-08-06
  Feedstock Self-Sufficiency patch had already built doctrine on that
  ownership. Corrected to point at the real owner. (2) the shared-
  vocabulary DOES bullet claimed sole reference-standard status without
  acknowledging `Admin/Canonical_Terms.md` exists — `Canonical_Terms.md`
  already correctly deferred to this file from its own side, so nothing
  was actually in conflict, just asymmetrically documented. Added a
  one-sentence reciprocal acknowledgment. Neither correction changes this
  file's actual authority or scope — both are documentation catching up
  to a state that was already true. One of the oldest files in the
  repository (RS-002 dates to 2026-06-11); worth noting that age alone
  is exactly why a stale cross-reference like the UNK-008 one can sit
  unnoticed this long — the file predates the ownership reassignment it
  was still describing. Human-directed.

- 2026-06-11: RS-002 resolved — `Forge_Flow.md` casing outlier corrected to
  `Forge_flow.md` in Archive/Rename_Registry.md. Canonical filename confirmed
  as `Forge_flow.md` throughout repository.
- 2026-06-06: Reference corrections pass — Navigation Anchors block added;
  Verification Ref corrected to Admin/Verification_Gates.md; all stale
  filenames updated per Rename Registry (Spin_Chamber_v0.md,
  Material_Separation_Gate_v0.md, Component_Triage_System.md, energy_v0.md,
  Trajectories_LF.md, Unknowns_LF.md, Air_Scrubber_v0.md, geck_forge_seed.md,
  Reduction_v0.md, Lazarus_forge_v0_flow.md); UNK-006 facility siting reference
  updated to Architecture/Facilities.md. Content unchanged.
  requires original application context. Gate C/D boundary
  clarified — functional vs. material integrity tests.
  Defined Terms section added. Reversibility notes added
  per outcome path. KPI labeled Placeholder. Gate
  Correspondence table added.
- May 2026: FL-001 — Motor worked example added to
  Operations/Gate_02_Triage.md (65% torque → Gate A fail,
  Gate C pass). Partial resolution — boundary cases remain.
  **Current verification (2026-09-10/FL-009): this claim cannot be
  confirmed — no such content exists in Gate_02_Triage.md.
  Disposition (2026-09-14): withdrawn as evidence of resolution;
  see FL-001's Resolution Path and FL-009 for the full annotation.
  Historical entry preserved above, not deleted.**
- 2026-05-15: FL-001 — Assembly disassembly clarification
  added. Gate logic applies to discrete items not fixed
  assemblies. Disassembly is a Gate C decision on the
  assembly — components re-enter at Gate A independently.
  Sequential order preserved at component level. See
  ASM-007 and Lessons Learned entry 2026-05-15. Status
  remains In Progress — Gate C/D boundary worked example
  and Oversight Gate edge cases still needed.
- 2026-05-15: FL-001 — Reformatted from prose to structured
  sidecar table format. Content preserved, provenance
  dates maintained.
- 2026-05-15: FL-002 — New entry. Reduction module
  unassigned. Upstream dependency for Material Separation
  Gate identified and indexed. Cross-referenced UNK-007
  in Unknowns.md.
- 2026-05-15: DS-001 — New reference entry. Purification
  stage terminology dispute logged. Full entry in
  Operations/Gate_04_Separation_Mechanical.md Active Disputes. Owner
  confirmed as this file. Resolution deferred until second
  mechanical separation module enters scope.
- 2026-05-16: FL-001 — Five boundary-case worked examples
  added. Five adversarial routing scenarios added. Genuine
  need minimum criteria added to Oversight Gate. KPI
  subordination note added. Degraded operation subsection
  added. Reduction under-specification explicitly stated.
  Governing language softened in File Purpose. Unknown ID
  naming convention documented. Status remains In Progress —
  additional boundary cases expected from operational runs.
  Last Reviewed updated to 2026-05-16.

---

## Held Proposals (Not Committed)

*Ideas worth preserving but not yet scoped or started — distinct*
*from Auditor Notes & Unknowns (active, blocking or trackable gaps)*
*and from Abandoned Paths (considered and rejected). A Held entry is*
*neither. Promote to a numbered Unknown (FL-*) when someone commits*
*to scoping it; move to Abandoned Paths if reconsidered and rejected.*

| ID | Proposal | Why Held | Logged |
|----|----------|----------|--------|
| HP-001 | ~~Irreversibility Levels taxonomy (R0-R4)~~ **Fully adopted 2026-09-08.** Taxonomy in Defined Terms; applied throughout Forge_flow.md (Component Library R0, Repair & Learn R2, three descriptive occurrences reworded to R4). Gate_03_Reduction.md's GR-005/ASM-001 safety-doctrine language also aligned to R4 (Grok-proposed, Claude-verified against source before applying; one additional occurrence, ASM-006, found and included). No safety intent changed — see Gate_03_Reduction.md Resolution Log 2026-09-08 entry | Closed | 2026-09-08 |
| HP-002 | ~~Reframe Human/AI Oversight Gate as a formal multi-exit exception-state~~ **Adopted 2026-09-08.** Found the five exits weren't new — they were already scattered as specific-case behavior (sensor drift, contamination mid-process, radiological escalation, operator unavailable, Gate D want/need) with no common naming. Formalized as Return to Flow / Hold / Reclassify / Escalate / Terminate; each scattered instance tagged with its exit name; no routing rule changed | Was a genuine consolidation, not new logic — did not require the caution originally flagged | 2026-09-08 |
| HP-003 | ~~Elevate the KPI-subordination sentence to a named "Flow Invariant" category~~ **Adopted 2026-09-08 as part of a 4-invariant Flow Invariants section (§1.1)**, matching real repo precedent found in Architecture/Forge_Net.md's Network Invariants (NI-1-8) — same consolidation-only pattern, same Candidate-doctrine status marker. Scope expanded from the single KPI sentence to include three other candidate rules already stated elsewhere (uncertainty-defaults-to-hold, discrete-items-only, Reduction-as-residual-path), per explicit human direction to match Forge_Net's multi-invariant pattern rather than adopt just one | Was flagged as needing a File_Template.md convention check before use — checked: no "Invariant" concept exists in the template itself, but real precedent exists elsewhere in the repo (Forge_Net.md), so this doesn't introduce an unprecedented category | 2026-09-08 |
| HP-004 | ~~Gate D's compound test reads ambiguous~~ **Resolved 2026-09-08 (Option A rewrite).** Rewrote as a single positive question ("Is Reduction the correct residual path?") instead of the double-negated compound test. Routing outcomes unchanged — same items still route the same places — only the test's phrasing changed. Gate Correspondence table row aligned to match; worked Examples 1 and 2 checked and already consistent with the new framing, no edit needed there | Was flagged as needing FL-001 treatment since it's a logic-adjacent change — treated with that care: verified against Gate Correspondence table and both existing worked examples before closing, not a silent edit | 2026-09-08 |
| HP-005 | ~~FL-001 boundary-determinism matrix~~ **Partially complete 2026-09-08.** Examples 4-7 added, closing repairable-not-worth-it, repurpose-vs-recovery, unknown material, and incomplete/conflicting evidence. Remaining gap: complex multi-component assemblies beyond Example 1's drill case — flagged in Lessons Learned as still needed. **Update, same day:** the Gate B cost/effort threshold noted here as "optional/unadopted" was adopted a few passes later as a Secondary Test — see Gate B section's Provisional notice and the tenth-pass Resolution Log entry. Example 4 updated to match | Residual scope is now narrower still — complex assemblies is the one clearly-open item; Gate B's new Secondary Test is adopted but explicitly flagged Provisional/unvalidated, not closed | 2026-09-08 |
| HP-006 | ~~Cross-layer reconciliation pass~~ **First pass complete 2026-09-08.** Cross-checked every Scope Boundary pointer across Forge_flow.md, Gate_02/03/04/05, Energy.md, Forge_Net.md — reconciled cleanly overall (including good triangulation on shared owners like Energy.md/Facilities.md). Found four orphaned handoffs, spun off as new Unknowns: TS-009, TS-010, SC-010, FL-003 (see Unknowns.md v5.02). Did not require HP-005/FL-001 closure first — ownership cross-checking was independent of gate-determinism validation | Closed as a pass; residual work now lives in the four spun-off Unknowns, not here | 2026-09-08 |
| HP-007 | ~~Create `Operations/Tooling_Inventory.md`~~ **Done 2026-09-08.** Grok created the file from the drafted skeleton; Claude reviewed it (clean diff against the rest of the repo — only this one new file), found and fixed two File_Template.md gaps (missing Lessons Learned and Active Disputes sections, both required even when empty), added the Components.md cross-reference stub the original draft had prepared but not applied, updated FL-004 to reflect the file's existence, and mirrored TI-001 into Unknowns.md. Inventory tables remain unpopulated — see TI-001 in that file, which stays open until first physical count | Closed as a pass; residual work (first physical inventory, owner assignment) lives in TI-001, not here | 2026-09-08 |
| HP-008 | ~~Per-gate "decision contract" table~~ **Adopted 2026-09-08 as §1.2 Gate Decision Contracts.** Pure extraction from live text — Required Inputs/Decision Question/Permitted Outputs/Uncertainty Output for Gates A-D and Oversight. No new routing rules; verified against the live text before insertion | Low-risk, consolidation-flavored — formalizes what's mostly already implied per gate. ChatGPT's Alpha 13 roadmap, ranked lowest-risk by both ChatGPT and Claude | 2026-09-08 |
| HP-009 | ~~Explicit UNKNOWN branch~~ **Partially adopted 2026-09-08** (the scoped "recommended first package" slice). Added explicit PASS/FAIL/UNKNOWN per-gate transitions to the Flow State/Transition Model. Gate body text and decision logic untouched — this only makes FI-2 mechanically visible. Full HP-009 (deeper transition-model formalization) remains open if more is wanted later | Closely tied to HP-010 (three-valued logic) — the full version is better scoped together with that; this slice deliberately stayed inside the "no new decision rules" boundary | 2026-09-08 |
| HP-010 | Three-valued gate logic (YES / NO / INDETERMINATE) plus an Evidence Sufficiency Check preceding each gate's actual test | Genuine new logic, same risk category as the Gate B Secondary Test (FL-005) — would touch every gate's decision structure, not just Gate B. Needs the same explicit go-ahead and provisional framing that Secondary Test got | 2026-09-08 |
| HP-011 | ~~Explicit per-transition ownership table~~ **Adopted 2026-09-09 as §1.3 Transition Ownership**, scoped to the four main gates + Oversight per Grok's own sequencing. Verified against existing cross-references (Gate Correspondence's "triage station outcomes map to these gates" statement) rather than newly assigned. Found and registered a real gap: Oversight has no assigned Operations or Admin owner (FL-006). Also found and fixed a stray-line content bug in FL-005 left over from an earlier insertion | Builds directly on this session's HP-006 cross-layer reconciliation work — plausible medium-risk consolidation, but scope (every transition, not just the four HP-006 found) is larger than a quick pass | 2026-09-08 |
| HP-012 | Explicit "Split" transition primitive — a gate may divide an input into independently routable outputs when portions have materially different recovery states (e.g. Example 5's aluminum extrusion) | New mechanism, not consolidation — Example 5 currently handles this via prose ("cut and sent to Reduction; good length to Component Library") without a named primitive. Real logic addition | 2026-09-08 |
| HP-013 | ~~Strengthen the lifecycle model~~ **Adopted 2026-09-09.** Added a Lifecycle loop note to the Flow State/Transition Model distinguishing the doctrine loop (Feedback, §7) from the material loop (re-triage, already in `Gate_02_Triage.md`) — both existed already, neither was previously named as forming a loop. Strengthened §5's "Fabrication is not terminal" line with a pointer. Framing only, no new routing rule, scoped smaller than originally feared (didn't require touching every section) | Conceptual/structural, touches how the whole document frames itself — bigger than a single-section edit | 2026-09-08 |
| HP-014 | ~~Formal distinction between "terminal for current processing" and "terminal for recovery"~~ **Adopted 2026-09-08.** Rewrote the Flow State/Transition Model's Terminal states line to define both senses explicitly; tagged Component Library and Repurpose as terminal-for-current-processing (re-entry eligible), Reduction as terminal-for-recovery (with a correction mid-edit: Reduction is the point of no return, but the actual inert-waste endpoint is reached after Purification, not at Reduction itself) | Resolves a real semantic tension already present between the Outcome Paths and Terminal States sections; likely low-to-medium risk, mostly clarification | 2026-09-08 |
| HP-015 | ~~Formal "re-entry contract"~~ **Adopted 2026-09-08.** Added a numbered 6-point contract after the Flow State/Transition Model's re-entry transitions bullet. Five of six points were already implied by ASM-007/FI-3; point 5 ("prior assessment does not automatically carry forward — no inheritance of the parent's failure state") was the genuinely underspecified piece, now explicit | ASM-007 already implies most of this; the "does not inherit assembly's failure state" point is the one genuinely underspecified piece worth making explicit | 2026-09-08 |
| HP-016 | Replace/supplement the growing prose-example collection (currently 7) with a systematic boundary matrix (condition × Gate A-D/Oversight outcome × expected route) for FL-001 closure | Structurally bigger than it sounds — could mean restructuring Examples 1-7, not just adding a table. ChatGPT itself frames this as "the destination," not a small next step | 2026-09-08 |

---

## Abandoned Paths

| Date | Path | Why Abandoned | Reconsider? |
|------|------|---------------|-------------|
| May 2026 | Gate A and Gate C defined with overlapping language | Identical items could route to either gate depending on interpretation — non-deterministic routing at the most common boundary case. Resolved by requiring Gate A to test original application context exclusively; Gate C handles all reduced or different applications | No — boundary is stable |
| May 2026 | Gate C and Gate D described with near-identical language | Boundary ambiguity between functional downgrade and material integrity tests. Items could satisfy both or neither. Resolved by making the tests explicitly distinct — Gate C asks can it do something useful; Gate D asks is the material itself recoverable | No — distinction is stable |
| May 2026 | Fully autonomous operation as a v0 goal | Automation is valid but not assumed at v0. Human judgment is explicit at every gate. Removing the autonomy assumption makes the flow executable manually from day one — a stronger bootstrap position | Reconsider at v3 when autonomous operation enters scope per Admin/Trajectories.md |
| May 2026 | Net-positive energy claims without measurement | Claiming net-positive economics before measurement is a Magic Energy fallacy. All energy claims labeled Placeholder until Operations/Energy.md baseline is established | No — measurement requirement is permanent doctrine |
| 2026-05-15 | Contamination defined as a closed fixed list | A fixed list creates a false sense of completeness — unforeseen contamination types proceed through gate logic without a defined response. Replaced with an open learning system: unknown contamination routes to Human/AI Oversight Gate and a new category is logged | No — open learning system is the correct architecture |
| 2026-05-15 | Gate logic applied to assemblies as fixed units | Created ambiguity about disassembly before reduction. Resolved by clarifying that gate logic applies to discrete items — assemblies may be disassembled at Gate C or D, with components re-entering at Gate A independently | No — component-level gate logic is stable |

---

## Drift Indicators

The following conditions trigger mandatory re-audit of this file.
All canonical drift indicators from File_Template.md apply.
The following are additional local triggers specific to the
Lazarus Forge operational flow document:

### Local Drift Triggers

| Trigger | Reason |
|---------|--------|
| Any module redefines a term from the Defined Terms section without updating this file | This document is the repository vocabulary standard — unauthorized redefinition causes silent semantic drift across all files that inherit the term |
| Purification stage definition revised without FL-DS-001 resolution and repository-wide propagation | FL-DS-001 is the active terminology dispute — any change here must update Operations/Gate_04_Separation_Mechanical.md, Unknowns.md, and any other file referencing the stage |
| Gate logic modified without FL-001 resolution | FL-001 is In Progress — gate changes before boundary cases are resolved risk introducing new non-determinism |
| Reduction module specified without FL-002 closure and cross-validation against Operations/Gate_04_Separation_Mechanical.md Inputs section | FL-002 and the GR-009 / MG-009 envelope drift must resolve together — a Reduction spec that doesn't match the Gate's provisional feedstock envelope creates a hidden dependency failure |
| Human/AI Oversight State removed or made optional | The Oversight State is the system's primary safeguard against premature irreversible action — removal requires explicit human authorization and full audit cycle |
| Contamination category list revised without open learning system clause preserved | The open learning system clause is the doctrine that handles unforeseen contamination — removing it closes the list and creates blind spots |
| Want/need policy definition changed without downstream file review | Want/need policy governs Fabrication priority and Oversight State decisions — changes propagate to Operations/Gate_02_Triage.md and Architecture/Geck_forge_seed.md at minimum |
| KPI definition promoted from Placeholder without Operations/Energy.md baseline established | KPI is explicitly Placeholder pending measurable value definition and energy accounting — premature promotion is a confidence without basis violation |
| ASM-007 assembly disassembly clarification removed from body without Lessons Learned update | The clarification resolves a real ambiguity — silent removal would reopen the gate logic overlap that was deliberately closed |
| Gate sequence made non-sequential or parallel without full audit cycle | Sequential gate order is the core architectural assumption — parallel processing changes the entire decision logic and must be treated as a major version change |

### Canonical Drift Triggers

*All mandatory re-audit conditions from File_Template.md
Section 10 apply without exception. Local triggers above are
additive, not substitutes.*
