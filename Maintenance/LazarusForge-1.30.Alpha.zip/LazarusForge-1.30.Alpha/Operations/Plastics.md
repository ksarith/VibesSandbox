# Plastics.md — Salvaged Polymers & Pyrolytic Fuel Recovery

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

> ⚠️ **Operational Safety Advisory**
> Thermal depolymerization (pyrolysis) operates at high temperatures (300°C–500°C)
> and generates highly flammable, toxic hydrocarbons and synthetic gas. Enclosure
> breach or oxygen ingress creates an immediate risk of explosive pressure buildup
> or flashback fire. Halogenated plastics (PVC, Teflon) release hydrochloric acid
> gas and dioxins at pyrolysis temperatures — reactor corrosion and toxic bypass are
> credible failure modes if triage misses contaminated feedstock. See PL-001.
> Air Scrubber operation, continuous venting, and oxygen exclusion are
> non-negotiable prerequisites before heating begins. When in doubt, do not heat.

---

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Exploration                                                         |
| Body Stability   | Volatile                                                            |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | Admin/Verification_Gates.md                                      |
| Last Audit       | 2026-10-30 — Vibe (Repo Custodian, delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A): X3 mechanical citation retrofit (Operations pass) — 20 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.30 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only; no ID renumbered; frozen history untouched; no gate advanced; Open Unknowns unchanged. Prior: 2026-10-24 — Claude (human-directed) four bare EC-014 citations qualified with their owning file, the missing 2026-09-20 Resolution Log entry backfilled and the log put in date order, from a Vibe per-file audit. Prior: 2026-09-20 — EC-013 Plastics safe-state descent sequence filed as Proposed/Placeholder (§EC-013 Descent Sequence). Blocking for hot runs retained until first hot-run validation. Prior: 2026-08-23 — PL-001 Resolved, Payment via Specification (Halogenated Polymer Triage Protocol added, class-split for PVC/Cl-Br vs. PTFE/fluoropolymer screening; Blocking Yes retained pending PL-001-R1 empirical validation); prior: 2026-05-27 (Grok — Skeptic/Auditor); revised 2026-06-08; PL-001 disposal-destination convergence pass 2026-08-15 |
| Auditor          | Vibe — Repo Custodian, 2026-10-30 X3 mechanical citation retrofit (Operations pass; delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A); prior: Grok — EC-013 descent section drafted and filed as Proposed/Placeholder (Path A, human-directed 2026-09-20); prior: Claude — PL-001 protocol drafted by Grok, revised once after a Claude Skeptic pass (Beilstein/fluorine reliability gap identified and corrected), human-ratified (human-directed), 2026-08-23; prior: Grok — Skeptic/Auditor |
| Open Unknowns    | 4 substantively open (PL-002, PL-003, PL-004, PL-005). PL-001 Resolved — Payment via Specification, 2026-08-23. EC-013 sequence registered as Proposed/Placeholder (does not close EC-013 tracker). |
| Active Disputes  | 0                                                                   |
| Highest Risk     | High                                                                |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

---

## Scope Boundary

**This file DOES define:**
- Triage routing doctrine for salvaged industrial and consumer polymers
- Conceptual framework for low-pressure, oxygen-free thermal depolymerization
  (pyrolysis)
- High-level design requirements for a batch-fed reaction chamber and condenser array
- Safety and chemical containment boundaries for off-gas treatment
- Char and solid residue handling doctrine

**This file DOES NOT define:**
- Precise temperature profiles for individual or unique polymer blends
- Mechanical blueprints for custom extrusion screws or filament-drawing rigs
- Refining or fractional distillation specifications for separating fuel oil into
  specialized fuel grades
- Air Scrubber hardware specification or alkaline buffering stage design
  (→ `Operations/Air_Scrubber.md`)
- Energetic or radiological hazard screening at intake
  (→ `Operations/Gate_01_Intake.md`)
- Contamination routing beyond plastic stream identification
  (→ `Operations/Gate_02_Triage.md`)
- Energy accounting for pyrolysis reactor operation
  (→ `Operations/Energy.md`)
- Facility siting, clearance, and hot-work zone requirements
  (→ `Architecture/Facilities.md` — FA-001 (`Architecture/Facilities.md`))
- Operator PPE standards and hearing/respiratory conservation program
  (→ `Admin/Safety_Protocols.md`)

---

## File Purpose

This document establishes the processing path for salvaged plastics within the
Lazarus Forge. Mixed or contaminated polymers represent both a recovery opportunity
and a significant logistical hazard — they cannot be safely routed to thermal
processing alongside metals, and mechanical repurposing yields diminish rapidly
with degradation. This file defines the triage hierarchy that routes plastics
toward the highest-value recovery path available, and specifies the pyrolytic fuel
recovery framework that handles what mechanical repurposing cannot.

Pyrolysis is positioned as a last-resort recovery path for otherwise intractable
mixed waste, not as a primary recycling method. Its core claim is falsifiable: mixed
low-value plastics can be safely converted to usable pyrolytic oil and syngas via
oxygen-free batch pyrolysis, provided halogenated streams are rejected at triage and
off-gases are captured by the Air Scrubber. If this file disappeared, mixed plastic
waste would have no governed processing path, and operators would lack the safety
doctrine required to handle pyrolysis off-gases and halogenated contamination.

---

## Assumptions

| ID      | Assumption                                                                                         | Basis                                                    | Confidence | Expiry Trigger                                                                 |
|---------|----------------------------------------------------------------------------------------------------|----------------------------------------------------------|------------|--------------------------------------------------------------------------------|
| ASM-001 | Sourced plastic feedstock will contain unrecognized or highly degraded multi-layer polymers        | Consumer and industrial salvage is fundamentally mixed; high-purity sorting cannot be guaranteed at v0 | High | First operational triage cycle characterizes actual feedstock purity distribution |
| ASM-002 | Mechanical recycling yields diminish rapidly after multiple heat cycles                            | Polymers shorten and degrade during mechanical re-extrusion; chemical breakdown path required for persistence | High | Operational filament-drawing data shows acceptable yield beyond current assumed threshold |
| ASM-003 | Waste heat from Spin Chamber or external sources can bootstrap reactor thermal demand              | Analogous — industrial waste heat recovery practice; cross-reference `Operations/Gate_05_Separation_Thermal.md` SC-007 | Low | SC-007 resolved — exhaust heat load characterized and available capacity confirmed |
| ASM-004 | Halogenated plastics (PVC, Teflon) are identifiable and rejectable at triage before reactor entry  | Class-split screening: Beilstein test + density for PVC/Cl-Br; labeling + density band for PTFE/fluoropolymers (Beilstein does not clear fluorine) | Low | PL-001 Resolved 2026-08-23 — protocol specified; hot-run clearance still requires PL-001-R1 empirical validation against representative feedstock |
| ASM-005 | Pyrolytic oil from mixed plastic feedstock is usable as heating fuel or generator input without significant refining | Analogous — small-scale pyrolysis literature; oil quality varies by feedstock | Low | PL-003 resolved — oil stability and contaminant profile characterized |

---

## I. General Plastics Triage Hierarchy

Consistent with the principle of *Salvage Before Reduction*, plastics enter a
progressive depth triage sequence:

1. **Direct Component Reuse:** Structural panels, enclosures, or functional hardware
   are preserved intact.
2. **Mechanical Repurposing (RepRap / Filament):** High-purity, cleanly identified
   single-stream plastics (e.g., clean PLA, ABS, PETG) are routed toward shredding
   and drawing into custom fabrication stock.
3. **Thermal Depolymerization (Pyrolysis):** Mixed, degraded, contaminated, or
   low-value bulk plastics that cannot support mechanical repurposing enter the
   chemical recovery loop.

**Triage decision boundary for mechanical vs. pyrolysis routing:**
The threshold at which plastic is too degraded for mechanical repurposing is
not yet formally defined — see PL-004. Provisional indicators that favor pyrolysis
routing over filament drawing: visible embrittlement or chalking, unknown polymer
identity, multi-layer or composite construction, visible contamination or bonded
dissimilar materials, or melt-flow behavior inconsistent with a known single
polymer class.

**Halogenated polymer rejection:**
PVC, Teflon, and other halogenated plastics must not enter the pyrolysis reactor.
At triage, suspected halogenated material is identified using the Beilstein test
(copper wire combustion — green flame indicates halogen presence) or density
sorting (PVC density ~1.4 g/cm³ is distinctly higher than most common
thermoplastics). Confirmed halogenated material routes to `Operations/Gate_02_Triage.md`'s
Contaminated bin (non-decontaminable state, 2026-08-15 shared-destination extension),
not to the reactor and not to an undefined "specialist disposal" — the same named
hold `Challenges/Waste.md` WA-002's hazardous fractions use, pending
`Admin/Ethical_Constraints.md` EC-014 (`Admin/Ethical_Constraints.md`)/GR-003 for final disposition. See PL-001.

---

## II. Pyrolytic Fuel Recovery Framework

Pyrolysis breaks down long-chain hydrocarbon molecules into shorter-chain liquid
and gaseous fuels. The process requires a closed system operating under three phases.

**Critical dependency:** This entire section depends on `Operations/Air_Scrubber.md`
being operational and maintaining alkaline buffering capacity before and during any
reactor run. Pyrolysis off-gas is toxic and flammable. Scrubber shutdown during an
active run is an emergency stop condition — see Drift Indicators. The alkaline
buffering stage in the scrubber is specifically required to neutralize any HCl
that bypasses halogenated feedstock rejection at triage. Cross-reference:
`Operations/Air_Scrubber.md` AS-003 (scrubber waste stream and saturation thresholds).

### A. Thermal Breakdown (The Reactor)

- Feedstock is sealed into an airtight batch reactor chamber
- The chamber is purged of oxygen — via inert gas purge or vacuum extraction —
  before heating begins. Purge completion must be logged before heat is applied.
- External heat raises the chamber temperature to **350°C–450°C** *(Analogous —
  standard pyrolysis temperature range for mixed polyolefins; halogen-free feedstock
  assumed)*
- At temperature, carbon-carbon bonds fracture, vaporizing solid plastic into
  gaseous hydrocarbons
- Reactor wall corrosion from residual acid gas is a credible long-term failure mode —
  see PL-002 for maintenance access and inspection requirements

### B. Condensation & Liquid Capture

- Vaporized gases are channeled from the reactor into a multi-stage condensation array
- Heavy-to-medium hydrocarbon chains condense at decreasing temperatures, producing
  pyrolytic oil (synthetic crude)
- Condensation array fouling from wax paraffins and heavy fractions is a maintenance
  item — cleaning access must be designed in from the start. See PL-002.
- Pyrolytic oil is stored for use as heating fuel, motor-generator input, or feedstock
  for downstream Forge thermal processes
- Oil stability and contaminant profile are uncharacterized at v0 — see PL-003

### C. Non-Condensable Syngas Channeling

- Light hydrocarbon gases (methane, ethane, propane fractions) will not condense at
  ambient temperatures and must be continuously drawn from the end of the condensation
  array
- Continuous draw maintains low-pressure state in the reactor — pressure buildup is
  a rupture risk. See PL-002.
- **Critical Safety Boundary:** Syngas must never accumulate in unvented spaces.
  Route immediately to a designated burner for controlled combustion, or channel
  directly into the Air Scrubber intake manifold for capture. The Air Scrubber is
  not a combustion device — syngas routed to the scrubber must pass through a
  dedicated combustion or thermal oxidation stage upstream of the scrubber inlet.
  Direct routing of unburned syngas into scrubbing liquid is not acceptable.

### D. Char and Solid Residue

- Real-world pyrolysis produces 5–20% solid char and ash residue by feedstock mass,
  depending on polymer type and contamination level *(Analogous — pyrolysis
  literature for mixed plastic feedstock)*
- Char composition is unknown at v0 — it may contain concentrated heavy metals,
  carbon black, inorganic fillers, and residual halogenated compounds from
  insufficiently rejected feedstock
- Char is not discarded as inert waste — it routes to `Operations/Gate_02_Triage.md`
  for assessment: potential carbon feedstock, potential hazardous waste requiring
  specialist handling
- Do not assume char is inert. Treat as potentially hazardous until characterized.
  See PL-005.

---

## Integration Hooks

- `Operations/Air_Scrubber.md` — primary safety dependency; off-gas capture,
  HCl neutralization via alkaline buffering stage, syngas combustion upstream
  of scrubber inlet; cross-reference AS-003 for saturation thresholds
- `Operations/Gate_01_Intake.md` — halogenated polymer detection at entry;
  GI-003 (`Operations/Gate_01_Intake.md`) augmented detection capability applies to plastic stream identification
- `Operations/Gate_02_Triage.md` — upstream routing decision for all plastics;
  char residue routes back here for hazardous vs. recoverable classification
- `Operations/Gate_03_Reduction.md` — pyrolysis is reduction-adjacent; shredding
  of bulk plastic feedstock before reactor loading follows Reduction doctrine
- `Operations/Gate_06_Fabrication.md` — mechanical repurposing path (filament
  drawing) connects to fabrication feedstock; RepRap stock quality feeds back
  to PL-004 threshold definition
- `Operations/Energy.md` — pyrolytic oil and syngas are candidate energy inputs
  to motor-generators and heating systems; reactor thermal demand feeds energy
  accounting
- `Operations/Gate_05_Separation_Thermal.md` — waste heat from Spin Chamber
  is a candidate bootstrap heat source for reactor thermal demand (ASM-003,
  SC-007)
- `Admin/Trajectories.md` — fractional distillation, filament extrusion hardware
  specification, and deep characterization of oil quality are v1+ scope items
- `Architecture/Facilities.md` — siting and hot-work zone requirements;
  pyrolysis reactor clearance zones and ventilation topology (FA-001 (`Architecture/Facilities.md`))
- `Admin/Safety_Protocols.md` — operator PPE standards; respiratory protection
  requirements for toxic off-gas handling

---

## Lessons Learned

| Date       | Evidence Type | What Was Tried | What Failed | What Was Learned | Confidence | Revalidation Needed |
|------------|---------------|----------------|-------------|------------------|------------|---------------------|
| 2026-05-26 | Audit Review  | Document created without syngas combustion stage specified | Syngas routed directly to Air Scrubber without noting that scrubber is not a combustion device — silent safety gap | Syngas must pass through dedicated combustion or thermal oxidation stage before scrubber inlet. Direct routing of unburned syngas into scrubbing liquid is not acceptable | Analogous | Yes — validate combustion stage design before first hot run |
| 2026-05-27 | Audit Review  | Char residue not acknowledged in initial draft | Pyrolysis always produces solid residue; omitting it created an incomplete material balance and a potential untracked hazardous waste stream | Char handling added as Section D. Char routes to Gate_02_Triage for classification — do not assume inert | Analogous | Yes — characterize char composition during first operational run |

---

## Active Disputes

| ID | Dispute Summary    | Positions in Conflict | Risk | Status | Owner |
|----|--------------------|-----------------------|------|--------|-------|
| —  | No active disputes | —                     | —    | —      | —     |

---

## Auditor Notes & Unknowns

### PL-001 — Halogenated Polymer Contamination (PVC / Teflon)

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Resolved — Payment via Specification, ratified 2026-08-23 |
| Risk          | High                                             |
| Priority      | Critical                                         |
| Type          | Chemical Safety                                  |
| Blocking      | Yes (before any hot operational runs — specification closure does not clear this; see PL-001-R1) |
| Owner         | Operations/Plastics.md                           |
| First Logged  | 2026-05-26                                       |
| Last Reviewed | 2026-08-23                                       |

**Description:** PVC and other halogenated plastics release hydrochloric acid (HCl)
gas and toxic dioxins when subjected to pyrolysis temperatures. Even small quantities
contaminate the entire reactor batch.

**Why It Matters:** HCl corrodes steel reactor vessels from the inside out over
repeated cycles and easily bypasses basic carbon filtration, creating both a
structural failure risk and a toxic environmental hazard. Dioxin release is a
severe long-term health and contamination risk.

**Halogenated Polymer Triage Protocol** *(PL-001 resolution vehicle — specification layer)*

PVC, PTFE (Teflon), and other halogenated plastics must not enter the pyrolysis reactor. This protocol defines the minimum decision procedure at triage. It does not claim field validation. Hot operational runs remain blocked until residual PL-001-R1 is closed.

*Scope.* In scope: identification and reject/hold decisions for suspected halogenated feedstock before reactor entry; routing of confirmed or unresolved halogenated material. Out of scope: Air Scrubber design (AS-003); Gate_01 augmented kit selection (GI-003 (`Operations/Gate_01_Intake.md`)); final long-term disposal chemistry (`Admin/Ethical_Constraints.md` EC-014 (`Admin/Ethical_Constraints.md`) / GR-003). Destination: positive or unresolved halogenated material → `Operations/Gate_02_Triage.md` Contaminated bin (non-decontaminable hold). No parallel sink.

*Two polymer classes (do not conflate).* Beilstein is a halide flame test biased toward chlorine/bromine — a negative result does not reliably rule out fluorine. Screening therefore splits by class:

| Class | Examples | What works | What does not clear |
|-------|----------|------------|-------------------------|
| Chlorinated / brominated | PVC (often recycling code 3), many vinyls | Beilstein (green flame) + density ~1.4 g/cm³ | — |
| Fluoropolymers | PTFE / Teflon, related F-polymers | Labeling, product form, density ~2.1–2.2 g/cm³ | Beilstein negative — fluorine does not reliably give the same diagnostic green-flame response; a negative Beilstein is not a "no halogen" certificate for this class |

Pass (halogen screen) requires that both classes have been addressed with a method appropriate to each — not "Beilstein negative ⇒ clear all halogen risk."

*Preconditions.* Triage before any material is charged to the pyrolysis reactor. Operator can attempt density comparison and, for the Cl/Br path, Beilstein under local site rules. If required tests for the suspected class cannot be performed → treat lot as Unresolved → Contaminated bin (do not pass to reactor).

*Decision sequence.* Perform in order. Stop at first decisive Reject. Document outcome for the lot.

| Step | Action | Decision |
|------|--------|----------|
| 1. Visual / marking screen | Recycling codes (e.g. 3 = PVC), "vinyl," "PTFE," "Teflon," fluoropolymer product types, known halogenated articles | Labeled PVC-class or PTFE-class → Reject → Contaminated bin. Otherwise continue. |
| 2. Density sort (class-aware) | PVC-class band: ~1.4 g/cm³. PTFE-class band: ~2.1–2.2 g/cm³ (distinctly heavier than PVC and common polyolefins). Common PE/PP ~0.9 g/cm³ | Density consistent with PVC-class → suspect chlorinated → Step 3a. Density consistent with PTFE-class → suspect fluoropolymer → Step 3b (not 3a alone). Light polyolefin-class density does not by itself clear halogen risk if labeling/form still suggests halogen polymer. Cannot test density → note; apply Step 3 by class if labeling/form suggests halogen polymer; if fully unknown mixed and untestable → Unresolved. |
| 3a. Beilstein (chlorinated / brominated path only) | Clean copper wire, heat, contact sample, return to flame. Green flame → halogen (Cl/Br-class) | Green → Reject → Contaminated bin. Negative → Cl/Br Beilstein path does not indicate chlorinated/brominated halogen; continue only for that path. Ambiguous / weak / dirty wire / unsure → Unresolved → Contaminated bin. |
| 3b. Fluoropolymer path (PTFE-class) | Do not clear on Beilstein negative. Use labeling, product form, and PTFE-class density band | Labeled or density-consistent PTFE-class → Reject → Contaminated bin. Suspected but unconfirmed → Unresolved → Contaminated bin. Never issue Pass for fluoropolymer suspicion on Beilstein alone. |
| 4. Mixed-lot rule | Lot contains mixed streams | If any significant fraction is Reject or Unresolved → whole lot holds to Contaminated bin or re-sort until halogenated fraction is removed and remaining fraction is re-screened under Steps 1–3. Do not average risk across the batch. |
| 5. Pass (halogen screen only) | PVC/Cl-Br path does not indicate reject (3a) and PTFE path does not indicate reject/unresolved (3b), using methods appropriate to each class | May proceed along ordinary Plastics triage toward later stages only under wider Gate/Plastics rules. This Pass is necessary, not sufficient, for a hot run. |

*Outcome table.*

| Outcome | Meaning | Route |
|---------|---------|--------|
| Reject | Halogen indicated for PVC/Cl-Br path and/or PTFE path | Contaminated bin (non-decontaminable) |
| Unresolved | Test impossible, ambiguous Beilstein (3a), PTFE suspicion without clear clear/reject, or mixed lot not fully separated | Contaminated bin until resolved or re-sorted |
| Pass (halogen screen) | Both classes screened with appropriate methods; no reject/unresolved halogen indication | Continue other triage; not authorization for hot pyrolysis |

Default under doubt: Unresolved → Contaminated bin. When in doubt, do not heat.

**Hard rule:** a negative Beilstein result clears only the chlorinated/brominated Beilstein path. It must not be treated as a universal "no halogen" result and must not be used to clear fluoropolymer suspicion.

*Interface with GI-003 (`Operations/Gate_01_Intake.md`) and AS-003.* GI-003 (`Operations/Gate_01_Intake.md`) (Gate_01 augmented detection): optional enrichment. If present and indicates halogenated hazard → Reject or Unresolved per that indication. If absent/Open, this protocol's class-aware Steps 1–3 remain the minimum path — do not wait on GI-003. AS-003 (scrubber alkaline / saturation): not a triage step. Defense in depth if imperfect rejection allows acid gas toward the scrubber. Confirmation is part of PL-001-R1, not a prerequisite to write or execute this reject protocol.

**Explicit non-goals.** Does not set reactor temperature profiles or scrubber hardware design. Does not authorize hot pyrolysis when this protocol is specified but not validated. Does not define Contaminated-bin final disposal (`Admin/Ethical_Constraints.md` EC-014 (`Admin/Ethical_Constraints.md`) / GR-003 / Gate_02). Does not replace Gate_01 intake procedures; it specializes halogen screening for the plastics → pyrolysis path. Does not claim Beilstein is diagnostic for fluorine.

**Residual risks, logged as child notes and not blocking this section's Payment via Specification — Blocking Yes remains until PL-001-R1 clears:**

| ID | Residual | Notes |
|----|----------|-------|
| PL-001-R1 | Empirical validation against a representative feedstock sample (include fluoropolymer challenge material when available) and confirmation that scrubber alkaline stage can handle accidental acid-gas bypass from imperfect rejection | Required before any hot operational run; specification alone does not clear Blocking Yes |
| PL-001-R2 | Operator training / false-negative rate under real contamination levels | Field data; adjust sequence only via dated revision after evidence |
| PL-001-R3 | GI-003 (`Operations/Gate_01_Intake.md`) kit maturity | Parallel; may strengthen Step 1–3 later without blocking this minimum protocol |
| PL-001-R4 | Stronger field fluoropolymer identification method when available | Until then: density band + label + hold-on-doubt (3b) is the specified minimum |

*§PL-001 — Resolved, Payment via Specification, ratified 2026-08-23. Closes PL-001 (logged 2026-05-26). Drafted by Grok, revised once after a Claude Skeptic pass identified that the Beilstein test is chlorine/bromine-biased and unreliable for fluorine — the original draft would have let a negative Beilstein result clear PTFE/fluoropolymer suspicion, exactly the false-negative failure mode this unknown exists to prevent. Revision split screening by polymer class (PVC/Cl-Br via Beilstein+density; PTFE/fluoropolymer via labeling+density band, explicitly never cleared by Beilstein alone) and rewrote the Pass condition as a conjunction requiring both classes screened, not a single shared threshold. Constitutional/doctrinal anchor: none required — this is an operational safety protocol, not governance doctrine; destination and cross-references verified against `Operations/Gate_02_Triage.md`'s existing Contaminated bin (2026-08-15 extension) and this file's own GI-003 (`Operations/Gate_01_Intake.md`)/AS-003 cross-references before integration. Full Closure Event — Proposer (Grok), Skeptic + Verifier (Claude, one revision then Accept), Human Ratification (Human Governing Authority) — recorded in this file's own Resolution Log, below. Blocking Yes remains in force for hot operational runs pending PL-001-R1 empirical validation; specification closure and operational clearance are deliberately distinct events. Human-directed.*

**Prior history (retained):**

**Grok review 2026-08-15:** Path adequate. Beilstein + density sorting are concrete v0 methods; GI-003 (`Operations/Gate_01_Intake.md`) and AS-003 cross-refs are real and correctly load-bearing. Blocking Yes before any hot run is correct. **Grok approved (path adequate).** Remains Open — triage protocol still needs definition + validation; do not run hot pyrolysis until closed. *(Superseded 2026-08-23 — protocol now written; Blocking Yes carried forward unchanged.)*

**Spec-depth pass, 2026-08-15 (digital-only — no equipment exists yet):** Verified against source before acting on Grok's shared-cluster proposal. This file's "specialist disposal" destination and `Challenges/Waste.md` WA-002's "routed per WA-004/GR-003" were two different sentences pointing at the same undefined place — neither named a real path. Resolved by extending `Operations/Gate_02_Triage.md` TS-002 (`Operations/Gate_02_Triage.md`)'s existing Contaminated bin non-decontaminable state (built earlier this session) to explicitly cover compositional hazards, not only surface contamination — no new destination invented, an existing one reused. Both files now converge on the same named hold. Does not change PL-001's disposition status or Blocking Yes — final disposal still correctly awaits `Admin/Ethical_Constraints.md` EC-014 (`Admin/Ethical_Constraints.md`)/GR-003.

---

### PL-002 — Reactor Thermal Runaway, Pressure Control, and Maintenance Access

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | High                                             |
| Priority      | Major                                            |
| Type          | Mechanical Engineering / Safety                  |
| Blocking      | Yes (before reactor fabrication)                 |
| Owner         | Operations/Plastics.md                           |
| First Logged  | 2026-05-26                                       |
| Last Reviewed | 2026-08-15                                       |

**Description:** The rate of vapor generation must not exceed the throughput
capacity of the condensation plumbing. Additionally, the reactor and condensation
array will experience progressive corrosion (acid attack from trace HCl), wax
fouling in condenser passages, and thermal cycling fatigue — none of which have
defined inspection intervals or maintenance access provisions.

**Why It Matters:** Rapid gas expansion inside a hot sealed container can cause
explosive mechanical rupture. Progressive corrosion or fouling without maintenance
access creates silent failure modes — the reactor degrades without visible
external indicators until a breach occurs.

**Resolution Path:** Specify a passive, high-reliability mechanical pressure
relief system (liquid-sealed bubbler lock) that allows emergency pressure relief
without admitting ambient air to the hot reactor. Define maintenance access points
for reactor interior inspection, condenser cleaning, and corrosion assessment.
Establish minimum inspection interval cadence (Placeholder — to be defined during
first operational cycle). Payment via Specification once relief system design is
validated and maintenance access provisions are incorporated into reactor design.

**Grok review 2026-08-15:** Path adequate. Passive bubbler-lock relief (no air ingress) is the right architecture for an oxygen-free hot reactor; maintenance access and corrosion inspection are correctly co-specified. Blocking Yes before fabrication is correct. **Grok approved (path adequate).** Remains Open — design still needs to be written and validated.

---

### PL-003 — Pyrolytic Fuel Stability and Contaminant Profile

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | Medium                                           |
| Priority      | Minor                                            |
| Type          | Fuel Chemistry                                   |
| Blocking      | No                                               |
| Owner         | Operations/Plastics.md                           |
| First Logged  | 2026-05-26                                       |
| Last Reviewed | 2026-08-15                                       |

**Description:** Recovered synthetic crude oil from mixed plastic pyrolysis is
often acidic and contains wax paraffins that separate and solidify at room
temperature. Contaminant profile varies by feedstock composition.

**Why It Matters:** Unrefined oil may clog secondary engine injectors or rapidly
corrode standard fuel storage containers if left untreated. Acidic oil damages
motor-generator components not designed for fuel oil service.

**Resolution Path:** Characterize minimum filtration or post-process washing steps
required to render oil stable for long-term storage in Forge auxiliary power
reserves. Cross-reference `Operations/Energy.md` for integration with motor-generator
fuel input. Payment via Specification once oil quality is characterized from first
operational reactor run.

**Grok review 2026-08-15:** Path adequate. Correctly deferred to first operational run for characterization; Energy.md cross-ref is real. Non-Blocking is appropriate. **Grok approved (path adequate).** Remains Open — needs measured oil quality data.

---

### PL-004 — Mechanical Filament-Drawing Threshold Not Defined

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | Low                                              |
| Priority      | Minor                                            |
| Type          | Technical Specification                          |
| Blocking      | No                                               |
| Owner         | Operations/Plastics.md                           |
| First Logged  | 2026-05-26                                       |
| Last Reviewed | 2026-08-15                                       |

**Description:** The exact conditions under which mechanical plastic recycling
(RepRap filament drawing) becomes unfeasible due to contamination or structural
degradation are unquantified. Triage routing between mechanical and pyrolysis
paths currently relies on operator judgment against provisional visual heuristics.

**Why It Matters:** Without a defined boundary, subjective routing during triage
may cause degraded feedstock to clog the fabrication gate or viable feedstock to
be prematurely destroyed.

**Resolution Path:** Establish formal triage heuristics — minimum: brittleness
snap test, melt-flow observation, polymer identity check (Beilstein, density,
or burn characteristics). Define pass/fail criteria for mechanical repurposing
routing. Candidate methods: melt-flow index testing (simple improvised version
feasible at v0), density measurement in water bath. Payment via Specification
once heuristics are validated against first operational triage cycle with
representative mixed feedstock.

**Grok review 2026-08-15:** Path adequate. Heuristics are concrete and v0-feasible; correctly resists inventing numeric thresholds without data. **Grok approved (path adequate).** Remains Open — needs validation against real mixed feedstock.

---

### PL-005 — Char and Solid Residue Composition Uncharacterized

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | Medium                                           |
| Priority      | Major                                            |
| Type          | Chemical Safety / Waste Management               |
| Blocking      | No                                               |
| Owner         | Operations/Plastics.md                           |
| First Logged  | 2026-05-27                                       |
| Last Reviewed | 2026-08-15                                       |

**Description:** Pyrolysis produces 5–20% solid char and ash residue by feedstock
mass. Char composition from mixed plastic feedstock is unknown — it may contain
concentrated heavy metals, carbon black, inorganic fillers, and residual halogenated
compounds.

**Why It Matters:** If char is treated as inert waste and disposed of without
characterization, hazardous materials may be released into the environment or
contaminate downstream processing streams. If char has carbon or mineral recovery
value, uncharacterized disposal wastes recoverable material.

**Resolution Path:** Characterize char composition from first operational reactor
run using available analytical methods — at minimum, visual inspection and
solubility testing. Cross-reference `Operations/Gate_02_Triage.md` for routing
to hazardous hold or material recovery as appropriate. Cross-reference
`Operations/Gate_03_Reduction.md` GR-003 (biological and chemical waste disposal
doctrine) for hazardous char disposition path. Payment via Specification once
char composition is characterized and a routing decision tree is defined.

**Grok review 2026-08-15:** Path adequate. Correctly sequences after first operational run; GR-003 and Gate_02 cross-refs are real. Non-Blocking is appropriate until char exists to characterize. **Grok approved (path adequate).** Remains Open — needs measured char data + routing tree.

---

### Resolution Log

- 2026-10-30: **X3 mechanical citation retrofit (Operations pass).** 20 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.30 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only: no ID renumbered, no Unknown opened or closed, no Spec Gate advanced, frozen history untouched. Out-of-whitelist bare IDs were left bare and reported to the human. (Vibe, Repo Custodian — delegated maintenance per Decision Brief 2026-10-29 item 4A.)

- 2026-10-24: Four bare EC-014 citations now name `Admin/Ethical_Constraints.md`; the 2026-09-20 entry below backfilled and the 2026-06-08 entry moved into date order (human-directed, from a Vibe per-file audit; each finding checked against source first). No protocol, decision table, Unknown or Spec Gate changed.

- 2026-09-20: **EC-013 Plastics safe-state descent sequence filed as Proposed/Placeholder (§EC-013 Descent Sequence).** Drafted by Grok (Path A, human-directed). Blocking for hot runs retained until first hot-run validation; this does not close the EC-013 tracker. *(Backfilled 2026-10-24 from this file's Last Audit and Auditor fields and the section's own header; no log entry was made at the time.)*

- 2026-08-23: **PL-001 (Halogenated Polymer Contamination) Resolved — Payment via Specification, ratified by Human Governing Authority.** Grok drafted a full class-aware Halogenated Polymer Triage Protocol. Claude Skeptic pass caught a real chemistry gap before integration: the Beilstein test is a chlorine/bromine-biased halide flame test and does not reliably detect fluorine, so the initial draft's single shared Beilstein-negative-clears-all logic would have let PTFE/fluoropolymer contamination pass triage undetected — exactly the false-negative failure mode PL-001 exists to prevent. Grok revised: screening split into a PVC/Cl-Br path (Beilstein + ~1.4 g/cm³ density) and a separate PTFE/fluoropolymer path (labeling + product form + ~2.1–2.2 g/cm³ density band, explicitly never cleared by Beilstein alone), with the Pass condition rewritten as a conjunction requiring both classes screened. Destination (Gate_02 Contaminated bin) and GI-003/AS-003 cross-references verified unchanged and accurate against source before integration. Full Closure Event — Proposer (Grok), Skeptic + Verifier (Claude, one revision then Accept), Human Ratification (Human Governing Authority). Four residuals (PL-001-R1 through R4) remain open as non-blocking child notes; PL-001-R1 (empirical validation against representative feedstock, including fluoropolymer challenge material) keeps Blocking Yes in force for hot operational runs — specification closure and operational clearance are deliberately distinct events, consistent with this repository's GOV-003 precedent. Open Unknowns: 5 substantively open → 4 (PL-002–005); PL-001 Resolved.

- 2026-08-15: **Grok resolution-path review (Operations continuation — Plastics).** All five PL unknowns reviewed against source. Every Resolution Path judged adequate; residual evidence needs (triage validation, reactor design, first-run characterization) correctly retained. Cross-refs (GI-003, AS-003, Energy.md, Gate_02, GR-003) verified real. Markers added; Last Reviewed → 2026-08-15 on all five. **No PL-* closed.** Open Unknowns remain 5. Blocking status unchanged (PL-001 and PL-002 Yes). Human-directed.

- 2026-08-15: **PL-001's disposal destination named — points to
  `Operations/Gate_02_Triage.md` TS-002's Contaminated bin instead of an
  undefined "specialist disposal."** Same pass wired WA-002 to the same
  destination. No change to PL-001's Blocking status or triage protocol
  requirement. Human-directed.

- 2026-08-10: **Pseudo-audit (Grok, same limits).** Findings only; Spec Gates
  left locked at 0/6. (1) Open Unknowns **5** = PL-001–005, matches local
  sidecar and `Unknowns.md`. (2) PL-001 correctly **Blocking Yes / Critical**
  (before any hot operational runs). (3) PL-002 correctly **Blocking Yes**
  (before reactor fabrication). (4) No PL-* closed; no pyrolysis claims
  advanced. Human-directed.

- 2026-06-08: Navigation Anchors block added. Verification Ref corrected from
  `Admin/Forge_Audit_Kit.md` to `Admin/Verification_Gates.md` (PC-001).
  Scope Boundary updated — `Architecture/Facilities.md` added for siting and
  hot-work zone requirements (PC-002); `Admin/Safety_Protocols.md` added for
  operator PPE and respiratory protection standards (PC-003). Both added to
  Integration Hooks.

- 2026-05-27: PL-002 — Scope expanded from pressure control only to include
  maintenance access and corrosion inspection requirements. Finding from Grok
  Skeptic/Auditor audit 2026-05-27.

- 2026-05-27: PL-004 — Resolution path expanded to include specific candidate
  triage methods (melt-flow index, density bath, Beilstein). Finding from Grok
  Skeptic/Auditor audit 2026-05-27.

- 2026-05-27: PL-005 — New entry. Char and solid residue handling gap identified
  in Grok Skeptic/Auditor audit 2026-05-27. Section D added to body.

---

## Abandoned Paths

| Date       | Path                                                              | Why Abandoned                                                                                                                      | Reconsider? |
|------------|-------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|-------------|
| 2026-05-27 | Direct syngas routing to Air Scrubber without combustion stage    | Air Scrubber is not a combustion device — routing unburned flammable gas into scrubbing liquid creates fire and explosion risk inside the scrubber | No — combustion stage upstream of scrubber inlet is permanent doctrine |

---

## §EC-013 Descent Sequence — Plastics / Pyrolysis (Proposed / Placeholder)

**STATUS: Proposed / Placeholder.** Filed 2026-09-20 under Path A (EL-006-P3–P5 style). This section is visible doctrine and registers the first per-process EC-013 (`Admin/Ethical_Constraints.md`) sequence. It does **not** carry operational force for hot runs until a Skeptic pass and first hot-run validation have occurred. **Blocking for hot operational runs remains in force.** Specified ≠ demonstrated.

**Cross-reference:** `Admin/Ethical_Constraints.md` EC-013 (`Admin/Ethical_Constraints.md`) (requirement owner); EC-004 (`Admin/Ethical_Constraints.md`) Governance Failure Modes (Pacifist posture + active-process descent carve-out). Layer A process-fault interlocks (including `Operations/Air_Scrubber.md` Fault 04 / thermal divert / fire → halt forced ventilation immediately) are always-on safety logic and are **not** substituted by this sequence. Layer B (this sequence) must obey Layer A; the fire-vent-halt override wins over any step that would keep forced airflow running while a Hot Zone fire is active.

### Trigger
Governance failure (or explicit human/governance command to enter safe-state) while a Plastics pyrolysis / reactor run is active — i.e., heat is applied, feedstock is sealed, or off-gas path is live.

### Ordered steps (Layer B)
1. **Stop feed / hold new material** — Cease any further feedstock introduction. Do not open the reactor under positive pressure or while hot.
2. **Preserve containment** — Keep the reactor sealed. Do not vent to atmosphere. Maintain the oxygen-exclusion boundary already established for the run.
3. **Managed heat-down** — Remove or ramp down external heat source. Allow passive or controlled cooling. Do not introduce air or oxidizer to “speed cooling.”
4. **Off-gas path continuity** — Keep the existing condensation / combustion / scrubber path under its normal controlled conditions while temperature and pressure decline. Do **not** bypass the upstream combustion stage. If Air_Scrubber Layer A interlocks (especially fire-vent-halt) fire, those interlocks take precedence and may force an immediate halt of forced ventilation.
5. **Purge only when safe** — Once temperature and pressure are within the design safe band for inert purge (Placeholder — numeric band to be set at first hardware designation), perform an inert-gas or vacuum purge as already required by this file’s oxygen-exclusion doctrine. Log purge completion.
6. **Isolation** — Isolate energy sources and mark the reactor out of service until a human clearance is recorded.

### Hard overrides (Layer A wins)
- Any Fire / Fault-04 / thermal-divert / fire-vent-halt condition from `Operations/Air_Scrubber.md` or local process interlocks overrides steps 3–5 as required to protect life and containment.
- Oxygen ingress or loss of seal at any point is an emergency stop condition (already stated in this file); the descent sequence does not relax that rule.

### Completion criteria
Descent is complete when: (a) heat source is removed or confirmed off, (b) reactor is sealed and pressure is non-rising, (c) off-gas path is in a controlled idle or purged state, (d) a durable log of steps taken (and any skipped under Layer A override) exists, and (e) the system may then enter full Pacifist posture per EC-004.

### Logging
Record trigger, each step executed or skipped (with reason), Layer A overrides that fired, final temperature/pressure band, and operator identity. Store outside the agent runtime session if agents participated in the decision.

### Explicit non-goals
- This sequence does **not** self-clear or authorize restart.
- Missing or incomplete sequence is **not** license to skip descent or to default to instant-halt when instant-halt itself would breach containment.
- Filing this text does **not** close EC-013 (`Admin/Ethical_Constraints.md`), clear Blocking for hot runs, or claim any physical validation.

### Residual / open items (tracked, not blocking this filing)
- Numeric safe temperature/pressure band for step 5 (Placeholder until first hardware designation).
- Exact interaction timing with Air_Scrubber interlocks under simultaneous fire + governance-failure conditions (to be refined against live `Air_Scrubber.md` rows).
- First hot-run validation required before this section may be promoted beyond Proposed/Placeholder.

*Filed 2026-09-20, Path A (Proposed/Placeholder), human-directed. Does not constitute Payment via Specification for EC-013 (`Admin/Ethical_Constraints.md`); the tracker remains Open until the agreed active set of hazardous-process files each have a registered sequence or explicit scope-out.*

---

## Drift Indicators

Mandatory re-audit conditions for this document:

- Pyrolysis reactor heated without logged oxygen purge completion
- Air Scrubber not operational or not verified before reactor heating begins
- Halogenated polymer triage rejection protocol bypassed or made optional
- Syngas routed directly to Air Scrubber without upstream combustion stage
- Char residue treated as inert and disposed of without characterization
- PL-001 triage protocol bypassed for either polymer class, or Beilstein
  treated as sufficient to clear fluoropolymer/PTFE-class suspicion
- Reactor fabricated without pressure relief system per PL-002
- Pyrolytic oil used in motor-generators without PL-003 characterization
- Mechanical repurposing path used for visibly degraded or unknown-identity polymer
  without PL-004 heuristic check
- Ethical Anchor field absent, altered, or does not match canonical string
- EC-013 (`Admin/Ethical_Constraints.md`) descent sequence absent, removed, or treated as operationally binding for hot runs while still marked Proposed/Placeholder

**Compound Drift Rule:** If multiple indicators activate simultaneously, halt
autonomous audit progression and escalate for human review.
