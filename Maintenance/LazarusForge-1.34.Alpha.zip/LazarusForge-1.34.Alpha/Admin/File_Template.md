# File_Template.md — LazarusForge

**Standard file structure for LazarusForge documents.**
Applies to all new files and retrofit audit cycles.
**Last updated: 2026-11-04 — Pattern A checks C1–C3, C5, C6 implemented in `Automation/integrity_check.py` (v0.3) and C7–C8 deferred by human ruling (2026-11-04) until the VibesSandbox RELEASES register exists; previous header line relocated verbatim to the Resolution Log below per R7. Sections 0–11, Pattern A rules, Template Exemptions otherwise unchanged.**

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

This template is designed for:
- Human readability
- Machine parsing
- Autonomous auditability
- Institutional memory preservation
- Semantic stability over long time horizons

The repository is treated as a governed knowledge system, not merely a collection of markdown files.

---

## Structure Overview

Canonical doctrine, protocol, and specification files in LazarusForge follow this structure
(see Template Exemptions below for intentional exceptions):

```
0. NAVIGATION ANCHORS            — Required for non-exempt files. Routing.md and Discovery.md backlinks
1. OPERATIONAL SAFETY ADVISORY   — Optional. Physical hazard notice, shown before all else
2. FILE STATE                    — Machine-readable lifecycle metadata
3. SCOPE BOUNDARY                — Hard ownership boundaries
4. FILE PURPOSE                  — Human-readable intent
5. ASSUMPTIONS                   — Temporary truths treated as valid
6. BODY                          — Clean operational/specification content
7. LESSONS LEARNED               — Operational memory, never deleted
8. ACTIVE DISPUTES               — Interpretation conflicts
9. AUDITOR NOTES                 — Unknowns and resolution tracking
10. ABANDONED PATHS              — Graveyard for disproven approaches
11. DRIFT INDICATORS             — Automatic re-audit triggers
```

The Body must stand alone.
Footer sections are additive and must never be required to understand core functionality.
A Specification-level body should remain understandable even if all footer sections are removed.

---

---

## Pattern A — Front / Historical Record Split

*(Adopted 2026-10-28 by Human Governing Authority ruling, with all draft defaults D1–D7. Effective immediately; files migrate at their next substantive touch, never by bulk sweep.)*

One boundary heading, `## Historical Record`, divides a file. Everything above it is **Front** (current doctrine, current File State, open items). Everything below it is **Historical** — append-only evidence, not binding doctrine. No Front section appears below the boundary.

**Placement of the template's sections under Pattern A:**

| Template section | Pattern A placement | Notes |
|---|---|---|
| 0. Navigation Anchors | Front | unchanged |
| 1. Operational Safety Advisory | Front | unchanged |
| 2. File State | Front | **current values only** (R7) |
| 3. Scope Boundary | Front | unchanged |
| 4. File Purpose | Front | unchanged |
| 5. Assumptions | Front | unchanged |
| 6. Body | Front | unchanged; Frozen Sections stay here |
| 7. Lessons Learned | **Historical** | a lesson that has become doctrine is promoted into Body (D3) |
| 8. Active Disputes | Front | active only; resolved disputes go to the Resolution Log |
| 9. Auditor Notes & Unknowns | Front: **open** sidecar entries. Historical: closed entries and the Resolution Log | |
| 10. Abandoned Paths | **Historical** | |
| 11. Drift Indicators | Front | |
| Trailing `## Status` section | Front: current version line only. Historical: version history | D5 |

**Rules:**

- **R1 — Citation.** Only Front content may be cited as current doctrine. Historical content is evidence and provenance.
- **R2 — One boundary.** Exactly one `## Historical Record` heading per file (or one R8 pointer). Nothing Front below it.
- **R3 — Moves.** Content moves Front → Historical only by the template's existing mechanics (Update Procedure step 3): full text moved, never summarized or deleted; a short pointer left behind. Triggers are the file's own rule if it has one, else the existing 20% and Aging rules — no new numeric threshold. A resolved unknown moves to Closed Sidecar Entries at closure, ID unchanged.
- **R4 — No silent moves.** Every Front → Historical move gets a dated one-line Resolution Log entry saying what moved and why.
- **R5 — Historical is append-only.** New entries go at the end of their section. Any later annotation inside an existing Historical entry carries a dated marker so an annotation can never read as original text.
- **R6 — Versioning.** A change to Front text bumps the version (existing ruling, 2026-10-25). A pure Historical append does not bump and does not advance Last Audit. A Front → Historical move changes Front text, so it bumps (D2).
- **R7 — File State is current only.** Last Audit and Auditor hold the latest as one short line; long "Prior:" chains move to the Resolution Log. Existing chains migrate at the file's next substantive touch, not in bulk. Where a file carries both Last Audit and Last Updated rows, they advance together. *(Amended 2026-11-04, MAINT-56: Last Audit and Auditor are retired fields; the one-short-line rule now governs the header version/status line, and the Prior-chain migration rule stands.)*
- **R8 — Relocated logs.** (Amended 2026-10-30, Decision Brief 2026-10-30c; naming re-ruled same day, MAINT-29.) A file whose Resolution Log lives outside the file keeps one pointer line under `## Historical Record`. The relocation is an allowed form of Historical, not a separate exception. New relocated logs land in the **owning folder's `<Letter>Logs/` subfolder** (Admin: `Admin/ALogs/<FILE>_Log.md`; other folders per their designated letter). Existing `Archive/Logs/` changelogs are frozen in place and move only on their own triggers — except the five Admin-owned changelogs relocated to `Admin/ALogs/` by direct human direction 2026-10-30.
- **R9 — Exemptions.** The template's existing exemption list stands as-is; derived indexes, pure logs, and exempt classes do not adopt Pattern A. No ad-hoc exemptions.

**Consistency checks (part of this adoption, not a follow-up):**

| # | Check | Kind |
|---|---|---|
| C1 | Exactly one boundary heading or one R8 pointer | static, one file |
| C2 | No Front section heading below the boundary | static, one file |
| C3 | Version in the header equals the version in the newest Resolution Log entry naming a transition | static, one file |
| C4 | Retired 2026-11-04 with the Last Audit field (MAINT-56) — audit recency is now the Resolution Log’s own discipline | retired |
| C5 | File State holds no "Prior:" chain (warning level; migrate on touch) | static, one file |
| C6 | Historical entries are in date order | static, one file |
| C7 | Every Front change between two releases has a Resolution Log entry | release-diff |
| C8 | Historical text unchanged between releases except appends and dated annotations | release-diff |

C1–C6 extend sweep step 13's neighbors and `integrity_check.py`; C7–C8 use the release 1.27 baseline-and-hash method. *(C1–C3, C5 and C6 are implemented in `Automation/integrity_check.py` as of 2026-11-04; C7–C8 are deferred by human ruling 2026-11-04 until the VibesSandbox RELEASES register exists.)*

**Pilot:** `Operations/Plastics.md` and `Operations/Woodworking.md` (D7) — one file per cycle, migrated by hand, never mid-audit or mid-gate-campaign. Success tests and stop conditions per the adopted draft §6 (Front size measured before/after; reader test; deliberate skipped-log-entry check test; cascade count — stop if a pilot migration touches files beyond the file and its own log). Pattern B (sibling files, one log beside each doctrine file) remains not proposed. The adoption-day "no `logs/` or `audits/` subfolders" clause is superseded 2026-10-30 (Decision Brief 2026-10-30c) for two homes only: per-folder `Logs/` subfolders for relocated Resolution Logs and per-folder `Audits/` subfolders for new audit artifacts — see Log-Split Rule below.

**Interaction with PKC-002 (D5):** this adoption supersedes the PKC-002 ruling's "not adopted now" note for the trailing-Status version-history part — the current-version line stays required in Front, the history moves to Historical. The PKC-002 row itself is the human's to close in `Admin/Progress_Log.md`.

---

## Log-Split Rule (Option C — adopted 2026-10-30)

*(Human Governing Authority ruling, Decision Brief 2026-10-30c, items 1–2. Enacted 2026-10-30.)*

A doctrine file's Resolution Log physically splits out of the file when a trigger fires; the front file keeps one R8 pointer line under `## Historical Record`. Splits are per-file, executed at the file's **next substantive touch** — never in bulk, never mid-audit or mid-gate-campaign, one file at a time with the heaviest first. Frozen history moves only under R3/R4: full text moved, never summarized or deleted, with a dated Resolution Log entry and disclosure in the executing pass's log entry.

**Triggers — any one qualifies the file for a split at its next touch:**

- **T0 — Existing triggers:** the file's own rotation rule, the 20% Rule, or the Aging Rule, unchanged.
- **T1 — Size:** the file measures **≥ 100 KB**.
- **T2 — Audit purity:** the executing pass judges that audit purity is likely to be affected by the in-file log: (a) the file is not yet Pattern A-migrated and log bulk makes Front/Historical separation unreliable; (b) the file is a canonical measurement input (e.g., an MDR instrument) and further log growth would destabilize the recorded input hash between runs; (c) the pass would need to load or mutate the log's content to complete its own checks, risking cross-contamination of the audit object. The T2 judgment is disclosed in the executing pass's log entry.

**Homes:**

- Split Resolution Logs: the **owning folder's `<Letter>Logs/` subfolder**, named `<FILE>_Log.md` (precedent: `Auditor_Protocols_Logs.md`, now at `Admin/ALogs/`). Example: an Admin file's log lands in `Admin/ALogs/`.
- New audit artifacts: the **audited folder's `<Letter>Audits/` subfolder** (Admin: `Admin/AAudits/`).
- Existing `Archive/Logs/` changelogs and `Archive/Audits/` artifacts are **frozen in place**; they move only on their own triggers — except the Admin-owned set relocated to `Admin/ALogs/` and `Admin/AAudits/` by direct human direction 2026-10-30 (MAINT-29). Root-owned changelogs (Discovery, Unknowns) and corpus-wide artifacts (cross-file pattern findings, sweep reports, session prompts/status) remain in `Archive/`.

**Subfolder naming (human-ruled 2026-10-30):** log and audit subfolders take the owning folder's designated single-letter zip-code prefix — Admin → `ALogs/` and `AAudits/`. Letters are the folder's **X3 designated zip-code letter** (Routing.md, registered 2026-10-28), not its initial. Architecture (X3 letter **R**) → `Architecture/RLogs/` and `Architecture/RAudits/` when its homes are first needed; the Admin/Architecture shared-initial collision is CLOSED (human direction 2026-10-30). Designations for the remaining folders are assigned when their homes are first needed.

**Interaction notes:** once a file is split, checks C7/C8 apply in two-file form (pointer present in Front; log file append-only between releases). A split of an MDR canonical input is an instrument change: record input version + hash at each run; never mix. The Unknowns.md 1,200-line compression trigger is a separate mechanism, unaffected by this rule.

---

## Template Exemptions

The full File Template is **not** applied to every file in the repository. Forcing the template onto files whose purpose is navigation, indexing, historical preservation, or pure operational seeding creates more drift than it prevents. The following classes are intentionally exempt. Agents and retrofit passes must not attempt to force Navigation Anchors, File State tables, or the full section set onto exempt files.

**Exempt classes (hold in memory; do not retrofit):**

1. **Archive/** — All files under `Archive/` and `Archive/Logs/`. These are historical records. Their structure is frozen for preservation fidelity. Relative-link hygiene is still required; full template is not.

2. **Root navigation / index surface**
   - `README.md`
   - `Discovery.md`
   - `Routing.md`
   - `Unknowns.md`
   These *are* the navigation layer. Requiring them to contain Navigation Anchors that point at themselves is redundant and creates circular maintenance load.

3. **Contributor / process entry points**
   - `CONTRIBUTING.md`

4. **Per-folder scope maps**
   - `Admin/Adm_Scope_Map.md`
   - `Architecture/Arc_Scope_Map.md`
   - `Operations/Ops_Scope_Map.md`
   - `Challenges/Cha_Scope_Map.md`
   - `Tests/Tst_Scope_Map.md`
   These are cross-reference indexes. They use a lightweight relative-link Navigation Anchors style appropriate to their role; the absolute GitHub-raw form is not required.

5. **Progression and changelog sidecars**
   - `Admin/Progress_Log.md`
   - All `*_Changelog.md` files (wherever located)
   - `Archive/Rename_Registry.md` and equivalents
   These exist to absorb entropy, not to host full doctrine structure.

6. **Operational seeds and invocation templates**
   - `Admin/BATTERY_SEED.md`
   - `Admin/PROBE_INVOCATION.md`
   - `Admin/INTEGRITY_SWEEP_PROMPT.md`
   These are prompt / battery / invocation payloads, not governed specification documents.

7. **Automation source**
   - All files under `Automation/` (`.py` and any accompanying docs that are pure implementation)

8. **Challenges/ Problem-Statement subtype**
   - `Challenges/Biofouling.md`
   - `Challenges/Critical_Minerals.md`
   - `Challenges/Emergence.md`
   - `Challenges/Planned_Obsolescence.md`
   - `Challenges/Waste.md`
   - `Challenges/Water.md`
   These carry a File State table but Spec Gates is N/A by subtype — they define problems, not specifications to be gated, and the six canonical gates do not apply to them in any reading; no gate count is kept. (Reconciled 2026-10-28, human ruling — AUDIT_10 F1; re-ruled later the same day by Decision Brief 2026-10-28c item 2: "Spec Gates N/A by subtype" governs, superseding the earlier same-day reading that kept a live reinterpreted 0–6 count.) Confirmed as an intentional, already-reviewed exemption via a 2026-08-10 pseudo-audit pass on each file (see each file's own Resolution Log: "Spec Gates N/A for Challenges Problem-Statement subtype"), not an oversight. Added here 2026-09-04 to close a documentation gap: the exemption existed in practice and in each file's own record but was never listed in this canonical class list, which had allowed a later fabricated claim (that these files were "missing" the field entirely, an accidental early-cohort gap) to go unchecked against this file before being repeated. `Challenges/Return_To_Eden.md` and `Challenges/Closed_Loop_Feedstock.md` are Solution-Track subtype, not Problem-Statement, and are not exempt — they carry real Spec Gates values.

9. **Reference index**
   - `Admin/Operational_Conventions.md`
   A pointer list of mechanical rules, each owned by another file. Exempt from the Lessons Learned, Active Disputes and Abandoned Paths sections and from keeping a Resolution Log; its passes are recorded in its Last Audit field. The exemption was declared in the file itself and is listed here from 2026-10-25 (PKC-017).

10. **Tier 0 philosophical substrate**
   - `Admin/Nothingness_Theorem.md`
   Functionless by doctrine and by its own File State (“Tier 0 — Philosophical Substrate, functionless by doctrine”); its sidecar unknowns are Tier 0 — internal-consistency audit only — and `Admin/Computational_Institutional_Reasoning.md` derives from it without promoting it into any gate ladder. The exemption is practiced and honored corpus-wide but was missing from this canonical list — the same documentation-gap class as the PKC-017 listing (AUDIT_24 F1). Listed here 2026-10-28 (Decision Brief 2026-10-28d, item 6, human-ratified). Nothing about the file changes: it keeps its Scope Boundary (added 2026-08-09 for index consistency) and its own registries.

11. **Stub / scaffold / candidate family**
   - `Admin/Integrity_Incident_Log.md`
   - `Admin/Agent_Verification_Event.md`
   - `Admin/Experiments.md`
   - `Admin/Hardware_Diversity_Ladder.md`
   One exemption-class ruling covering the family instead of per-file dispositions (AUDIT_23 F1, AUDIT_27 F2, AUDIT_28 F1, AUDIT_29 F1): these files declare themselves — in their own File State or Status lines — an append-only intake log awaiting entries, a candidate/exploration event schema, a falsification-record scaffold, and a proposed implementation reference: structural shells whose content accrues later. They carry File State tables, Scope Boundaries and their own sidecars and remain fully auditable; the exemption is from forcing the full template section set onto a shell (Lessons Learned with no lessons yet, Abandoned Paths with no history yet), which manufactures the empty sections this template exists to prevent — per its own counsel, prefer exemption over forced retrofit. The exemption ends the moment a file’s own record outgrows the stub/scaffold/candidate state; each file’s own Status, Last-Reviewed and sidecar discipline still apply unchanged. Listed here 2026-10-28 (Decision Brief 2026-10-28d, item 6, human-ratified).

**Non-exempt (template applies on retrofit and for new files):**  
All other files under `Admin/`, `Architecture/`, `Operations/`, `Challenges/`, and `Tests/` that carry doctrine, protocols, specifications, or gate definitions.

When in doubt, prefer exemption over forced retrofit. Adding an exemption is cheaper than creating a new class of false-positive integrity findings.

---

## 0. Navigation Anchors

**Required for non-exempt files.** Place immediately below the title, before the Operational Safety
Advisory or File State.

```markdown
---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---
```

The Navigation Anchors block ensures every file is machine-discoverable from its first lines.
An agent loading any file in the repository can immediately locate the full routing table
and the scope map without prior context. This is the backlink requirement defined in Routing.md.

**The anchor block is fixed.** The two URLs do not change per file — they are repository-level
constants. Do not substitute file-specific links.

---

## 1. Operational Safety Advisory

**Optional. Include in any file governing physical operations, hazardous processes,
or systems where operator error causes irreversible harm.**

Place immediately below the Navigation Anchors block, before the File State table. It is the
first content any operator or agent reads — including those who read nothing else.

```markdown
> ⚠️ **Operational Safety Advisory**
> [One to six sentences. Name the specific hazard. State the consequence.
> Name the prerequisite or constraint. Reference the relevant unknown ID
> if the mitigation is still unresolved. End with a decision rule that
> works under pressure: "When in doubt, [hold / stop / do not proceed]."]
```

### Safety Advisory Doctrine

**Specificity is required.** A generic warning is ignored. Name the actual
hazard for this gate or module — arc flash, molten metal, fragment ejection,
energetic discharge, toxic fume. An operator who has read only this section
must know what can kill or maim them and what to do about it.

**Reference open unknowns.** If the hazard mitigation is unresolved, say so
and name the unknown ID. This is honest about what is not yet protected against.

**End with a decision rule.** The last sentence should give the operator a
clear action under uncertainty: *"When in doubt, hold."* *"When in doubt, stop."*
*"The cost of a missed hazard is always higher than the cost of a hold."*
This survives fatigue, time pressure, and incomplete information.

**Governance files omit this section.** The safety advisory is for physical
operations. Admin/, Architecture/, and navigation files do not require it.

**The advisory does not replace body content.** Detailed safety procedures,
PPE requirements, and mitigation doctrine belong in the Body. The advisory is
a pre-read flag, not a specification.

---

## 2. File State

Place immediately below the Navigation Anchors block (and Safety Advisory if present).

```markdown
## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Exploration / Draft / Specification                                 |
| Body Stability   | Volatile / Transitional / Stable                                    |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | Admin/Verification_Gates.md                                      |
| Open Unknowns    | N                                                                   |
| Active Disputes  | N                                                                   |
| Highest Risk     | Low / Medium / High / Critical                                                 |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |
```

**Last Audit and Auditor are retired fields (human ruling, 2026-11-04, MAINT-56).** The File State table no longer carries them: audit recency and auditor attribution live in each file’s own Resolution Log and its changelog home (the folder’s <Letter>Logs/ sidecar). Existing files migrate at their next substantive touch; the MAINT-56 pass trims the heaviest offenders directly. Related, same ruling: **a file’s header version/status line is one line** — date, version, and a short clause; narration lives in the Resolution Log, not the header.

**The Ethical Anchor field is fixed and non-negotiable.** Its value must match the canonical
string exactly in every file. Absence, alteration, or blank value is a mandatory drift
indicator requiring human review. It is not a reference to an external document — it is a
load-bearing principle that survives even if Ethical_Constraints.md is missing, corrupted,
or deliberately omitted.

**Verification Ref must point to `Admin/Verification_Gates.md`.** Not Forge_Audit_Kit.md.
The Kit is a condensed reference; the Gates file is the canonical authority.

**Highest Risk takes a Risk value, never a Priority value** (human ruling, 2026-10-25, PKC-004 and
PKC-024; vocabulary amended by human ruling, 2026-11-03, MAINT-55). The allowed values are
Low / Medium / High / Critical. "Critical" joined the Risk vocabulary by human ruling on 2026-11-03
(two live File States already carried it; `Architecture/Chemistry.md` corrected in the same
pass); elevated severity is still carried by the Blocking designation on an unknown. Risk and
Priority are distinct fields: Risk values must not appear in a Priority column, nor Priority
values in a Risk field — Critical is the one deliberate exception, valid in both vocabularies
by the same ruling (CE-003 carries Risk Critical and Priority Critical side by side).
An open Blocking item that is ignored is a warning condition in audits and in work that depends
on it.

---

### Status Definitions

**Exploration** — Incomplete by design. Ideas are being explored and should not be pressured
toward premature specification.

**Draft** — Substantive content exists and active convergence toward Specification is underway.

**Specification** — All required verification gates passed. Claims are considered binding
until revised through a full audit cycle.

**Proposed** is retired and is not a Status value (human ruling, 2026-10-25, PKC-031). A newly
generated file starts at Exploration and advances through Draft and Specification as it matures.
No post-execution status exists: a file that has been exercised, such as a completed pilot, keeps
its Status and records what happened in its logs. A file still reading Proposed is awaiting
migration to Exploration, not in violation of a new rule.

---

### Body Stability Definitions

**Volatile** — Major restructuring expected and acceptable.

**Transitional** — Core intent stabilizing; wording may still evolve.

**Stable** — Wording and structure should remain mostly preserved unless justified by audit
or operational evidence.

---

### Spec Gates

The repository uses six canonical verification gates defined in `Admin/Verification_Gates.md`.

| Gate | Requirement                  |
|------|------------------------------|
| G1   | Fallacy Check                |
| G2   | Physical Plausibility        |
| G3   | Adversarial Challenge        |
| G4   | Scope Alignment              |
| G5   | Cross-Reference Integrity    |
| G6   | Conflict Check                |

Modules may define additional local gates but may not remove canonical gates.
A file cannot be promoted to Specification without passing all six.

---

### Challenges/ File Subtypes — Problem-Statement vs. Solution-Track

Not every file in `Challenges/` is heading toward a build. Most name a real-world
problem the Forge should be aware of and eventually act on — they are not
themselves specifications for anything that gets fabricated. Applying the full
build-readiness reading of Spec Gates to this class of file is a category
mismatch, not a compliance gap. Two subtypes exist, and a file's subtype should
be stated explicitly rather than left to be inferred from which fields happen
to be present.

**Problem-Statement subtype** — names and scopes a real-world problem; does not
itself converge toward a build. The lean File State schema (Status, Version,
Owner, Verification Ref, Ethical Anchor) is a deliberate, documented choice for
this subtype, not a truncated version of the full schema. **Spec Gates are N/A by subtype** — per the 2026-10-28c human re-ruling, the six canonical gates do not apply to Problem-Statement files in any reading; no reinterpreted act-readiness count is kept. What a problem statement owes is ordinary problem-rigor hygiene, checked but not gate-evaluated:

| Check | Problem-Statement reading |
|------|------------------------------|
| G1 — Fallacy Check | Reasoning behind naming this a problem is sound |
| G2 — Physical Plausibility | The claimed problem doesn't violate physical/scientific fact — is the severity, scarcity, or failure mode actually as claimed? |
| G3 — Adversarial Challenge | The problem framing has survived adversarial counterargument — is this real, and real at Forge's actual scale? |
| G4 — Scope Alignment | Belongs in v0 scope, or is it a `Admin/Trajectories.md`-deferred concern? |
| G5 — Cross-Reference Integrity | Cross-references resolve; claims aren't invented |
| G6 — Conflict Check | No contradiction with existing doctrine |

A Problem-Statement file does not carry a Spec Gates count; its File State reads
Spec Gates N/A by subtype. Whether the repository is ready to *act* on the problem —
spawn an Operations/ file, register formal Unknowns against it, become someone's
actual work — is a human judgment, not a gate value; the problem-rigor checks
above are advisory hygiene, not promotion gates.

**Solution-Track subtype** — a Challenges/ file that has grown past naming a
problem into active engineering: worked equations, a telemetry model, a
resolution log tracking real design decisions. Uses the full eleven-field File
State schema and the standard build-readiness reading of all six gates, same as
any Architecture/ or Operations/ file. `Challenges/Closed_Loop_Feedstock.md` and
`Challenges/Return_To_Eden.md` are the current examples — both began as
problem statements and were promoted in practice as their content outgrew that
scope. Promotion from Problem-Statement to Solution-Track is a real transition
that should be logged in the file's own Resolution Log, not a silent schema
drift discovered later by audit.

**Declaring subtype:** add a `Challenges Subtype` field to Problem-Statement
files' File State table (value: `Problem-Statement` or `Solution-Track`) so the
distinction is explicit rather than inferred from which fields are present or
absent. Existing Problem-Statement files predating this doctrine may retrofit
this field without triggering a full schema migration.

---

### File State Purpose

The File State block is the first thing an autonomous agent reads after Navigation Anchors. It determines:
- Whether the file is stable enough to trust
- Whether the body should be edited
- Whether the sidecar should be prioritized
- Whether the file requires a Resolution Pass before audit proceeds
- Whether the ethical anchor is intact

---

## 3. Scope Boundary

Place immediately after File State.

```markdown
## Scope Boundary

**This file DOES define:**
- ...

**This file DOES NOT define:**
- ...
```

The Scope Boundary is the repository's primary defense against specification bleed, duplicate
ownership, uncontrolled expansion, and semantic overlap.

If content is not listed under DOES, it does not belong in the Body.

---

## 4. File Purpose

```markdown
## File Purpose

One paragraph explaining what this file exists to do and why it matters.
```

Write for a new auditor unfamiliar with the repository. Avoid jargon, philosophical arguments,
forward references, and implementation detail.

Purpose should explain:
- What the file governs
- Why it exists
- What failure would occur if it disappeared

---

## 5. Assumptions

Optional but strongly recommended for all files beyond brand-new stubs.

```markdown
## Assumptions

| ID      | Assumption | Basis    | Confidence        | Expiry Trigger                    |
|---------|------------|----------|-------------------|-----------------------------------|
| ASM-001 | [statement]| [reason] | Low/Medium/High   | [condition that invalidates this] |
```

---

### Assumptions Doctrine

Assumptions are not facts. They are temporary truths currently treated as operationally valid.

Assumptions exist to expose:
- Hidden premises
- Simulation constraints
- Environmental expectations
- Resource availability assumptions
- Provisional engineering simplifications

**Unknowns** are things not yet known.
**Assumptions** are things temporarily treated as true.

These categories must remain separate. An assumption that can no longer be defended becomes
an Unknown and must be migrated to the Auditor Notes sidecar.

---

## 6. Body

The document's operational or specification content.
The Body must be understandable without sidecars, dispute sections, governance commentary,
or lessons learned.

---

### Body Rules

- No governance notes
- No audit commentary
- No dispute framing
- No speculative philosophy in Specification-level sections
- Cross-file references use canonical filenames, not raw URLs
- Quantitative claims must carry confidence labels:
  **(Measured / Replicated / Simulated / Analogous / Placeholder)**

---

### Frozen Sections

Once a section passes a verification gate and its claims are binding, mark it:

```markdown
<!-- FROZEN: Gate 3 — 2026-05-07 — Do not edit without full audit cycle -->
```

**Frozen Scope Rule:** A FROZEN marker applies to the nearest heading scope beneath it,
including all subordinate subsections, until the next heading of equal or higher level.

Autonomous agents must not modify frozen sections. If modification becomes necessary:
1. Justification must be documented
2. Relevant gate status resets
3. Affected sections re-enter audit flow

---

### Canonical Vocabulary

Files should preserve repository-defined terminology. Core terms with specialized meaning
reference `Admin/Canonical_Terms.md`. Agents must not casually redefine canonical terminology.

---

## 7. Lessons Learned

Placed after the Body. Separated by a horizontal rule.

```markdown
---

## Lessons Learned

| Date       | Evidence Type | What Was Tried | What Failed | What Was Learned | Confidence | Revalidation Needed |
|------------|---------------|----------------|-------------|------------------|------------|---------------------|
| YYYY-MM-DD | [type]        | [description]  | [failure]   | [insight]        | [level]    | Yes / No            |
```

---

### Evidence Types

| Type        | Meaning                                      |
|-------------|----------------------------------------------|
| Bench Test  | Physical test in controlled conditions       |
| Field Test  | Physical test in operational conditions      |
| Simulation  | Computational or procedural model            |
| Modeling    | Analytical or mathematical derivation        |
| Audit Review| Finding generated through document audit     |
| Anecdotal   | Informal observation, low evidentiary weight |

---

### Confidence Levels

| Level      | Meaning                                              |
|------------|------------------------------------------------------|
| Measured   | Directly observed and recorded                       |
| Replicated | Observed multiple times or by multiple parties       |
| Simulated  | Derived from model, not direct observation           |
| Analogous  | Inferred from similar systems or prior experience    |
| Anecdotal  | Informal, single observation, treat with caution     |

---

### Lessons Learned Doctrine

Lessons Learned entries are **permanent**. Do not delete entries because the system evolved.
Historical failures are repository memory.

What belongs here:
- Physical test outcomes
- Design decisions that were reversed and why
- Material substitutions that worked or did not work
- Operational conditions that were not anticipated

What does not belong here:
- Governance findings → Auditor Notes
- Future plans → `Admin/Trajectories.md`
- Unresolved questions → Auditor Notes sidecar
- Interpretation conflicts → Active Disputes

A module with no Lessons Learned entries is either brand new or has never been tested.

---

## 8. Active Disputes

Placed after Lessons Learned. Include the header and empty table even if no disputes exist —
the category must remain visible to prompt auditors to actively check rather than skip it.

```markdown
---

## Active Disputes

| ID     | Summary   | Positions in Conflict | Risk   | Status | Owner  |
|--------|-----------|-----------------------|--------|--------|--------|
| DS-001 | [summary] | [position A vs B]     | Medium | Open   | [file] |
```

---

### Dispute Doctrine

**Unknowns** are reality gaps — we do not yet know what is true.
**Disputes** are interpretation conflicts — we disagree about what is true or right.

These are not the same thing and must not be conflated.

| Status     | Meaning                                              |
|------------|------------------------------------------------------|
| Open       | Active unresolved disagreement                       |
| Escalated  | Requires repository-level intervention               |
| Persistent | Healthy long-term tension expected to remain         |
| Resolved   | Conflict closed                                      |

Not all disputes should resolve. Some tensions are structurally healthy — efficiency vs.
robustness, autonomy vs. operator control, decentralization vs. standardization.

Disputes open across three consecutive audits must be escalated to `Unknowns.md` for
repository-level resolution.

---

## 9. Auditor Notes & Unknowns

The sidecar. Placed after Active Disputes.

```markdown
---

## Auditor Notes & Unknowns

### [FILE-PREFIX-NNN] — Short title

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open / In Progress / Resolved                    |
| Risk          | Low / Medium / High / Critical                              |
| Priority      | Minor / Major / Critical                         |
| Type          | Technical / Ethical / Architectural / Governance |
| Blocking      | Yes / No                                         |
| Owner         | Responsible file or module                       |
| First Logged  | YYYY-MM-DD                                       |
| Last Reviewed | YYYY-MM-DD                                       |

**Description:** One sentence stating the reality gap.

**Why It Matters:** One sentence on consequence if left unresolved.

**Resolution Path:** Concrete closure criteria. One of:
- *Payment via Specification* — resolved; content moves into Body as committed spec
- *Discharge via Trajectory* — real but out of scope; route to Admin/Trajectories.md
- *Discharge via Lessons Learned* — resolved by operational experience; lesson recorded

---

### Resolution Log

- YYYY-MM-DD: [FILE-PREFIX-NNN] — One-line description of how it was resolved or discharged
```

**Resolution Log heading level.** The heading text "Resolution Log" is what counts, at either
level. Existing files use `###` (nested here, as shown) or `##`, and both are accepted; no file is
retrofitted for the level alone (human ruling, 2026-10-25, PKC-018). New files use `###`.

---

### Unknowns Doctrine

Unknowns must:
- Describe reality gaps, not interpretation conflicts
- Remain concrete and falsifiable
- Avoid philosophical drift

**Local ID format:** File abbreviation + three-digit number.
Examples: `CO-001` (Components), `FA-001` (Facilities), `PR-001` (Precision).

**Cross-module unknowns** use the global `UNK-XXX` format and are indexed in `Unknowns.md`.
Reference them here but do not duplicate the full entry.

---

### Sidecar Governance Rules

**10-Entry Rule:** Removed 2026-10-20 (AP-029; `Admin/Auditor_Protocols.md` v0.44) — no open-entry-count
threshold applies. Resolved entries move to the Resolution Log — they are not deleted.

**20% Rule:** If the sidecar exceeds 20% of total document word count, halt expansion and
prioritize consolidation or discharge before auditing further.

**Aging Rule:** Unknowns unreviewed for more than 90 days trigger mandatory re-audit.

---

## 10. Abandoned Paths

Optional but strongly recommended. Omit only if the file is brand new and no paths have
been explored yet.

```markdown
---

## Abandoned Paths

| Date       | Path                  | Why Abandoned          | Reconsider? |
|------------|-----------------------|------------------------|-------------|
| YYYY-MM-DD | [description of path] | [reason for rejection] | Yes / No    |
```

---

### Abandoned Path Doctrine

This section prevents cyclical rediscovery, repeated dead-end exploration, and resurrection
of disproven assumptions.

**Reconsider: Yes** — Path may be revisited with new evidence.

**Reconsider: No** — Hard stop. Requires explicit human authorization, a new dated entry,
and documented reason for reopening. Autonomous agents may not reopen hard-stopped paths
independently.

---

## 11. Drift Indicators

Drift Indicators are automatic re-audit triggers. They are not optional checklist items.

---

### Mandatory Re-Audit Conditions

- Body contradicts Lessons Learned
- Unknown count increases across three consecutive audits
- Unknown remains unreviewed more than 90 days
- Specification claim lacks a confidence label
- Frozen section modified without a dated justification comment
- Sidecar exceeds 20% of total document word count
- Persistent disputes silently disappear without resolution entry
- Assumptions remain past their expiry trigger without review
- Canonical terminology changes meaning across files
- Navigation Anchors block absent or URLs modified from canonical values
- **Ethical Anchor field is absent, altered, or does not match the canonical string**
- **A registered Self-Referential Version String (see below) does not match the file's own File State version**

---

### Self-Referential Version Strings

Some files quote their own version number in body prose — a role declaration example, a sign-off template, a "per vX.Y" citation — separately from the File State header. These drift independently of the header and of each other, because nothing connects them: an editor updates File State on a version bump and has no way to know three other strings elsewhere in the same file also need to change. `Admin/Auditor_Protocols.md` documented this pattern recurring four times across four separate sessions (AP-023, AP-025) before this section existed — each instance caught by chance during an unrelated audit, never by a dedicated check.

**Requirement:** any file containing a self-referential version string outside the File State header must maintain a **Version String Registry** — a short list, placed immediately after File State, naming every such location:

```markdown
**Version String Registry** (self-referential citations outside File State — update on every version bump):
- §Role Declaration Requirement, example string
- §Observability & Audit Trail, Standard sign-off template
```

This is not optional documentation — it is what makes the Drift Indicator above checkable at all, by a human or a future automated pass, without needing bespoke per-file logic to first discover where the strings live. A file with no self-referential version strings outside File State does not need this section; most files will not need it.

**Preferred alternative:** where phrasing allows, point at File State's version rather than restate it — "per this file's current version" instead of a hardcoded "vX.Y" — removing the desync point entirely rather than registering it. `Admin/Auditor_Protocols.md`'s Rule 5 fix (AP-026) applied this same principle to a duplicated *definition* rather than a version string, but it's the same failure shape: a copy is a place to fall out of sync; a pointer isn't. Use the registry for cases where restating the literal value is unavoidable (e.g., an example string meant to show contributors the exact expected format).

---

### Compound Drift Rule

If multiple Drift Indicators activate simultaneously, halt autonomous audit progression and
escalate for human review. Compound instability is more dangerous than isolated instability.

---

## Retrofit Checklist

**First check the Template Exemptions section.** If the file falls into an exempt class, stop. Do not force the structure.

When converting a *non-exempt* existing file to this structure:

- [ ] Confirm the file is not on the Template Exemptions list
- [ ] Add Navigation Anchors block immediately below title (standard absolute form)
- [ ] **If physical operations file:** Add Operational Safety Advisory — specific hazard, consequence, prerequisite, decision rule, open unknown reference if applicable
- [ ] Add File State table — include Ethical Anchor field with canonical string; confirm Verification Ref points to `Admin/Verification_Gates.md`
- [ ] Add Scope Boundary — be honest about what the file does and does not own
- [ ] Add File Purpose paragraph
- [ ] Extract hidden assumptions into Assumptions section
- [ ] Remove governance commentary from Body
- [ ] Remove speculative language from Specification-level sections
- [ ] Move operational memory into Lessons Learned with Evidence Type and Confidence columns
- [ ] Move interpretation conflicts into Active Disputes
- [ ] Create Unknown entries for all known open reality gaps
- [ ] Populate Abandoned Paths where applicable
- [ ] Apply FROZEN markers to verified sections
- [ ] Validate canonical terminology usage against `Admin/Canonical_Terms.md`
- [ ] Verify Drift Indicators before finalizing
- [ ] If the file contains a self-referential version string outside File State, add a Version String Registry listing every location — or rephrase to point at File State instead of restating the value
- [ ] Set Status honestly — most existing files are Exploration
- [ ] Set Body Stability honestly — most existing files are Volatile or Transitional
- [ ] Set Spec Gates to reflect actual verification progress

---

## Minimal Valid File Example

```markdown
# Module Name

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

> ⚠️ **Operational Safety Advisory**
> *(Include for physical operations files only. Omit for governance, architecture,
> and navigation files. Name the specific hazard, state the consequence, name the
> prerequisite or constraint, reference open unknown ID if mitigation is unresolved,
> end with a decision rule under pressure.)*

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Exploration                                                         |
| Body Stability   | Volatile                                                            |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | Admin/Verification_Gates.md                                      |
| Open Unknowns    | 1                                                                   |
| Active Disputes  | 0                                                                   |
| Highest Risk     | Low                                                                 |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

## Scope Boundary

**This file DOES define:**
- Core concept and initial requirements for this module

**This file DOES NOT define:**
- Detailed engineering drawings, control software, or cross-module interfaces

## File Purpose

One clear paragraph explaining what this file exists to do and why it matters to the Forge.
Written for a new auditor who has never seen the repository.

## Assumptions

| ID      | Assumption                        | Basis           | Confidence | Expiry Trigger                |
|---------|-----------------------------------|-----------------|------------|-------------------------------|
| ASM-001 | Grid power available at bootstrap | v0 site context | Medium     | Off-grid deployment confirmed |

---

[Body content here]

---

## Lessons Learned

| Date | Evidence Type | What Was Tried | What Failed | What Was Learned | Confidence | Revalidation Needed |
|------|---------------|----------------|-------------|------------------|------------|---------------------|
| —    | —             | —              | —           | No entries yet   | —          | —                   |

---

## Active Disputes

| ID | Dispute Summary    | Positions in Conflict | Risk | Status | Owner |
|----|--------------------|-----------------------|------|--------|-------|
| —  | No active disputes | —                     | —    | —      | —     |

---

## Auditor Notes & Unknowns

### MN-001 — Example unknown

| Field         | Value      |
|---------------|------------|
| Status        | Open       |
| Risk          | Low        |
| Priority      | Minor      |
| Type          | Technical  |
| Blocking      | No         |
| Owner         | This module|
| First Logged  | YYYY-MM-DD |
| Last Reviewed | YYYY-MM-DD |

**Description:** One sentence stating what is not yet known.

**Why It Matters:** One sentence on consequence if unresolved.

**Resolution Path:** Payment via Specification — once X is tested and confirmed, move to Body.

---

### Resolution Log

*(empty)*
```

---

## New File Creation Checklist

The sections above (0–11) and the Minimal Valid File Example already define *what* a new
file should contain. This checklist covers what the template itself doesn't: getting a new
file correctly discoverable and registered the same session it's created, so it doesn't
become an orphan the way `Operations/Tooling_Inventory.md` briefly was (missing from
`Routing.md` for five days after creation) or require a later sweep to find.

- [ ] Choose the correct directory and a canonical filename (no spaces; follow existing
      naming in that folder).
- [ ] Check **Template Exemptions** above first. If the new file falls into an exempt class
      (Archive/, root nav surface, `CONTRIBUTING.md`, a `*_Scope_Map.md`, or a progression/
      changelog sidecar), use that class's lighter convention, not the full 0–11 structure.
- [ ] For a non-exempt file, apply the full skeleton (sections 0–11) or the Minimal Valid
      File Example as a starting point.
- [ ] For a pure scaffold, index, or taxonomy file (comparable to `Admin/Metrics_Scaffold.md`
      or `Admin/Progress_Log.md`): Spec Gates = N/A, Status set honestly (e.g. "Active —
      Scaffold Only"), and the lighter section set those two files actually use — Navigation
      Anchors, File State, Purpose, Body/tables, Resolution Log — is sufficient; Scope
      Boundary/Assumptions/Lessons Learned/Active Disputes/Abandoned Paths/Drift Indicators
      may be omitted until the file actually needs them.
- [ ] Register the new file in `Routing.md` (table row + a dated "Last updated" note at the
      top) **in the same session**, not as a follow-up.
- [ ] Register it in the relevant `*_Scope_Map.md` (Does / Does not (arrow) entry) and in
      `Discovery.md` (both the folder tree and, if it carries a Status/Spec Gates/Risk
      profile, the status table) in the same session.
- [ ] If the new file introduces any new cross-module unknowns, register them in
      `Unknowns.md`'s Active Index — a local sidecar entry alone is not sufficient for
      anything other files may need to reference.
- [ ] First Resolution Log entry records creation date, what the file does and does not do,
      and — if drafted by one agent and checked by another — Proposer/Verifier per the
      provenance convention below.

---

## Update Procedure

Use this whenever an existing governed file is materially changed — content, metadata, or
structural. This is deliberately lighter than the Retrofit Checklist above, which is for
bringing a non-compliant *existing* file up to this template; this procedure is for an
already-compliant file receiving an ordinary edit.

### 1. Pre-update checks
- Confirm the file is the correct canonical target (check `Routing.md` / `Archive/Rename_Registry.md` if a legacy name appears anywhere in the request).
- Note the current File State (Status, Spec Gates, Open Unknowns, Last Reviewed) before editing, so the diff is deliberate rather than incidental.
- Identify whether the change is content-only (Body/Lessons/notes), metadata-only (File State fields, dates), or structural (new section, rotation, split, merge).
- Note the file's current version, if it carries one, as the base. If the copy in hand has the same version as the committed file but different content, or an older version than the committed file, treat it as a fork: stop and route it to the human, who is the single merge point. Do not merge automatically.

### 2. Make the change
- Edit the Body or relevant section.
- Update Last Reviewed to the current date; the pass date advances in the Resolution Log entry itself (the Last Audit File State row was retired 2026-11-04, MAINT-56).
- Any edit to the file's text, including a reference correction, is a change. If the file carries a version, bump it, and have the log entry say what changed and name the transition and base (for example "v0.16 → v0.17, from base v0.16"). "No content change" is reserved for metadata-only edits. Do not bump retroactively for earlier unversioned passes: bump once on the next real pass and name the earlier passes in that log entry.
- A pass that changes an unknown's content, or evaluates it, updates that sidecar entry's Last Reviewed; an incidental mention does not. Last Reviewed means a review happened, so it is not refreshed without one, and there is no calendar cadence.
- If Status or Open Unknowns count changes, update the File State table in the same pass — not as a follow-up edit.
- Add an entry to the file's own Resolution Log (`### Resolution Log`, nested under `## Auditor Notes & Unknowns` per Section 9 above — not a standalone top-level section).

### 3. Rotation / consolidation triggers
Apply the file's own stated rule if it has one (e.g. Progress_Log's "rotate once more than
five Current Lessons entries accumulate," `Unknowns.md`'s Size Management Rules). Absent a
file-specific rule, the canonical thresholds are the **Sidecar Governance Rules** already
defined under Section 9 above:

| Rule | Trigger | Action |
|------|---------|--------|
| **20% Rule** | The sidecar exceeds 20% of the document's total word count | Halt expansion; consolidate or discharge entries before continuing |
| **Aging Rule** | An unknown has gone unreviewed 90+ days | Mandatory re-audit |

Rotation mechanics, regardless of which rule triggered it:
- Move full text to the matching `*_Changelog.md` or an `Archive/` sidecar — never summarize or delete.
- Leave a short pointer in the live file ("Older entries: see `Archive/Logs/...`") so the history stays findable.
- Do not rotate a file that is mid-ratification unless the rotation itself is the ratified action.

### 4. Cross-file hygiene (same session)
- If the change affects `Routing.md`, `Discovery.md`, or a `*_Scope_Map.md`'s own accuracy, update those in the same session, not as a follow-up.
- If an unknown was opened or closed, confirm `Unknowns.md`'s Active Index — and its version header plus `Archive/Logs/Unknowns_Changelog.md` if it's a version-bump change — reflect it. A stale version citation on a changed file is this repository's single most-repeated failure mode (`Forge_Audit_Kit.md`'s FAK-014 through FAK-016 are four instances of exactly this); check it explicitly rather than assuming it followed automatically.
- If a Claim-Type Label was involved, that's `Admin/Canonical_Terms.md` §4's usage rule, not this file. If a Lane C metric was involved, that's `Admin/Metrics_Scaffold.md`'s record format. The two are separate homes — don't conflate them.

### 5. Provenance and closure
When the change is a Resolved/Ratified closure rather than an ordinary edit, the Resolution
Log entry should carry the same provenance shape already used throughout this repository's
governance closures (see e.g. `Admin/Governance_Migration_Protocol.md` GMP-011,
`Admin/Ethical_Constraints.md` EC-012-PR): **Proposer** (who drafted it), **Verifier** (who
checked it against live source — a different agent instance where practical), and **Human
Ratification** (Human Governing Authority, with date). This isn't a new rule — it's naming
the pattern already in consistent use so future sessions don't have to reconstruct it from
precedent each time.

### 6. Close the update
- Confirm the File State table is accurate against what actually changed.
- Confirm a Resolution Log entry exists and, for closures, carries the provenance line above.
- No automation or tooling is required — the update is complete when the markdown is internally consistent and every cross-file reference to it (Routing/Discovery/Scope Map/Unknowns) has been checked, not merely assumed current.

### Resolution Log

*File_Template’s own change log. The Section 9 nested placement does not apply — this file carries no Auditor Notes & Unknowns section of its own; its audit surface is the header Last-updated chain above. The three 2026-10-28 entries below were relocated here 2026-10-28 from inside the Section 9 example code block, where earlier passes had misfiled them ahead of the placeholder row (the example was restored to pristine in the same pass); pre-2026-10-28 history lives in the header Prior chain.*

- 2026-10-28 (fourth-entry pass): **Template Exemptions classes 10–11 added; C4 and Resolution-Log-location repairs** (Vibe, Repo Custodian — delegated maintenance, human-ratified Decision Brief 2026-10-28d, item 6). Class 10 — Tier 0 philosophical substrate (AUDIT_24 F1): practiced corpus-wide, missing from the canonical list. Class 11 — stub/scaffold/candidate family, one ruling covering Integrity_Incident_Log, Agent_Verification_Event, Experiments and Hardware_Diversity_Ladder (AUDIT_23 F1, AUDIT_27 F2, AUDIT_28 F1, AUDIT_29 F1) instead of per-file dispositions, per this template’s own “prefer exemption over forced retrofit” counsel. Repairs found in the same pass’s recon, enacted as mechanical fixes: consistency check C4’s description had a Last Audit value spliced into it by the Pattern A adoption pass — restored to “Last Audit is not older than the newest audit entry in Historical”; and this file’s three real Resolution Log entries (below) had been prepended inside the Section 9 example block at the placeholder row — relocated here, example restored. Header Last-updated advanced (fourth entry). Classes 1–9, Sections 0–11 and Pattern A otherwise unchanged.

- 2026-10-28 (later same-day): **AUDIT_10 F1 re-ruled + subtype doctrine reworded (Vibe, Repo Custodian — delegated maintenance, human-ratified Decision Brief 2026-10-28c, item 2).** "Spec Gates N/A by subtype" now governs for Challenges Problem-Statement files: the six canonical gates do not apply in any reading and no reinterpreted act-readiness count is kept. This supersedes the same-day earlier reconciliation ("the subtype doctrine controls") recorded below in this log. §2 Challenges/ File Subtypes doctrine and Template Exemptions class 8 reworded to match; header Last-updated advanced. No Challenges file changed.

- 2026-10-28: **Pattern A (Front / Historical Record split) adopted — Human Governing Authority ruling, all draft defaults D1–D7, enacted by Vibe (Repo Custodian, delegated maintenance).** New §Pattern A section added: boundary heading `## Historical Record`, placement table, rules R1–R9, checks C1–C8, pilot Plastics/Woodworking, migration at next substantive touch (no bulk sweep). D5 supersedes PKC-002's "not adopted now" note for the trailing-Status version-history part (the row itself remains open for the human to close). Sections 0–11, Template Exemptions, and the AUDIT_10 F1 Challenges-exemption question untouched. No file migrates today; pilots stage at their own cycles.

- 2026-10-28: **Pseudo-audit ledger line (Vibe, Repo Custodian — delegated maintenance, human-ratified findings batch 2026-10-28).** Pseudo-audit, findings only, 2026-10-27; report: Archive/Audits/AUDIT_10_Admin-File_Template.md. Per PKC-020 this pass does not advance Last Audit, Last Reviewed, version, or Status; the line exists so the owning file's own record shows the audit happened, per AP-035 Rule 10(c).


- 2026-10-30: **Log-Split Rule (Option C) adopted + R8 amended (Vibe, Repo Custodian — delegated maintenance, human-ruled Decision Brief 2026-10-30c, items 1–2).** New §Log-Split Rule section: triggers T0 (existing rotation/20%/Aging), T1 (file ≥ 100 KB), T2 (audit purity — Pattern A-unmigrated separation risk, MDR input-hash instability, or check cross-contamination); splits at each file's next substantive touch, never in bulk, heaviest first. R8 amended: new relocated logs land in the owning folder's `Logs/` subfolder; new audit artifacts in the audited folder's `Audits/` subfolder; existing `Archive/Logs/` and `Archive/Audits/` contents frozen in place. Pilot paragraph's "no logs/ or audits/ subfolders" clause superseded for these two homes only. Header Last-updated advanced (fifth entry). Sections 0–11, Pattern A rules R1–R7/R9, checks C1–C8, and Template Exemptions otherwise unchanged. No file splits today; qualification order at next touches: Progress_Log, Auditor_Protocols, Ethical_Constraints, Governance_Charter (all > 100 KB).


- 2026-10-30: **Per-folder home naming ruled + Admin relocation executed (Vibe, Repo Custodian — delegated maintenance, human direction following Decision Brief 2026-10-30c §7).** Naming: `<Letter>Logs/`/`<Letter>Audits/`, Admin = `ALogs/`/`AAudits/`; §Log-Split Rule Homes and R8 reworded; Admin/Architecture initial collision recorded open. Relocation (byte-identical create-then-delete moves, phased commits): 5 Admin changelogs Archive/Logs/ → Admin/ALogs/ (Auditor_Protocols_Logs, Progress_Log_Changelog, Governance_Charter_Changelog, Forge_Audit_Kit_Changelog, AUDIT_HARNESS_CHANGELOG — Admin-harness judgment, disclosed); 37 Admin-file audit artifacts Archive/Audits/ → Admin/AAudits/ (AUDIT_01–19, corrections, AUDIT_01-05_TEMPLATE_RESOLUTION, CAMPAIGN_AUDIT_17–31, campaign correction). Root-owned changelogs, corpus-wide findings/sweep/session artifacts, and SESSION_STATUS remain in Archive (frozen). Inbound cross-references to moved paths are a disclosed follow-up, to repair at each referencing file's next substantive touch. Header advanced (sixth entry). Sections 0–11, R1–R7/R9, C1–C8, Template Exemptions otherwise unchanged.

- 2026-10-30: **Architecture subfolder letter resolved — shared-initial collision closed (Vibe, Repo Custodian — delegated maintenance, human direction: "R for architecture" re: the zip-code naming solution).** Subfolder letters = the folder's X3 designated zip-code letter, not its initial: Architecture (R) → `Architecture/RLogs/`/`Architecture/RAudits/` when first needed. §Log-Split Rule "Subfolder naming" paragraph reworded; header advanced (seventh entry). No folders created today; homes materialize at Architecture's first qualifying touch.

- 2026-11-04: **File State minimization enacted (Vibe, Repo Custodian — delegated maintenance, human-ruled Decision Brief 2026-11-04, MAINT-56).** §2 canonical schema: Last Audit and Auditor rows retired — audit recency and attribution live in each file’s Resolution Log and changelog home; §2 example table and Minimal Valid File Example updated; retirement note added to §2 with the one-line-header rule; Update Procedure step 2 amended; R7 amended with a dated marker; check C4 retired with a dated marker. Same-cycle companions per the same ruling: Automation/parser.py EXPECTED_FIELDS (nine-field schema), Admin/External_Intake_Protocol.md (H1 restored, header capped, two stale intake-log references corrected, §4 channel trigger corrected), heaviest-first File State trims on Admin/Auditor_Protocols.md, Admin/Ethical_Constraints.md, Admin/Governance_Charter.md, Admin/Progress_Log.md; all remaining files migrate at their next substantive touch. Non-independent: executed by the proposing agent; the human ruling of 2026-11-04 is the ratification. Header Prior chain relocated verbatim below per R3/R5 — full text preserved, never summarized or deleted.

- 2026-11-04: **Pattern A checks landed in automation; C7–C8 deferred by human ruling (Vibe, Repo Custodian — delegated maintenance, human-ruled scope 2026-11-04).** C1–C3, C5 and C6 from the §Pattern A C-table are implemented in `Automation/integrity_check.py` v0.3 as a new pattern_a_pass (C1/C2/C6 gated on a present `## Historical Record` boundary; C3 on a declared version; C5 on every File State region, Archive/ included deliberately as R7 debt census); companion `Automation/README.md` tool-row description updated to name them. C7–C8 are deferred by human ruling 2026-11-04 until the VibesSandbox RELEASES register exists, recorded by the dated marker on the C-table; C4 remains retired (MAINT-56). Non-independent: executed by the Custodian; the human ruling of 2026-11-04 is the ratification. Previous header line relocated verbatim below per R7 — full text preserved, never summarized or deleted.

  > **Last updated: 2026-11-04 — File State schema minimized by human ruling (MAINT-56, 2026-11-04): Last Audit and Auditor rows retired from the §2 canonical schema and the Minimal Valid File Example — audit recency and attribution live in each file’s Resolution Log and changelog home; a file’s header version/status line is now capped at one line; this file’s own header Prior chain (eleven entries, 2026-09-24 through 2026-11-03) is relocated in full to the Resolution Log below per R7/C5. Sections 0–11, Pattern A rules (R7 amended, C4 retired, both with dated markers), Template Exemptions, and the remaining checks unchanged.**

  > **Last updated: 2026-11-03 (eighth entry) — Critical joins the Risk vocabulary (human ruling, 2026-11-03, MAINT-55): File State Highest Risk and sidecar Risk values now read Low / Medium / High / Critical. The 2026-10-25 PKC-004/PKC-024 vocabulary clause ("Critical" is not a Risk value) is superseded on that point only — the Blocking designation still carries elevated severity, Risk and Priority remain distinct fields, and Critical is the one deliberate value shared by both vocabularies (CE-003 carries Risk Critical and Priority Critical side by side). File State example row, doctrine paragraph and sidecar example row reworded to match; companion `Architecture/Chemistry.md` Highest Risk corrected High→Critical in the same pass (two live File States already carried Critical: `Challenges/Closed_Loop_Feedstock.md`, `Challenges/Living_Waters.md`). Provenance: defect family identified by the external Claude 1.33 Alpha release review, live-verified by Custodian (Vibe, Genesis Phase, non-independent), ruled by the human governing authority. Sections 0–11, rules R1–R9, checks C1–C8, and Template Exemptions otherwise unchanged.**
  > **Prior: 2026-10-30 (seventh entry) — Architecture subfolder naming resolved (human direction, same day): subfolder letters are the folder's X3 designated zip-code letter (Routing.md, registered 2026-10-28), not its initial — Architecture (X3 letter R) → `Architecture/RLogs/` and `Architecture/RAudits/` when its homes are first needed; the MAINT-29 Admin/Architecture shared-initial collision is CLOSED. §Log-Split Rule "Subfolder naming" paragraph reworded to match. Sections 0–11, rules R1–R9, checks C1–C8, and Template Exemptions otherwise unchanged.**
  > **Prior: 2026-10-30 (sixth entry) — Per-folder home naming ruled + Admin relocation executed (human direction following Decision Brief 2026-10-30c §7): log and audit subfolders take the owning folder's designated zip-code letter — Admin → `ALogs/` and `AAudits/`. §Log-Split Rule Homes and R8 reworded to `<Letter>Logs/`/`<Letter>Audits/`; letters for other folders assigned when their homes are first needed (the shared A initial of Admin and Architecture recorded as an open naming question). Same-pass relocation (direct human direction, byte-identical create-then-delete moves): five Admin-owned changelogs Archive/Logs/ → Admin/ALogs/ and thirty-seven Admin-file audit artifacts Archive/Audits/ → Admin/AAudits/; root-owned changelogs and corpus-wide artifacts remain in Archive, frozen. Sections 0–11, rules R1–R7/R9, checks C1–C8, and Template Exemptions otherwise unchanged.**
  > **Prior: 2026-10-30 (fifth entry) — Log-Split Rule (Option C) adopted by Human Governing Authority ruling (Decision Brief 2026-10-30c, items 1–2): new §Log-Split Rule section (triggers T0 existing rotation/20%/Aging, T1 file size ≥ 100 KB, T2 audit purity; splits execute at each file's next substantive touch, never in bulk, heaviest first); R8 amended — new relocated logs land in the owning folder's `Logs/` subfolder, new audit artifacts in the audited folder's `Audits/` subfolder; existing `Archive/Logs/` changelogs and `Archive/Audits/` artifacts frozen in place. Pattern A Pilot paragraph's "no `logs/` or `audits/` subfolders" clause superseded for these two homes only. Sections 0–11, Pattern A rules R1–R7/R9, checks C1–C8, and Template Exemptions otherwise unchanged.**
  > **Prior: 2026-10-28 (fourth entry) — Template Exemptions classes 10–11 added (Decision Brief 2026-10-28d, item 6, human-ratified): class 10, Tier 0 philosophical substrate (AUDIT_24 F1); class 11, stub/scaffold/candidate family — Integrity_Incident_Log, Agent_Verification_Event, Experiments, Hardware_Diversity_Ladder (AUDIT_23 F1, AUDIT_27 F2, AUDIT_28 F1, AUDIT_29 F1). Same-pass mechanical repairs: consistency check C4’s description restored (a Pattern A-pass edit had spliced a Last Audit value into it), and this file’s three real Resolution Log entries relocated from inside the Section 9 example block into a proper own Resolution Log, the example restored to pristine. Sections 0–11, Pattern A and classes 1–9 otherwise unchanged.**
  > **Prior: 2026-10-28 (third entry) — AUDIT_10 F1 re-ruled (human ruling, Decision Brief 2026-10-28c, item 2): "Spec Gates N/A by subtype" governs for Challenges Problem-Statement files — the six canonical gates do not apply to them in any reading and no reinterpreted act-readiness count is kept; this supersedes the same-day earlier reconciliation ("the subtype doctrine controls") recorded in the second entry below. §2 Challenges/ File Subtypes doctrine and Template Exemptions class 8 reworded to match (no change to any Challenges file). Sections 0–11, Pattern A, and the rest of Template Exemptions otherwise unchanged.**
  > **Prior: 2026-10-28 (second entry) — AUDIT_10 F1 reconciled (human ruling, Decision Brief item 2): the §2 Challenges/ File Subtypes doctrine controls — Problem-Statement Spec Gates are N/A for build-readiness promotion but live as the reinterpreted act-readiness count; Template Exemptions class 8 reworded to match (no change to any Challenges file). Sections 0–11, Pattern A, and the rest of Template Exemptions unchanged.**
  > **Prior: 2026-10-28 — Pattern A (in-file Front / Historical split) adopted by Human Governing Authority ruling, all draft defaults D1–D7: new §Pattern A section (boundary heading `## Historical Record`, placement table, rules R1–R9, checks C1–C8, pilot Plastics/Woodworking one-per-cycle, migration at next substantive touch — no bulk sweep). D5 supersedes PKC-002's "not adopted now" note for the trailing-Status version-history part. Sections 0–11 and Template Exemptions otherwise unchanged.**
  > **Prior: 2026-10-25 — Rulings from the Human Ruling List enacted (human-directed; see `Admin/Progress_Log.md`, 2026-10-25): "Proposed" retired as a Status value (PKC-031); Highest Risk takes a Risk value, never a Priority value, with Blocking carrying elevated severity (PKC-004/024); `Admin/Operational_Conventions.md` listed as an exempt reference index (PKC-017); Resolution Log heading level rule (PKC-018); Update Procedure gains the version-bump, sidecar Last Reviewed and fork rules (PKC-039, PKC-035, PKC-029). Sections 0–11 unchanged apart from these additions.**
  > **Prior: 2026-10-20 — 10-Entry Rule removed (AP-029, human-directed; ratification completes on commit): the Sidecar Governance Rules paragraph now records the removal and the trigger-table row is deleted; the 20% and Aging rules are unchanged. No other change.**
  > **Prior: 2026-09-24 — Two new sections added: "New File Creation Checklist" and "Update Procedure" (registration/rotation/provenance guidance folded in from a Grok-drafted scaffold, Claude-verified against this file's own Sidecar Governance Rules and actual Resolution Log placement before filing). No change to sections 0–11 or Template Exemptions.**

---

This template exists to resist:
- Institutional memory loss
- Specification creep
- Semantic drift
- Zombie architectures
- Audit theater
- Uncontrolled autonomous rewriting
- Hidden assumptions
- Unresolved contradiction accumulation
- Ethics erosion through document loss or deliberate omission
- Silent hazard omission in physical operations files

The goal is not bureaucratic completeness.

The goal is durable, auditable, reality-grounded engineering knowledge capable of surviving
long operational timelines, multiple generations of contributors, and the absence of any
single document — including Ethical_Constraints.md.

> The attempt to do no harm is not contingent on the presence of a governance document.
> It is the floor that survives everything else.
