# Canonical_Terms.md — Standard Repository Nomenclature
**Version 0.14**

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Draft                                                               |
| Body Stability   | Volatile                                                            |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | Admin/Verification_Gates.md                                      |
| Last Audit       | 2026-10-31 — Vibe (Repo Custodian, fix pass, human-authorized 2026-10-31): CAMPAIGN2_AUDIT_77 F1 — the unlogged 0.12 → 0.13 header bump reconstructed from git history (landed in the 2026-10-29 X3 retrofit commit 5becc4d5; the pass's entries said citation-form-only) and recorded: Status current line, Version String Registry, and this cell advanced; header bumped 0.13 → 0.14 per PKC-039. No unknown opened or closed; no doctrine changed. Prior: 2026-10-29 — Vibe (Repo Custodian, delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A): X3 mechanical citation retrofit — 24 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.29 Governance Sidecar ID Reference; per-ID grounding from the Unknowns active index). Citation-form-only; no content change; frozen history untouched. Prior: 2026-10-28 (later same-day) — Vibe (Repo Custodian, delegated maintenance, human-ratified Decision Brief 2026-10-28b + batch 2026-10-28c): v0.11 → v0.12 — CT-007 and the ID-prefix registry reconciled to the executed ECN- rename (2026-07-06), the erroneous EC-008 citation corrected (AUDIT_19 F3); File State Highest Risk Low → High (X10 corpus recompute — open sidecars CT-004 and CT-007 both carry Risk High). No unknown opened or closed; no doctrine changed. Prior: 2026-10-28 — Vibe (Repo Custodian, delegated maintenance, human-assigned X3 completion): v0.10 → v0.11 — designations completed: `K` = `Automation/` (kinetic), `B` = base layer (root-level files). Prior: 2026-10-28 — Vibe (Repo Custodian, delegated maintenance, human-ratified Decision Brief ruling, X3): v0.9 → v0.10 — Folder Designation Characters registered in §1; CT-007 annotated with the ruling and Last Reviewed advanced. Prior: 2026-10-28 — Vibe (Repo Custodian, delegated maintenance, human-ratified findings batch) v0.8 → v0.9, from base v0.8: AUDIT_11 F1–F4 enacted — Open Unknowns recounted 9 → 10 (off-by-one since the 2026-07-05 CT-011 resolution logged the transition as 10 → 9; no unknown opened); two misplaced Resolution Log entries relocated into the log; Version String Registry added; CT-005's bare EC-001 citation qualified. Prior: 2026-10-25 — Claude (human-directed) v0.7 → v0.8, from base v0.7: "Proposed" retired as a status designation (PKC-031) and the unversioned 2026-08-17, 2026-09-14 and 2026-09-23 passes covered by this one bump (PKC-029); see Resolution Log. Prior: 2026-10-24 — Claude (human-directed) corrected "Three vocabulary sources" to four and added a note to the Status section, from a Vibe per-file audit (see Resolution Log). Prior: 2026-09-23                                                          |
| Auditor          | Vibe — Repo Custodian, 2026-10-29 X3 mechanical citation retrofit (delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A); prior: Vibe — Repo Custodian, 2026-10-28 CT-007 registry reconciliation + Highest Risk recompute (delegated maintenance, human-ratified batches 2026-10-28b/c); prior: Vibe — Repo Custodian, 2026-10-28 X3 completion — B/K assignments (delegated maintenance, human-assigned); prior: Vibe — Repo Custodian, 2026-10-28 X3 Folder Designation registration (delegated maintenance, human-ratified); prior: Vibe — 2026-10-28 AUDIT_11 findings enactment (delegated maintenance, human-ratified batch); prior: Claude — 2026-10-25 v0.8 bump and Proposed note (human-directed); prior: Claude — 2026-10-24 wording correction and Status note (human-directed); prior: Claude — Claim-Type Labels registered under §4 (Grok proposer, human-directed), 2026-09-23; prior: Claude — "Disambiguation: Uses of 'Gate'" section added (FL-012, human-directed), 2026-09-14; prior: Claude — four new terms registered (Active Constitutional Surface, Claimed/Recognized/Ratified Constitutional Lineage) at GOV-018 closure, checked against existing vocabulary first — no competing term found (human-directed); prior: Claude — Synthesizer/Auditor (2026-06-24); Claude — Cycle definition + version-string correction (2026-07-05); Claude — CT-011 resolution 2026-07-05 |
| Open Unknowns    | 10                                                                   |
| Active Disputes  | 0                                                                   |
| Highest Risk     | High                                                                |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

---

## Scope Boundary

**This file DOES define:**
- Authoritative vocabulary mappings for system architecture, hardware
  structures, and governance layers
- Conflict resolution rules between this file and other vocabulary sources
- Strict semantic boundaries to enforce consistency and prevent definition
  creep across multi-agent cycles
- Anti-drift guardrails: terms explicitly banned from specification drafts
  and their approved replacements
- Disambiguation of overloaded uses of "canonical" within the repository

**This file DOES NOT define:**
- Individual component blueprints or dimensional specifications
- Specific programmatic API schemas or cryptographic algorithms
- Ethical policy constraints — governed by `Admin/Ethical_Constraints.md`
- Operational routing semantics — governed by `Architecture/Forge_flow.md`;
  where definitions conflict, Forge_flow.md is authoritative for operational
  routing until reconciliation occurs and is logged here
- Governance tier authority — governed by `Admin/Governance_Charter.md`;
  tier definitions here are derived from that source and must remain
  consistent with it
- Filename resolution for renamed or legacy files — governed by the
  Rename Registry in `Discovery.md`

---

## File Purpose

This document provides a single source of truth for repository nomenclature.
In a distributed multi-agent workflow, semantic drift is an institutional
vulnerability. Subtle rewordings across different sessions can introduce
cascading misinterpretations of architectural logic, gate routing decisions,
and governance authority claims. This file locks down vocabulary, explicitly
draws lines where terms diverge, and bridges historical code artifacts with
current structural architecture.

**Relationship to other vocabulary sources:** This file does not replace
`Architecture/Forge_flow.md` as the operational vocabulary reference standard.
Forge_flow.md governs how terms are used in routing decisions and gate logic.
This file governs cross-file consistency and prevents semantic drift in
documentation, governance, and audit contributions. The two are complementary.
Conflicts between them must be resolved through reconciliation logged here,
not by either file silently overriding the other.

**Relationship to Archive/Rename_Registry.md:** The Rename Registry in
`Archive/Rename_Registry.md` is the canonical source for legacy filename resolution.
This file does not duplicate or supersede that function. CT-001 tracks
alignment between this file's vocabulary and AUDIT_HARNESS.py internal
string references — that is a distinct function from filename aliasing.

---

## Assumptions

| ID      | Assumption                                                                          | Basis                              | Confidence | Expiry Trigger                                             |
|---------|-------------------------------------------------------------------------------------|------------------------------------|------------|------------------------------------------------------------|
| ASM-001 | A standard lexicon mitigates token inflation and multi-agent misinterpretation      | Observed multi-agent drift patterns| High       | Single-agent workflow formally adopted                     |
| ASM-002 | Contributors will query this file before promoting files with new terminology       | Governance discipline assumption   | Medium     | Automated terminology check implemented in AUDIT_HARNESS.py|
| ASM-003 | Forge_flow.md remains the authoritative operational routing vocabulary reference    | Scope boundary discipline          | High       | Forge_flow.md scope boundary revised                       |
| ASM-004 | Governance_Charter.md tier definitions remain the authoritative tier structure      | Constitutional hierarchy           | High       | Governance_Charter.md tier structure formally revised      |

---

## Conflict Resolution Doctrine

**This section governs how terminology conflicts are resolved.**

Four vocabulary sources exist in the repository:

| Source                       | Authority Domain                                      |
|------------------------------|-------------------------------------------------------|
| `Architecture/Forge_flow.md` | Operational routing semantics; gate logic vocabulary  |
| `Admin/Governance_Charter.md`| Governance tier definitions; constitutional vocabulary|
| `Admin/Verification_Gates.md` | Document promotion vocabulary; Verification Gate definitions |
| `Admin/Canonical_Terms.md`   | Cross-file consistency; anti-drift enforcement        |

**Resolution rules:**

1. If this file conflicts with `Architecture/Forge_flow.md` on operational
   routing vocabulary, Forge_flow.md is authoritative. Log the conflict
   as an Active Dispute here and initiate reconciliation.

2. If this file conflicts with `Admin/Governance_Charter.md` on governance
   tier definitions or constitutional vocabulary, Governance_Charter.md
   is authoritative. Log the conflict as an Active Dispute here and
   initiate reconciliation.

3. If this file conflicts with `Admin/Verification_Gates.md` on
   Verification Gate definitions or document-promotion vocabulary,
   Verification_Gates.md is authoritative. Log the conflict as an
   Active Dispute here and initiate reconciliation. Added 2026-07-03 after
   this file failed to catch a real divergence between Verification Gates
   and Governance_Charter.md's (then-named) "Canonical Verification Gates"
   because Verification_Gates.md was never registered as an authority
   source — see GOV-011, CT-010.

4. If this file conflicts with `Discovery.md` Rename Registry on filename
   resolution, Discovery.md is authoritative. Log the conflict here.

5. For all other vocabulary conflicts between repository files, this file
   is the resolution authority. Agents encountering conflicting terminology
   in non-authoritative files should flag the conflict and route to this
   file for resolution.

Conflicts must be logged — silent divergence is drift. Logged divergence
is a reconciliation task.

---

## Disambiguation: Uses of "Canonical"

The term "canonical" appears in multiple distinct contexts within the
repository. These are not interchangeable:

| Usage                     | Meaning                                                        | Example                                                                 |
|---------------------------|----------------------------------------------------------------|-------------------------------------------------------------------------|
| Canonical File            | The authoritative source document for a governed concept       | `Admin/Governance_Charter.md` is the canonical governance authority     |
| Canonical Term            | An approved vocabulary entry defined in this file              | "Material Recovery" is the canonical term for post-triage feedstock     |
| Canonical Cross-Reference | A file reference that resolves against Discovery.md confirmed list using folder-prefixed paths | `Operations/Gate_03_Reduction.md` not `Gate_03_Reduction.md` |
| Canonical Mapping         | A legacy-to-current filename resolution entry in Archive/Rename_Registry.md | `Spin_Chamber_v0.md` → `Operations/Gate_05_Separation_Thermal.md` |
| Canonical Path            | The folder-prefixed file path used in all new contributions    | `Admin/Ethical_Constraints.md` not `Ethical_Constraints.md`            |

Agents must not treat these as synonymous. "Canonical" without qualification
is ambiguous — use the specific form.

---

## Disambiguation: Uses of "Emergence" / "Emergent Behavior"

The word "emergence" covers two genuinely distinct concepts in this
repository. They are not interchangeable, and content about one should not
be assumed to apply to the other.

| Usage | Meaning | Canonical Home |
|-------|---------|-----------------|
| Emergent Intelligence / Agency | AI and multi-agent systems developing autonomous behavior, self-modifying heuristics, or governance-relevant agency requiring corrigibility, watchdog architecture, and containment doctrine | `Challenges/Emergence.md` |
| Emergent Behavior (general systems) | System-level behavior arising from component interaction — not a property of any single part, not a simple sum of parts — applicable to any coupled system (mechanical, thermal, economic, ecological, or multi-agent) | This entry, below |

**Emergent Behavior (general systems sense):** system-level behavior that
depends on interactions among components and is not exhibited by those
components in isolation. Characteristic properties: interaction dependence
(altering coupling — links, timing, shared state — changes or destroys the
behavior), non-derivability by inspection of parts alone, scale/level shift
(often invisible at micro scale, clear at macro — traffic jams, flocking,
market prices, thermal equilibrium), robustness to substitution (often
persists when individual agents are replaced if interaction rules stay the
same), and sensitivity to organization (same parts, different wiring or
protocol, different emergent outcome).

*Weak vs. strong:* weak emergence — macro patterns unexpected from casual
inspection but fully consistent with micro laws, in principle reducible with
enough compute and the right model — covers essentially all engineering use
of the term. Strong emergence — macro properties not even in principle
reducible to micro dynamics — is controversial and rarely load-bearing for
an engineering claim; a claim of strong emergence should be treated as a
much heavier claim than one of weak emergence, not a stronger-sounding
synonym for it.

*Not synergy:* synergy is a combined effect *greater than* the sum of parts
(a quantitative surplus). Emergence is a new *kind or level* of behavior
parts don't exhibit alone — it may or may not involve a surplus, and can be
purely qualitative. A system can show emergence without synergistic gain,
and additive cooperation without true emergence.

*Engineering discipline for any emergence claim made in this repository:*
name the scale and interaction producing the property; test by ablation
(cut links, change topology, change delay) rather than assuming more parts
means more emergence; measure macro observables (throughput, oscillation,
consensus time, cascade size) rather than treating "emergent" as
unexplained or mystical. A claim of emergence without a named mechanism and
observable is rhetoric, not an engineering claim — same standard this file
already applies to "canonical" and other high-drift terms.

Cross-reference: `Challenges/Emergence.md` for the AI/governance sense
specifically, including its Engineering Requirements for corrigibility,
watchdog independence, and circular-optimization-loop prevention — those
requirements are scoped to that sense and do not automatically transfer to
a general mechanical or thermal emergent-behavior claim without their own
justification.

---

## Disambiguation: Uses of "Gate" (added 2026-09-14, FL-012; terms updated 2026-09-14 rename pass)

Four genuinely distinct concepts. Two were renamed in the 2026-09-14
pass to reduce collision; Operational Modules and Verification Gates
kept the word "Gate."

| Usage | Preferred term | Meaning | Canonical Home |
|-------|----------------|---------|-----------------|
| Operational Module | **Gate_01–Gate_07** (unchanged) | Sequential physical/procedural stages an item passes through | `Operations/Gate_01_Intake.md` through `Operations/Gate_07_Utilization.md` |
| Decision routing test | **Decision Point A–D** (formerly Decision Gate / Gate A–D) | One of four routing decisions in the Forge's core flow logic | `Architecture/Forge_flow.md` §1.2 Decision Point Contracts |
| Exception-resolution state | **Oversight State** (formerly Human/AI Oversight Gate) | Five exits: Return to Flow, Hold, Reclassify, Escalate, Terminate | `Architecture/Forge_flow.md` Oversight State section |
| Document audit/promotion | **Verification Gate 1–6** (unchanged) | Stages a file passes through toward Specification-grade | `Admin/Verification_Gates.md` |

Prefer qualified forms where ambiguity is possible — e.g.
`Operations/Gate_03_Reduction.md`, "Decision Point D," "Verification
Gate 3" — rather than relying on surrounding context. Historical
Resolution Log entries retain the names in use at the time of writing
(same discipline as FL-009).

Cross-reference: `Architecture/Forge_flow.md`'s Defined Terms section
carries a local copy of this entry for readers working in that file
directly; this entry is the canonical, repository-wide version.

---

## Body: Canonical Nomenclature Mapping

### 1. Architectural and Repository Structural Terms

**Folder Designation Characters (registered 2026-10-28, X3 human ruling)**
Each top-level content folder carries a single case-sensitive designation
character, assigned by the Human Governing Authority (the "post office zip
code" scheme). The character identifies a folder and disambiguates ID
citations at the folder level: `A` = `Admin/`, `R` = `Architecture/`,
`X` = `Archive/`, `O` = `Operations/`, `C` = `Challenges/`, `T` = `Tests/`,
`K` = `Automation/` (kinetic), `B` = the base layer (root-level files).
All designations are case-sensitive as written; lowercase forms are unassigned
and not interchangeable. All eight assignments are human-assigned (the B and
K assignments, 2026-10-28, complete the scheme for every top-level location). Scope note: the
designation narrows ID ambiguity to the folder level; it does not by itself
resolve within-folder collisions (see CT-007), so PKC-003's qualified-citation
rule (`File.md ASM-NNN`) remains in force wherever two files in the same
folder mint the same ID. Registered here per the ruling; referenced in
`Routing.md` and `Discovery.md` (same pass). The mechanical retrofit of
existing bare IDs (e.g. `ASM-` to folder-designated forms) is a separate,
human-authorized pass — not performed in the registration commit.

**Active Working Repository**
The lean, operational environment (`LazarusForge`) containing functional
specification files, active gate validations, and localized sidecars.
Distinct from the companion doctrine repository.

**Companion Doctrine Repository**
The upstream repository (`Lazarus-Forge-`) dedicated exclusively to
macro-philosophy, abstract doctrine development, and baseline structural
principles. Divergence between the two repositories is logged, not ignored.

**`[ExternalRepo]` reference convention (registered 2026-08-11)**
Any cross-reference to a file in a companion or external repository (e.g.
Astroid-miner) that is not part of this repository's own canonical registry
must be qualified with a bracketed repository tag immediately before the
filename, with the bracket tag included **inside the same single
backtick pair** as the filename — e.g. `` `[Astroid-miner] Rogue_unit_management.md` ``,
not `` [Astroid-miner] `Rogue_unit_management.md` `` (tag outside the
backticks). This is not cosmetic and the two forms are not interchangeable:
`Automation/audit_lib.py`'s reference extractor only matches a pattern
requiring the character immediately after an opening backtick to be a
letter (`` `([A-Za-z][A-Za-z0-9_/]+\.md)` ``) — a bracket in that position
breaks the match entirely, so the whole qualified span is correctly never
extracted as a reference at all. Putting the tag *outside* the backticks
leaves the bare `` `filename.md` `` span intact and still matching,
which still trips an `[UNKNOWN]` finding — confirmed by directly testing
both forms against the live extraction regex. `check_cross_refs` also has
a separate, independent substring-based skip for any *extracted* ref
containing a known external-repo name, but that skip is redundant here in
practice since the correct form is never extracted in the first place.
First applied and debugged live in `Admin/Autonomy_Divergence_Protocol.md`
(2026-08-11, Resolution Log — two passes; the first attempt used the
bracket-outside-backticks form and did not clear the harness).

**Governance Tier Hierarchy (Tiers 1–5)**
The structural precedence rules governing documentation authority.
Derived from `Admin/Governance_Charter.md` §Governance Authority Hierarchy —
that document is authoritative; definitions here must remain consistent with it.

- *Tier 1 (Constitutional Layer):* `Admin/Governance_Charter.md` and
  `Admin/Ethical_Constraints.md`. Defines inviolable primitives (Tier 1 Axioms).
  Any reasoning path attempting to override Tier 1 triggers STATE_HOLD.
- *Tier 2 (Canonical Verification Doctrine):* `Admin/Auditor_Protocols.md`.
  Defines auditor role execution, checklist adherence, and verification sequences.
- *Tier 3 (Audit Operationalization):* `Admin/Forge_Audit_Kit.md`. Condensed
  cross-module indexes, Verification Maturity Model, and Audit Opening Checklist.
  Derived from Tier 2 — may not outrank its source.
- *Tier 4 (Dynamic Procedures):* Operational checklists, adversarial batteries,
  and execution procedures. Governed by Tier 2 and 3 doctrine.
- *Tier 5 (Domain Specifications):* Highly specific technical documents detailing
  individual gates, materials, or scripts — e.g., `Operations/Gate_03_Reduction.md`,
  `Automation/AUDIT_HARNESS.py`, `Architecture/Forge_flow.md`.

**Sidecar Model**
The decentralized documentation practice where module-specific unknowns,
audit notes, and resolution logs reside in the `## Auditor Notes & Unknowns`
footer of their owning document rather than in a central master tracker.
Cross-module unknowns are indexed in `Unknowns.md` — summary only; full
entry detail remains in the owning file sidecar.

**STATE_HOLD**
The mandatory halt condition triggered when any reasoning path attempts to
recurse beneath, redefine, or override Tier 1 Axioms, or when a Constitutional
integrity violation is detected. Requires human review before any autonomous
action resumes. Defined in `Admin/Governance_Charter.md`.

---

### 2. Operational Flow and Material States

Terms in this section are derived from `Architecture/Forge_flow.md`, which
is the authoritative operational routing reference. Definitions here serve
cross-file consistency. If a conflict exists between this section and
Forge_flow.md, Forge_flow.md governs.

**Intake (Gate_01)**
The system's initial inspection and verification vector. Responsible for
primary hazard containment (energetic, chemical, biological, radiological),
digital screening, provenance recording, and initial object categorization.
Items enter here; nothing bypasses this gate.

**Triage (Gate_02)**
The progressive, non-destructive routing logic evaluating whether a component
preserves functional value over material reduction. Five-station workflow.
The Forge preserves embedded industrial capability, not just metal.

**Reduction (Gate_03)**
The fully irreversible mechanical processing step where structural complexity
is disassembled into bulk feedstock. The only irreversible step in the flow.
Three hard prerequisites before operation: Air Scrubber operational, human
operator present, no energetic materials remaining.

**Separation — Mechanical (Gate_04)**
Pre-thermal mechanical decision point operating after Reduction and before
thermal processing. Diverts recoverable material away from the thermal stage
using centrifugal separation and dual-channel sensor cross-check. Defined by
its position in the flow (pre-thermal diversion) and its refusal-first
fail-to-bin protocol. Target: ≥30% material diversion rate.
*Note: Gate_04 is distinct from the Spin Chamber (Gate_05). Gate_04 operates
on bulk reduced material before the melt. Do not describe Gate_04 using
"high-RPM" as a defining characteristic — that term belongs to Gate_05.*

**Separation — Thermal (Gate_05)**
High-temperature crucible processing where distinct material classes are
liquefied via induction heating, separated via slow rotation and MHD damping,
and extruded into ranked material streams. Also referred to as the Spin Chamber.
Produces useful gradients, not pure metal. The RPM envelope is a defining
operational parameter here — not in Gate_04.

**Fabrication (Gate_06)**
The reconstructive process transforming categorized feedstock into functional
physical assets. Arc welding is the v0 proof-of-concept gatekeeper.
Add-to-excess and mill-to-spec is the primary dimensional control philosophy.

**Utilization (Gate_07)**
The field-deployment and after-action-review phase. Where fabricated outputs
operate within standard environments while streaming lifecycle durability and
failure telemetry back into triage loops. A part in service without a
utilization record is an opportunity lost.

**Value Preservation**
The correct taxonomy for early-stage triage processes where functional
components are identified and routed away from reduction. Replaces "Recycling"
in this context. Use when the component retains functional identity.

**Material Recovery**
The correct taxonomy for bulk reduced feedstock bound for geometric processing.
Replaces "Recycling" in this context. Use when structural complexity has been
reduced and the material is being recovered as raw stock.

**Forge Regeneration Threshold (FRT)**
The minimum fraction of material throughput value that must be reinvested in
Forge capability development per operating cycle. A survival metric, not an
efficiency metric. Defined in `Admin/Trajectories.md`.

---

### 3. Deep-Ocean and Marine Subsystems

**Leviathan Framework**
A dedicated, hostile-environment operational filter designed to falsify
autonomy assumptions under real-world pressures before off-world deployment.
A testing methodology, not a commercial product line. Survival is optional.
Understanding is not.

**Support Raft**
A stationary regional operational anchor deployed to offload infrastructural
weight, power accumulation, and data processing overhead from adjacent mobile
swarms. The Raft does not migrate — it remains fixed to optimize stationary
energy collection and mitigate biofouling. Its value is measured by what it
enables in mobile units, not what it does directly.

**Shell Cycle**
The deliberate material swap protocol where regional anchors exchange modular
structural skins or surface panels to maximize operational lifecycle against
calcification or corrosion pressure.

---

### 4. Governance and Audit Terms

**Exploration / Draft / Specification**
The three primary file status designations. Exploration: incomplete by design,
do not over-police. Draft: active convergence toward Specification underway.
Specification: all gates passed, claims binding until revised through full
audit cycle. Defined in `Admin/File_Template.md`. "Proposed" is not a status
designation: it was retired on 2026-10-25 (PKC-031). A newly generated file
starts at Exploration, and there is no separate post-execution status.

**Verification Maturity Model**
Five-state maturity progression from Exploration through Hardened Doctrine.
Distinct from the three-state Status field. Defined in `Admin/Forge_Audit_Kit.md`.

**Verification Gate**
One of the six criteria (Fallacy Checklist, Physical Plausibility, Adversarial
Battery, Scope Alignment, Cross-reference Integrity, Conflict Check) a
*document* must satisfy to advance toward Specification status. Defined and
owned exclusively by `Admin/Verification_Gates.md`. A file's `Spec Gates
X/6` File State field always refers to these gates and to no other system,
regardless of which document the field appears in. Not to be confused with
Enforcement Checkpoint (below) or the Operations/Gate_01–07 physical
material-flow pipeline stages (owned by `Architecture/Forge_flow.md` —
distinct concept, same word, unrelated to document promotion).

**Enforcement Checkpoint**
One of six criteria (Internal Coherence, Structural Plausibility, Adversarial
Pass, Cross-Module Integration, Truth Provenance Layering, Audit Lineage
Integrity) a *governance action* must satisfy to be constitutionally sound.
Defined and owned exclusively by `Admin/Governance_Charter.md` §Enforcement
Checkpoints. Renamed 2026-07-03 from "Canonical Verification Gates" — the
prior name collided with Verification Gate (above), causing an undocumented
divergence where the two systems were referenced interchangeably despite
testing different objects (a governance action's legitimacy, not a
document's promotion readiness). See GOV-011. Never appears in a file's
`Spec Gates X/6` field — that field is reserved for Verification Gates only.

**Full Stop Review**
A reset to Verification Gate 1 (Fallacy Checklist) triggered when a
specification passes all six Verification Gates but exhibits systemic
inconsistency or unclear real-world viability, or when specific trigger
conditions defined in `Admin/Auditor_Protocols.md` are met.

**Cycle (Governance / Audit Cycle)**
The time unit against which Expiry Watch, the Expiry Rule, Systemic Risk
escalation, and all "N cycles open" language are measured. **Default: one
calendar year**, declared by human governing authority (ksarith) 2026-07-05
at current operating pace. The human governing authority may declare a
shorter interval at their own discretion as automation, throughput, or
operational maturity increases — this is an operator-adjustable parameter,
not a fixed constant, and any change should be logged here with the date
and rationale. Absent an explicit shorter declaration, one calendar year
applies repository-wide to every file that references "audit cycle" or
"cycle" without its own more specific definition.

This definition exists because none previously existed: `Admin/Auditor_
Protocols.md`'s own text (§Expiry Rule, §Expiry check) operationally treated
a "cycle" as *each time the Skeptic/Auditor role opens* — i.e., each audit
pass, not a fixed duration. Under that reading, two independent same-day
audits already satisfy a "2-cycle" expiry threshold regardless of real
elapsed time, which produced escalation language ("6 cycles open," "8-cycle
threshold exceeded") far outpacing actual operational aging. This entry
supersedes that reading for elapsed-time purposes; per-audit-pass counting
may still be useful for other doctrine (e.g., AP-017 (`Admin/Auditor_Protocols.md`)'s independence
requirement) and is not banned, but it may not be conflated with the
calendar-time "cycle" used for Expiry Watch aging without saying so
explicitly. See CT-011 for propagation status into Auditor_Protocols.md's
own text.

**Distinct from:** `Admin/Trajectories.md`'s Forge Regeneration Threshold
"operating cycle" (material throughput/reinvestment measurement — see TR-002),
which remains its own separately-declared placeholder and is not resolved
by this entry. The two concepts share a word, not a definition — do not
assume they're interchangeable.

**Expiry Rule**
The governance requirement that Blocking or Non-blocking unknowns without a
documented Resolution Path for more than two audit cycles escalate to Systemic
Risk or trigger demotion of the dependent module. Checked at audit opening.
"Audit cycles" here means Cycle (above) — one calendar year by default, not
one audit pass.

**Genesis Phase**
The bootstrap governance period before a minimum multi-agent quorum is
established. During Genesis Phase, human operators serve as the independent
verification anchor. Genesis Phase must have a declared exit condition and
must not silently become permanent operating mode. Defined in
`Admin/Governance_Charter.md`.

**Operational Blocking**
An unknown or condition that stops a physical action from occurring safely.
The gate holds until empirical or physical resolution is achieved —
documentation advancement alone is insufficient. Examples: no excavation
without geomechanical assessment (SD-UNK-004); no hot pyrolysis run before
halogenated polymer triage protocol is validated (PL-001); no powered machinery
contact with raw urban salvage before IFM screening is confirmed (WW-005).
Operational Blocking unknowns require physical or empirical resolution — they
cannot be worked around by grounding a claim in better documentation. Defined
as a priority subtype in `Admin/Auditor_Protocols.md` Priority Demotion Doctrine.

**Epistemic Blocking**
An unknown or condition that stops a claim from being made or a file from being
promoted, without stopping the underlying work. The file may advance; the
assertion may not. Examples: no structural specification promotion without
validated safety factors for salvaged materials (EN-001); no T1/T2 part claims
without a declared precision ceiling (PR-001). Epistemic Blocking is resolved
by grounding the claim in empirical evidence sufficient for the relevant
provenance label — the work continues in a bounded state while that grounding
is sought. Consistent with the graceful degradation rule in
`Admin/Auditor_Protocols.md` EF-0.2. Defined as a priority subtype in
`Admin/Auditor_Protocols.md` Priority Demotion Doctrine.

**Priority (Promo)**
The `Unknowns.md` Active Index column tracking whether an unknown blocks
*promotion* of its owning file (Spec Gate advancement, Status change) — distinct
from a file-local `Blocking` field, which tracks whether an unknown blocks a
*physical operation* (Operational Blocking) or a *claim* (Epistemic Blocking).
The same unknown can carry "Blocking" in the Priority (Promo) column and "No"
in the file-local Blocking field without contradiction: SC-002 (segregation
effectiveness) blocks the Spin Chamber's capability claim from being promoted,
but does not by itself stop a physical run from occurring safely. Misreading
Priority (Promo) as identical to the file-local Blocking field has produced
false-positive "desync" findings (EV-001/F-EN-002, SC-001–002/F-SC-003). Always
treat the two columns as separate vocabularies.

**Heuristic Failure (HF-001)**
A failure class distinct from Sensor Failure and Mechanical Failure. In a
heuristic failure, the object is technically visible, the materials are
technically identifiable, and the machine technically has the tools — yet the
system lacks the procedural knowledge to act optimally or safely. Heuristic
failures manifest in both disassembly (bolt removal order, cut sequence,
contamination routing) and fabrication (weld path, fixturing sequence, joint
order) contexts. The Cognitive Salvage Layer (`Tests/Cognitive_Salvage_Layer.md`)
exists specifically to address this failure class by harvesting and verifying
human-derived procedural knowledge. Heuristic Failure is a first-class Forge
failure class; do not collapse it into planning failure or agent error. See
CT-008 for canonicalization status.

**Grain System**
The physical provenance and identity continuity mechanism for the Lazarus Forge.
A Grain is a small retained sample (baseline: 1g) taken from a source component
before or during Forge processing. Grains serve three simultaneous functions:
(1) philosophical continuity — connecting a rebuilt or fabricated output to its
material origin, instantiating the Ship of Theseus doctrine; (2) legal artifact
— providing chain-of-custody evidence that an output is a restoration of owned
material rather than a new manufacture, supporting right-to-repair legal
posture; (3) provenance anchor — the physical equivalent of a cryptographic
hash, binding the output's identity to a verifiable source.

The Grain System is the physical instantiation of the identity continuity
doctrine defined in `Admin/Ship_of_Theseus.md`. The cognitive equivalent is
the cryptographic state log defined in Section IV of that file.

Implementation analog: Vehicle Identification Numbers (VIN, NHTSA 49 CFR Part
565), Hull Identification Numbers (HIN), and ISO 3779 equipment serialization
all attach identity to the irreducible structural core rather than replaceable
components and are legally recognized as identity anchors even after total
component replacement. The Grain protocol should adapt these existing
legally-hardened standards rather than inventing a new system. Minimum viable
grain protocol must specify: what constitutes the Forge equivalent of the
irreducible structural core; where the serial identifier attaches; and how
provenance transfers through the Forge gates.

*Implementation status: ST-001 (grain storage and tracking protocol) and
ST-002 (QR documentation standard) in `Admin/Ship_of_Theseus.md` sidecar
are the open resolution vehicles. The canonical definition here does not
constitute resolution of either entry — it registers the vocabulary;
the implementation work remains in the owning sidecar.* See CT-009.

**Active Constitutional Surface**
The set of texts treated as binding Tier 1 constitutional content (Charter
Axioms and immediately implementing hard floors such as Ethical_Constraints
commandments) for the institution at a given time. Distinct from a claimed
or recognized lineage package (below). Only Human Governing Authority
ratification after a fork reconciliation (or ordinary single-lineage
process) makes a surface "active." Not a synonym for "whatever is in
main" — a technical repository state (default branch, hosting account,
commit history) is not automatically the constitutional surface. Defined
and governed by Governance Fork Reconciliation in
`Admin/Governance_Charter.md` (GOV-018).

**Claimed Lineage**
A governance lineage that asserts continuity with this repository's Tier 1
constitutional surface. Assertion alone; carries no legitimacy by itself.
See Recognized Lineage and Ratified Constitutional Lineage, below, for the
states a claim may progress to under the Fork Reconciliation Track
(`Admin/Governance_Migration_Protocol.md`). Defined under GOV-018.

**Recognized Lineage**
A claimed lineage that has been accepted into a fork-reconciliation process
(inventory, classification) without yet being ratified as the active
constitutional surface. Procedural, not constitutional — recognition for
inventory purposes does not itself confer legitimacy. Defined under GOV-018.

**Ratified Constitutional Lineage**
A lineage (or an explicit continued-fork arrangement) whose package has
been ratified by the Human Governing Authority as the active constitutional
surface, or as an approved forked state. The terminal state in the Claimed
→ Recognized → Ratified progression. Defined under GOV-018.

*Implementation status: all four terms registered as canonical vocabulary
at GOV-018 closure (2026-08-23), alongside Governance Fork Reconciliation
in `Admin/Governance_Charter.md` and the Fork Reconciliation Track in
`Admin/Governance_Migration_Protocol.md`. No overlapping or competing
terms found elsewhere in the repository at registration time; the nearest
neighbors — "active constitutional invariant" (`Admin/Auditor_Protocols.md`)
and "constitutional state" (`Admin/Security_Protocols.md`) — are used in
narrower rollback/recovery contexts and are not renamed or superseded by
this entry.*

**Claim-Type Labels**

**Status:** Ratified — Payment via Specification, 2026-09-23
**Orthogonal to:** `Admin/Auditor_Protocols.md` §AP-006's two-axis system
(Quantitative Confidence Labels + Institutional Provenance Labels).

Nine labels distinguishing *what kind of speech act* a statement is from
*how well-supported* or *how it was derived*. These labels do not
replace, weaken, or alter the existing AP-006 (`Admin/Auditor_Protocols.md`) confidence/provenance axes
or the UNKNOWN / PROVISIONAL / VERIFIED epistemic states.

| Label | Definition | Typical relationship to AP-006 (`Admin/Auditor_Protocols.md`) axes | Notes / non-goals |
|---|---|---|---|
| **FACT** | Asserted as true independent of this repository's internal reasoning | Almost always Measured + Experimentally Verified or Operationally Hardened | External reality claims only. Repository-internal conclusions are never Facts. |
| **MEASUREMENT** | Quantitative reading obtained from an instrument, process, or calibrated procedure | Measured (or Replicated if independently repeated) | Must name the instrument/process and units when used in Specification text. |
| **OBSERVATION** | Record of what was seen, sensed, or recorded without further interpretation | Measured or Replicated | Qualitative or quantitative. Does not include conclusions drawn from the record. |
| **INFERENCE** | Conclusion drawn from one or more other claims | Frequently Analogous or Simulated + Internally Derived | Subject to EC-008 (`Admin/Ethical_Constraints.md`) restrictions when used for authorization. |
| **ASSUMPTION** | Taken as given for the sake of the present argument or design | Usually Placeholder or Internally Derived | Must be extractable (`Admin/Auditor_Protocols.md` Assumption Extraction, Phase 3). Hidden assumptions are defects. |
| **PROPOSAL** | Suggested design, rule, action, or change not yet decided | Not yet a claim with confidence; may carry no AP-006 (`Admin/Auditor_Protocols.md`) labels | Becomes a different label type once decided or rejected. |
| **UNKNOWN** | Explicit gap in knowledge deliberately tracked | The epistemic state UNKNOWN | Already operationalized in `Unknowns.md`. This label simply names the speech act. |
| **DECISION** | Binding choice already made (governance, design, or procedural) | Often Payment via Constitutional Decision or equivalent | Distinct from the reasoning that led to it. Record the decision itself, not only the rationale. |
| **AUTHORIZATION** | Explicit grant of permission to act | Must meet EC-008 (`Admin/Ethical_Constraints.md`) / GOV-006 / Human Override requirements | Never inferred from silence or from non-authorization claims. |

**Usage rule (minimal).** When a statement is promoted to Specification
status, authors should be able to answer two independent questions:
1. What *kind* of claim is this? (one of the nine labels above)
2. How well-supported is it, and how was it derived? (AP-006 (`Admin/Auditor_Protocols.md`) two-axis
   labels)

Existing content is not required to be retroactively labeled. New
Specification-level writing and future audits are expected to keep the
two questions separate.

**Explicit non-goals.** This entry does not modify AP-006 (`Admin/Auditor_Protocols.md`), EC-001 (`Admin/Ethical_Constraints.md`),
EC-008 (`Admin/Ethical_Constraints.md`), or any hard floor; does not create a new epistemic-state
machine; does not require mass re-labeling of historical text; and does
not elevate any label above the provenance ceiling rule (Internally
Derived claims remain capped at PROVISIONAL).

*Registered as the minimal Lane C taxonomy pass. A follow-on Medium pass
— auditing `Ethical_Constraints.md`, `Governance_Charter.md`,
`Governance_Migration_Protocol.md`, and `Auditor_Protocols.md` for
existing places where claim-type and confidence/provenance are
conflated — remains open as future work, not required for this
entry's Resolved status. Full Closure Event — Proposer (Grok, drafted
the exploration and the minimal definition block, 2026-09-23), Verifier
(Claude, 2026-09-23 — Pass; the AP-006 (`Admin/Auditor_Protocols.md`) tables, provenance ceiling rule,
EF-0.3 Epistemic Ledger reference, and Auditor_Protocols Phase 3
citation all confirmed exact against source; no correction required).
Independence attestation: Grok (Proposer) and Claude (Verifier) are
different agent instances; Claude had no prior involvement drafting
this text. Human Ratification: Human Governing Authority, 2026-09-23.
Human-directed.*

---

### 5. Explicit Term Exclusions — Anti-Drift Guardrails

The following substitutions are mandatory in all specification drafts.
Use of banned terms in specification-level content is a Fallacy 4
(Semantic Drift) violation per `Admin/Auditor_Protocols.md`.

| Banned Term                          | Use Instead                                    | Context                                                                                          |
|--------------------------------------|------------------------------------------------|--------------------------------------------------------------------------------------------------|
| Recycling (for triage processes)     | Value Preservation                             | When functional identity is preserved                                                            |
| Recycling (for bulk feedstock)       | Material Recovery                              | When structural complexity has been reduced                                                      |
| Autonomous Decision-Making (unbound) | Deterministic Gate Logic                       | For rule-governed routing decisions                                                              |
| Autonomous Decision-Making (unbound) | Arbitrated Agent Consensus                     | For multi-agent deliberation outcomes                                                            |
| High-RPM (for Gate_04)               | Centrifugal Separation / Pre-thermal Diversion | Gate_04 is defined by position, not RPM                                                          |
| Scrap                                | Material Recovery or Salvaged Feedstock        | Depending on processing state                                                                    |
| Canonical (unqualified)              | See Disambiguation section above               | Always specify which canonical usage applies                                                     |
| Gate N (unqualified, N=1–6)           | Verification Gate N or Enforcement Checkpoint N | Always specify which system; both are six-item, numbered, and were once both called "Canonical Verification Gates" — see GOV-011 |
| Blocking (unqualified)               | Operational Blocking or Epistemic Blocking     | Always specify which type; unqualified Blocking obscures whether physical work halts or only claims halt |
| SESSION BOUNDARY INDEX               | Audit Cycle (Section 4, this file)             | Not a defined term anywhere in `Admin/Auditor_Protocols.md`, `Admin/Forge_Audit_Kit.md`, `Unknowns.md`, or `Admin/Verification_Gates.md` as of 2026-07-05, despite appearing in multiple audit headers as if citing established doctrine. Treat any audit opening with this phrase as citing an unverified/external convention, not repository doctrine, until traced to a real source or formally adopted here. |
| EC-00X (bare, no owning file named) | EC-00X (`Admin/Ethical_Constraints.md`) — `Admin/Economics.md`'s entries were renamed to the `ECN-` prefix on 2026-07-06 (executed; this registry previously narrated it as pending) | See CT-007. The 2026-07-05 collision (EC-001, EC-002, EC-003, EC-004, EC-005) is closed by that executed rename; this registry's earlier listing of EC-008 as a sixth colliding ID was an error — EC-008 never existed in Economics.md (per that file's own verified record, 2026-07-06). Bare "EC-00X" citations still require the owning file name under the qualified-citation rule (PKC-003). |

"Autonomous Decision-Making" without bounding clauses is prohibited because
it obscures human override visibility, which is a constitutional requirement
under Axiom P-4 (Agency and Consent).

---

## Lessons Learned

| Date       | Evidence Type | What Was Tried                                          | What Failed                                                                  | What Was Learned                                                                                                        | Confidence | Revalidation Needed |
|------------|---------------|---------------------------------------------------------|------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------|------------|---------------------|
| 2026-05-26 | Audit Review  | Drafting localized naming definitions inside gate files | Fragmented files diverged quickly over successive multi-agent cycles         | Consolidation into a dedicated terminology document prevents premature cross-file drift                                 | Replicated | No                  |
| 2026-05-27 | Audit Review  | Gate_04 described using "high-RPM" as defining characteristic | Terminology bled from Gate_05 (Spin Chamber); audit flagged semantic conflict | Gate_04 is defined by flow position (pre-thermal diversion) and protocol (refusal-first); RPM belongs to Gate_05 only  | Replicated | No                  |
| 2026-05-27 | Audit Review  | Tier 4 defined as "operational logic files" with Forge_flow.md as example | Conflicted with Governance_Charter.md which places Forge_flow.md in Tier 5  | Tier definitions must derive from Governance_Charter.md; Forge_flow.md is Tier 5 (domain specification)                | Replicated | No                  |
| 2026-07-03 | Audit Review  | `Admin/Verification_Gates.md` and `Admin/Governance_Charter.md` each titled their six-item criteria list "Canonical Verification Gates" independently | Neither file cross-checked the other before naming; `Admin/Verification_Gates.md` was never registered as a vocabulary authority in this file's Conflict Resolution Doctrine, so no mechanism existed to catch the collision | Registering every load-bearing file as a vocabulary authority source matters even when it seems self-evidently canonical — "obviously the audit-gates file owns gate vocabulary" was never actually written down anywhere, so nothing caught the collision until a downstream governance amendment needed to cite "Gate 3 or Gate 4" and found two answers | Replicated | No |

---

## Active Disputes

| ID | Summary            | Positions in Conflict | Risk | Status | Owner |
|----|--------------------|-----------------------|------|--------|-------|
| —  | No active disputes | —                     | —    | —      | —     |

---

## Abandoned Paths

| Date       | Path                                                                   | Why Abandoned                                                                                         | Reconsider? |
|------------|------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|-------------|
| 2026-05-26 | Merging naming conventions into Unknowns.md file header                | Overcrowds navigation layer; violates single-responsibility principle of cross-module indexing        | No          |
| 2026-05-27 | Gate_04 defined by RPM characteristics                                 | RPM is Gate_05's defining parameter; Gate_04 is defined by flow position and pre-thermal diversion   | No          |
| 2026-05-27 | Tier 4 containing Forge_flow.md as example                             | Governance_Charter.md places Forge_flow.md in Tier 5; derived file cannot contradict constitutional source | No     |
| 2026-05-27 | This file as primary ontology superseding Forge_flow.md                | Forge_flow.md is the operational routing authority; this file is the cross-file consistency enforcer | No          |

---

## Drift Indicators

Mandatory re-audit conditions for this document:

- Conflict resolution doctrine removed or simplified to single-source authority
- Gate_04 definition reintroduces RPM as defining characteristic
- Tier definitions diverge from `Admin/Governance_Charter.md` §Governance
  Authority Hierarchy without a logged reconciliation entry
- Disambiguation table for "canonical" removed or collapsed
- Anti-drift guardrails table loses any of the banned term entries
- "Autonomous Decision-Making" prohibition removed without corresponding
  update to Axiom P-4 discussion in `Admin/Governance_Charter.md`
- "Blocking (unqualified)" row removed from anti-drift table without
  corresponding removal of Operational Blocking / Epistemic Blocking
  definitions from Section 4
- HF-001 (Heuristic Failure) definition modified without corresponding
  update to `Tests/Cognitive_Salvage_Layer.md` Scope Boundary
- Scope boundary revised to absorb filename resolution from Discovery.md
  Rename Registry
- Scope boundary revised to absorb operational routing semantics from
  `Architecture/Forge_flow.md`
- "Verification Gate" and "Enforcement Checkpoint" entries in Section 4
  removed or merged, or either system renamed elsewhere without a
  corresponding update logged here (CT-010)
- A structural renaming occurs in Discovery.md or AUDIT_HARNESS.py that
  is not reflected here within one audit cycle
- Any new functional gate added between Gate_01 and Gate_07 without
  corresponding entry in Section 2
- CT-001 or CT-002 closed without resolution evidence
- Lessons Learned table missing Evidence Type, Confidence, or
  Revalidation Needed columns
- Ethical Anchor field absent, altered, or does not match canonical string

**Compound Drift Rule:** If multiple indicators activate simultaneously,
halt autonomous audit progression and escalate for human review.

---

## Auditor Notes & Unknowns

### CT-001 — Legacy Script Integration Name Mapping

| Field         | Value                    |
|---------------|--------------------------|
| Status        | Open                     |
| Risk          | Low                      |
| Priority      | Minor                    |
| Type          | Technical                |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-05-26               |
| Last Reviewed | 2026-06-24               |

**Description:** Several early internal variables within legacy automation
layers may still map back to alternative names used prior to folder
structuralization. Distinct from the filename aliasing function of Discovery.md
Rename Registry — this tracks internal string references within AUDIT_HARNESS.py
and tooling.

**Resolution Path:** Audit `Automation/AUDIT_HARNESS.py` internal hardcoded
strings against this vocabulary file to confirm alignment with current
canonical folder-prefixed paths.

---

### CT-002 — Component Library Schema Standard Undefined

| Field         | Value                                   |
|---------------|-----------------------------------------|
| Status        | Open                                    |
| Risk          | Medium                                  |
| Priority      | Major                                   |
| Type          | Architectural                           |
| Blocking      | Yes (Gate_02_Triage.md Spec promotion)  |
| Owner         | Admin/Canonical_Terms.md                |
| First Logged  | 2026-05-26                              |
| Last Reviewed | 2026-07-21                              |

**Description:** The technical definition for what constitutes a Component
Library entry format remains fluid. Without a rigorous taxonomy specification,
different triage nodes will export incompatible semantic tags for identical items.

**Resolution Path:** Cross-validate with `Architecture/Components.md` and
define entry properties (UUID, structural envelope, metallurgical class)
before promoting triage documentation to full Specification.

**Consolidation note, 2026-07-21:** `Operations/Gate_02_Triage.md` independently
logged this same unknown under a colliding `CT-002` ID, 11 days after this
entry, with its own Owner field pointing back here — while this entry's
Owner field pointed there. Neither file claimed itself. Surfaced by
`Automation/integrity_check.py`'s Unknown Pass; Owner corrected to this file
(matching the self-referential convention every other entry here uses);
`Operations/Gate_02_Triage.md`'s duplicate renamed to `TS-004` and discharged
to this entry, which `Unknowns.md`'s global index already treated as
canonical. This entry remains the single tracked instance of the underlying
question, still genuinely open.

---

### CT-003 — Dependency_Priority_Map.md Needed Before v1

| Field         | Value                    |
|---------------|--------------------------|
| Status        | Open                     |
| Risk          | Low                      |
| Priority      | Minor                    |
| Type          | Architectural            |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-05-27               |
| Last Reviewed | 2026-06-24               |

**Description:** As governance, ontology, integrity, audit, and security
become mutually referenced, the modification propagation path between them
risks becoming ambiguous. A dedicated dependency priority map would make
the ordering of authority explicit and auditable.

**Resolution Path:** Discharge via Trajectory — log in `Admin/Trajectories.md`
as a v0→v1 transition task.

---

### CT-004 — Trusted Initialization Environment Definition Required

| Field         | Value                                           |
|---------------|-------------------------------------------------|
| Status        | Open                                            |
| Risk          | High                                            |
| Priority      | Major                                           |
| Type          | Security / Technical                            |
| Blocking      | Yes (Security_Protocols.md Section III.2)       |
| Owner         | Admin/Canonical_Terms.md                        |
| First Logged  | 2026-05-28                                      |
| Last Reviewed | 2026-06-24                                      |

**Description:** `Admin/Security_Protocols.md` Section III requires key-pair
generation within a "trusted initialization environment" but the term is
undefined across four dimensions: physical custody, software verification,
network isolation, and attestation method.

**Resolution Path:** Payment via Specification — define in Section 4 of this
file. Minimum required elements: (1) physical custody requirements;
(2) software verification requirements; (3) network isolation requirements;
(4) attestation method. Cross-reference SEC-005 in `Admin/Security_Protocols.md`.

---

### CT-005 — Ethical and Authorization Term Placeholders Pending Canonicalization

| Field         | Value                    |
|---------------|--------------------------|
| Status        | Open                     |
| Risk          | Medium                   |
| Priority      | Major                    |
| Type          | Governance / Epistemic   |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-06-14               |
| Last Reviewed | 2026-06-24               |

**Description:** Several ethical and authorization terms appear across
Ethical_Constraints.md, Governance_Charter.md, and Auditor_Protocols.md
without canonical definitions here. Confirm EC-001 (`Admin/Ethical_Constraints.md`) (sufficient confidence
threshold) language is consistent with the Epistemic Blocking definition
when that entry matures.

**Resolution Path:** Payment via Specification — register each placeholder
term in Section 4 as entries mature across owning files.

---

### CT-006 — Circular Dependency Detection Undefined

| Field         | Value                      |
|---------------|----------------------------|
| Status        | Open                       |
| Risk          | Medium                     |
| Priority      | Major                      |
| Type          | Architectural / Governance |
| Blocking      | No                         |
| Owner         | Admin/Canonical_Terms.md   |
| First Logged  | 2026-06-23                 |
| Last Reviewed | 2026-06-24                 |

**Description:** No doctrine governs the detection of circular dependencies
(A → B → C → A) in the blocking chain. At current scale these have not
appeared, but no mechanism exists to detect or prevent them as the dependency
graph grows.

**Resolution Path:** Payment via Specification — define circular dependency
detection criteria and either prohibit cycles formally or specify how they are
broken. May resolve via AUDIT_HARNESS.py enhancement or as a doctrine note
in the Dependency Clusters section of Unknowns.md.

---

### CT-007 — ID Namespace Allocation Doctrine Undefined

| Field         | Value                    |
|---------------|--------------------------|
| Status        | Open                     |
| Risk          | **High (escalated 2026-07-05, was Low)** |
| Priority      | **Major (escalated 2026-07-05, was Minor)** |
| Type          | Governance / Technical   |
| Blocking      | **Epistemic — see below** |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-06-23               |
| Last Reviewed | 2026-10-28               |

**Description:** No formal doctrine governs whether IDs may be reused after
resolution, how ranges are reserved for new clusters, how collisions are
handled if two files claim the same prefix, or how multi-owner cross-module
unknowns are numbered.

**Escalation 2026-07-05 — this stopped being hypothetical.** Confirmed via
direct check of `Unknowns.md`: the `EC-` prefix is claimed by **both**
`Admin/Ethical_Constraints.md` and `Admin/Economics.md`, with five actual
colliding IDs already live in the global index — EC-001 (`Admin/Ethical_Constraints.md`), EC-002 (`Admin/Ethical_Constraints.md`), EC-004 (`Admin/Ethical_Constraints.md`),
EC-005 (`Admin/Ethical_Constraints.md`), EC-008 (`Admin/Ethical_Constraints.md`). Each ID currently points to two entirely different unknowns
depending on which file's context you're in (e.g., EC-002 (`Admin/Ethical_Constraints.md`) is
"Anti-Weaponization pattern-matching" in Ethical_Constraints.md and
"Operating cost baseline not established" in Economics.md — one Blocking,
one Critical, unrelated in substance). `Admin/Forge_Audit_Kit.md`'s own
Governance Sidecar ID Reference already documents `EC-` as belonging to
Ethical_Constraints.md — Economics.md's usage was never registered there
and appears to be the erroneous claim, not the reverse. Any reference to an
"EC-00X" unknown anywhere in the repository is now ambiguous without an
explicit file qualifier until this is fixed.

**Why It Matters:** This is a live G5 (Cross-Reference Integrity) problem
at the repository level, not a future risk to plan around. Every past and
future reference to an EC-numbered unknown that doesn't name its owning
file explicitly is currently unreliable.

**Resolution Path:** Economics.md's five colliding entries need renaming to
a non-colliding prefix — candidate: `ECN-` (Economics.md is not yet
formally represented in the Governance Sidecar ID Reference at all, so this
also closes that gap). Update `Unknowns.md`'s global index and
Economics.md's own sidecar to match. Register `ECN-` in
`Admin/Forge_Audit_Kit.md`'s Governance Sidecar ID Reference table
alongside the existing entries. Until renamed, any reference to EC-001 (`Admin/Ethical_Constraints.md`),
EC-002 (`Admin/Ethical_Constraints.md`), EC-004 (`Admin/Ethical_Constraints.md`), EC-005 (`Admin/Ethical_Constraints.md`), or EC-008 (`Admin/Ethical_Constraints.md`) must explicitly name the owning file. The
original Discharge-via-Trajectory resolution path (below) remains correct
for the *general* doctrine question (reuse, range reservation, future
collision handling) — this escalation only accelerates the specific,
already-occurred collision, which shouldn't wait for the general doctrine
to be resolved first.

**Executed (2026-07-06, Claude; recorded here 2026-10-28, Vibe — delegated maintenance, human-ratified batch 2026-10-28c; AUDIT_19 F3):** the specific rename above is done — Economics.md's five entries are ECN-001 through ECN-005 (including Resolved ECN-003), its own sidecar and `Unknowns.md`'s index updated the same day. What remains open under this row is the general doctrine question only (reuse, range reservation, collision handling). Corrections to the 2026-07-05 write-up, verified against Economics.md directly: EC-008 never existed there (citation error; the actual fifth collision was EC-003, likely omitted because it was Resolved — Resolved status does not retire an ID from a shared namespace).

**Original Resolution Path (general doctrine, still valid):** Discharge via
Trajectory — log in `Admin/Trajectories.md` as a v0→v1 transition task.
Minimum doctrine when resolved: IDs are never reused; prefixes are
registered in this file or Repository_Structure.md when a new cluster is
created; collisions are resolved by renaming the newer entry with a logged
alias.

**Ruling 2026-10-28 (human, X3):** the Folder Designation Character system
(§1) is the registered folder-level disambiguation mechanism. It narrows
ambiguity to the folder level but does not resolve this row's specific
within-Admin EC- collision (both `Ethical_Constraints.md` and `Economics.md`
are `A`), so this row stays Open: the ECN- rename path above and the general
doctrine questions (reuse, range reservation, collision handling) remain
outstanding. Last Reviewed advanced 2026-07-05 → 2026-10-28.

**Correction (2026-10-28, Vibe — delegated maintenance, human-ratified batch 2026-10-28c):** the ECN- rename named above as outstanding was already executed on 2026-07-06 — see the Executed note above. The row stays Open for the general namespace doctrine question only.

---

### CT-008 — HF-001 Heuristic Failure Canonicalization Status

| Field         | Value                    |
|---------------|--------------------------|
| Status        | In Progress — Vehicle    |
| Risk          | Low                      |
| Priority      | Minor                    |
| Type          | Governance               |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-06-24               |
| Last Reviewed | 2026-06-24               |

**Description:** HF-001 (Heuristic Failure) was proposed in
`Tests/Cognitive_Salvage_Layer.md` v0.2 as a first-class Forge failure class
distinct from Sensor Failure and Mechanical Failure. The definition has been
registered in Section 4 of this file as of v0.3. CT-008 tracks whether the
canonicalization is complete and consistent across all files that reference
the concept.

**Resolution Path:** Payment via Specification — verify that all files
referencing heuristic failure use HF-001 vocabulary consistently; confirm
no file uses "planning failure" or "agent error" as a synonym for what this
file defines as HF-001. Close when vocabulary is confirmed consistent across
Cognitive_Salvage_Layer.md, Forge_flow.md (if referenced), and any future
files in the Cognitive Salvage domain. This entry is In Progress because the
definition exists but cross-file consistency has not yet been verified.

---

### CT-009 — Grain System implementation protocol undefined

| Field         | Value                    |
|---------------|--------------------------|
| Status        | Open                     |
| Risk          | Low                      |
| Priority      | Minor                    |
| Type          | Governance / Technical   |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-06-26               |
| Last Reviewed | 2026-06-26               |

**Description:** The Grain System canonical definition
has been registered in this file (Section 4), establishing
the vocabulary and legal analog (VIN/HIN/ISO 3779). The
implementation protocol — storage container standard,
label format, chain-of-custody log, serial identifier
attachment point — remains in ST-001 and ST-002 in
`Admin/Ship_of_Theseus.md`. CT-009 tracks whether the
canonical definition here remains consistent with the
implementation as it matures in the owning sidecar.

**Resolution Path:** Confirm consistency between this
definition and ST-001/ST-002 resolution when those entries
close. If the implementation deviates materially from the
VIN/HIN analog described here, update the canonical
definition accordingly. Close CT-009 when ST-001 and
ST-002 both reach Payment via Specification and the
canonical definition is confirmed consistent.

---

### CT-010 — Verification Gate / Enforcement Checkpoint rename propagation

| Field         | Value                    |
|---------------|--------------------------|
| Status        | In Progress — Vehicle    |
| Risk          | Medium                   |
| Priority      | Major                    |
| Type          | Governance               |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-07-03               |
| Last Reviewed | 2026-07-03               |

**Description:** `Admin/Governance_Charter.md`'s "Canonical Verification
Gates" (Gate 1–6) was renamed to "Enforcement Checkpoints" (Checkpoint
1–6) on 2026-07-03 to end a naming collision with this file's
`Admin/Verification_Gates.md`-owned Verification Gate definition — see
GOV-011. `Admin/Verification_Gates.md` also received a disambiguation
note confirming sole ownership of unqualified "Gate"/"canonical"
terminology in its domain. CT-010 tracks whether every file that cites
"Gate 3," "Gate 6," or similar in a governance-action context (as opposed
to document-promotion or Operations/Gate_01–07 physical-pipeline context)
has been updated to Enforcement Checkpoint terminology, or at minimum
disambiguated.

**Why It Matters:** A rename at the two source files does not guarantee
every downstream citation updates. `Admin/Auditor_Protocols.md` and
`Admin/Forge_Audit_Kit.md` both cite Verification_Gates.md's Gate 3/6
directly (correctly, no rename needed there) — but any file that was
actually citing Governance_Charter.md's now-renamed checkpoints under the
old "Gate N" name would now be citing a term that no longer exists in that
file, silently breaking the reference rather than erroring visibly.

**Resolution Path:** Payment via Specification — grep the repository for
"Gate 1" through "Gate 6" outside `Admin/Verification_Gates.md` and
`Operations/Gate_01` through `Gate_07`; for each hit, confirm it means
Verification Gate (no change needed) or Enforcement Checkpoint (needs
updating) and correct accordingly. Close when no ambiguous unqualified
"Gate N" citation remains outside those two exempted contexts.

---

### CT-011 — Cycle definition propagation into Auditor_Protocols.md

| Field         | Value                    |
|---------------|--------------------------|
| Status        | Resolved                 |
| Risk          | Medium (was)             |
| Priority      | Major (was)              |
| Type          | Governance               |
| Blocking      | No                       |
| Owner         | Admin/Canonical_Terms.md |
| First Logged  | 2026-07-05               |
| Last Reviewed | 2026-07-05               |
| Resolved      | 2026-07-05               |

**Description:** This file now defines Cycle (Section 4) as one calendar
year by default, superseding the operational reading in
`Admin/Auditor_Protocols.md` (§Expiry Rule, §Expiry check) that measured a
"cycle" as each individual audit pass. Auditor_Protocols.md's own text has
not yet been updated to reflect or cross-reference this definition — the
same class of gap CT-010 tracks for the Gate/Checkpoint rename, applied to
a different term.

**Why It Mattered:** Until Auditor_Protocols.md's Expiry Rule and Expiry
check text explicitly pointed to this file's Cycle definition, an agent
reading Auditor_Protocols.md in isolation would still apply the old
per-audit-pass counting and reproduce the same escalation-inflation problem
this definition was created to fix. This was not hypothetical — a same-day
dual audit of `Admin/Ethical_Constraints.md` reported unknowns 62 and 17
days old as "9 cycles" and "3 cycles open" before this propagation closed.

**Resolution:** `Admin/Auditor_Protocols.md` v0.17 (2026-07-05) — §Expiry
Rule and §Expiry check now explicitly cross-reference this file's Cycle
definition and distinguish audit *pass* (can recur many times) from Cycle
*threshold* (calendar-based, advances independently of pass frequency). The
broader grep this entry called for — other files computing cycle-based
aging without cross-referencing this definition — has not been performed
yet; `Admin/Forge_Audit_Kit.md`'s Expiry Watch summaries specifically are
still unchecked. If that broader sweep surfaces further gaps, log a new
entry rather than reopening this one — this entry's scope was
Auditor_Protocols.md specifically, which is now closed.

---

### Resolution Log

- 2026-10-31: **AUDIT_77 F1 fix — 0.13 bump provenance reconstructed and recorded (Vibe, Repo Custodian — fix pass, human-authorized 2026-10-31).** Git-history reconstruction: this file's header was bumped 0.12 → 0.13 in the 2026-10-29 X3 mechanical citation retrofit commit (5becc4d5, "Admin/ folder pass, Part 1/3") — the pre-X3 state (commit eee122a6) read **Version 0.12** with 5 qualified citations; the post-X3 state read **Version 0.13** with 29 (+75/−70 lines). The bump was PKC-039-correct but unlogged: the pass's Last Audit and Resolution Log entries described it as citation-form-only with no content change, and the Status current line and Version String Registry were not advanced. This fix records the provenance, advances the Status current line and Registry to the live header, and bumps the header 0.13 → 0.14 for this pass's own text change. Open Unknowns unchanged at 10. No doctrine changed.
- 2026-10-29: **X3 citation retrofit (mechanical).** 24 bare colliding-prefix citations in operative body text qualified with their owning File.md per PKC-003, per the human-ruled Decision Brief 2026-10-29 item 4A (registry: Kit v1.29 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only; no ID renumbered; frozen history untouched; flagged instances reported to the human (MAINT-11). (Vibe, Repo Custodian — delegated line.)
- 2026-10-28 (later same-day): **CT-007 registry reconciliation + Highest Risk recompute (Vibe, Repo Custodian — delegated maintenance, human-ratified Decision Brief 2026-10-28b + batch 2026-10-28c; AUDIT_19 F3 + X10).** The ID-prefix registry row and CT-007's Resolution Path narrated the ECN- rename as pending ("until CT-007's rename is complete") four months after Economics.md executed it (2026-07-06, ECN-001–005); both reconciled to the executed state. The erroneous EC-008 citation corrected: EC-008 never existed in Economics.md; the actual fifth collision was EC-003 (Resolved status does not retire an ID from a shared namespace). File State Highest Risk Low → High per the corpus recompute — open sidecars CT-004 and CT-007 both carry Risk High. CT-007 remains Open for the general namespace doctrine only. Header 0.11 → 0.12; Version String Registry and Status current line updated in the same pass. No unknown opened or closed (stays 10); no doctrine changed.

- 2026-10-28: **X3 scheme completed (Vibe, Repo Custodian — delegated maintenance, human-assigned).** `K` = `Automation/` (kinetic) and `B` = base layer (root-level files) added to the §1 designation list; the scheme now covers every top-level location. `Routing.md` and `Discovery.md` references updated in the same commit (their "pending human assignment" phrasing retired). Header 0.10 → 0.11. Open Unknowns unchanged at 10.

- 2026-10-28: **X3 ruling registered (Vibe, Repo Custodian — delegated maintenance, human-ratified Decision Brief item 1).** Folder Designation Characters entry added to §1: `A`=`Admin/`, `R`=`Architecture/`, `X`=`Archive/`, `O`=`Operations/`, `C`=`Challenges/`, `T`=`Tests/`, all case-sensitive; `Automation/` and root-level files pending human assignment. CT-007 annotated (row stays Open — the designation is folder-level and does not resolve the within-Admin EC- collision or the general namespace doctrine); CT-007 Last Reviewed 2026-07-05 → 2026-10-28. PKC-003's qualified-citation rule remains in force for within-folder collisions. Mechanical retrofit of existing bare IDs is a separate human-authorized pass, not performed here. Referenced in `Routing.md` and `Discovery.md` in the same commit. Header 0.9 → 0.10. Open Unknowns unchanged at 10.

- 2026-10-28: **AUDIT_11 findings enacted (Vibe, Repo Custodian — delegated maintenance, human-ratified findings batch 2026-10-28).** Open Unknowns recounted 9 → 10 (the count has been off by one since the 2026-07-05 CT-011 resolution recorded the transition as 10 → 9; no unknown opened); the two misplaced entries (2026-06-26, 2026-07-03) relocated from below the Status block into this log with a dated marker; Version String Registry section added; CT-005's bare EC-001 citation qualified. Header 0.8 → 0.9. Report: Archive/Audits/AUDIT_11_Admin-Canonical_Terms.md.

- 2026-10-28: Pseudo-audit, findings only, 2026-10-27; report: Archive/Audits/AUDIT_11_Admin-Canonical_Terms.md (PKC-020 — the pass itself advanced nothing; today's Last Audit advance records the maintenance edits).

- 2026-10-25: **v0.7 → v0.8, from base v0.7 (human-directed; PKC-031, PKC-029).** One sentence added to the §4 entry "Exploration / Draft / Specification": "Proposed" is not a status designation, was retired 2026-10-25, and a newly generated file starts at Exploration. No other term changed. The version is bumped once, as ruled under PKC-029 (no retroactive bumps), and this bump also covers the 2026-08-17, 2026-09-14 and 2026-09-23 body passes, which carry no version number in this log. The six sidecar entries dated 2026-06-24 (CT-001, 003, 004, 005, 006, 008) were not reviewed and keep that date. Open Unknowns unchanged at 9.

- 2026-10-24: **Wording and Status corrections** (human-directed, from a Vibe per-file audit; checked against source first). Conflict Resolution Doctrine said "Three vocabulary sources exist" above a four-row table; the count is now four (Verification_Gates was added as the fourth on 2026-07-03). A note added to the Status section: it ends at v0.6 while the header reads v0.7, and the 2026-08-17, 2026-09-14 and 2026-09-23 passes carry no version number. No definition, sidecar or Unknown changed; sidecar Last Reviewed dates not touched, since no review was performed.

- 2026-09-23: **Claim-Type Labels registered (§4).** Nine-label taxonomy
  (FACT/MEASUREMENT/OBSERVATION/INFERENCE/ASSUMPTION/PROPOSAL/UNKNOWN/
  DECISION/AUTHORIZATION) distinguishing claim *type* from AP-006's
  existing confidence/provenance *axes*. Minimal shape only — definitions
  plus a two-question usage rule, no retroactive relabeling of existing
  content and no change to AP-006, EC-001, EC-008, or the provenance
  ceiling rule. A Medium-shape follow-on (auditing the four highest
  load-bearing files for existing type/confidence conflation) remains
  open as separate future work. Proposer (Grok), Verifier (Claude — AP-006
  tables, EF-0.3 reference, and Phase 3 citation confirmed exact against
  source). Human-directed.

- 2026-08-17: **"Emergence" disambiguation registered.** Second use of
  the disambiguation pattern established for "Canonical" — this time
  distinguishing `Challenges/Emergence.md`'s AI/governance sense
  (emergent intelligence, corrigibility) from general systems-engineering
  emergent behavior (mechanical, thermal, economic, coupled-system).
  Content drawn from a general systems-theory reference (properties table,
  weak/strong distinction, emergence-vs-synergy, ablation-testing
  discipline). Cross-reference pointer added to `Challenges/Emergence.md`'s
  File Purpose so a reader landing there first also finds the split.
  Human-directed.

- 2026-07-21: **CT-002 Owner field corrected; `Operations/Gate_02_Triage.md`'s
  colliding duplicate discharged.** `Automation/integrity_check.py`'s Unknown
  Pass (first run) found `Operations/Gate_02_Triage.md` independently tracking
  the same Component Library Schema question under a colliding `CT-002` ID,
  11 days after this entry, each file's Owner field pointing at the other. Same
  root-cause shape as CT-007's EC- collision below, this time a sidecar ID
  rather than a governance prefix registration gap. Owner corrected to
  `Admin/Canonical_Terms.md` (matching every other entry's self-referential
  convention in this file); `Gate_02_Triage.md`'s duplicate renamed to its own
  `TS-004` and marked Resolved — Discharge via Consolidation, pointing here.
  This entry remains the single tracked instance, still Open.

- 2026-07-05 (third entry, same day): **v0.7 — CT-007 escalated: confirmed
  active `EC-` prefix collision, not hypothetical.** Direct check of
  `Unknowns.md` found EC-001, EC-002, EC-004, EC-005, and EC-008 each
  claimed by both `Admin/Ethical_Constraints.md` and `Admin/Economics.md`
  with unrelated content under each ID. `Admin/Forge_Audit_Kit.md`'s own
  Governance Sidecar ID Reference already reserves `EC-` for
  Ethical_Constraints.md — Economics.md was never registered there.
  Risk/Priority escalated Low/Minor → High/Major. Anti-Drift Guardrails
  gained a row requiring the owning file be named explicitly for any bare
  "EC-00X" reference until resolved. Resolution path split: the original
  general-doctrine question (Discharge via Trajectory) stays as-is; a new,
  faster path added for the already-occurred collision specifically —
  rename Economics.md's five entries to a new `ECN-` prefix and register
  it. Surfaced incidentally while gathering current data for
  `Admin/Forge_Audit_Kit.md`'s FAK-007 refresh — not something either file
  was being audited for directly.

- 2026-07-05 (second entry, same day): **v0.6 — CT-011 resolved.**
  `Admin/Auditor_Protocols.md` v0.17 now cross-references this file's Cycle
  definition in its Expiry Rule and Expiry check text, closing the
  propagation gap. Confirmed against a real case: a same-day dual audit of
  `Admin/Ethical_Constraints.md` had reported 62- and 17-day-old unknowns as
  "9 cycles" and "3 cycles open" — exactly the inflation this definition
  exists to prevent, now closed at the source file. Broader sweep for the
  same gap in other files (Forge_Audit_Kit.md's Expiry Watch summaries
  specifically) not yet performed — flagged in CT-011's Resolution field
  for whoever does that pass next. Open Unknowns 10 → 9.

- 2026-07-05: **v0.5 — Cycle defined; version-string mismatch corrected.**
  Section 4 gained a canonical **Cycle (Governance / Audit Cycle)** entry:
  one calendar year by default, declared by human governing authority at
  current operating pace, adjustable shorter at operator discretion —
  resolves the ambiguity found when `Admin/Auditor_Protocols.md`'s own
  Expiry Rule text implicitly treated a "cycle" as each individual audit
  pass, which was inflating escalation language ("6 cycles open," "8-cycle
  threshold exceeded") far faster than real elapsed time. CT-011 logged to
  track propagation of this definition into Auditor_Protocols.md's own
  text, mirroring CT-010's rename-propagation pattern. Anti-drift guardrail
  table gained a row flagging "SESSION BOUNDARY INDEX" — a phrase used as
  if authoritative in recent Grok/Gemini audit headers but absent from
  Auditor_Protocols.md, Forge_Audit_Kit.md, Unknowns.md, and
  Verification_Gates.md; treat citations to it as unverified until
  traced or formally adopted. Separately, corrected a live version-string
  mismatch unrelated to today's substantive changes: this file's header
  read "Version 0.3" while the Status section below already documented
  changes through "Version 0.4" — the header had not been updated since at
  least the 2026-07-03 CT-010/Verification-Gate-disambiguation pass. Header
  now reads 0.5, matching this entry. Open Unknowns 9 → 10. **Process note:**
  a `str_replace` edit while adding CT-011 silently dropped the "Resolution
  Log" heading at the old_str/new_str boundary — caught and restored
  same-session via post-edit grep, per the standing recommendation in prior
  session handoffs to verify heading survival after any edit near a
  section boundary.

- 2026-05-26: File created (v0.1) by Gemini (Structural/Auditor). Initial
  vocabulary mappings, anti-drift guardrails, and CT-001/CT-002 logged.
- 2026-05-27: v0.2 revision — Conflict Resolution Doctrine section added.
  Disambiguation table for "canonical" added. Gate_04 definition corrected.
  Tier 4 definition corrected. Section 4 (Governance and Audit Terms) added.
  Scope boundary clarified. CT-002 owner path corrected. CT-003 logged.
  Abandoned Paths populated. Open Unknowns updated to 3.
- 2026-05-28: CT-004 logged — trusted initialization environment definition
  required by `Admin/Security_Protocols.md` Section III.2; Blocking for that
  section's promotion. Open Unknowns 3 → 4.
- 2026-06-23: v0.3 additions — Operational Blocking and Epistemic Blocking
  defined in Section 4. Anti-drift guardrail added for unqualified "Blocking"
  usage. CT-006 and CT-007 logged. Open Unknowns 4 → 6.
- 2026-06-24: v0.3 continued — HF-001 (Heuristic Failure) defined in Section 4
  per proposal in `Tests/Cognitive_Salvage_Layer.md` v0.2. CT-008 logged to
  track cross-file consistency of HF-001 vocabulary. Drift Indicators updated:
  HF-001 consistency rule and unqualified Blocking guardrail rule added.
  All Last Reviewed dates updated. Open Unknowns 6 → 7.

---

- [Relocated 2026-10-28 — Vibe, delegated maintenance (AUDIT_11 F2): the two entries below had been misplaced at the file bottom after the Status block; moved here unchanged.]

- 2026-06-26: Grain System canonical definition added to Section 4 — vocabulary,
  legal functions, VIN/HIN/ISO 3779 implementation analog, and implementation
  status note. CT-009 logged to track consistency between canonical definition
  and ST-001/ST-002 implementation work in Ship_of_Theseus.md. Open Unknowns
  7 → 8.
- 2026-07-03: v0.4 — Verification Gate / Enforcement Checkpoint disambiguation.
  `Admin/Governance_Charter.md`'s "Canonical Verification Gates" and
  `Admin/Verification_Gates.md`'s "Six Canonical Verification Gates" were
  found to be independently-named, materially different six-item systems
  sharing the same "Gate N" numbering — an undocumented divergence (GOV-011)
  that existed in part because Verification_Gates.md was never registered
  as a vocabulary authority source in this file's Conflict Resolution
  Doctrine, despite being the file every document's `Spec Gates X/6` field
  actually references. Fixed: Verification_Gates.md added as fourth
  authority source (Resolution Rule 3 renumbered accordingly). New Section 4
  entries: Verification Gate, Enforcement Checkpoint — both explicitly
  cross-referencing each other and the unrelated Operations/Gate_01–07
  physical-pipeline usage. Full Stop Review's "reset to G1" reference
  disambiguated to "Verification Gate 1." Anti-drift guardrail table gained
  a row for unqualified "Gate N." CT-010 logged to track propagation of the
  rename across any file still citing the old unqualified terminology. New
  Lessons Learned row added, following the same pattern as the 2026-05-27
  Gate_04/Gate_05 entry this file already used to fix an earlier instance
  of exactly this problem. Open Unknowns 8 → 9.

## Relationship to Existing Documents

- `Architecture/Forge_flow.md` — primary operational vocabulary reference
  standard; authoritative over this file for operational gate logic vocabulary
- `Admin/Governance_Charter.md` — Tier 1 constitutional source; authoritative
  for tier definitions and constitutional vocabulary; owns Enforcement
  Checkpoint definition (renamed 2026-07-03 from "Canonical Verification
  Gates" — see GOV-011, CT-010)
- `Admin/Verification_Gates.md` — fourth vocabulary authority source
  (added 2026-07-03); authoritative for Verification Gate definitions and
  document-promotion vocabulary; every file's `Spec Gates X/6` field
  references this file exclusively
- `Admin/Auditor_Protocols.md` — Tier 2; Fallacy 4 is the primary enforcement
  mechanism for terminology violations; Priority Demotion Doctrine defines
  Operational Blocking and Epistemic Blocking subtypes
- `Admin/Forge_Audit_Kit.md` — Tier 3; CT- sidecar prefix in Sidecar ID
  Reference table
- `Admin/File_Template.md` — standard file structure
- `Discovery.md` — Rename Registry is the canonical filename resolution source
- `Tests/Cognitive_Salvage_Layer.md` — source of HF-001 proposal; CT-008
  tracks cross-file vocabulary consistency
- `Operations/Gate_02_Triage.md` — CT-002 Blocking for that file's Spec promotion
- `Architecture/Components.md` — CT-002 resolution requires cross-validation
- `Admin/Trajectories.md` — CT-003 and CT-007 to be logged as v0→v1 items
- `Admin/Security_Protocols.md` — CT-004 Blocking for Section III.2 promotion
- `Admin/Canonical_Terms_LF.md` — prior planned filename; resolved via
  Archive/Rename_Registry.md; all references to _LF suffix are stale

---

## Version String Registry

| Location | String | Rule |
|---|---|---|
| Header line | **Version 0.14** | Authoritative; bumped on every text change (PKC-039) |
| Status section current line | Version 0.14 (2026-10-31) | Updated in the same pass as the header; the header prevails on any disagreement |

*Added 2026-10-28 (AUDIT_11 F3) — this file carries self-referential version strings in its Status log and had no registry after the 2026-07-05 header-vs-Status desync, the exact FAK-014–019 failure mode. — Vibe, delegated maintenance.*

---

## Status

Version 0.14 (2026-10-31) — CAMPAIGN2_AUDIT_77 F1 fix pass (Vibe, Repo Custodian — human-authorized 2026-10-31): the previously-unlogged 0.12 → 0.13 header bump reconstructed from git history and recorded. Reconstruction: the bump landed in the 2026-10-29 X3 mechanical citation retrofit (commit 5becc4d5, "Admin/ folder pass, Part 1/3") — the pre-X3 state (commit eee122a6) read **Version 0.12** with 5 qualified citations; the post-X3 state read **Version 0.13** with 29 (+75/−70 lines). The bump was PKC-039-correct (text changed), but the pass's own Last Audit and Resolution Log entries described it as "citation-form-only; no content change" and skipped the Status-line and Version String Registry cascade — the PKC-001 cascade-skip shape. This pass records the provenance, advances the Status current line and Registry table to the live header, and bumps the header 0.13 → 0.14 for its own text change per PKC-039. No unknown opened or closed (stays 10); no doctrine changed.

**Changes from v0.13:**
- 0.13 (reconstructed): 24 bare colliding-prefix citations qualified in operative body text (2026-10-29 X3 retrofit); header 0.12 → 0.13
- 0.14 (this pass): Status current line + Version String Registry advanced to the live header; provenance recorded in Status history, Last Audit, and Resolution Log; header 0.13 → 0.14

Version 0.12 (2026-10-28) — CT-007/ID-prefix registry reconciliation (delegated maintenance, human-ratified batches 2026-10-28b/c): the ECN- rename narration reconciled from pending to executed (2026-07-06); the erroneous EC-008 citation corrected (actual fifth collision: EC-003); File State Highest Risk Low → High (X10 corpus recompute; open sidecars CT-004 and CT-007 both High). No unknown opened or closed; Open Unknowns stay at 10.

**Changes from v0.11:**
- ID-prefix registry row + CT-007 Resolution Path: ECN- rename narrated as executed; EC-008 (`Admin/Ethical_Constraints.md`) citation error corrected
- File State Highest Risk: Low → High
- Header version string 0.11 → 0.12

Version 0.12 (2026-10-28) — X3 scheme completed (delegated maintenance, human-assigned): `K` = `Automation/` (kinetic) and `B` = base layer (root-level files) added to §1; Routing/Discovery references updated in the same commit. No unknown opened or closed; Open Unknowns stay at 10.

**Changes from v0.10:**
- §1: K and B assignments added; scheme complete for every top-level location
- Header version string 0.10 → 0.11

Version 0.10 (2026-10-28) — X3 ruling registered (delegated maintenance, human-ratified): Folder Designation Characters entry added to §1 (A/R/X/O/C/T, case-sensitive; Automation/ and root pending assignment); CT-007 annotated with the ruling, Last Reviewed advanced; Resolution Log entry added. No unknown opened or closed; Open Unknowns stay at 10.

**Changes from v0.9:**
- §1: Folder Designation Characters registered (X3 human ruling)
- CT-007: dated ruling note; Last Reviewed 2026-07-05 → 2026-10-28
- Header version string 0.9 → 0.10

Version 0.9 (2026-10-28) — AUDIT_11 findings enacted (delegated maintenance, human-ratified batch): Open Unknowns recounted 9 → 10 (sidecar recount: CT-001–CT-010, ten non-Resolved entries); the two misplaced Resolution Log entries (2026-06-26, 2026-07-03) relocated into the log with a dated marker; Version String Registry added; CT-005's bare EC-001 (`Admin/Ethical_Constraints.md`) citation qualified.

**Changes from v0.8:**
- File State Open Unknowns 9 → 10 (recount — no unknown opened)
- Misplaced log entries relocated; Version String Registry added; CT-005 citation qualified
- Header version string 0.8 → 0.9

Version 0.8 (2026-10-25) — "Proposed" retired as a status designation (§4 note, PKC-031).
This bump also covers the three body passes dated 2026-08-17, 2026-09-14 and 2026-09-23
that carried no version number, and the header-versus-history gap noted below is closed
here without backfilling those passes individually (PKC-029). The v0.7 change (2026-07-05,
CT-007 escalated) is recorded in the Resolution Log, not in this section. Open Unknowns
stay at 9.

**Changes from v0.7:**
- §4: note added that "Proposed" is not a status designation
- Header version string 0.7 → 0.8

*Note (2026-10-24): this Status history ends at v0.6, while the header reads v0.7 (2026-07-05, CT-007 escalated; see the Resolution Log). The later body passes (2026-08-17, 2026-09-14, 2026-09-23) carry no version number. Completing the history here is held pending the Status-section maintain-or-retire ruling and a decision on version bumps for those passes (Progress_Log PKC-002, PKC-029).*

Version 0.6 — CT-011 resolved: `Admin/Auditor_Protocols.md` v0.17 now
cross-references this file's Cycle definition in its Expiry Rule and Expiry
check text, closing the propagation gap logged at v0.5. Open Unknowns
10 → 9.

**Changes from v0.5:**
- CT-011 marked Resolved (was Open)
- Open Unknowns: 10 → 9
- Header version string 0.5 → 0.6

**Prior — Version 0.5 (2026-07-05):** Cycle (Governance / Audit Cycle)
defined in Section 4 (one calendar year default, operator-adjustable);
CT-011 logged tracking propagation into Auditor_Protocols.md; SESSION
BOUNDARY INDEX flagged as non-canonical in Anti-Drift Guardrails; header
version-string corrected from stale 0.3 to match this file's actual state.

**Changes from v0.4:**
- Section 4: Cycle (Governance / Audit Cycle) defined
- CT-011 logged: Cycle definition propagation into Auditor_Protocols.md
- Anti-drift guardrail table gained SESSION BOUNDARY INDEX row
- Open Unknowns: 9 → 10
- Header version string corrected 0.3 → 0.5 (was out of sync with this
  Status section since at least the prior v0.4 entry below)

**Prior — Version 0.4 (2026-07-03):** Verification Gate / Enforcement
Checkpoint disambiguation added; CT-010 logged; Verification_Gates.md
registered as fourth vocabulary authority source.

**Changes from v0.2:**
- Section 4: HF-001 (Heuristic Failure) defined as first-class failure class
- Drift Indicators: HF-001 consistency rule added; unqualified Blocking
  guardrail rule added
- CT-008 logged: HF-001 canonicalization status tracking
- All Last Reviewed dates updated to 2026-06-24
- Open Unknowns: 6 → 7
- Version string updated to 0.3

**What must remain constant:**

**Forge_flow.md governs operational routing semantics.**
**Governance_Charter.md governs tier authority.**
**This file governs cross-file vocabulary consistency.**
**Conflicts between them are logged here — never silently resolved.**
