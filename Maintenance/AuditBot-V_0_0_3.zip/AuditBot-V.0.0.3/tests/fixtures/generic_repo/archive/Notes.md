# Notes
Old notes.
