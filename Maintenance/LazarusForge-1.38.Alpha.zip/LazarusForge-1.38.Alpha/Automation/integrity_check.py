"""
Lazarus Forge - Repository Integrity Checker (integrity_check.py)

Repo-wide version of checks previously only possible one file at a time
inside a single AUDIT_HARNESS.py session. Imports audit_lib.py and
parser.py rather than reimplementing their logic — see audit_lib.py's
own docstring for why that split exists.

One real dependency worth naming rather than hiding: the Reference Pass
needs a legacy-name ALIASES map to correctly classify LEGACY vs UNKNOWN
cross-references, and that map currently only lives in AUDIT_HARNESS.py
as data. This module imports ALIASES (a dict, not logic) from there.
That is a lesser coupling than duplicating parsing logic would be, but
it is still a dependency — if AUDIT_HARNESS.py's ALIASES import ever
fails, the Reference Pass degrades to an empty alias map rather than
crashing, and says so in its output.

Passes, run in sequence, each appending Finding objects to one shared list:

    1. Walk Repository
    2. Registry Pass       — orphan detection (file exists, not in Routing.md)
    3. Metadata Pass       — Ethical Anchor + File State, via parser.py
    4. Unknown Pass        — duplicate sidecar ID detection
    5. Reference Pass      — cross-reference resolution, via audit_lib.py
    6. Version String Pass — self-citation version drift (AP-025 pattern)
    7. Pattern A Pass      — Pattern A consistency (C1–C3, C5, C6)
    8. Size Census Pass    — T1 split-queue roster, derived per run (R-1a, 2026-11-12 ruling set)
    9. Output              — structured JSON + human-readable summary

Honesty about scope, stated up front rather than discovered later:
    - Registry Pass inherits parse_routing()'s known limitation: files
      with no extension or a space in the name (e.g. the two Admin/
      Tier-0 philosophical documents) cannot be matched by the
      backtick-path regex. These are reported separately as NOTE
      severity ("could not be checked"), never as false-positive
      CRITICAL orphans.
    - Unknown Pass only matches defining occurrences (`### ID` sidecar
      headers), not table-row mentions in Unknowns.md's cross-reference
      index — a mention is not a duplicate definition, and conflating
      the two was the exact false-positive risk flagged when this tool
      was scoped.
    - Version String Pass only catches the specific "FILENAME vX.Y"
      self-citation pattern that caused AP-023/AP-025. It does not
      attempt to locate or verify a file's declared Version String
      Registry entries against arbitrary prose — that would require
      mapping a human-readable section description to actual text,
      which is a judgment task, not a mechanical one. Declining that
      here rather than shipping a heuristic that looks more thorough
      than it is.
"""

import os
import re
import json
import sys

from parser import MetadataParser
from audit_lib import Finding, parse_routing, check_cross_refs

# Suppress AUDIT_HARNESS LIVE registry dump on import; this tool uses
# local Routing.md only. DEGRADED still surfaces as a one-liner.
os.environ.setdefault("AUDIT_HARNESS_QUIET", "1")

try:
    from AUDIT_HARNESS import ALIASES
    _ALIASES_SOURCE = "AUDIT_HARNESS.ALIASES"
except Exception as e:
    ALIASES = {}
    _ALIASES_SOURCE = f"unavailable ({e}) — Reference Pass LEGACY classification degraded"


TOOL_NAME = "integrity_check"
TOOL_VERSION = "0.4"  # 0.4: Size Census Pass (T1 roster, R-1a); 0.3: Pattern A checks (C1–C3, C5, C6); 0.2: LOCAL-ONLY scope label; quiet harness import; DEGRADED if aliases fail

# Sidecar ID pattern: matches "### AP-017 — ..." style defining headers,
# not table rows. Prefix is 2-6 uppercase letters, ID is 3+ digits.
SIDECAR_ID_RE = re.compile(r'^###\s+([A-Z]{2,6}-\d{3,}(?:-[A-Z0-9]+)*)\b')
# Includes trailing suffix segments (e.g. "-PR", "-R1", "-R3") in the captured
# ID. Without this, `\b` after the numeric part also matches on the boundary
# before a trailing hyphen, so a residual/sub-item like "EC-012-PR" was
# captured as plain "EC-012" — a false same-file "duplicate" against the
# real EC-012 (found and fixed 2026-09-29; this repo uses that suffix
# pattern deliberately, e.g. EC-011-R3, GMP-010-R1, EC-012-PR are each their
# own distinct entry, not a duplicate of their base ID).

# Self-citation version pattern: "Auditor_Protocols.md v0.23" or
# "Auditor_Protocols v0.23" (both forms appear in the real repo).
SELF_VERSION_RE = re.compile(r'([A-Za-z_]+(?:\.md)?)\s+v(\d+\.\d+)')

# File State version line, e.g. "**Version 0.25**"
FILE_STATE_VERSION_RE = re.compile(r'^\*\*Version\s+(\d+\.\d+)\*\*', re.MULTILINE)

# --- Pattern A consistency (File_Template.md §Pattern A), added v0.3 ---
# C1: exactly one boundary heading. An R8 pointer file still keeps the
# boundary heading itself, so pointers need no special case here.
BOUNDARY_RE = re.compile(r'^##\s+Historical\s+Record\s*$')

# C3 declared-version forms, tried in order: 1. the File State line
# "**Version 0.25**" (FILE_STATE_VERSION_RE above); 2. a version block
# "**Version 0.11 (working)**" (bold prefix only); 3. a status line
# "Version 0.18 — Exploration" (Ethical_Constraints-style header).
VERSION_BLOCK_RE = re.compile(r'^\*\*Version\s+(\d+\.\d+)', re.MULTILINE)
STATUS_LINE_VERSION_RE = re.compile(r'^Version\s+(\d+\.\d+)\s+—', re.MULTILINE)

# C3/C6: a Resolution Log line is trusted only when a date sits at (or a
# short label like "Note (" precedes a date at) the line start.
RL_DATE_RE = re.compile(r'^\s*(?:[-*]\s*)?(?:\*\*)?\s*(?:[A-Za-z][\w \-]{0,40}\()?(\d{4}-\d{2}-\d{2})')

# C3: a version transition named on a trusted line.
TRANSITION_RE = re.compile(r'v?(\d+\.\d+)\s*(?:→|->)\s*v?(\d+\.\d+)')

# C5: a "Prior:" chain link in the File State region (header block).
PRIOR_CHAIN_RE = re.compile(r'^[ \t]*(?:[-*][ \t]*)?\*{0,2}[ \t]*Prior[ \t]*\*{0,2}[ \t]*:')

# C2: headings that legitimately straddle or sit below the boundary.
C2_EXEMPT_HEADINGS = ("Auditor Notes & Unknowns", "Lessons Learned", "Abandoned Paths")

# C2 structural scan: level-2 headings.
H2_RE = re.compile(r'^##\s+(.+?)\s*$')

# C5: on an unmigrated file the File State region (header block) ends at
# the first level-2 heading.
TOPLEVEL_HEADING_RE = re.compile(r'^##[ \t]+\S')


def walk_repo(root):
    """
    Returns a list of (relative_path, is_extensionless) for every
    trackable file under root. Trackable = ends in .md, or has no
    extension and isn't a hidden/build file. Mirrors the same
    convention used for the earlier one-off census in this project.
    """
    results = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith('.') and d != '__pycache__']
        for fn in filenames:
            if fn.startswith('.'):
                continue
            rel = os.path.relpath(os.path.join(dirpath, fn), root)
            rel = rel.replace(os.sep, '/')
            if fn.endswith('.md'):
                results.append((rel, False))
            elif '.' not in fn:
                results.append((rel, True))
    return sorted(results)


def registry_pass(root, all_files, findings):
    """Orphan detection: does every trackable file appear in Routing.md's registry?"""
    routing_path = os.path.join(root, "Routing.md")
    if not os.path.exists(routing_path):
        findings.append(Finding("CRITICAL", "REGISTRY", "Routing.md",
                                 "Routing.md not found at repo root — cannot run Registry Pass."))
        return

    with open(routing_path, encoding="utf-8") as f:
        routing_content = f.read()

    registry = parse_routing(routing_content)
    registered_paths = set(registry.values())
    registered_names = set(registry.keys())

    for rel_path, is_extensionless in all_files:
        basename = rel_path.split('/')[-1]
        if is_extensionless or ' ' in basename:
            findings.append(Finding("NOTE", "REGISTRY", rel_path,
                                     "Extensionless or space-containing filename — "
                                     "parse_routing() cannot match this by design; "
                                     "verify registration in Routing.md manually."))
            continue
        if rel_path in registered_paths or basename in registered_names:
            continue
        if rel_path == "Routing.md" or rel_path == "Discovery.md" or rel_path == "README.md":
            continue  # root navigation files are not expected to register themselves
        findings.append(Finding("WARNING", "REGISTRY", rel_path,
                                 "Not found in Routing.md's Master Routing Map — "
                                 "possible orphan (unregistered file) or a registration gap."))


def metadata_pass(root, all_files, findings):
    """Ethical Anchor + File State sweep via parser.py, repo-wide."""
    for rel_path, is_extensionless in all_files:
        if is_extensionless:
            continue  # parser.py's table/YAML scan needs the .md body shape; skip by design
        full_path = os.path.join(root, rel_path)
        result = MetadataParser(full_path).parse()

        if not result.detected_schemas:
            continue  # no File State table at all — not this pass's concern; Registry/structural gap

        if result.ethical_anchor_status == "missing":
            findings.append(Finding("WARNING", "CONSTITUTION", rel_path,
                                     "Ethical Anchor missing from File State."))
        elif result.ethical_anchor_status == "present_but_altered":
            findings.append(Finding("CRITICAL", "CONSTITUTION", rel_path,
                                     f"Ethical Anchor present but does not match canonical string: "
                                     f"'{result.ethical_anchor.preferred_value}'"))

        for conflict_field in result.conflicting_fields:
            findings.append(Finding("WARNING", "STRUCTURE", rel_path,
                                     f"Conflicting readings for '{conflict_field}' across schemas."))


def unknown_pass(root, all_files, findings):
    """Duplicate sidecar ID detection — defining headers only, not table mentions.

    Archive/ is excluded from this scan. As of the 1.17 release, every
    detected cross-file duplicate (14 pairs, checked 2026-09-29) was a live
    file plus a preserved historical snapshot under Archive/Logs/ or
    Archive/Transcripts/ — a prior-state copy kept intentionally per this
    repository's own Repository_Integrity_Protocol.md prior-state doctrine,
    not a competing live definition. Two of the fourteen archive copies
    (Archive/Transcripts/Configurations.md) self-declare this in their own
    header ("SUPERSEDED — prior-state snapshot... Correctly preserved per
    RIP prior-state"). Excluding Archive/ here still catches the real
    failure mode this check exists for — the same ID defined twice among
    live, current files — while no longer flagging preservation-by-design
    as a critical. If Archive/ ever needs its own duplicate/consistency
    check against its live counterpart, that should be a separate, lower-
    severity pass, not this one.
    """
    id_locations = {}  # id -> list of (file, line_no)

    for rel_path, is_extensionless in all_files:
        if is_extensionless:
            continue
        if rel_path.startswith("Archive/") or rel_path.startswith("Archive\\"):
            continue
        full_path = os.path.join(root, rel_path)
        try:
            with open(full_path, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except Exception:
            continue
        for i, line in enumerate(lines):
            m = SIDECAR_ID_RE.match(line.strip())
            if m:
                uid = m.group(1)
                id_locations.setdefault(uid, []).append((rel_path, i + 1))

    for uid, locations in id_locations.items():
        files_involved = {f for f, _ in locations}
        if len(files_involved) > 1:
            loc_str = "; ".join(f"{f}:{ln}" for f, ln in locations)
            findings.append(Finding("CRITICAL", "DUPLICATE_ID", uid,
                                     f"'{uid}' defined as a sidecar entry in more than one file: {loc_str}"))
        elif len(locations) > 1:
            # Same file, same ID header twice — different but related bug.
            loc_str = "; ".join(f"{f}:{ln}" for f, ln in locations)
            findings.append(Finding("WARNING", "DUPLICATE_ID", uid,
                                     f"'{uid}' has multiple sidecar headers within the same file: {loc_str}"))


def reference_pass(root, all_files, findings):
    """Cross-reference resolution sweep, repo-wide, via audit_lib.check_cross_refs."""
    routing_path = os.path.join(root, "Routing.md")
    if not os.path.exists(routing_path):
        return  # already flagged by registry_pass
    with open(routing_path, encoding="utf-8") as f:
        registry = parse_routing(f.read())

    for rel_path, is_extensionless in all_files:
        if is_extensionless:
            continue
        full_path = os.path.join(root, rel_path)
        try:
            with open(full_path, encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception:
            continue
        check_cross_refs(rel_path, content, registry, ALIASES, findings)


def version_string_pass(root, all_files, findings):
    """
    Self-citation version drift: "FILENAME vX.Y" strings that don't match
    the file's own current File State version. Scoped narrowly — see
    module docstring for what this deliberately does not attempt.
    """
    for rel_path, is_extensionless in all_files:
        if is_extensionless:
            continue
        full_path = os.path.join(root, rel_path)
        try:
            with open(full_path, encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception:
            continue

        fs_match = FILE_STATE_VERSION_RE.search(content)
        if not fs_match:
            continue
        current_version = fs_match.group(1)

        basename_stem = rel_path.split('/')[-1].replace('.md', '')
        for m in SELF_VERSION_RE.finditer(content):
            cited_name, cited_version = m.groups()
            cited_stem = cited_name.replace('.md', '')
            if cited_stem != basename_stem:
                continue  # citing a different file's version, not self-citation
            if cited_version != current_version:
                line_no = content[:m.start()].count('\n') + 1
                findings.append(Finding("WARNING", "VERSION_STRING", rel_path,
                                         f"Self-citation 'v{cited_version}' at line {line_no} does not "
                                         f"match File State version v{current_version}."))


def unknowns_summary_pass(root, all_files, findings):
    """
    Counts active (Open / In Progress / Reopened) rows in Unknowns.md's
    per-topic tables, bucketed by the table's own Priority (Promo) column
    value (Critical / Major / Minor / Blocking / Other).

    Scope, stated honestly: this counts what the Priority (Promo) column
    itself says. It does NOT reconcile against each owning file's own
    "Blocking: Yes/No" sidecar field — that field lives in 80+ separate
    files and cross-checking it here would be a much larger undertaking
    than this pass is scoped for. A row whose Priority column literally
    reads "Blocking" is counted as Blocking; a row whose owning file sets
    Blocking: Yes but whose Priority column here says "Major" is counted
    as Major. This is a real, current limitation, not a rounding error —
    noted in the output so it isn't mistaken for a reconciled count.

    Only counts rows inside this file's own topic tables (the standard
    "| ID | Title | Owning File | Status | Subtype | Priority (Promo) |"
    format). Resolved entries do not appear in these tables per this
    file's own Size Management Rule 2 (see Unknowns.md itself) and are
    correctly excluded by construction, not by filtering Status here.
    """
    unknowns_path = os.path.join(root, "Unknowns.md")
    if not os.path.exists(unknowns_path):
        findings.append(Finding("WARNING", "UNKNOWNS_SUMMARY", "Unknowns.md",
                                 "Unknowns.md not found — cannot summarize active unknowns."))
        return {"total": 0, "by_priority": {}, "by_status": {}}

    with open(unknowns_path, encoding="utf-8") as f:
        lines = f.readlines()

    row_re = re.compile(r'^\|\s*([A-Z]{2,8}-[\dR]{2,}[a-z]?)\s*\|(.*)\|(.*)\|(.*)\|(.*)\|(.*)\|\s*$')
    by_priority = {}
    by_status = {}
    total = 0

    for line in lines:
        m = row_re.match(line.rstrip('\n'))
        if not m:
            continue
        status = m.group(4).strip()
        priority = m.group(6).strip()
        if status.lower() in ("status", "---") or not status:
            continue  # header / separator row
        if "resolved" in status.lower():
            continue  # should not appear per Rule 2, but skip defensively rather than miscount
        total += 1
        by_status[status] = by_status.get(status, 0) + 1
        bucket = priority if priority in ("Critical", "Major", "Minor", "Blocking") else (priority or "Unlabeled")
        by_priority[bucket] = by_priority.get(bucket, 0) + 1

    return {"total": total, "by_priority": by_priority, "by_status": by_status}


def pattern_a_pass(root, all_files, findings):
    """
    Pattern A consistency checks, per File_Template.md §Pattern A.

    Implemented 2026-11-04 (v0.3) under a human-ruled scope: C1, C2,
    C3, C5 and C6. C4 is retired (MAINT-56) and C7–C8 are deferred
    by human ruling 2026-11-04 until a RELEASES register exists —
    this pass checks none of those and does not pretend to.

    Gating, stated up front rather than discovered later:
    - C1, C2 and C6 apply only to a file that HAS a
      `## Historical Record` boundary. No live file has migrated to
      Pattern A yet, so unmigrated files are skipped silently here;
      the migrated/unmigrated counts in the report carry that
      information without per-file NOTE noise.
    - C3 applies to any file that declares a version by one of the
      three known header forms, migrated or not.
    - C5 applies to every file's File State region (header block:
      above the boundary, or above the first `## ` heading on an
      unmigrated file). Frozen files under Archive/ are included
      deliberately — this is a census of R7 Prior-chain debt, not a
      live-file-only sample; expect warnings there until a human
      rules an exemption gate.

    Known limits, in the spirit of this module's own docstring:
    - C3 trusts a Resolution Log line only when a date sits at (or a
      short label like "Note (" precedes a date at) the line start,
      and only transitions that involve the declared version. A
      transition mentioned mid-paragraph is not evidence.
    - C6 is direction-agnostic (ascending and descending both pass)
      and tolerant of same-day entries; it flags only a real reversal.
    """
    migrated = 0
    unmigrated = 0
    declared_files = 0
    prior_chain_files = 0

    for rel_path, is_extensionless in all_files:
        if is_extensionless:
            continue
        full_path = os.path.join(root, rel_path)
        try:
            with open(full_path, encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception:
            continue
        lines = content.split("\n")

        # --- C1: exactly one boundary heading ---
        boundary_line = None
        boundary_count = 0
        for i, ln in enumerate(lines):
            if BOUNDARY_RE.match(ln):
                if boundary_count == 0:
                    boundary_line = i
                boundary_count += 1
        if boundary_count > 1:
            findings.append(Finding("CRITICAL", "PATTERN_A", rel_path,
                                     f"Found {boundary_count} '## Historical Record' "
                                     "boundary headings — C1 requires exactly one."))
        if boundary_line is None:
            unmigrated += 1
        else:
            migrated += 1

        # --- C2: no Front heading below the boundary ---
        if boundary_count == 1:
            front_headings = set()
            for ln in lines[:boundary_line]:
                m = H2_RE.match(ln)
                if m:
                    h = m.group(1)
                    if h not in C2_EXEMPT_HEADINGS and h != "Historical Record":
                        front_headings.add(h)
            for j, ln in enumerate(lines[boundary_line + 1:], start=boundary_line + 2):
                m = H2_RE.match(ln)
                if not m:
                    continue
                h = m.group(1)
                if h in C2_EXEMPT_HEADINGS or h == "Historical Record":
                    continue
                if h in front_headings:
                    findings.append(Finding("WARNING", "PATTERN_A", rel_path,
                                             f"Front heading '## {h}' reappears below "
                                             f"the boundary at line {j} — C2 violated."))

        # --- C3: header version vs newest dated RL transition ---
        m = (FILE_STATE_VERSION_RE.search(content)
             or VERSION_BLOCK_RE.search(content)
             or STATUS_LINE_VERSION_RE.search(content))
        if m:
            declared = m.group(1)
            declared_files += 1
            newest = None  # (date, line_no, source, target)
            for j, ln in enumerate(lines, start=1):
                dm = RL_DATE_RE.match(ln)
                if not dm:
                    continue
                for tm in TRANSITION_RE.finditer(ln):
                    src, tgt = tm.group(1), tm.group(2)
                    if declared == src or declared == tgt:
                        if newest is None or (dm.group(1), j) > (newest[0], newest[1]):
                            newest = (dm.group(1), j, src, tgt)
            if newest is None:
                findings.append(Finding("WARNING", "PATTERN_A", rel_path,
                                         f"Header declares v{declared} but no dated "
                                         "Resolution Log entry names a transition to "
                                         f"or from v{declared} — C3 cannot confirm the "
                                         "header version."))
            elif newest[3] != declared:
                findings.append(Finding("WARNING", "PATTERN_A", rel_path,
                                         f"Header version v{declared} does not match the "
                                         "newest dated Resolution Log transition "
                                         f"'{newest[2]} → {newest[3]}' at line "
                                         f"{newest[1]} — C3 violated."))

        # --- C5: no Prior: chain in the File State region ---
        if boundary_line is not None:
            region_end = boundary_line
        else:
            region_end = len(lines)
            for i, ln in enumerate(lines):
                if TOPLEVEL_HEADING_RE.match(ln):
                    region_end = i
                    break
        hits = [j for j, ln in enumerate(lines[:region_end], start=1)
                if PRIOR_CHAIN_RE.match(ln)]
        if hits:
            prior_chain_files += 1
            findings.append(Finding("WARNING", "PATTERN_A", rel_path,
                                     "File State region still holds a Prior: chain "
                                     f"({len(hits)} link(s), first at line {hits[0]}) — "
                                     "C5/R7 debt; migrate on next touch."))

        # --- C6: dated entries below the boundary are in date order ---
        if boundary_count == 1:
            dated = []
            for j, ln in enumerate(lines[boundary_line + 1:], start=boundary_line + 2):
                dm = RL_DATE_RE.match(ln)
                if dm:
                    dated.append((j, dm.group(1)))
            if len(dated) >= 2:
                dates = [d for _, d in dated]
                asc = all(dates[i] <= dates[i + 1] for i in range(len(dates) - 1))
                desc = all(dates[i] >= dates[i + 1] for i in range(len(dates) - 1))
                if not (asc or desc):
                    direction = None
                    for i in range(len(dates) - 1):
                        if dates[i] < dates[i + 1]:
                            direction = "asc"
                            break
                        if dates[i] > dates[i + 1]:
                            direction = "desc"
                            break
                    for i in range(len(dates) - 1):
                        bad = ((direction == "asc" and dates[i] > dates[i + 1])
                               or (direction == "desc" and dates[i] < dates[i + 1]))
                        if bad:
                            findings.append(Finding("WARNING", "PATTERN_A", rel_path,
                                                     "Historical Record dated entries "
                                                     f"out of order: line {dated[i][0]} "
                                                     f"({dated[i][1]}) vs line "
                                                     f"{dated[i + 1][0]} "
                                                     f"({dated[i + 1][1]}) — C6 violated."))
                            break

    return {
        "migrated_files": migrated,
        "unmigrated_files": unmigrated,
        "declared_version_files": declared_files,
        "prior_chain_files": prior_chain_files,
        "checks": "C1–C3, C5, C6",
        "retired": "C4 (MAINT-56)",
        "deferred": "C7–C8 (human ruling 2026-11-04, until a RELEASES register exists)",
    }


# --- Size Census Pass (T1 split-queue roster), added v0.4 ---
# R-1a of the human's 2026-11-12 reduction-review ruling set ("Can I
# have you begin the cleanup?"): the T1 split queue self-reports every
# run, derived from live files, never maintained by hand (the MAINT-89
# derive-don't-maintain precedent).
# T1 bar: File_Template §Log-Split Rule trigger T1 reads "the file
# measures >= 100 KB". This census reads that as 100,000 bytes (SI),
# the reading the 2026-11-12 reduction-review census itself used
# (Canonical_Terms.md at 100,570 bytes is in the roster;
# Computational_Institutional_Reasoning.md at ~91 KB is out). A
# 102,400-byte (binary) reading would exclude Canonical_Terms.md; if
# the human rules the bar differently, change T1_BYTES here — one
# constant, derived everywhere.
T1_BYTES = 100_000

# A "log home" is a file whose containing directory name ends in
# "Logs" (Admin/ALogs/, Archive/Logs/, the root Logs/, and
# Architecture/RLogs/ when it materializes). R-6b (2026-11-12 ruling
# set) accepted log homes' size as honest — they are Historical by
# definition — so they stay on the roster but are classed differently
# from split-queue doctrine files. Classification is directory-based
# only; a log-named file outside a *Logs/ directory is classed as a
# doctrine file.
LOG_HOME_DIR_RE = re.compile(r"(?:^|/)[A-Za-z_]*Logs/")


def size_census_pass(root, all_files, findings):
    """T1 size census: measure every trackable file, roster the queue.

    Scope, stated honestly:
    - Measures bytes on disk at run time (os.path.getsize); a census,
      not a content check. Nothing here decides or executes a split —
      R8 executes splits at each file's next substantive touch.
    - Covers every trackable file walk_repo returns, including
      extensionless files and everything under Archive/ (the
      2026-11-12 census counted Archive/Logs/Unknowns_Changelog.md).
    - Every over-bar file produces one WARNING: the queue is real and
      open (F-FT-3), and R-6b's acceptance covers the log homes'
      size, not their absence from the roster.
    """
    measured = []
    for rel_path, _is_extensionless in all_files:
        full_path = os.path.join(root, rel_path)
        try:
            size = os.path.getsize(full_path)
        except OSError:
            continue
        measured.append((rel_path, size))
    measured.sort(key=lambda t: (-t[1], t[0]))

    roster = []
    for rel_path, size in measured:
        if size < T1_BYTES:
            continue
        is_log_home = bool(LOG_HOME_DIR_RE.search(rel_path))
        roster.append({"path": rel_path, "bytes": size, "log_home": is_log_home})
        if is_log_home:
            msg = (f"{size} bytes, at or above the {T1_BYTES}-byte T1 bar — "
                   "log home; size accepted as honest per R-6b (2026-11-12 ruling set).")
        else:
            msg = (f"{size} bytes, at or above the {T1_BYTES}-byte T1 bar — "
                   "R8 Log-Split queued (next substantive touch, heaviest first).")
        findings.append(Finding("WARNING", "SIZE_CENSUS", rel_path, msg))

    return {
        "t1_bytes": T1_BYTES,
        "files_measured": len(measured),
        "over_bar_count": len(roster),
        "over_bar_log_homes": sum(1 for r in roster if r["log_home"]),
        "over_bar_split_queue": sum(1 for r in roster if not r["log_home"]),
        "roster_over_bar": roster,
        "authority": ("R-1a, the human's 2026-11-12 reduction-review ruling set "
                      "(derived from live files each run, never maintained by hand)"),
    }

def run(root):
    findings = []
    all_files = walk_repo(root)

    registry_pass(root, all_files, findings)
    metadata_pass(root, all_files, findings)
    unknown_pass(root, all_files, findings)
    reference_pass(root, all_files, findings)
    version_string_pass(root, all_files, findings)
    pattern_a_summary = pattern_a_pass(root, all_files, findings)
    size_census_summary = size_census_pass(root, all_files, findings)
    unknowns_summary = unknowns_summary_pass(root, all_files, findings)

    by_severity = {"CRITICAL": [], "WARNING": [], "NOTE": []}
    for f in findings:
        by_severity.setdefault(f.severity, []).append(f)

    aliases_degraded = (
        "degraded" in _ALIASES_SOURCE.lower()
        or _ALIASES_SOURCE.startswith("unavailable")
    )
    report = {
        "tool": TOOL_NAME,
        "tool_version": TOOL_VERSION,
        "repo_root": root,
        "files_scanned": len(all_files),
        "aliases_source": _ALIASES_SOURCE,
        "verification_scope": {
            "routing_source": "local Routing.md at repo root (not a network fetch)",
            "aliases_source": _ALIASES_SOURCE,
            # LOCAL-ONLY: this tool never uses a network Routing fetch.
            # DEGRADED only when the alias map is unavailable.
            "status": "DEGRADED" if aliases_degraded else "LOCAL-ONLY",
            "note": (
                "Reference Pass LEGACY classification degraded — alias map unavailable"
                if aliases_degraded else
                "Local Routing.md + ALIASES; not a live GitHub Routing verification"
            ),
        },
        "summary": {sev: len(items) for sev, items in by_severity.items()},
        "findings": [f.to_dict() for f in findings],
        "unknowns_summary": unknowns_summary,
        "pattern_a": pattern_a_summary,
        "size_census": size_census_summary,
    }
    return report


def print_summary(report):
    print(f"Files scanned: {report['files_scanned']}")
    print(f"Aliases source: {report['aliases_source']}")
    vs = report.get("verification_scope") or {}
    if vs.get("status") == "DEGRADED":
        print(f"Verification scope: DEGRADED — {vs.get('note', '')}")
    print()
    for sev in ("CRITICAL", "WARNING", "NOTE"):
        count = report["summary"].get(sev, 0)
        print(f"{sev}: {count}")
    print()
    for sev in ("CRITICAL", "WARNING"):
        items = [f for f in report["findings"] if f["severity"] == sev]
        if items:
            print(f"=== {sev} ===")
            for item in items:
                print(f"  [{item['category']}] {item['file']}: {item['message']}")
            print()


def print_health_summary(report):
    """
    Tier 1 + Tier 2 health summary, added 2026-08-27 per a scoped
    dashboard request. Tier 1 = PASS/FAIL per existing check category,
    derived from CRITICAL/WARNING counts already in this report — no
    new checking logic, just a threshold read on what the six passes
    above already found. Tier 2 = active-unknown counts from
    Unknowns.md's own Priority column, via unknowns_summary_pass.

    Deliberately does NOT include a "Governance state" / "Physical
    validation" / overall "ALPHA readiness" badge. Those would require
    inventing a threshold this repository's own doctrine does not
    define anywhere, which is exactly the kind of manufactured-looking-
    mechanical number this repo's own Placeholder/Analogous confidence
    discipline exists to prevent. If that judgment is wanted, it
    belongs to a human, as an explicitly-dated, explicitly-manual
    field — not this function.

    As of 0.2: prints an explicit verification-scope line. This tool
    always uses local Routing.md (never a network fetch). If ALIASES
    could not be imported from AUDIT_HARNESS, status is DEGRADED and
    LEGACY cross-ref classification must not be treated as complete.
    """
    by_cat = {}
    for f in report["findings"]:
        by_cat.setdefault(f["category"], []).append(f)

    categories = [
        ("REGISTRY", "Registry (Routing.md coverage)"),
        ("CONSTITUTION", "Metadata / Ethical Anchor"),
        ("STRUCTURE", "Metadata / File State consistency"),
        ("DUPLICATE_ID", "Sidecar ID uniqueness"),
        ("REFERENCE", "Cross-reference resolution"),
        ("VERSION_STRING", "Version-citation freshness"),
        ("PATTERN_A", "Pattern A checks (C1–C3, C5, C6)"),
        ("SIZE_CENSUS", "T1 size census (R-1a derived roster)"),
    ]

    vs = report.get("verification_scope") or {}
    scope_status = vs.get("status", "NORMAL")

    print("=" * 46)
    print("REPOSITORY HEALTH —", report["repo_root"])
    print("=" * 46)
    print()
    if scope_status == "DEGRADED":
        print("*** VERIFICATION SCOPE: DEGRADED ***")
        print(f"  {vs.get('note', 'One or more inputs unavailable')}")
        print(f"  Routing source: {vs.get('routing_source', 'local Routing.md')}")
        print(f"  Aliases source: {vs.get('aliases_source', report.get('aliases_source', ''))}")
        print("  Do not treat LEGACY cross-ref classification as complete.")
        print()
    else:
        print(f"Verification scope: {scope_status}")
        if vs.get("note"):
            print(f"  {vs['note']}")
        print()
    print(f"Files scanned: {report['files_scanned']}")
    print(f"Aliases source: {report['aliases_source']}")
    print(f"Routing source: {vs.get('routing_source', 'local Routing.md at repo root (not a network fetch)')}")
    print()
    print("--- Tier 1: mechanical checks (PASS/FAIL) ---")
    for cat_key, cat_label in categories:
        items = by_cat.get(cat_key, [])
        crit = sum(1 for i in items if i["severity"] == "CRITICAL")
        warn = sum(1 for i in items if i["severity"] == "WARNING")
        status = "FAIL" if crit else ("REVIEW" if warn else "PASS")
        # Reference pass is incomplete when aliases are degraded
        if cat_key == "REFERENCE" and scope_status == "DEGRADED":
            status = "DEGRADED" if status == "PASS" else f"{status}/DEGRADED"
        note = f" ({crit} critical, {warn} warning)" if (crit or warn) else ""
        print(f"  {cat_label:<38} {status}{note}")
    print()
    print("--- Tier 2: active unknowns (from Unknowns.md's own tables) ---")
    us = report["unknowns_summary"]
    print(f"  Total active (Open/In Progress/Reopened): {us['total']}")
    for bucket in ("Critical", "Blocking", "Major", "Minor", "Unlabeled"):
        if bucket in us["by_priority"]:
            print(f"    {bucket:<12} {us['by_priority'][bucket]}")
    other = {k: v for k, v in us["by_priority"].items()
             if k not in ("Critical", "Blocking", "Major", "Minor", "Unlabeled")}
    if other:
        print(f"    (other Priority-column values found: {other})")
    print()
    print("  Note: 'Blocking' here reflects this table's own Priority")
    print("  column value, not a cross-check of each owning file's")
    print("  Blocking: Yes/No sidecar field. See function docstring.")
    print()
    print("Not included: no generated \"ALPHA readiness\" or \"Governance")
    print("state\" badge. See print_health_summary() docstring for why.")
    print("=" * 46)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python integrity_check.py <repo_root> [--json output.json] [--health]")
        sys.exit(1)

    repo_root = sys.argv[1]
    report = run(repo_root)

    if "--health" in sys.argv:
        print_health_summary(report)
    else:
        print_summary(report)

    if "--json" in sys.argv:
        idx = sys.argv.index("--json")
        out_path = sys.argv[idx + 1]
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print(f"Full report written to {out_path}")
