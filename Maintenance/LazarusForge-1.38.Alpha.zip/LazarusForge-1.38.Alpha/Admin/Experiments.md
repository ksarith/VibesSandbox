# Experiments.md

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Draft                                                               |
| Body Stability   | Stub                                                                |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | `Admin/Verification_Gates.md`                                    |
| Last Audit       | 2026-11-05 — Vibe (Architect line PRIMARY, Repo Custodian secondary) — full account in the Resolution Log's 2026-11-05 entry; Prior narratives retained in the Resolution Log (R-5a one-line form, MAINT-137). |
| Auditor          | Vibe — Architect line PRIMARY (Repo Custodian secondary), 2026-11-05 — full account in the Resolution Log's 2026-11-05 entry; prior seat history retained in the Resolution Log (R-5a one-line form, MAINT-137). |
| Open Unknowns    | 0                                                                   |
| Active Disputes  | 0                                                                   |
| Highest Risk     | Low                                                                 |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

---

## Scope Boundary

**This file DOES define:**
- Structured falsification records for specific PROVISIONAL claims requiring physical grounding
- The institutional mechanism by which PROVISIONAL claims become VERIFIED in the Forge's epistemic system
- Pass/fail criteria for physical tests, sensor reads, material assays, and code execution grounding events
- Linkage between experimental outcomes and Epistemic Ledger entries in owning file sidecars
- The grounding artifact referenced when a claim is promoted from PROVISIONAL to VERIFIED

**Boundary (2026-10-06):** This file records **physical-world / external-grounding** falsification only. **Process and capability experiments** (CAP-meta-stale, AVE batches, MAQT runs, Candidate memory tests) live under `Tests/Field_Logs/` (and related Tests/ design files). Empty rows *here* do **not** mean “the Forge has run no experiments.”

**This file DOES NOT define:**
- Process/capability experiment logs (→ `Tests/Field_Logs/`)
- Operational test system specifications (→ `Tests/Living_Waters.md`, `Tests/Trophic_Forge.md`, `Tests/Solar_Descent.md`)
- System-level design validation (→ `Admin/Verification_Gates.md`)
- Unknown tracking or status management (→ `Unknowns.md`)
- Future or speculative experiments without defined method and pass/fail criteria (→ owning file sidecar resolution paths or `Admin/Trajectories.md`)
- Lab notebook or engineering journal content
- Project planning or experiment scheduling

---

## File Purpose

This file is the physical-world complement to the Epistemic Ledger defined in `Admin/Auditor_Protocols.md` §EF-0.3. Where the Ledger records state corrections after reality has spoken, this file records the structured tests that produce those corrections — the falsification events themselves.

Every entry targets a specific PROVISIONAL claim or open unknown in another file. The entry defines the hypothesis, the method, and the criteria by which the outcome constitutes grounding (VERIFIED) or falsification (new unknown or revised PROVISIONAL). When an experiment completes, its outcome feeds an Epistemic Ledger entry in the owning file's sidecar, and the EXP-ID becomes the grounding artifact for any provenance claim.

**The governing constraint from `Admin/Auditor_Protocols.md` §EF-0.8b:** A simulation confirming a simulation is not external grounding. Every entry in this file must specify a method that contacts physical reality — sensor telemetry, material assay, hardware test, or code execution against real tool returns. Internally derived modeling alone does not qualify as an experimental method here.

**Relationship to `Admin/Auditor_Protocols.md` §AP-010:** This file is the institutional coupling layer between the epistemic grounding doctrine (EF-0.8b) and the physical test infrastructure in `Tests/`. AP-010 partially resolves when entries in this file establish documented grounding paths to active test harnesses.

**Honest v0 acknowledgment:** At current maturity, **no physical-grounding experiments have been logged in this file**. It remains a governance stub for physical/sensor/assay/code-against-tool-returns records. Process/capability work (CAP, AVE, MAQT, Candidate runs) is recorded under `Tests/Field_Logs/` — see that tree before concluding “no experiments exist.” Do not treat the absence of entries *here* as evidence that all claims are grounded, nor as evidence that no Forge experiments of any kind have run.

---

## Entry Schema

Each experiment occupies one named section. Five fields required. No entry may be created without a defined Grounding Target, Hypothesis, and Pass/Fail Criteria — entries without these three fields are incomplete and must not be referenced as grounding artifacts.

```
### [EXP-ID] — Short descriptive title

| Field               | Value |
|---------------------|-------|
| Grounding Target    | (Unknown ID or PROVISIONAL claim reference — owning file and section) |
| Hypothesis          | (The specific falsifiable claim being tested) |
| Method              | (Physical test, sensor read, material assay, or code execution — must contact reality) |
| Pass/Fail Criteria  | (What outcome = VERIFIED; what outcome = falsified / new unknown) |
| Status              | (Planned / In Progress / Complete) |
| Outcome             | (VERIFIED / PROVISIONAL / UNKNOWN / Falsified — populate on completion) |
| Ledger Reference    | (EF-0.3 Epistemic Ledger entry ID in owning file sidecar — populate on completion) |
| Date Completed      | (Populate on completion) |
```

**Status values:**
- `Planned` — method and criteria defined; test not yet run
- `In Progress` — test underway; outcome pending
- `Complete` — outcome recorded; Ledger entry created

**Outcome values:**
- `VERIFIED` — claim survived falsification attempt; passes provenance ceiling to Experimentally Verified
- `PROVISIONAL` — partial grounding achieved; uncertainty bounds narrowed but full verification not reached
- `UNKNOWN` — test was inconclusive; insufficient data
- `Falsified` — claim contradicted by physical result; new unknown(s) logged; Epistemic Ledger entry mandatory

---

## Experiments

*No **physical** entries yet in this file. Process/capability Field_Logs exist under `Tests/Field_Logs/` (e.g. CAP-meta-stale-01, AVE sample 01). First entries **here** when physical testing begins on priority unknowns. Candidates: `Operations/Electronics.md` CF-001 (hardware watchdog), `Architecture/Engineering.md` EN-001 (salvaged material safety factors), `Architecture/Chemistry.md` CE-003 (field polymer identification).*

*(Candidates = priority unknown targets for future entries, not entries — they carry none of the five Entry Schema fields and do not count as logged experiments. Clarified 2026-10-28, AUDIT_28 F5, human-ratified Decision Brief 2026-10-28d.)*

---

## Assumptions

| ID      | Assumption | Basis | Confidence | Expiry Trigger |
|---------|------------|-------|------------|----------------|
| EXP-ASM-001 | Physical testing will precede any specification promotion to Operational Spec | Governance doctrine (EF-0.8b) | High | EF-0.8b amended |
| EXP-ASM-002 | Simulation results alone will not satisfy VERIFIED status for physical claims | Epistemic Anchor (EF-0.0) | High | Axiom Zero amended |
| EXP-ASM-003 | Pass/fail criteria must be defined before an experiment begins — post-hoc criteria invalidate the grounding artifact | Scientific method; Anti-Distortion Clause (EF-0.0 §2) | High | EF-0.0 amended |

---

## Drift Indicators

- Entry added without defined Grounding Target, Hypothesis, or Pass/Fail Criteria
- Outcome field populated as VERIFIED without a corresponding Epistemic Ledger entry in the owning file sidecar
- Method field describes internal modeling or simulation only — no physical contact point
- EXP-ID cited as grounding artifact for a VERIFIED claim but entry Status is still Planned or In Progress
- File begins accumulating speculative future experiments rather than completed or in-progress grounding events
- Ethical Anchor absent or altered

**Compound Drift Rule:** Multiple simultaneous indicators → halt autonomous progression, escalate for human review.

---

## Auditor Notes & Unknowns

*No sidecar unknowns at stub stage. First unknowns will emerge from experimental outcomes.*

---

## Resolution Log

- 2026-11-12: **MAINT-137 R-5a — the MAINT-56 Last Audit retirement completed for this file (one-line cells; R3 full-text move, nothing deleted or summarized).** The File State Last Audit and Auditor cell narratives moved verbatim from the cells into this log; the cells now read one line each (date + seat + Resolution Log pointer). The last audit date (2026-11-05) and seat are unchanged — bookkeeping, not a review. No header version string exists in this file; nothing to bump. The moved cell text, verbatim:

  Last Audit (former cell): 2026-11-05 — Vibe (MAINT-63 X3 straggler pass; human-ratified MAINT-62 ruling set §2): the three candidate-ID pointers in the candidates note qualified with owning-file citations — `Operations/Electronics.md` CF-001 (hardware watchdog), `Architecture/Engineering.md` EN-001 (salvaged material safety factors), `Architecture/Chemistry.md` CE-003 (field polymer identification). AUDIT_28 F5 (Category B) re-verified on the same pass: the 2026-10-28 candidates clarification is present and intact — no edit, re-verification only, separately logged. Prior: 2026-10-28 — Vibe (Repo Custodian, delegated maintenance, human-ratified Decision Brief 2026-10-28d): candidates note clarified per AUDIT_28 F5 — one explanatory line under the Experiments section; no schema, entry or boundary change. Prior: 2026-10-06 (boundary clarification — ChatGPT assessment, human-directed; see Resolution Log); header corrected 2026-10-24 (Claude, human-directed, from a Vibe per-file audit). Prior: 2026-06-21 

  Auditor (former cell): Vibe — Architect line PRIMARY (Repo Custodian secondary), 2026-11-05 MAINT-63 execution pass (non-independent Genesis Phase, Q-2 invoked, disclosed); prior:  Prior: Vibe — Repo Custodian, 2026-10-28 candidates-note clarification (delegated maintenance, human-ratified Decision Brief 2026-10-28d); prior: ChatGPT — assessment 2026-10-06 (human-directed); Claude — header correction 2026-10-24 (human-directed); prior: Claude — Synthesizer 
- 2026-11-05: **Candidate-ID pointers qualified; AUDIT_28 F5 re-verified (MAINT-63).** The candidates note now cites `Operations/Electronics.md` CF-001 (hardware watchdog), `Architecture/Engineering.md` EN-001 (salvaged material safety factors), and `Architecture/Chemistry.md` CE-003 (field polymer identification) with owning-file qualifiers. AUDIT_28 F5 (ruling set §2 Category B) was re-verified on the same pass: the 2026-10-28 candidates clarification (human-ratified Decision Brief 2026-10-28d) is present and intact — no edit made, re-verification only, separately logged in the execution record. Per the human-ratified MAINT-62 ruling set §2; executed 2026-11-05, Vibe — Architect line PRIMARY (Repo Custodian secondary), non-independent Genesis Phase, Q-2 invoked, disclosed.
- 2026-10-28: **Candidates note clarified** (Vibe, Repo Custodian — delegated maintenance, human-ratified Decision Brief 2026-10-28d; AUDIT_28 F5). One explanatory line added under the Experiments section: the three named candidates are priority unknown targets for future entries, not entries — they carry none of the five Entry Schema fields. Removes the ambiguity by which the file's own drift indicator ("File begins accumulating speculative future experiments...") could be read to fire on its own candidates note. No schema, entry, boundary or gate change; no unknown opened or closed.

- 2026-10-24: Header corrected (human-directed, from a Vibe per-file audit; checked against source first): Last Audit and Auditor now cover the 2026-10-06 boundary clarification, which changed the Scope Boundary, File Purpose and the entries note but had not advanced them. No body text, Unknown or Spec Gate changed.

- 2026-10-06: Boundary clarified — this file = physical grounding only; process/capability experiments → `Tests/Field_Logs/`. Honest acknowledgment and entries note updated so “no experiments” cannot be misread as repo-wide. ChatGPT assessment; human-directed hygiene.
- 2026-06-21: File created as Admin-layer governance stub. Schema defined. No experiments logged. Identified as partial resolution path for AP-010 (physical test harness coupling to epistemic grounding layer). Three priority candidates for first entries noted in Experiments section.
