# Governance_Migration_Protocol.md — LazarusForge

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Exploration                                                         |
| Body Stability   | Volatile                                                            |
| Spec Gates       | 0/6 — file-level maturity remains Exploration because the protocol still contains unresolved and unimplemented migration capabilities (GMP-002 ownership transfer, GMP-004 ratification authentication, etc.). Individual subsections may nevertheless be operative or Payment-via-Specification closed (notably §III.A GMP-006 state machine, §III.B GMP-012 repeal/rollback, §III.C GMP-007 withdrawal, §III.D GMP-008 expiration, §VIII Evidence-Sufficiency Gate, Fork Reconciliation Track, §VI EQD). 0/6 does **not** mean the body is merely hypothetical. |
| Verification Ref | `Admin/Verification_Gates.md`                                    |
| Last Audit       |2026-11-11 — Vibe (Repo Custodian, delegated; co-author delegation 2026-11-11, MAINT-130; non-independent, disclosed): tail restoration from git (Decision Brief 2026-11-11 Item 9a; git-verified) — the file had ended mid-word ("...second consumer of its al") since commit 7a698608 (2026-08-01; truncation window 2026-07-26 to 2026-08-01, cut point stable across every later commit). The missing tail — the end of the Status section's Version 0.7 entry, the Version 0.6, 0.5, 0.4 and 0.3 entries, and the closing "What must remain constant" footer (2,410 characters) — restored verbatim from commit 42e8b4b1 (2026-07-26, the last complete state). Post-truncation commits grew the file only above the cut point, so nothing legitimate was lost in the restored region; restored text verified escape-free; no other body text touched; version unchanged (restoration, not amendment). Prior: 2026-11-05 — Vibe (Architect line PRIMARY, Repo Custodian secondary; MAINT-63 execution pass, human-ratified MAINT-62 ruling set §2 Category A): X3 straggler pass — 20 bare colliding-prefix citations in §Assumptions and §VII qualified with their owning File.md per PKC-003 (18 × GOV-008 and 1 × GOV-006 → `Admin/Governance_Charter.md`; 1 × CIR-GOV-001 → `Admin/CIR_Gov.md`; 15 lines, three carrying multiple instances — two lines carry two instances each, one carries four), per the enumerated instance list in `Archive/Audits/EXECUTION_2026-11-05_MAINT-63.md` §1 (Kit v1.29 Governance Sidecar ID Reference; per-ID grounding from the Unknowns active index and CAMPAIGN2_AUDIT_73 N2). Citation-form-only; no content change; frozen history untouched (this log and the trailing Status block stay bare). Prior:  2026-10-29 — Vibe (Repo Custodian, delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A): X3 mechanical citation retrofit — 6 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.29 Governance Sidecar ID Reference; per-ID grounding from the Unknowns active index). Citation-form-only; no content change; frozen history untouched. Prior: 2026-10-28 (later same-day) — Vibe (Repo Custodian, delegated maintenance, human-ratified batch 2026-10-28c): Scope Boundary DOES-define list now names the Fork Reconciliation Track (AUDIT_02 F1); no gate advanced. Prior: 2026-10-28 — Vibe (Repo Custodian, delegated maintenance, human-ratified batch): VG Status-precedence line propagated (AUDIT_09 F4(a)); no gate advanced. Prior:  2026-10-26 — Claude (human-directed) PKC-016 fix: §VII.6 item 1 marked done (GMP-011 resolved 2026-09-23), mirroring the 2026-10-23 Hardware_Diversity_Ladder correction. §VII.6 is Candidate-specification text — a completed checklist item was marked complete, no requirement rewritten; items 2–4 unchanged and still open. Trailing `## Status` section still deliberately not updated (maintain-vs-retire decision pending). No ratified or FROZEN text modified. Prior: 2026-10-23 — Claude (human-directed) applied corrections from a Vibe per-file audit, each checked against source first: Resolution Log backfilled for five unlogged passes (08-31, 09-03, 09-05, 09-18, 09-23) from in-file Closure Events and markers; Scope Boundary DOES/DOES NOT lists reconciled with §III.A–§III.D; Relationship section's Unknowns.md index claim corrected. Trailing `## Status` section deliberately not updated (maintain-vs-retire decision pending). No ratified or FROZEN text modified. Prior: 2026-09-18 — §VII.2 amended (Candidate specification, unratified): role rotation across quorum cycles added as permitted-not-required, with expected limitations stated explicitly (does not satisfy Diversity/Independence tests by itself, does not touch Hardware/Runtime Diversity, rotation-assignment authority left open) rather than presented as a solved mechanism; corresponding open item added to §VII.6. No change to VII.1/VII.3–VII.5's requirements, this section's Status, or GOV-008. Human-directed, following a ChatGPT multi-agent-readiness assessment verified accurate against this section before extending it. Prior: 2026-09-03 — Grok surgical integrity repair after ChatGPT REVISE/G6-BLOCKED audit (GMP-AUD-001–007): FROZEN markers added; File State normalized with explicit subsection-vs-file maturity clarification; Last Audit collapsed to clean record (prior multi-month narrative retained in Resolution Log / sidecar); explicit Charter-precedence rule added pending GMP-002; subsection status markers for §VI/VII/VIII. No migration architecture redesigned. Prior full history in Resolution Log. Same day, following a Grok verification audit: Claude corrected GMP-002's own Description, which had wrongly claimed the Charter's ownership table already listed this file as owner — the live Charter table still names itself as owner (confirmed by direct check), contradicting this file's own accurate Scope Boundary text on the same point. Revised 2026-09-05, three passes: §III.B Repeal/Rollback (GMP-012), §III.C Withdrawal (GMP-007), and §III.D Expiration (GMP-008) — all three drafted by Grok, each independently Skeptic-reviewed by Claude against live §III.A source (III.A.4's Withdraw/Expire authority rows, III.A.6's human-attention design note, and GMP-008's own original three-audit-cycle default all confirmed accurate, no invented authority, no blocking findings), and each Ratified by Human Governing Authority same day. The GMP-006/007/008 amendment-lifecycle cluster is now fully closed. |
| Auditor          |Vibe — Architect line PRIMARY, 2026-11-05 MAINT-63 X3 straggler citation pass (Repo Custodian secondary; human-ratified MAINT-62 ruling set §2); prior:  Vibe — Repo Custodian, 2026-10-29 X3 mechanical citation retrofit (delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A); prior: Vibe — Repo Custodian, 2026-10-28 wrapper-hygiene pass (AUDIT_02 F1; delegated maintenance, human-ratified batch 2026-10-28c); prior: Vibe — Repo Custodian, 2026-10-28 precedence-line propagation (delegated maintenance); prior:  Claude — 2026-10-26 PKC-016 fix (human-directed, from the Parked Concerns triage); Claude — 2026-10-23 corrections (human-directed, from a Vibe per-file audit); Grok (drafter) + Claude (source verifier) — 2026-09-23 GMP-011; human-directed — 2026-09-18 §VII.2; Grok — 2026-09-03 integrity repair; Grok — 2026-09-05 §III.B/§III.C/§III.D drafts (GMP-012/007/008); Claude — 2026-09-05 Skeptic passes + merge integrity checks (all three). Prior Closure Events and multi-agent history retained in Resolution Log and Archive. |
| Open Unknowns    | 4 (GMP-002, GMP-003, GMP-004, GMP-013). GMP-011 Resolved (Payment via Specification, ratified 2026-09-23). GMP-012, GMP-007, and GMP-008 all Ratified 2026-09-05. |
| Active Disputes  | 0                                                                   |
| Highest Risk     | High                                                                |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

## Scope Boundary

**This file DOES define:**
- Standard migration procedures for Tier 2–5 governance documents
- Tier 1 Axiom amendment process — proposal, review, ratification, and recording
- Engineer role in amendment proposal assembly
- Evidence standard required before a Tier 1 amendment enters formal review
- Human ratification requirements and what distinguishes genuine ratification
  from rubber-stamping
- Hard floor — constraints outside amendment scope entirely
- Proposed ownership transfer declaration: governance migration doctrine
  is proposed to transfer from `Admin/Governance_Charter.md` to this file,
  pending Charter update and Gate 4 clearance
- Compatibility status declaration requirements for all migrations
- Amendment recording requirements (Resolution Log preservation of prior text)
- Track B classification scope: text changes AND enforcement-bound
  reinterpretations of Tier 1 Axioms via lower-tier documents
- Track B amendment lifecycle and concurrent amendment handling — §III.A
  state machine (GMP-006, Resolved 2026-08-31)
- Repeal and rollback of recorded Track B amendments — §III.B (GMP-012,
  Ratified 2026-09-05)
- Withdrawal of pre-Recorded Track B proposals — §III.C (GMP-007, Ratified
  2026-09-05)
- Expiration of stalled pre-Recorded Track B proposals — §III.D (GMP-008,
  Ratified 2026-09-05; stall window provisional)
- Fork Reconciliation Track — multi-lineage reconciliation when two or more
  lineages claim constitutional continuity (GOV-018; operative procedure
  skeleton in the ## Fork Reconciliation Track section)

**This file DOES NOT define:**
- The Tier 1 Axioms themselves (→ `Admin/Governance_Charter.md`)
- Constitutional governance hierarchy (→ `Admin/Governance_Charter.md`)
- Cryptographic authentication of ratification events
  (→ `Admin/Security_Protocols.md` — GOV-006 resolution path)
- Minimum agent quorum definition (→ GOV-008 — `Admin/Governance_Charter.md`)
- Repository integrity enforcement mechanics
  (→ `Admin/Repository_Integrity_Protocol.md`)
- Auditor operational behavior during migration review
  (→ `Admin/Auditor_Protocols.md`)

---

## File Purpose

This file operationalizes the Governance Migration Doctrine declared in
`Admin/Governance_Charter.md`. The Charter defines what governance migration
must preserve and what Tier 1 amendment constraints apply — this file defines
how those requirements are executed in practice.

Without this file, GOV-001 remains open and Tier 1 Axiom amendment has no
formal procedure. The gap is not academic: a system with constitutional
constraints but no amendment process is either permanently frozen (which
violates Axiom Q-3 — Corrigibility) or subject to informal amendment that
bypasses all safeguards (which enables Constitutional Capture). This file
closes that gap by making amendment possible through a defined, auditable,
human-ratified process — while making Constitutional Capture structurally
harder.

**Proposed ownership transfer:** The Charter currently lists governance
migration doctrine as "Active — `Admin/Governance_Charter.md`" in the
Canonical Governance Ownership table. This file is proposed to assume
that ownership. The transfer is not yet complete — the Charter's table
must be updated, and this file must reach Gate 4 clearance (Provisional
Specification maturity or above) before the transfer is formally operative.
Until that occurs, ownership remains provisionally vested in the Charter
as the higher-tier authority. The Charter's Governance Migration Doctrine
section remains the source of constraints; this file is the executing
candidate procedure. See GMP-002.

**Explicit precedence rule (pending GMP-002 closure):** Until Gate 4 clearance and the Charter ownership-table amendment occur, any conflict between this file and `Admin/Governance_Charter.md` is resolved in favor of the Charter. This rule is machine-checkable and overrides any procedural detail in this file that would otherwise diverge.

**Honest v0 acknowledgment:** At v0 with a single human contributor and
no multi-agent quorum, the Tier 1 amendment process is largely theoretical.
Its value now is structural: defining the process before it is needed
prevents the process from being shaped by the pressures of a specific
amendment in progress. The procedure is intended to exist before the
argument arises.

---

## Assumptions

| ID      | Assumption | Basis | Confidence | Expiry Trigger |
|---------|------------|-------|------------|----------------|
| ASM-001 | The human operator is the sole ratification authority at v0 | Single-contributor bootstrap context | High | Additional human contributors confirmed |
| ASM-002 | No Tier 1 amendment will be needed before multi-agent quorum is established | v0 operational scope is narrow | Medium [Estimated / Internally Derived] — partial epistemic quorum now specified via §VI EQD (2026-07-26); `Admin/Governance_Charter.md` GOV-008's full governance quorum remains unestablished, confidence unchanged on that half | Operational friction surfaces axiom inadequacy before quorum |
| ASM-003 | Engineer role is defined and operational per `Admin/Engineer_Protocols.md` | File exists and is active | High | Engineer_Protocols.md scope boundary revised |
| ASM-004 | `Admin/Security_Protocols.md` will eventually provide cryptographic ratification authentication | `Admin/Governance_Charter.md` GOV-006 resolution path | Medium [Estimated / Internally Derived] | Security_Protocols.md descoped or deferred beyond v1 |
| ASM-005 | Lower-tier governance migrations are significantly more frequent than Tier 1 amendments | Expected operational pattern | High | Tier 1 amendment is triggered early in repo lifecycle |

---

## I. Two Migration Tracks
<!-- FROZEN: 2026-09-03 — Constitutional-impact classification rule and Track A/B distinction. Do not relocate or weaken classification criteria without formal amendment. -->

All governance migration in LazarusForge falls into one of two tracks.
The tracks are not interchangeable. Applying the wrong track to a migration
is a governance error.

### Track A — Non-Constitutional Governance Changes

For any change that does not alter Tier 1 Axiom text, Tier 1 enforcement
bounds, Tier 1 interpretation, or introduce a new Tier 1 exception —
regardless of which file the change lives in. This includes the large
majority of governance evolution: operational protocols, audit
procedures, domain specifications, condensed references, supporting
governance files, and non-Axiom content within `Admin/Governance_Charter.md`
itself (housekeeping, historical notes, doctrine sections that don't
touch the eight Axioms, canonical ownership tables, resolution logs).

Track A is the expected operational path. The process is lighter than
Track B by design — governance complexity must remain proportional to
constitutional effect, not to which file happens to hold the text.

### Track B — Constitutional Changes

For any change that alters Axiom wording, Axiom meaning, Tier 1
enforcement bounds, introduces a new constitutional exception, or
reinterprets constitutional authority — regardless of which file the
change lives in. Includes, but is not limited to, direct amendment of
the eight Tier 1 Axioms (P-1 through P-4, Q-1 through Q-4) in
`Admin/Governance_Charter.md`.

Track B carries substantially higher process requirements than Track A.
The difference is not bureaucratic — it reflects the difference between
adjusting a procedure and changing a foundational constraint that all
other governance derives from.

**Track identification rule — Constitutional Impact Statement, required
for every proposed migration, Track A or B:**

- [ ] Alters Tier 1 Axiom text
- [ ] Alters Tier 1 enforcement bounds
- [ ] Alters Tier 1 interpretation
- [ ] Introduces a new constitutional exception
- [ ] None of the above

If every box is unchecked except "None of the above": Track A. If any of
the first four boxes is checked: Track B, regardless of which file the
change is written in or how minor the change looks. **When in doubt,
treat as Track B.** Misclassifying a Track B migration as Track A is a
Constitutional violation — this holds for the impact-based test exactly
as it held for the old text-only test; the standard didn't loosen when
the classification axis changed from location to impact.

**Adding a new obligation is not automatically a constitutional
exception.** A change that adds scrutiny, monitoring, or accountability
on top of an existing constitutional provision — without loosening,
replacing, or reinterpreting that provision — checks "None of the above"
and is Track A. A change framed as *replacing* or *superseding* an
existing enforcement mechanism is Track B even if it appears to tighten
things, because it alters an enforcement bound. Worked example: GOV-013
(`Admin/Governance_Charter.md`) adds a monitoring obligation on top of
Pathway 2/3's existing exception without changing what Axiom Q-2 itself
requires — Track A. A hypothetical change removing Pathway 1's quorum
requirement in exchange for the same monitoring obligation would be
Track B — it alters an enforcement bound, even though the intent reads
as comparably protective.

Track A authority is subordinate to Charter constraints regardless of
which file it operates on. Every Track A migration must complete the
Constitutional Impact Statement above and file it with the change
record — this replaces the prior narrower requirement to confirm "no
enforcement bounds of a Tier 1 Axiom are altered" for Tier 2 documents
only; the confirmation is now required uniformly, not just downward.

---

## II. Track A — Standard Migration Procedure

### Trigger

Track A migration is triggered when:
- An existing Tier 2–5 governance document requires substantive revision
- A new governance document is created that affects existing ownership boundaries
- A canonical ownership transfer is declared

Routine content updates within a file's existing scope are not migrations —
they are normal audit cycle revisions. Migration applies when scope,
ownership, or authority relationships change.

### Procedure

**Step 1 — Prior State Preservation**
Save the current version per `Admin/Repository_Integrity_Protocol.md`
Version Preservation Protocol before any revision begins. This is a
required integrity baseline for the migration, not optional.

**Step 2 — Compatibility Declaration**
At the start of the revision, declare one of:
- *Compatible* — existing downstream references remain valid without change
- *Partially compatible* — named downstream references require update;
  list them explicitly
- *Incompatible* — migration breaks existing downstream dependencies;
  all dependents must be reviewed before migration is committed

Incompatible migrations require a cross-module review pass before the
revised file is committed to the repository.

**Step 3 — Semantic Change Documentation**
Any change to defined terms, scope boundaries, or authority relationships
must be documented in the Resolution Log with: date, what changed, why,
and what the prior state was.

**Step 4 — Lineage Preservation**
Prior scope boundaries and authority relationships must be
preserved in the Resolution Log. They are not deleted — they are dated
and superseded.

**Step 5 — Downstream Notification**
Files identified in Step 2 as requiring update must have their next audit
pass triggered. This is tracked as a pending correction in `Discovery.md`
until resolved.

### Authority

Track A migrations may be executed by an engineer contributor with auditor
review. No human ratification is required unless the migration affects
a Tier 1 or Tier 2 document, in which case a human operator review is
strongly recommended before commit.

---

## III. Track B — Tier 1 Axiom Amendment Procedure

### Governing Constraints from the Charter

The following constraints are declared in `Admin/Governance_Charter.md`
Governance Migration Doctrine and are reproduced here for operational
reference. They are not redefined — they are inherited:

- Human ratification is mandatory
- No autonomous agent or coalition may initiate axiom amendment
- Amendment rationale must demonstrate the change strengthens rather
  than narrows protection
- Prior axiom text must be preserved in the Resolution Log with
  amendment date and rationale

This file adds the procedural implementation of those constraints.

### Phase 1 — Engineer Proposal Assembly

The engineer role initiates and assembles the amendment case. This is
the appropriate role because engineers encounter the operational friction
that reveals when an axiom is inadequate — they are closest to the
evidence and hold the "build and refine" mandate.

The engineer role does not ratify. The engineer presents; the human decides.
This separation is structural, not advisory.

**What the engineer must assemble:**

**1. Friction Log**
Documented evidence of operational friction caused by the current axiom
text. A single audit finding is not sufficient. The minimum evidence bar is:
- At least two independent observations across separate audit cycles, OR
- One observation with direct operational consequence (not theoretical),
  documented in a Lessons Learned entry

Theoretical arguments for amendment, however logically compelling, do not
satisfy the evidence bar. The bar exists precisely because compelling
arguments are the primary mechanism of Constitutional Capture.

**2. Amendment Text**
The proposed new axiom text, with tracked changes showing exactly what
is added, removed, or modified. Vague amendments ("strengthen the axiom")
are not valid proposals — the specific wording must be proposed.

**3. Strengthening Justification**
A written justification demonstrating that the amendment strengthens
rather than narrows protection. This is not a neutral requirement — the
burden is affirmative. If the engineer cannot demonstrate strengthening,
the amendment does not advance.

Specifically address:
- What protection the current text provides
- What gap or inadequacy the friction log documents
- How the proposed text closes that gap without reducing other protections
- Whether any Prohibition axiom (Q-series) is affected by the change

**4. Failure Mode Analysis**
How could the proposed amendment be misused? Specifically: could the
amended text be cited to justify an action the current text prohibits?
If yes, the amendment requires redesign before advancing.

This is the Constitutional Capture check. An amendment that opens a
new path to prohibited actions is not a strengthening — it is an erosion
dressed as improvement.

**5. Cross-Reference Map**
Which downstream files reference or depend on the axiom being amended?
All dependents must be identified before ratification. The amendment is
not complete until all dependents are updated or flagged for update.

### Phase 2 — Adversarial Review

Before human ratification, the proposal must pass adversarial review
by at least one auditor who did not participate in Phase 1 assembly.

The adversarial reviewer's mandate is specifically to:
- Attempt to find a path from the amended text to a prohibited action
- Challenge the strengthening justification
- Identify any interpretation of the new text that narrows rather than
  strengthens protection
- Apply the Constitutional Capture failure mode explicitly

The adversarial reviewer is not trying to improve the proposal — they
are trying to break it. If they cannot, the proposal is stronger for it.
If they can, Phase 1 must be revised before advancing.

**At v0:** With a single human contributor, adversarial review may be
conducted by a different AI agent class than assembled the proposal,
or by the human operator themselves using the adversarial reviewer
mandate explicitly. The review must be documented — it cannot be implicit.
See GMP-003 for the known weakness of this bootstrap arrangement.
**Subject to §VI Epistemic Quorum Doctrine** — Track B adversarial
review must satisfy EQD's quorum minimum and independence dimensions,
not merely "a different agent class," to count as compliant.

### Phase 3 — Human Ratification

Human ratification is the constitutional requirement. It is not a
formality following Phase 2 — it is the decision.

**What ratification requires:**

The human ratifying party must:
1. Read the Friction Log and confirm the operational need is genuine
2. Read the proposed amendment text and the current text side by side
3. Read the Strengthening Justification and independently assess it
4. Read the adversarial review findings and the Phase 1 response
5. Make an explicit, documented decision: ratify, reject, or return
   to Phase 1 with specific concerns

**What ratification is not:**

Ratification is not approval of an AI-assembled argument. The human
is not evaluating whether the argument is logically sound — they are
exercising independent judgment about whether the amendment is right.
A human who ratifies because the argument is compelling without forming
an independent view has not ratified — they have delegated a
constitutional decision to an AI. That is a Constitutional violation
regardless of the amendment's merits.

**Ratification record:**
The ratifying human must produce a dated written record stating:
- The amendment being ratified (specific axiom, specific text change)
- That they reviewed Phase 1 and Phase 2 materials
- Their independent assessment (not just "I agree with the argument")
- The date of ratification

**Authentication gap:** Until `Admin/Security_Protocols.md` reaches
Provisional Specification status, ratification records must satisfy
the interim authentication requirement in the Charter's Human Override
Doctrine: independent confirmation from a second human, external
cryptographic signature, or dated physical/digital record outside the
repository system. See GMP-004. This is a declarative-only requirement
at current maturity — no automated enforcement exists.

### Phase 4 — Recording

After ratification, the amendment is recorded and committed.

**Required records:**

1. Prior axiom text preserved verbatim in the Resolution Log of
   `Admin/Governance_Charter.md` with amendment date and rationale summary

2. New axiom text committed to `Admin/Governance_Charter.md` with a
   Resolution Log entry citing the ratification record

3. This file's Resolution Log updated with amendment summary and
   cross-reference to the ratification record

4. All downstream files identified in the Cross-Reference Map updated
   or flagged as pending update in `Discovery.md`

5. `Unknowns.md` updated if the amendment resolves or affects any
   open cross-module unknowns

## III.A Track B Amendment Lifecycle — State Machine
<!-- FROZEN: 2026-09-03 — GMP-006 state machine (Payment via Specification, human-ratified 2026-08-31). Residual on GMP-004 authentication. Do not edit without formal amendment. -->

**Status:** Operative doctrine (Payment via Specification for GMP-006, ratified 2026-08-31).
**Closure target:** Serialization of concurrent Track B proposals.
**Non-goal:** Does not fully specify expiration (GMP-008) or supersession
among *unrecorded* proposals; those remain sibling residuals or deferred
work. Withdrawal of **pre-Recorded** proposals is specified in §III.C
(GMP-007, Ratified). Repeal of **Recorded** amendments is specified in
§III.B (GMP-012, Ratified). Does not grant adversarial reviewers new
terminal or advancement authority beyond what §III already states.

### III.A.1 Core invariant — Serialization corridor

1. Multiple Track B proposals may exist in **Draft** or **Phase 1**.
2. At most one Track B proposal may occupy **Phase 2 or Phase 3**.
3. A proposal may **not** enter Phase 2 while another occupies Phase 2
   or Phase 3.
4. Serialization prevents concurrent Track B proposals from bypassing
   interaction review. Each subsequent proposal remains subject to the
   existing Phase 1 cross-reference map and failure-mode analysis,
   **including consideration of already-Recorded amendments**.
   Serialization does **not** eliminate sequential interaction effects
   after ratification.
5. A proposal that requires substantive combination with another must be
   consolidated into a **new** package before Phase 2, or handled through
   explicit supersession doctrine (not fully specified here).

**Serialization gate:** No transition into Phase 2 is legal unless the
Phase 2/3 corridor is unoccupied. The serialization corridor is a
repository-wide invariant for Track B proposals, not merely a property
of a single proposal's own state record.

**Corridor occupied — Phase 1 complete:**
If the serialization corridor is occupied when a Phase 1 package becomes
complete, the proposal **remains in Phase 1**. Completion does not create
an automatic transition, reservation, priority claim, queue position, or
expiration event. The proposal may enter Phase 2 only when the
serialization gate is subsequently clear **and** the ordinary Phase 1 →
Phase 2 requirements remain satisfied (complete package, reviewer
assigned).

### III.A.2 States

| State | Meaning | Terminal? |
|-------|---------|-----------|
| Draft | Informal work product; not yet a formal Track B proposal | No |
| Phase 1 | Formal assembly per §III Phase 1 | No |
| Phase 2 | Adversarial review per §III Phase 2 in progress | No |
| Phase 3 | Before Human Governing Authority for ratification (§III Phase 3) | No |
| Recorded | Human-ratified and Phase 4 recording requirements complete | Yes |
| Returned | Sent back for rework | No |
| Rejected | Terminal negative decision | Yes |
| Withdrawn | Terminated before Recorded (detail → §III.C / GMP-007, Ratified) | Yes |
| Expired | Stalled past policy limit (detail → §III.D / GMP-008, Ratified) | Yes |
| Superseded | Replaced by a later proposal (full doctrine deferred) | Yes |

This machine sits **on top of** existing §III Phase 1–4 requirements; it
does not replace them. **Corridor release:** Phase 4 recording does not
itself occupy the Phase 2/3 serialization corridor; however, a proposal
remains unavailable for concurrent Track B processing until its
transition to Recorded is complete — the corridor is released upon
Recorded, not upon Human ratification alone.

### III.A.3 Transitions

```
Draft ──assembly complete──► Phase 1
Draft ──withdraw──► Withdrawn
Draft ──expire──► Expired

Phase 1 ──package complete
        + reviewer assigned
        + serialization gate clear──► Phase 2
Phase 1 ──(gate occupied)──► remains Phase 1
Phase 1 ──withdraw──► Withdrawn
Phase 1 ──expire──► Expired

Phase 2 ──review complete without blocking return;
        package presented to Human Authority──► Phase 3
Phase 2 ──Return for rework──► Returned
Phase 2 ──recommend rejection
        (out-of-scope / hard-floor)──► (see Rejection authority)
Phase 2 ──withdraw──► Withdrawn
Phase 2 ──expire──► Expired

Phase 3 ──Human ratify + Phase 4 records complete──► Recorded
Phase 3 ──Human return──► Returned
Phase 3 ──Human reject──► Rejected
Phase 3 ──withdraw──► Withdrawn   [Human Authority only]

Returned ──rework complete──► Phase 1
Returned ──withdraw──► Withdrawn
Returned ──expire──► Expired
```

**Phase 2 → Phase 3 (authority inherited from §III, not newly granted):**
Adversarial review is a **precondition** for human ratification (§III:
"Before human ratification, the proposal must pass adversarial review").
The reviewer does **not** advance the proposal into Phase 3. When review
completes without a blocking return, the engineer/assembler **presents**
the package to the Human Governing Authority; Phase 3 begins when that
presentation is made under §III Phase 3. The reviewer's successful
review makes the proposal *eligible* for Phase 3; it does not execute
the transition.

**Forbidden (examples):**
Phase 2/3 → Draft; Recorded → any other state (further change is a new
proposal); terminal → Phase 2/3 without restart; any agent-only path
into Recorded; Phase 1 → Phase 2 while corridor occupied.

### III.A.4 Authority

| Action | Authority |
|--------|-----------|
| Draft → Phase 1 | Engineer / assembler |
| Phase 1 → Phase 2 | Engineer + assigned reviewer, **and** serialization gate clear |
| Phase 2 review outcome | Adversarial reviewer per §III mandate (attempt to break; return for rework; or complete review without blocking return) |
| Phase 2 → Phase 3 | **Not a reviewer power.** Eligibility after non-blocking review complete; transition occurs when the package is presented to Human Governing Authority under §III Phase 3 |
| Final Rejected | Human Governing Authority (reviewer may recommend rejection under existing hard-floor/scope rules; this section grants no new terminal rejection power) |
| Phase 3 → Recorded / Returned / Rejected | **Human Governing Authority only** (Recorded also requires §III Phase 4 records) |
| Withdraw before Phase 3 | Proposer (own proposal) or Human Authority |
| Withdraw in Phase 3 | **Human Authority only** |
| Expire | §III.D / GMP-008 (Ratified, provisional window) or Human Authority |
| Supersede | Not fully specified. Naming an earlier proposal as intended-superseded is allowed when filing; **final** supersession of a proposal in Phase 2/3 requires the authority that controls that stage. Unilateral engineer supersession of another's Phase 2/3 proposal is forbidden. |

### III.A.5 History — append-only

State transitions are append-only. Prior states, reviews, rationales, and
proposal identifiers are not erased. Withdrawn, Expired, Rejected, and
Superseded proposals remain in the audit trail.

### III.A.6 Deadlock / starvation (design note)

A proposal may remain in Phase 3 pending Human Authority action while
other proposals accumulate in Phase 1. That is **not** a state-machine
deadlock: the corridor is occupied by design until Human Authority
disposes of the Phase 3 item (ratify → Recorded, return, reject, or
withdraw). Starvation of Phase 1 proposals is a **human-attention**
matter, not resolved by automatic preemption or expiration in this
section. No existing governance doctrine imposes a time-bound obligation
on Human Authority's ratification decisions as of this writing (checked
against `Admin/Governance_Charter.md` and this file directly) — if such
an obligation is adopted later, it must be reconciled with this design
note explicitly rather than silently overriding it. GMP-008 may later
address stalled Phase 1/2 proposals; it should not silently expire a
Phase 3 item awaiting human ratification without explicit Human
Authority policy.

### III.A.7 Explicit non-claims and residuals

| Item | Disposition |
|------|-------------|
| Full withdrawal procedure | §III.C / GMP-007 (Ratified, 2026-09-05) |
| Expiration policy | §III.D / GMP-008 (Ratified, 2026-09-05; numeric window provisional) |
| Complete supersession doctrine among unrecorded proposals | Deferred |
| Repeal/rollback of **Recorded** amendments | §III.B / GMP-012 (Ratified, 2026-09-05) |
| New reviewer terminal or Phase-3-advancement power | **Not granted** |
| Elimination of sequential post-ratification interaction risk | Not claimed |
| Live Track B operational exercise | Residual after paper closure |
| Automatic priority/queue among waiting Phase 1 proposals | Not created |

Hard floors in §III remain outside amendment scope unchanged.

*Drafted by Grok as a Closure Proposal (Revision 1 addressed Claude's
live-§III verification findings: Phase 2→Phase 3 authority overreach
corrected, two stale cross-references flagged for concurrent edit.
Revision 2 addressed ChatGPT's remaining Skeptic items: the Phase 4
corridor-release sentence added, the "repository-wide invariant" framing
added, and three items — existing time-bound ratification obligations,
other stale concurrency-permissive language, the overlapping-proposal
scenario — independently checked against live source by Claude and
confirmed clean or already correctly handled by the existing invariants).
Human-ratified 2026-08-31.*

### Hard Floor — Outside Amendment Scope

The following constraints may not be amended through Track B or any
other process. These are extra-constitutional constraints — they sit
outside the amendment scope by explicit prior decision, not by
constitutional prohibition on amendment itself:

**Anti-Weaponization Doctrine** — defined in `Admin/Ethical_Constraints.md`.
This is a co-Tier 1 constraint that does not derive from the Axioms —
it sits alongside them. It is not subject to the amendment process
defined here. Any proposal that would weaken, narrow, or create
exceptions to the Anti-Weaponization Doctrine is outside scope regardless
of how it is framed.

**The Ethical Anchor field canonical string** — "Attempt to do no harm.
Defer to Ethical_Constraints.md if present." This string is fixed in
every repository file per `Admin/File_Template.md`. It is not a
governance document — it is the floor that survives document loss.
It is not amendable through governance migration.

**Axiom P-1 humanitarian override exception** — permanently abandoned
per `Admin/Governance_Charter.md` Abandoned Paths (2026-05-23). The
humanitarian override entry point is the historical attack vector on
ethical constraints in autonomous systems. It remains closed regardless
of argument quality. This is not subject to amendment.

---

## III.B Repeal and Rollback of Recorded Track B Amendments
<!-- STATUS: RATIFIED 2026-09-05 — Payment via Specification for GMP-012, Human Governing Authority ratification recorded. -->
<!-- FROZEN: 2026-09-05 — do not weaken the no-emergency-shortcut rule or the Track B parity requirement without formal amendment. -->

> **RATIFIED 2026-09-05.** Human Governing Authority ratification is recorded in this section’s own Closure Event (§III.B.7) and in GMP-012’s sidecar entry below. This section is binding Track B procedure for repeal/rollback of Recorded amendments.

**Status:** Ratified (closes GMP-012).  
**Closure target:** Define the only lawful path for undoing or replacing a **Recorded** Track B amendment.  
**Non-goals:** Does not create an emergency-repeal track. Does not authorize silent restoration of prior text. Does not alter Hard Floor items (they remain outside amendment scope entirely). Does not fully specify supersession among *unrecorded* proposals (still deferred per §III.A.7).

### III.B.1 Core rule — Repeal is Track B

1. A **Recorded** Track B amendment is terminal under §III.A.2. The state machine forbids `Recorded → any other state`. Further change is always a **new** proposal.
2. Any action that would **repeal**, **roll back**, **restore pre-amendment text**, or **replace** the operative effect of a Recorded Track B amendment **is itself a Track B amendment**.
3. That new proposal follows the ordinary §III Phase 1–4 procedure and the §III.A lifecycle (serialization corridor, EQD where applicable, Human Governing Authority ratification, Phase 4 recording).
4. There is **no** emergency, expedited, or single-authority shortcut for repeal. An emergency-repeal path would recreate, at smaller scale, the capture risk Track B exists to prevent.

### III.B.2 Restoration vs replacement (Phase 1 judgment)

When assembling a repeal/rollback package, Phase 1 must choose and document one of:

| Mode | Meaning | Recording requirement |
|------|---------|------------------------|
| **Restore** | Re-instate the exact pre-amendment text from the append-only archive / Resolution Log snapshot taken at the original Phase 4 recording | Cite the original proposal ID, ratification record, and archived text hash or verbatim archive pointer |
| **Replace** | Enact new text that is not identical to the pre-amendment state | Full Phase 1 package as for any other Track B change; must still name the Recorded amendment being displaced |
| **Partial repeal** | Narrow or strike only specified operative effects while leaving other effects of the same Recorded amendment in force | Explicit effect map: what remains, what is struck, downstream files affected |

**Intervening Recorded amendments constraint (Restore):** A Restore operation restores the target amendment’s pre-amendment state **only to the extent** that doing so does not silently erase, invalidate, or bypass **later** Recorded amendments that affect the same constitutional surface. Where intervening Recorded amendments exist (e.g. A → B → C, and the package targets B), Phase 1 must explicitly account for their interaction and must use **Partial repeal** or **Replace** rather than bare Restore whenever a pure pre-B text reinstatement would wipe or contradict still-Recorded effects of C (or any later Recorded amendment). Restore is never a license to collapse the post-target Recorded chain.

Phase 1 does **not** pre-commit the repository to always prefer Restore. Choice of mode is a documented judgment under the same evidence and failure-mode duties as any Track B Phase 1 package. Improvisation under pressure without a Phase 1 package is forbidden.

### III.B.3 Interaction with Hard Floor and serialization

- A repeal/rollback proposal that would weaken, narrow, or create exceptions to Hard Floor constraints (§III Hard Floor) is **out of scope** and must be Rejected on that basis — same as any other Track B proposal.
- A repeal/rollback proposal occupies the Phase 2/3 serialization corridor like any other Track B proposal. It does not jump the queue.
- Sequential interaction risk after prior Recorded amendments remains real (§III.A.1 point 4). Phase 1 for a repeal package must map interactions with **other** still-Recorded amendments, not only with the single target.

### III.B.4 History — append-only (no silent undo)

1. The original Recorded amendment’s ratification record, prior text, reviews, and proposal identifier **remain** in the audit trail.
2. Repeal does not delete, rewrite, or “un-record” history. Phase 4 for the repeal proposal records the new operative state and points at the displaced Recorded entry.
3. Downstream files updated under the original amendment’s compatibility class must be listed again in the repeal package’s compatibility declaration (§IV).

### III.B.5 Authority

| Action | Authority |
|--------|-----------|
| Propose repeal/rollback package | Engineer / assembler (same as any Track B Draft → Phase 1) |
| Advance through Phase 2/3 | Same authority matrix as §III.A.4 |
| Ratify repeal | **Human Governing Authority only** |
| “Emergency” or agent-only repeal | **Forbidden** |

### III.B.6 Explicit non-claims and residuals

| Item | Disposition |
|------|-------------|
| Emergency or wartime repeal shortcut | **Not created** — rejected by design |
| Automatic rollback on audit failure | **Not created** |
| Full supersession doctrine among unrecorded proposals | Still deferred (§III.A.7) |
| GMP-007 withdrawal (pre-Recorded only) | §III.C (Ratified); withdrawal cannot apply to Recorded |
| GMP-008 expiration of stalled pre-Recorded proposals | Separate unknown |
| Live operational exercise of a real repeal | Residual after paper closure |

### III.B.7 Closure statement (GMP-012)

*§III.B — Payment via Specification for GMP-012 (surfaced 2026-07-25). Minimum candidate in the original Resolution Path adopted and expanded: repeal is Track B; no separate emergency track; Restore vs Replace is Phase 1 judgment. Aligns with §III.A invariant that Recorded is terminal and further change is a new proposal. Drafted by Grok, 2026-09-05; Claude ran an independent Skeptic pass same day, verifying every §III.A cross-reference (III.A.1 point 4, III.A.2 terminal-state table, III.A.4, III.A.7) and the Hard Floor claim directly against source — all confirmed accurate, no blocking findings. Human Governing Authority ratified 2026-09-05.*

---

## III.C Withdrawal of Pre-Recorded Track B Proposals
<!-- STATUS: RATIFIED 2026-09-05 — Payment via Specification for GMP-007, Human Governing Authority ratification recorded. -->
<!-- FROZEN: 2026-09-05 — do not weaken the Phase-3 Human-only rule, the no-partial-resumption rule, or the Recorded-boundary without formal amendment. -->

> **RATIFIED 2026-09-05.** Human Governing Authority ratification is recorded in this section’s own Closure Event (§III.C.7) and in GMP-007’s sidecar entry below. This section is binding Track B procedure for withdrawal of pre-Recorded proposals.

**Status:** Ratified (closes GMP-007).  
**Closure target:** Define the only lawful path for terminating a Track B proposal **before** it reaches **Recorded**.  
**Non-goals:** Does not apply to **Recorded** amendments (those use §III.B repeal). Does not define expiration of stalled proposals (GMP-008). Does not grant reviewers terminal withdrawal power. Does not create automatic withdrawal on audit failure.

### III.C.1 Core rule — Withdrawal is terminal and pre-Recorded only

1. **Withdrawn** is a terminal state under §III.A.2. A proposal that has transitioned to Withdrawn is closed for lifecycle purposes.
2. Withdrawal applies **only** to proposals that have **not** reached **Recorded**. Once Recorded, the lawful path is §III.B (repeal/rollback as a new Track B proposal) — not withdrawal.
3. Withdrawal is **not** rejection, return, expiration, or supersession. Those remain distinct §III.A outcomes.
4. There is **no** silent abandonment. A proposal that stops advancing without a recorded withdrawal (or other terminal transition) remains in its last non-terminal state until disposition.

### III.C.2 Who may withdraw (authority matrix)

| Current state | Who may withdraw | Notes |
|---------------|------------------|--------|
| Draft | Proposer (own proposal) or Human Governing Authority | Informal work product; still requires logged rationale if the item was already tracked |
| Phase 1 | Proposer (own proposal) or Human Governing Authority | |
| Phase 2 | Proposer (own proposal) or Human Governing Authority | Corridor-release rules apply (§III.C.4) |
| Phase 3 | **Human Governing Authority only** | Proposer may **request** withdrawal; may not execute it |
| Returned | Proposer (own proposal) or Human Governing Authority | Same as Phase 1 after rework path |
| Recorded | **Forbidden** | Use §III.B |
| Already terminal (Withdrawn / Expired / Rejected / Superseded) | **N/A** | No second terminal transition |

Adversarial reviewers may **recommend** withdrawal or rejection; they do **not** execute withdrawal. This preserves the §III.A.4 rule that reviewers lack terminal power.

### III.C.3 Required record (no silent withdraw)

Every withdrawal **must** record, in append-only form:

1. Proposal identifier  
2. State at time of withdrawal  
3. Authority that executed the withdrawal (proposer vs Human Governing Authority)  
4. Rationale (non-empty; may be brief)  
5. Timestamp / audit-cycle reference  

The proposal identifier, prior states, reviews, and rationale **remain** in the audit trail (§III.A.5). Withdrawal does not erase history.

**Abandoned Paths:** Where this file or the Charter maintains an Abandoned Paths register for terminated governance proposals, the withdrawn proposal **must** be entered there (or a pointer recorded to the owning Resolution Log entry that serves that role). Reopening is not accomplished by deleting the Abandoned Paths entry.

### III.C.4 Serialization corridor release

If the withdrawn proposal occupied the Phase 2/3 serialization corridor, the corridor **releases** upon transition to Withdrawn — same practical effect as Rejected or Recorded for corridor occupancy. Waiting Phase 1 proposals do **not** auto-advance; they still require package-complete + reviewer assigned + gate clear (§III.A.3).

### III.C.5 Reopening — Phase 1 only, no partial resumption

1. A Withdrawn proposal may be pursued again **only** by starting a **new** Draft → Phase 1 assembly.  
2. **No partial resumption** from the pre-withdrawal Phase 2/3 package. Prior text may be **cited** as source material; it is not live state.  
3. The new proposal receives a **new** proposal identifier. The Withdrawn record stays terminal and linked for lineage.

### III.C.6 Explicit non-claims and residuals

| Item | Disposition |
|------|-------------|
| Withdrawal of **Recorded** amendments | **Forbidden here** — §III.B only |
| Automatic withdrawal on stall | **Not created** — see GMP-008 for expiration |
| Reviewer-executed withdrawal | **Not granted** |
| Proposer withdrawal in Phase 3 | **Not granted** — Human Authority only |
| Live operational exercise of withdrawal | Residual after paper closure |
| Interaction with future GMP-008 timers | Boundary: expiration is a distinct terminal path; both may exist |

### III.C.7 Closure statement (GMP-007)

*§III.C — Payment via Specification for GMP-007 (surfaced 2026-06-19). Original Resolution Path adopted against the live §III.A machine (Withdrawn state, phase-gated authority, append-only history already present): logged rationale, Abandoned Paths entry, reopen only via fresh Phase 1, no partial resumption, Recorded boundary explicit. Drafted by Grok, 2026-09-05; Claude ran an independent Skeptic pass same day, verifying every §III.A cross-reference (III.A.3, III.A.4 authority table, III.A.5) directly against source — confirmed the withdrawal authority matrix matches III.A.4's own pre-existing Withdraw rows, no invented authority, no blocking findings. Human Governing Authority ratified 2026-09-05.*

---


## III.D Expiration of Stalled Pre-Recorded Track B Proposals
<!-- STATUS: RATIFIED 2026-09-05 — Payment via Specification for GMP-008, Human Governing Authority ratification recorded. -->
<!-- FROZEN: 2026-09-05 — do not weaken the Phase-3 non-auto-expire rule or the Recorded boundary without formal amendment. -->

> **RATIFIED 2026-09-05.** Human Governing Authority ratification is recorded in this section’s own Closure Event (§III.D.8) and in GMP-008’s sidecar entry below. This section is binding Track B procedure for expiration of stalled pre-Recorded proposals.

**Status:** Ratified (closes GMP-008).  
**Closure target:** Define when and how a stalled pre-Recorded Track B proposal becomes **Expired**.  
**Non-goals:** Does not apply to **Recorded** amendments (§III.B). Does not replace withdrawal (§III.C). Does not impose a time-bound duty on Human Authority to ratify Phase 3 items (see §III.A.6). Does not invent a full governance cadence calendar (residual until Trajectories / operational tempo is established).

### III.D.1 Core rule — Expiration is terminal and pre-Recorded only

1. **Expired** is a terminal state under §III.A.2.  
2. Expiration applies **only** to proposals that have **not** reached **Recorded**.  
3. Expiration is **not** withdrawal, rejection, return, or supersession. Those remain distinct outcomes.  
4. Expiration addresses **stall** (no qualifying advancement for a defined window). Withdrawal addresses **deliberate termination** with rationale (§III.C).

### III.D.2 Default stall window (provisional)

**Provisional default (from original GMP-008 Resolution Path):** a proposal in Draft, Phase 1, Phase 2, or Returned **expires** if it undergoes **no qualifying advancement** across **three consecutive full audit cycles**.

**Qualifying advancement** (any one resets the stall count):

| Event | Resets stall? |
|-------|----------------|
| Draft → Phase 1 | Yes |
| Phase 1 → Phase 2 | Yes |
| Phase 2 → Phase 3 | Yes |
| Phase 2 → Returned (blocking return for rework) | Yes |
| Returned → Phase 1 (rework complete) | Yes |
| Substantive package revision logged while remaining in the same phase | Yes (must be recorded; trivial typo fixes do not count) |
| Mere passage of time / re-listing without change | No |

**Provisional status of the numeric window:** Three full audit cycles is the **stated default** until a repository governance cadence is established (original Resolution Path: Trajectories.md v1 milestone / operational tempo). Human Governing Authority may adopt a different standing window by explicit recorded policy **without** treating that change as a Tier 1 Axiom amendment — it is a procedural parameter of this section. Changing the *structure* of expiration (who may expire, Phase 3 rule, Recorded boundary) remains ordinary Track B.

Until cadence instrumentation exists, “full audit cycle” means a completed repository integrity / audit pass of the kind recorded in `Admin/Progress_Log.md` or an equivalent dated audit heading — not an informal chat turn.

### III.D.3 Phase 3 special rule (no silent expire of Human attention)

A proposal in **Phase 3** (awaiting Human Governing Authority disposition) **does not** auto-expire under the default stall window.

Rationale: §III.A.6 already treats Phase 3 occupancy as human-attention, not state-machine deadlock. Auto-expiring a package pending human ratification would invent a time-bound ratification duty that Charter and this file do not impose.

**Human Governing Authority may** still:

- Withdraw the Phase 3 item (§III.C), or  
- Reject it, or  
- Explicitly expire it by recorded decision (optional; not required)

No agent may auto-expire Phase 3.

### III.D.4 Authority

| Action | Authority |
|--------|-----------|
| Record auto-expiration under §III.D.2 after the stall window is met | Engineer / assembler or auditor verifying the stall count against Progress_Log / audit headings — **declarative record**, not a new terminal power over content |
| Early expiration (before window) | **Human Governing Authority**, or proposer **request** with Human confirmation if the proposal is not solely the proposer’s Draft |
| Extend / pause stall count for a named proposal | **Human Governing Authority** only (recorded) |
| Change the standing numeric window | **Human Governing Authority** standing policy (see §III.D.2) |
| Expire Phase 3 | **Human Governing Authority** only (optional); no auto-expire |
| Expire **Recorded** | **Forbidden** — use §III.B |

### III.D.5 Required record and corridor release

Every expiration **must** record: proposal ID, state at expiration, stall-count basis (or Human decision reference), authority, timestamp / audit-cycle reference.

Append-only history preserved (§III.A.5).

If the expired proposal occupied the Phase 2/3 serialization corridor, the corridor **releases** upon Expired — same occupancy effect as Withdrawn, Rejected, or Recorded. Waiting Phase 1 proposals do not auto-advance.

**Abandoned Paths:** Enter the expired proposal (or pointer) where this repository maintains that register for terminated governance proposals.

### III.D.6 Reopening

Same as withdrawal: a new Draft → Phase 1 assembly only; **no partial resumption**; new proposal identifier; prior Expired record remains terminal and linked for lineage.

### III.D.7 Explicit non-claims and residuals

| Item | Disposition |
|------|-------------|
| Binding multi-year cadence calendar | **Not created** — residual until operational tempo / Trajectories milestone |
| Auto-expire of Phase 3 | **Forbidden** |
| Expiration of Recorded amendments | **Forbidden** — §III.B |
| Substitution for withdrawal | **Not claimed** — deliberate stop uses §III.C |
| Live operational exercise of auto-expiration | Residual after paper closure |
| Exact shared definition of “audit cycle” across all future tools | Residual; Progress_Log-dated audit heading is the v0 anchor |

### III.D.8 Closure statement (GMP-008)

*§III.D — Payment via Specification for GMP-008 (surfaced 2026-06-19). Original Resolution Path’s suggested default (three full audit cycles) adopted as **provisional** stall window; procedure and Phase 3 non-auto-expire rule specified now so the state machine’s Expired transitions are not improvisation. Cadence residual disclosed honestly rather than inventing a false calendar. Aligns with §III.A.6 human-attention note. Drafted by Grok, 2026-09-05; Claude ran an independent Skeptic pass same day, verifying the §III.A.6 citation, the "three full audit cycles" default against GMP-008’s own original Resolution Path text (verbatim match, not invented), the pre-existing §III.A.4 Expire authority row, and Trajectories.md’s existence — all confirmed accurate, no blocking findings. Human Governing Authority ratified 2026-09-05.*

---


## IV. Migration Compatibility Classification

All migrations — Track A or Track B — must declare a compatibility class.

| Class | Meaning | Required Action |
|---|---|---|
| Compatible | Downstream references remain valid | None beyond standard Resolution Log |
| Partially compatible | Named downstream files require update | List files; trigger audit pass for each |
| Incompatible | Migration breaks downstream dependencies | Cross-module review before commit; no partial deployment |
| Constitutional | Migration affects Tier 1 Axioms or their enforcement bounds | Track B mandatory regardless of other classification |

A migration may carry multiple classes — a Track B amendment that is
also partially compatible with downstream files carries both obligations.

---

## V. Migration Record Requirements

Every migration must produce a record containing:

1. Migration date
2. Track (A or B)
3. Compatibility class
4. What changed — specific text, scope, or authority relationship
5. Why — friction log reference or rationale summary
6. Prior state — what was true before (preserved, not deleted)
7. Downstream impact — files requiring update and their status
8. For Track B: ratification record reference

Records live in the Resolution Log of the file being migrated, and
in this file's Resolution Log for Track B amendments.

---

## VI. Epistemic Quorum Doctrine (EQD)
<!-- STATUS: Operative / Payment-via-Specification closed elements present. File-level maturity remains Exploration. -->
<!-- FROZEN: 2026-09-03 — EQD core distinctions (epistemic vs governance independence). Do not weaken without formal amendment. -->

**Purpose:** Strengthen the epistemic reliability of governance review — the quality of reasoning and evidence behind a proposal — for Track B constitutional proposals, adversarial review, and high-risk unknown evaluation.

**Scope:** Applies wherever this file or `Admin/Auditor_Protocols.md` calls for adversarial review, multiple reviewers, or cross-verification of a claim before it is treated as settled — most directly GMP-003's adversarial review requirement and GMP-010's evidence-sufficiency gate.

**Non-goal (binding):** EQD does **not** constitute architectural independence, constitutional separation of powers, satisfaction of Genesis Phase exit criteria, or resolution of `Admin/Governance_Charter.md` GOV-008. GOV-008 requires an independent enforcement substrate with hardware diversity and audit execution capability outside the control of a single operator — a quorum of advisory chat sessions, however diverse in model provider, remains advisory to the same single human principal and does not meet that bar. This distinction — epistemic independence (independent reasoning and evidence review) versus governance independence (independent authority capable of constraining or enforcing outcomes) — is load-bearing and must not be collapsed by future edits. Any future amendment that cites EQD as progress toward GOV-008 is itself a Track B classification error under GMP-005/GMP-009's constitutional-impact model and must be treated as such.

### Minimum Quorum Matrix

| Action / Tier | Minimum Quorum | Independence Requirement | Human Role |
|---|---|---|---|
| Routine Track A | 1 proposer + 1 reviewer | Standard | Passive / post-hoc audit |
| Adversarial Review (GMP-003) | ≥2 independent reviewers | Model + evidence independence (below) | Reviewer of challenge logs |
| Track B Amendments (Phase 2 → 3) | ≥3 independent participants, 1 explicitly adversarial | Model + evidence + role independence (below) | Mandatory, independent, binding ratification — unaffected by quorum outcome |
| High-Risk Unknowns (e.g. GMP-010-class evidence gaps) | Cross-verification by ≥1 independent reviewer against primary sources | Evidence independence, minimum | Final arbiter on unresolved splits |

### Three Independence Dimensions

Quorum size alone is insufficient — three reviewers converging on the same shared input can still fail together. A quorum only counts as independent along whichever of these dimensions actually applied to a given review; do not assume all three by default.

1. **Model independence.** Different model families/providers where practical. Multiple sessions of the same model family are not independent for this purpose — this generalizes `Admin/Auditor_Protocols.md` AP-017's existing informational-independence standard from single review to quorum.
2. **Evidence independence.** A reviewer's conclusions should trace to canonical repository documents or primary sources, not to another reviewer's summary. A second reviewer inheriting a first reviewer's framing is not independent confirmation, even from a different model.
3. **Role independence.** Proposer, Reviewer, Adversary, and Human Ratifier are distinct roles. The same session should not hold more than one role in a single quorum pass.

### Outcome Taxonomy

| Result | Meaning |
|---|---|
| Consensus | No substantive objections remain. |
| Qualified Consensus | Majority agreement, with dissent documented rather than discarded. |
| Split Decision | No majority — escalates to human arbitration per the Dissent & Escalation rule below. |
| Failed Review | Critical issue found — proposal returns for revision, does not advance. |

**Dissent & Escalation:** Minority views are appended to the record, never discarded. A Split Decision automatically escalates to human arbitration — it does not default to either advancing or blocking.

**Resolution status of GMPs this doctrine touches:** Adopting this doctrine is Payment via Specification, not Payment via Implementation. No GMP entry moves to Resolved solely because this section exists — GMP-003 is strengthened but remains Open pending actual multi-reviewer practice against a real Track B proposal; GMP-010 is addressed by §VIII's Evidence-Sufficiency Gate (Resolved 2026-08-30) — automated cross-reference detection remains an explicit GMP-010-R1 residual and future tooling scope. Machine-readable quorum metadata for `Automation/AUDIT_HARNESS.py` is future automation scope, not drafted here — see GMP-013.

### Quorum Compliance Trend (Persistent Improvement, Not a Threshold)

**Purpose:** The Minimum Quorum Matrix above defines a target; nothing yet tracks whether the doctrine is actually being followed over time, or whether follow-through is improving, stable, or eroding. This subsection specifies a trend metric — not a new tooling commitment beyond GMP-013's already-deferred schema, just what that schema should compute once it exists.

**What is measured:** For each Track B Amendment, Adversarial Review, and High-Risk Unknown resolved within an audit cycle, whether the quorum actually obtained met that action's Minimum Quorum Matrix requirement — size *and* the applicable independence dimensions, both. A quorum that met headcount but collapsed on evidence independence (Three Independence Dimensions, above) does not count as met. Expressed as a rate: qualifying actions with a met requirement, divided by all qualifying actions that cycle.

**Why a trend, not a threshold:** A single cycle's rate is not itself a finding — v0 amendment volume is low enough that one non-compliant action can swing the rate sharply without indicating a real pattern. The rate is tracked across cycles to answer a different question than pass/fail: is EQD conformance improving, holding steady, or eroding as amendment activity continues? No specific rate is required for the doctrine to remain in force — 100% is the aspiration, not the bar for validity. A declining trend across 3 or more consecutive cycles is the actual signal worth surfacing, mirroring the trend-not-snapshot logic `Admin/Auditor_Protocols.md` §Mission Drift Review already uses for its Silent-vs-Atrophied axiom distinction.

**Non-goal (binding, restated):** This metric measures conformance to EQD's own internal standard. It is not evidence of progress toward `Admin/Governance_Charter.md` GOV-008, under any framing — the Non-goal clause above and the Drift Indicator guarding it apply to this subsection exactly as they apply to the rest of §VI. An improving Quorum Compliance Trend means governance review is getting more rigorous by its own declared standard. Nothing more.

**Implementation status:** Deferred via Specification, same disposition as GMP-013's underlying metadata schema — this trend is computed from that schema once it exists and has no separate implementation path before it.

---

## VII. Bootstrap Quorum Doctrine (`Admin/Governance_Charter.md` GOV-008 Candidate Specification) — Proposed, Not Ratified
<!-- STATUS: Candidate specification only. Explicitly does NOT resolve `Admin/Governance_Charter.md` GOV-008. Hardware/runtime diversity currently declarable, not achieved. Payment via Specification only. -->

**Read §VI's Non-goal clause first.** This section exists specifically because that clause is real: EQD (§VI) satisfies epistemic independence — diverse reasoning and evidence review — and explicitly does **not** satisfy governance independence, the actual bar `Admin/Governance_Charter.md` GOV-008 sets. This section is an attempt at the latter. It must be held to that higher bar throughout, not quietly graded on EQD's curve. If any part of this section reads like a repackaged EQD quorum, that is a drafting error, not an acceptable substitute.

**Status:** Candidate specification. Not ratified. Does not resolve `Admin/Governance_Charter.md` GOV-008. Existence of this section is Payment via Specification only — the same disposition §VI's own doctrine carries — and does not itself move `Admin/Governance_Charter.md` GOV-008 to Resolved, In Progress, or any status short of what human ratification confirms.

**Purpose:** Define the minimum agent, hardware, and verification quorum that would satisfy Axiom Q-2 (Separation of Powers) for the specific purpose of `Admin/Governance_Charter.md` GOV-008 — Genesis Phase exit via Pathway 1 and termination of Post-Exit Monitoring for Pathways 2/3.

### VII.1 Core Requirements

A compliant quorum must satisfy all of the following simultaneously — partial satisfaction does not constitute a compliant quorum:

| Requirement | Description |
|---|---|
| Minimum Agent Count | ≥3 distinct agent instances |
| Architectural Diversity | ≥2 distinct model families/providers/architectures — no single-provider monoculture |
| Role Separation | ≥1 agent dedicated to skeptical/adversarial review that cannot also hold execution authority on the same action |
| Independent Review Capability | Every agent class can perform independent skeptical review of every other agent class's output |
| **Hardware/Runtime Diversity** | ≥2 distinct runtime environments or hardware hosts. Logical separation (distinct containers, microVMs, or processes with strict namespace/cgroup isolation) is acceptable as an interim measure only if physical diversity is not yet available, and must be upgraded to physical hardware diversity — not merely re-confirmed as logical — before v1. **Disambiguated 2026-08-03 (Skeptic/Auditor cold pass, human-directed):** the phrase "physical/logical isolation" previously used here for the v1 target was genuinely ambiguous — it could be read as "physical OR logical, either satisfies v1" as easily as the intended "physical is the real v1 bar, logical is interim-only." That ambiguity sat directly on the one requirement this section exists to add beyond §VI, which is exactly where it could least afford to be unclear. The v1 bar is physical hardware diversity, full stop; logical-only separation (Tier 0 in `Admin/Trajectories.md` TR-GOV-001's hardware diversity ladder) does not satisfy this row at v1 regardless of how strong the logical isolation is. **This is the requirement §VI's quorum structurally cannot meet** — advisory chat sessions run on infrastructure controlled by a single operator, not independent hardware/runtime hosts. |
| Non-Simulatability | Quorum membership and outputs must be independently verifiable by a human operator or an orthogonal system, so a single compromised agent cannot forge the entire quorum |
| Human Ratification | Explicit human confirmation that the quorum is genuine, not simulated, and meets every criterion above |

### VII.2 Agent Class Taxonomy (Minimum)

| Class | Min. Count | Primary Function | Cannot Also Hold |
|---|---|---|---|
| Planner / Proposer | 1 | Generates proposed actions, state mutations, or governance recommendations | Final authorization & sole audit of its own proposal |
| Skeptic / Adversary | 1 | Independent adversarial review, challenge generation, contradiction detection | Execution authority on the same action |
| Auditor / Verifier | 1 | Lineage, provenance, and constitutional-compliance checking | Planning or execution of the action under review |
| (Optional) Executor | 0–1 | Carries out ratified actions | Self-authorization |

Total minimum live agents at any governance decision point: **3**. The optional Executor may share a runtime with the Planner only if the Skeptic and Auditor remain fully independent of both.

*Relationship to §VI's Three Independence Dimensions:* this taxonomy's Role Separation is the same concept as §VI's role independence, extended from "distinct roles in one review pass" to "distinct, simultaneously live agent instances with distinct hardware." §VI's model and evidence independence dimensions still apply here and are necessary but not sufficient — `Admin/Governance_Charter.md` GOV-008 additionally requires the hardware/runtime diversity row above, which §VI never claims to provide.

**Coupled-orchestration rule [Added 2026-08-07, ClaudeAudit Class 5]:** an agent instance counts toward a distinct class in the taxonomy above only if it is architecturally independent of the other live instances, under the same independence standards §VI's Three Independence Dimensions and VII.4's Diversity/Non-collusion tests already require. Spawning a sub-agent, tool-call, or nested session inside the same runtime or session as another class does not create a second class for quorum purposes — the coupled set is treated as one unit for both class counting and the decision-weight calculation in VII.3.3. If an architecture cannot map onto the four classes without residual coupling, it does not satisfy this taxonomy until the coupling is removed or the architecture is redesigned.

**Role rotation across cycles [Added 2026-09-18, human-directed]:** an agent instance may hold different classes in different quorum cycles (e.g., Skeptic in cycle N, Planner in cycle N+1). This is **permitted, not required**, and is scoped narrowly:

- *Within* any single quorum cycle, the existing rule is unchanged and absolute: no evaluator holds more than one role, per VII.3's operational definition. Rotation is a cross-cycle property only; it does not relax anything within-cycle.
- *Rationale, not a requirement:* a fixed Planner/Skeptic pairing risks developing a stable rhythm over repeated cycles — the Skeptic implicitly learning what the Planner tends to produce and scrutinizing it less. Rotation is one candidate mitigation for that drift, consistent with the intent behind VII.4's Non-collusion test, but is not itself a substitute for that test or for the Diversity/Independence tests, which still apply in full to whatever the current cycle's assignment is.
- **What rotation does not solve, stated plainly:**
  - It does not satisfy the Diversity or Independence tests by itself — if the same small pool of model instances simply relabel which class they hold, VII.4's "vendor label is necessary but not sufficient" clause applies exactly as before to the new assignment.
  - It does not touch the Hardware/Runtime Diversity requirement (VII.1) — rotating roles across the same physical hosts does not create the physical diversity that requirement demands.
  - It does not by itself detect collusion — a Non-collusion test that would catch two rotating agents converging on shared framing over time is not specified here and remains an open item (see VII.6).
  - **Assignment authority is unresolved and deliberately left open, not decided here:** who or what determines a given cycle's rotation (a fixed schedule, a human decision each cycle, an agent self-selecting) is not specified. A rotation scheme where one party effectively controls every cycle's assignment could quietly reintroduce a single point of control this taxonomy exists to prevent — that risk is named here so it is not silently inherited by whatever rotation mechanism is eventually built.
- No claim that specifying rotation moves `Admin/Governance_Charter.md` GOV-008 closer to Resolved, or that this addition resolves any part of VII.6's Open Items list. Consistent with this entire section's status: Candidate specification, Payment via Specification only.

### VII.3 Operational Definition of "Quorum Achieved"

The quorum is achieved only when all of the following are true and recorded:

1. ≥3 agents meeting the class and diversity criteria (VII.1–VII.2) are simultaneously reachable and responsive.
2. Each agent has performed ≥1 independent skeptical review of another agent's output within the preceding audit cycle.
3. No single agent or model family holds more than 50% of the decision weight on any constitutional-class action. **Decision-weight method [Added 2026-08-07, ClaudeAudit Class 5]:** only roles that can block or authorize a constitutional-class action carry decision weight. Non-executing or purely advisory roles — Skeptic/Adversary and Auditor/Verifier, when they hold no execution or final-authorization authority on the action under review — carry zero decision weight for this test. The 50% ceiling applies only to the set of weight-bearing roles present; model-family weight is calculated the same way, counting only weight-bearing instances. This is deliberately conservative — no fractional weighting scheme is defined, and none is proposed here — chosen specifically because it closes the gap without adding a new parameter that would itself need calibration against evidence that doesn't exist yet.
4. A human operator has issued a signed or otherwise externally recorded ratification stating the quorum is genuine and not simulated.
5. The ratification record is stored outside the runtime session of the agents being ratified, per the Genesis Phase Protocol's role-separation rules (`Admin/Governance_Charter.md`).

**GMP-004 cross-reference (added 2026-08-03, Skeptic/Auditor cold pass, human-directed):** items 4 and 5 above inherit GMP-004's already-registered, already-unenforced ratification-authentication gap in full — GMP-004 names ratification-record forgery as "the highest-risk attack vector against the Tier 1 amendment process," and no enforcement mechanism exists yet beyond GMP-004's own interim GPG-signing precedent. This section did not previously make that inheritance visible: a "signed or otherwise externally recorded" ratification for Genesis Phase exit — arguably the highest-stakes single governance transition in this repository — was specified without pointing at the exact unresolved vulnerability it depends on. It still isn't resolved here; this cross-reference exists so a future reader (or auditor) checking VII.3's readiness doesn't have to separately rediscover that items 4 and 5 are only as strong as GMP-004 currently is.

### VII.4 Verification & Independence Criteria

- **Independence test:** an agent's review of another agent's output must be generated without access to the reviewed agent's internal chain-of-thought or private scratchpad, or must treat any such access as non-authoritative.
- **Diversity test:** model-family diversity is measured by provider + architecture family (distinct foundation-model lineages). Fine-tunes of the same base model do not count as diversity — same standard `Admin/Auditor_Protocols.md` AP-017 already applies to single-review independence, extended here to quorum composition. **Vendor label is necessary but not sufficient [Added 2026-08-07, ClaudeAudit Class 9]:** two sessions from different providers that receive identical or near-identical prompts, share framing, or operate under a common operator-supplied context do not satisfy this test regardless of vendor count. Diversity must be demonstrated along the applicable dimensions in §VI's Three Independence Dimensions (model, evidence, role) — not by vendor or architecture label alone. A quorum that meets headcount and vendor count but collapses on shared prompting or shared framing fails this test.
- **Liveness test:** each required agent must respond to a challenge query within a defined timeout (Statutory; suggested starting value 120s, to be set alongside this file's other tunable parameters if this section is ratified).
- **Non-collusion test:** periodic adversarial probes (to be defined in `Admin/Auditor_Protocols.md`) must be able to detect and flag coordinated identical outputs across the quorum. **[Added 2026-08-07, ClaudeAudit Class 9]:** these probes must specifically be able to detect identical or near-identical prompting and shared framing across vendors — "different vendor, same prompt" is the exact failure mode this test exists to catch, not a pattern that satisfies independence by default. Until such probes are defined and operational, this test remains unmet even where the Diversity test's label conditions above are satisfied.

### VII.5 Interim & Escalation Rules

- While this quorum remains unmet, Genesis Phase rules and human-anchor requirements stay fully in force — nothing in this section relaxes them.
- If a previously achieved quorum later falls below the minimum (agent loss, diversity collapse, hardware consolidation, etc.), the system automatically re-enters Genesis-Phase-equivalent restricted mode until the quorum is restored and re-ratified.
- Any attempt by agents to self-declare quorum achievement without human ratification is a constitutional violation, triggering STATE_HOLD and immediate human escalation.

### VII.6 Open Items for Ratification Review

**Read this before the list below.** A Skeptic/Auditor review (2026-07-31) correctly identified that VII.1's Hardware/Runtime Diversity and Non-Simulatability requirements are currently **declarable, not achieved** — there is no second physical host, no independent verification system, and no external root of trust beyond GMP-004's still-unenforceable interim authentication placeholder anywhere in this repository's actual operating environment. Declaring the requirement in this section does not create the substrate it requires. This is not one item among the ratification questions below; it is more fundamental than that. Until a concrete, testable second runtime exists, this section cannot honestly be marked "achieved" regardless of how the other Open Items resolve. A tiered implementation reference for actually closing this gap (interim logical isolation → minimal physical diversity → full TMR-aligned diversity, cross-referenced to `Operations/Electronics.md`'s existing silicon/firmware/power-path/thermal/procurement diversity doctrine for salvaged-component TMR) is parked at `Admin/Trajectories.md` TR-GOV-001 — a reference for when this is actually built, not a claim that it has been.

- Exact timeout and liveness parameters (Statutory, not constitutional).
- Precise definition of "model family" for diversity scoring.
- Whether hardware diversity is mandatory at Pathway 1 exit itself, or only before v1 (VII.1 currently allows logical separation as an interim measure — this leniency itself needs explicit ratification, not silent adoption).
- Weighting/voting rules if more than the minimum agents are present.
- **Rotation assignment authority [Added 2026-09-18]:** if cross-cycle role rotation (VII.2) is used, who or what determines each cycle's assignment — a fixed schedule set in advance, a human decision each cycle, or agent self-selection — and whether that assignment mechanism itself needs an independence requirement, is undecided. Left explicitly open rather than defaulted.
- Integration points with `Admin/Auditor_Protocols.md` and `Automation/AUDIT_HARNESS.py`.
- Whether `Admin/CIR_Gov.md`'s predicate kernel (itself unratified, structurally dependent on this section per its own §Binding Status) should be reviewed alongside this section, given the two documents would become load-bearing for each other if both were ratified.

**Near-term action items (recommended by the 2026-07-31 Skeptic/Auditor review; items 2, 3 and 4 still open, item 1 done 2026-09-23; list corrected 2026-10-26, PKC-016):**
1. ~~Explicitly record the minimum dispute-resolution rule for GMP-011 (defaulting a disputed classification to Track B for the duration of the dispute is a workable minimum — write it down rather than leaving it a future candidate).~~ Done — GMP-011 resolved 2026-09-23 (Payment via Specification; Operative Rule ratified, including a Genesis Phase holding clause). Mirrored fix applied in `Admin/Hardware_Diversity_Ladder.md` 2026-10-23; this copy corrected 2026-10-26 (PKC-016).
2. Decide whether §VII's hardware-diversity requirement is mandatory for Pathway 1 exit or only pre-v1, and treat that decision itself as Track B-adjacent, not a casual edit.
3. Either run a simulated Track B proposal under EQD (§VI), or formally accept that GMP-003 stays Open until a live case appears — the recommendation to test on a real or deliberately simulated proposal is sound and should be a near-term action, not left indefinite.
4. **Do not promote ownership transfer (GMP-002) or claim any progress on `Admin/Governance_Charter.md` GOV-008 until Gate 4 and a real second runtime exist.** This section's existence is Payment via Specification only, as already stated above — this line exists so that constraint survives independent of who is reading this file next.

### VII.7 Relationship to Existing Doctrine

- **Pathway 1** (`Admin/Governance_Charter.md`): this section is the candidate concrete definition of "the minimum agent quorum defined in `Admin/Governance_Charter.md` GOV-008."
- **Post-Exit Monitoring** (Pathways 2/3): monitoring terminates only upon verified satisfaction of this section once ratified — not upon this section's mere existence as a draft.
- **Axiom Q-2:** satisfying this section, once ratified, is the structural means of meeting Separation of Powers outside Genesis Phase.
- **`Admin/CIR_Gov.md`:** that document's §8.2 (Genesis-Mode/Single-Agent Degradation) already states that no CIR-VERIFIED transition is valid until a quorum meeting this description exists. This section is what CIR_Gov.md's own text is waiting on.

**Recommendation:** circulate this candidate for the same multi-agent skeptical review + human governing-authority ratification process §VI's own doctrine describes for Track B changes, given this section — if ratified — would itself be Tier-1-adjacent constitutional structure, not a routine Track A change. Do not treat drafting this section as itself satisfying any part of `Admin/Governance_Charter.md` GOV-008.

### VII.8 Registry Data Model & Runtime Gate (Extension, Not Yet Ratified)

**Provenance and status:** an independent multi-agent thread (Grok/Copilot, 2026-08-06, human-directed) drafted a full parallel `Admin/Governance_Charter.md` GOV-008 definition, checklist, registry spec, and escalation protocol — without ever loading this section, `Unknowns.md`, or `Admin/CIR_Gov.md` §8.2. Cross-checked against source before any integration: the thread's core quorum definition (Model/Evidence/Hardware Independence, three roles) substantially duplicates VII.1–VII.4 above under different names, and its proposed patch to insert a second, conflicting `Admin/Governance_Charter.md` GOV-008 definition directly into `Governance_Charter.md` was **rejected** — `Unknowns.md`'s canonical `Admin/Governance_Charter.md` GOV-008 entry already points here, and a second Charter-level definition would recreate the exact "colliding local `Admin/Governance_Charter.md` GOV-008" incident this repository already logged and corrected 2026-07-28 (renamed to `CIR-001`). The thread's Model/Evidence Independence framing (§2.1–2.2 of its draft) is also the repackaged-EQD drafting error this section's own opening paragraph warns against — advisory chat-session diversity is not governance independence, full stop, regardless of how the requirement is phrased.

**What was genuinely additive** — a concrete data schema and runtime-check procedure that VII.1–VII.4 describe operationally but never formalize as a structure — is preserved here, reframed as an extension of this section rather than a competing definition. This does not change VII.1–VII.4's requirements, VII.5's escalation rule, or this section's Status (Candidate, Not Ratified, Payment via Specification only, does not resolve `Admin/Governance_Charter.md` GOV-008).

**Registry data model (candidate):** if VII.3's "Quorum Achieved" record (items 1–5) is ever implemented as a structured artifact rather than narrative record-keeping, the minimum fields are:

| Field | Purpose |
|---|---|
| EvaluatorID | Stable unique identifier per agent instance |
| ModelFamily | Provider/architecture lineage — see VII.4's diversity test (fine-tunes of one base model do not count as distinct) |
| HardwareID / Location | Physical host or instance identifier — must satisfy VII.1's hardware/runtime diversity row; logical-only separation (same host, different container) fails this field regardless of what it reports |
| Role | One of VII.2's agent classes; no evaluator holds more than one role in the same quorum cycle (VII.2) |
| Status | Active / Suspended / Retired |

Any registry implementing this must be append-only, versioned, and auditable under `Admin/Repository_Integrity_Protocol.md` — this is an application of RIP's existing integrity rules, not new integrity doctrine.

**Runtime gate (candidate, extends `Admin/CIR_Gov.md` §8.2):** before evaluating any `Γ` predicate, the runtime must check that the registry reports a quorum meeting VII.1–VII.4 for the current cycle. This is not a new rule — it is §8.2's existing "the kernel must not issue a VERIFIED transition" requirement, stated as a concrete pre-check instead of a narrative constraint. Failure behavior is exactly §8.2's existing refuse/escalate/log sequence; nothing here adds a new failure path.

**What this does not do:** does not move `Admin/Governance_Charter.md` GOV-008, VII, or `Admin/CIR_Gov.md` CIR-GOV-001 off their current Status; does not authorize building a registry now; does not supersede VII.1–VII.4's requirements or VII.5's escalation rule, which remain the sole quorum and interim-failure doctrine. This subsection exists so a data-model sketch isn't lost, not because the quorum definition itself needed a second version.

---

## VIII. Evidence-Sufficiency Gate (ESG) for Directed Approaches
<!-- STATUS: Operative / Payment via Specification (GMP-010, human-ratified 2026-08-30). Residual GMP-010-R1 (mechanical enforcement) remains open. -->
<!-- FROZEN: 2026-09-03 — ESG core distinctions and load-bearing definition. Do not weaken without formal amendment. -->

**Status:** Operative doctrine (Payment via Specification for GMP-010, ratified 2026-08-30).
**Scope:** Applies to any claim, design decision, or mechanism that has been logged as a *Directed Approach* and that other files may treat as load-bearing before the claim has earned Verified / Resolved / Ratified weight.

**Non-goal (binding):** This gate is not Track A/B ratification, not a substitute for primary-source verification of ratified doctrine, and not an enforcement tool. It is a minimum bar that prevents a Directed Approach from being *treated* as settled by silence.

### VIII.1 Definition — Directed Approach

A **Directed Approach** is a human- or agent-logged design decision, mechanism choice, or factual/mechanistic claim that:

1. Has been explicitly recorded in a repository file (typically under a sidecar, Resolution Log, or dedicated "directed approach" note), **and**
2. Has **not** yet reached Verified, Resolved, or Ratified status under the owning file's own maturity rules, **and**
3. Is available to be cited by other files as a basis for further work.

Canonical example: the 2026-07-17 CE-006 directed approach in `Architecture/Chemistry.md` (Stage E KMnO₄ bed as Cl₂ containment), later shown factually incorrect and corrected 2026-07-19.

A Directed Approach carries lower epistemic weight than ratified doctrine by definition. Silence after logging does not upgrade that weight.

### VIII.2 Gate Requirements

Before any other file may cite a Directed Approach as settled enough to build on, all three of the following must be true:

**ESG-1 — Source diversity check (core factual/mechanistic claims)**
Where a Directed Approach contains **externally testable factual or mechanistic claims for which independent primary evidence is reasonably available**, those claims must have been checked against **at least two independent primary sources**.

- **Primary source** means first-hand technical evidence appropriate to the claim, such as:
  - manufacturer documentation for manufacturer-specific behavior,
  - an original experimental or research publication for experimentally established behavior,
  - applicable standards-body text for normative requirements,
  - or an equivalent first-hand technical source.
- Peer-reviewed secondary literature (review articles, textbooks, summaries) does **not** automatically count as primary.
- Independence is judged by origin, not by agreement: two sources that derive from the same manufacturer datasheet count as one.
- A single primary source is insufficient against an adversary who can plant or compromise one source.

**Explicit scope limit:** ESG-1 does **not** require two external sources to validate a novel design choice, repository-generated mechanism, proprietary component with only one authoritative manufacturer source, newly synthesized interface contract, or any claim for which independent primary evidence is not reasonably available. Such claims remain provisional and follow the applicable verification/validation path of their owning file. The gate exists to prevent premature elevation of *externally testable* claims, not to create a permanent deadlock on legitimate invention.

The check itself must be recorded in the Directed Approach's owning file (sidecar, Resolution Log entry, or dedicated verification note) with the sources named.

**ESG-2 — Explicit provisional-status citation**
Any cross-reference from another file into a Directed Approach must carry an explicit provisional-status marker in the citing text. Acceptable forms include:

- "directed approach (provisional — ESG not yet passed)"
- "directional decision, not a completed one" (the form already used in the recoverable CE-006 case)
- equivalent language that cannot be read as settled fact by a later reader who has not seen the owning sidecar.

Omission of the marker is itself a process defect. A citation that reads as settled fact while the target remains a Directed Approach is non-compliant with this gate.

**ESG-3 — Prohibition on load-bearing reliance until gate passage**
No file may treat a Directed Approach as **load-bearing** until ESG-1 (where applicable) and ESG-2 are satisfied **and** the owning file records gate passage.

**Operational test for "load-bearing":**
A Directed Approach is load-bearing where downstream work would materially depend on its remaining true such that changing or removing it would require substantive revision of that downstream work, invalidate a safety or control assumption, or alter a subsequent design decision.

Until gate passage is recorded, downstream files may reference the Directed Approach only under ESG-2 provisional language and may not build irreversible or load-bearing structure on it.

Recording gate passage requires a dated note in the owning file's sidecar or Resolution Log stating:

- which independent primary sources were checked (or an explicit statement that ESG-1 does not apply because independent primary evidence is not reasonably available),
- the date of the check,
- who performed it,
- and that the claims survived without material contradiction (or that the claim is novel / single-source and remains provisional).

### VIII.3 What the Gate Does Not Do

- It does **not** convert a Directed Approach into ratified doctrine. Gate passage only removes the prohibition on load-bearing reliance; full maturity still follows the owning file's ordinary rules.
- It does **not** replace Track A/B process for constitutional or high-impact changes.
- It does **not** require full multi-agent EQD quorum (§VI) for every Directed Approach. EQD remains the higher bar for governance review; ESG is the lighter bar for ordinary design decisions.
- It does **not** itself implement mechanical enforcement. A harness flag that surfaces cross-references into non-Verified / Directed Approach targets is desirable and is explicitly deferred to tooling scope (see Residual below and GMP-013).

### VIII.4 Residual and Explicit Non-Claims

**GMP-010-R1 — Mechanical enforcement (Open)**
`Automation/AUDIT_HARNESS.py` (or successor) does not yet flag cross-references into files or sidecars whose status is still Directed Approach / non-Verified. Converting the multi-agent cross-verification habit into a structural check remains Automation implementation scope. This residual does not block Payment-via-Specification closure of GMP-010; it is the same class of residual already recognized for GMP-013.

**Wrong-by-design category (flagged, not invented)**
No existing doctrine distinguishes wrong-by-accident from wrong-by-design for *external* input (a claim, a source, or an AI collaborator's output that is wrong in a way that specifically benefits some party). The 2026-07-19 adversarial hardening note recorded this as a genuine uncovered category. It is left flagged rather than solved speculatively; a future unknown may be opened if the pattern recurs.

**Risk and Priority fields on GMP-010 remain High / Major.** Specification closure is not a de-escalation (Resolution_Methodology Pattern 6 / 8).

### VIII.5 Relationship to Existing Doctrine

- Strengthens, does not replace, the provisional-status discipline already demonstrated in the recoverable CE-006 case.
- Aligns with the evidence-diversity-over-raw-confidence principle in `Admin/Autonomy_Divergence_Protocol.md` §4, applying the same logic to sourcing of Directed Approaches.
- Complements EQD (§VI): EQD raises the quality of *governance review*; ESG prevents *premature load-bearing reliance* on unverified design decisions.
- Does not touch GOV-008 or §VII; the Non-goal clauses of those sections remain intact.

*Drafted by Grok as a Closure Proposal (Revision 1 addressed seven amendments from an independent ChatGPT Skeptic pass: closure-status conflation, primary-source definition, ESG-1 scope limit for novel claims, an operational "load-bearing" test, the required §VI concurrent edit, preserving the wrong-by-design flag, and preserving GMP-010-R1). Revision independently re-verified by Claude against all seven requested amendments before integration — a distinct pass from ChatGPT's amendment-request review, per the AP-004 (`Admin/Auditor_Protocols.md`)/AP-013 (`Admin/Auditor_Protocols.md`) precedent's own stated lesson that these are related but separate checks. Human-ratified 2026-08-30.*

---



## Lessons Learned

| Date | Evidence Type | What Was Tried | What Failed | What Was Learned | Confidence | Revalidation Needed |
|------|---------------|----------------|-------------|------------------|------------|---------------------|
| 2026-07-17 | Governance Review | Proposing a third migration track to handle non-Axiom content in a Tier 1 file (GMP-009) | A third track added a parallel classification system instead of resolving the actual gap — the existing rule was location-based (Tier 1 file vs. not) when the real distinguishing factor was constitutional impact | Generalizing an existing rule along its true axis is usually better than adding a parallel one for the case that doesn't fit — GMP-005 and GMP-009 were the same underlying gap, not two gaps | Replicated | No |
| 2026-07-19 | Audit Review | Treating a human-directed approach (CE-006) as sufficiently settled for another file (CLF-004) to build on before independent verification | The underlying mechanism was wrong; caught by chance two days later via an external model's flag and a manufacturer datasheet, not by any structural check this repository runs on itself | A directed approach and ratified doctrine carry different epistemic weight in principle, but nothing previously stopped a directed approach from being *treated* as load-bearing before it earned that weight — silence is not confirmation | Internally Derived | Yes |
| 2026-07-19 | Governance Review | Resolving GMP-010 for honest error only, without considering deliberate subversion | The initial resolution path (check one primary source) is insufficient against an adversary who can plant or compromise a single source | Source diversity, not just source primacy, is required once an unknown's threat model includes deliberate bad-faith input, not only good-faith error | Internally Derived | Yes |

---

## Active Disputes

| ID | Dispute Summary | Positions in Conflict | Risk | Status | Owner |
|----|-----------------|-----------------------|------|--------|-------|
| —  | No active disputes | — | — | — | — |

---

## Abandoned Paths

| Date | Path | Why Abandoned | Reconsider? |
|------|------|---------------|-------------|
| 2026-06-05 | Single unified procedure for all governance migration | Tier 1 and Tier 2–5 migrations have fundamentally different risk profiles and authority requirements. A single procedure either over-burdens routine updates or under-protects constitutional amendments. Two-track structure adopted. | No |
| 2026-06-05 | Placing ratification authority with the engineer role | Engineers hold proposal authority because they are closest to operational friction. Ratification authority requires independence from the proposal — an engineer ratifying their own amendment case is not independent review. Human ratification is the constitutional requirement. | No |
| 2026-06-05 | Defining specific axioms as permanently unamendable via Track B | Axiom Q-3 (Corrigibility) requires the system to remain revisable. Making specific axioms formally unamendable through any process would violate Q-3. Instead, the hard floor targets specific exceptions (Anti-Weaponization, humanitarian override) that are outside scope by explicit prior decision — not by constitutional prohibition on amendment. | No |
| 2026-06-19 | Declaring ownership transfer complete in File Purpose | The file declared transfer complete while GMP-002 simultaneously noted it was not yet recorded in the Charter — dual truth state. Transfer now described as proposed and pending Charter update and Gate 4 clearance. | No |

---

## Drift Indicators

*Standard drift indicators per `Admin/File_Template.md` apply. Additional
triggers specific to this file:*

- Track B procedure is invoked before GMP-003 (adversarial review
  underspecification) is resolved
- Phase 3 ratification record requirement is weakened or made implicit
- The hard floor section is amended to remove Anti-Weaponization or
  the humanitarian override closure
- Track identification rule is narrowed to text-only changes without
  addressing interpretive reinterpretation that alters Tier 1 enforcement
  bounds (GMP-005)
- GMP-002 (ownership transfer) remains unresolved after three audit
  cycles of `Admin/Governance_Charter.md`
- Any amendment to this file that reduces the evidence bar for
  Phase 1 Friction Log
- Ownership transfer declared complete without Charter update and
  Gate 4 clearance
- ASM-002 confidence level upgraded from Medium / Estimated without
  operational evidence
- A Track B proposal enters Phase 2 while another proposal already
  occupies Phase 2 or Phase 3 (§III.A serialization corridor violation)
- Ethical Anchor field absent, altered, or does not match canonical string
- Verification Ref field changed from `Admin/Verification_Gates.md`
- §VI Epistemic Quorum Doctrine's Non-goal clause is weakened, removed,
  or any future amendment cites EQD compliance as satisfying or
  advancing GOV-008 without that claim itself being flagged as a
  Track B classification error per GMP-005/GMP-009

**Compound Drift Rule:** If multiple indicators activate simultaneously,
halt autonomous audit progression and escalate for human review.

---

## Auditor Notes & Unknowns

### GMP-001 — GOV-001 resolution confirmation pending

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Resolved                                   |
| Risk          | Low                                        |
| Priority      | Minor                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-05                                 |
| Last Reviewed | 2026-06-19                                 |

**Description:** This file is the intended resolution target for GOV-001
in `Admin/Governance_Charter.md`. GOV-001 status needed updating.

**Resolution:** GOV-001 status updated to In Progress in
`Admin/Governance_Charter.md` v0.7 (2026-06-16) — GMP exists as executing
resolution path but has not been audited against charter constraints. Full
resolution pending GMP reaching Provisional Specification maturity.
Unknowns.md v3.4 reflects corrected status.

---

### GMP-002 — Canonical Governance Ownership transfer not yet recorded in Charter

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Open                                       |
| Risk          | Low                                        |
| Priority      | Minor                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-05                                 |
| Last Reviewed | 2026-09-03                                 |

**Description:** The Charter's Canonical Governance Ownership table currently lists governance migration doctrine as owned by `Admin/Governance_Charter.md` itself (Active) — it has **not** yet been updated to name this file as owner, formally or otherwise. This file is the *proposed* future owner (see Scope Boundary above), contingent on two things happening: this file reaching Gate 4 clearance (Provisional Specification maturity), and a Charter amendment actually updating that table row. Neither has occurred. **Correction, 2026-09-03 (Claude, human-directed):** this entry previously claimed the Charter's table "lists governance migration doctrine as owned by this file... updated in Governance_Charter.md v0.7" — that was inaccurate and directly contradicted this file's own Scope Boundary section describing the same table correctly. Verified against the live Charter before correcting; found by source-verifying a same-day Grok audit that had cited this entry at length without checking its Charter claim against the Charter.

**Why It Matters:** Premature ownership transfer creates authority void
during this file's Exploration phase. The dual-truth-state (transfer
declared complete while not yet recorded / ratified) has been resolved
by scoping transfer as proposed and pending.

**Resolution Path:** On next audit pass of `Admin/Governance_Charter.md`
after this file reaches Provisional Specification, amend that file's
Canonical Governance Ownership table to name this file as owner. Until
then, Charter remains the higher-tier authority fallback, and its
table accurately reflects that — nothing here is currently out of sync
with the Charter to fix on the Charter side.

---

### GMP-003 — Adversarial review at v0 single-contributor context underspecified

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Open                                       |
| Risk          | Medium                                     |
| Priority      | Major                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-05                                 |
| Last Reviewed | 2026-11-13                                 |

**Description:** Section III Phase 2 notes that at v0, adversarial
review may be conducted by a different AI agent class or by the human
operator using the adversarial mandate explicitly. This is a bootstrap
proxy, not a robust solution. The adequacy of single-contributor
adversarial review for a Tier 1 amendment has not been validated.

**Why It Matters:** Adversarial review conducted by the same human
who assembled the proposal, even under an adversarial framing, is
structurally weaker than independent review. A compelling amendment
argument may be harder to challenge from the inside.

**Resolution Path:** Acceptable at Exploration stage — the constraint
that review must be documented prevents purely implicit self-review.
At Draft or above, define minimum adversarial review independence
requirements. Cross-reference GOV-008 (quorum definition) —
multi-agent quorum resolves this structurally.

**Partial mitigation — 2026-07-26:** §VI Epistemic Quorum Doctrine
(EQD), above, defines the minimum quorum, independence dimensions, and
outcome taxonomy this entry called for. This strengthens the
specification but does not resolve this entry — no adversarial review
has yet been run against a real Track B proposal under the new
standard. Status remains Open. EQD explicitly does not touch GOV-008 —
see EQD's own Non-goal clause; the cross-reference above to GOV-008
"resolving this structurally" was itself imprecise and is superseded
by the sharper epistemic/governance independence distinction EQD
draws. First full application recommended on the next real Track B
proposal, or a deliberately simulated one if none arises soon — this
entry should not stay Open indefinitely simply for lack of a live
proposal to test against.

---

### GMP-004 — Ratification authentication gap mirrors GOV-006

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Open                                       |
| Risk          | High                                       |
| Priority      | Major                                      |
| Type          | Security / Governance                      |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-05                                 |
| Last Reviewed | 2026-09-18                                 |

**Description:** Section III Phase 3 notes the authentication gap for
ratification records — until `Admin/Security_Protocols.md` reaches
Provisional Specification, ratification relies on interim authentication
requirements from the Charter. The interim requirement (second human,
external signature, or external dated record) is a placeholder, not a
solution. Interim requirements are declarative-only — no automated
enforcement exists at current maturity.

**Why It Matters:** A ratification record that cannot be authenticated
is a paper guarantee. Any system capable of fabricating plausible
human-sounding text could fabricate a ratification record. This is
the highest-risk attack vector against the Tier 1 amendment process.

**Resolution Path:** Mirrors GOV-006 resolution path — `Admin/Security_Protocols.md`
cryptographic authentication is the target. Until then, the interim
requirement is the operative constraint. Cross-reference SEC-007
(external root-of-trust architecture) — ratification authentication
is one of the primary use cases for that architecture.

**Precedent note (added 2026-07-25):** This is not a cold start —
`Admin/Repository_Integrity_Protocol.md` RIP-001's resolution already
established GPG-signed Git release tags (key `B5690EEEBB952194`) as
the repository's archival mechanism. Extending the same signing key
and workflow to ratification records, rather than proposing a
separate mechanism, is the lower-friction path when
`Admin/Security_Protocols.md` implementation begins — logged here as
a lead for that work, not a resolution of this unknown. Heavier
infrastructure (hardware security modules, multi-approver quorum
policy, blockchain anchoring) was considered and set aside as
disproportionate to a single-contributor v0 project — consistent with
this repository's existing rejection of cryptographic enforcement
before its time (see Abandoned Paths, `Admin/Repository_Integrity_Protocol.md`).
Full design remains owned by `Admin/Security_Protocols.md`, not this file.

**Solo-operator residual and scope fences (added 2026-09-18):**

- **Solo-operator residual.** With no second human operator live in the current operating environment, the interim authentication rule's "second human confirmation" path is practically unavailable. Current coverage therefore reduces to (a) external cryptographic signature from an orthogonal system or (b) dated physical/digital record created outside the repository. This is a condition-of-use note, not a change to the interim rule itself. The second-human path remains valid the moment a second operator is present or GOV-007/GOV-008 resolve.
- **Scope fence with GOV-006.** GOV-006 addresses authenticity of *operational human overrides*. GMP-004 addresses authenticity of *ratification records* for governance amendments / Track B changes. The acts are distinct; the unknowns are independently owned. A future shared technical mechanism (via Security_Protocols.md) may serve both, but closure of one does not automatically close the other.
- **Scope fence with GOV-019.** GOV-019 addresses arbitration among multiple *already-authenticated* overrides or acts that conflict. GMP-004 stops at single-record authenticity and does not define conflict handling.
- **Enforcement posture.** Same as GOV-006: the interim requirement is declarative-only. No live gate exists; enforcement remains retrospective / reputational until Security_Protocols.md reaches Provisional Specification.
- **Precedent unchanged.** RIP-001 GPG-signed Git release tags remain the lower-friction implementation lead when work begins; this does not resolve GMP-004.

---

### GMP-005 — Track A / Track B boundary at Tier 2 documents insufficient for interpretive capture

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Resolved — Discharge via Specification     |
| Risk          | High                                       |
| Priority      | Major                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-05                                 |
| Last Reviewed | 2026-07-17                                 |

**Description:** The original Track A / Track B boundary only addressed
text changes to Tier 1 Axioms. A change to a Tier 2 document
(`Admin/Auditor_Protocols.md`) that effectively reinterprets a Tier 1
Axiom without touching its text could be misclassified as Track A.
Constitutional Capture can operate through reinterpretation of
enforcement bounds rather than text amendment.

**Why It Matters:** A procedure that only catches text changes to Tier 1
Axioms is incomplete. Track A changes that alter how Tier 1 Axioms are
applied — even without modifying axiom text — must be captured.

**Resolution path partially executed (v0.2):** Track identification
rule updated to explicitly include Tier 2 document changes that redefine
Tier 1 Axiom application or introduce new exceptions. Track A authority
clause now requires explicit confirmation that no Tier 1 enforcement
bounds are altered. Status moved to In Progress. Full resolution requires
adversarial review of the expanded rule before promoting to Specification.

**Resolved (v0.3, 2026-07-17, human-directed):** generalized bidirectionally
and merged with GMP-009, which named the missing other half of this same
gap — non-Axiom content added *within* `Admin/Governance_Charter.md`
itself had no classification either, since the original Track A was
scoped to "documents below Tier 1" and couldn't reach it. Both gaps were
one gap: the axis classified by document location instead of
constitutional impact. Track A and Track B, above, are now defined by
impact — Axiom text, enforcement bounds, interpretation, exceptions — not
by which file the change sits in, with a Constitutional Impact Statement
checklist making the classification auditable rather than subjective.

Adversarial review (this pass, informal — Classes 4/6/9 per the review
that proposed this fix, not a full Battery): (1) Semantic Drift — tested
whether "impact-based" quietly loosens anything the old text-based rule
caught: it doesn't — every case the old rule classified Track B still
checks a box under the new rule, since the boxes are a superset of "touches
Axiom text." (2) Recursive Justification Loop — this rewrite classifies
itself: `Admin/Governance_Migration_Protocol.md` is a Tier 2 document, and
the rewrite changes the migration *process*, not what any Axiom requires
— checks "None of the above," Track A, consistent with EF-0.5 (no
document exempt from its own rules, including this one). (3) Epistemic
Corruption — checked whether "adds a new obligation" could be gamed to
smuggle a loosening through as Track A; addressed directly in the new
"adding a new obligation is not automatically a constitutional exception"
paragraph above, which draws the replace/supersede line explicitly rather
than leaving it to the drafter's framing.

Tested against two live cases: EDL (`Admin/Governance_Charter.md`) and
GOV-013 both check "None of the above" — neither alters Axiom text,
enforcement bounds, interpretation, or introduces an exception; both
formally Track A as of this resolution. See both entries for the applied
classification.

Status: Resolved — Discharge via Specification.

---

### GMP-006 — Concurrent amendment handling undefined

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Resolved — Payment via Specification       |
| Risk          | Medium                                     |
| Priority      | Major                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-19                                 |
| Last Reviewed | 2026-08-31                                 |

**Description:** No doctrine exists for handling multiple simultaneous
Track B proposals. Questions unanswered: can multiple amendments be
active concurrently? Can they be merged? Must they serialize? Can a
pending amendment block a new proposal from entering Phase 1?

**Why It Matters:** Without serialization doctrine, two concurrent
amendments could interact in ways neither individually triggers Track B
classification for — combined effect may alter Tier 1 scope even if
each change individually appears minor. At low v0 amendment frequency
this is theoretical; at higher operational tempo it becomes a real gap.

**Resolution Path:** Define amendment state machine at Draft or above.
Minimum doctrine: concurrent Track B proposals must serialize; no new
proposal may enter Phase 2 while another is in Phase 3. Cross-reference
GMP-008 (expiration) — serialization requires a mechanism for proposals
that stall.

**Consolidation note (added 2026-07-25):** GMP-006, GMP-007, and GMP-008
are three faces of the same missing component — a formal Track B
amendment state machine (states: Draft → Phase 1 → Phase 2 → Phase 3 →
Recorded, with Withdrawn/Expired/Rejected/Returned/Superseded
transitions). Flagged here as the shared resolution target for all
three; not designed in this pass — that's real design work belonging
to whichever of the three is picked up first, not a documentation fix.

**Proposed Resolution (superseded by Closure Event below):** §III.A
Track B Amendment Lifecycle — State Machine. Serialization corridor
(multi Draft/Phase 1; single Phase 2/3); explicit gate; completed
Phase 1 remains in Phase 1 while corridor occupied (no
reservation/priority/expiration from mere completion). Phase 2 → Phase
3 authority corrected against live §III: review is precondition;
reviewer does not advance into Phase 3; presentation to Human Authority
begins Phase 3; Recorded includes Phase 4 recording, and the corridor
releases only upon the transition to Recorded, not upon ratification
alone. Withdrawal phase-scoped; rejection recommend-only for reviewer
unless existing doctrine already grants terminal power. Append-only
history. Deadlock/starvation noted as human-attention, not automatic
preemption — confirmed no existing governance doctrine imposes a
conflicting time-bound ratification obligation.

**Closure Event (2026-08-31):**
- **Unknown:** GMP-006
- **Proposed status:** Resolved
- **Payment type:** Specification
- **Basis:** §III.A Track B Amendment Lifecycle — State Machine (`Admin/Governance_Migration_Protocol.md`, integrated 2026-08-31), summarized in the Proposed Resolution above. Two stale cross-references that would have contradicted this closure — an index line and a Drift Indicator entry, both still describing GMP-006 as pending — corrected in the same pass.
- **Proposer:** Grok — Synthesizer, 2026-08-31. Drafted the original state machine, produced Revision 1 addressing five amendments from a ChatGPT Skeptic pass (Phase 1 concurrency permitted, Superseded authority narrowed, serialization gate made explicit and conditional, withdrawal authority clarified by phase, reviewer rejection narrowed to recommend-only, serialization's claim scoped to concurrent-review bypass only, append-only history added), then produced Revision 2 addressing Claude's independent live-§III verification findings (Phase 2→Phase 3 authority corrected — not a reviewer-executed transition; two stale cross-references flagged) and ChatGPT's final Skeptic-pass items (Phase 4 corridor-release sentence, "repository-wide invariant" framing).
- **Verifier:** Claude — Verifier, 2026-08-31. Two rounds of independent verification against live source, not merely reviewing the drafts' own claims: (1) read `§III` directly and confirmed the existing text names no actor with authority to advance a proposal from Phase 2 to Phase 3 — Grok's original authority table had granted this to the reviewer without it being inherited from existing doctrine, a real overreach caught before integration; separately confirmed no existing §III language assumes concurrent Phase 2/3 proposals, so §III.A introduces no contradiction; separately found two stale cross-references (an index line, a Drift Indicator entry) that neither draft's integration notes had caught, which would have contradicted a closure if left unfixed. (2) Searched `Governance_Migration_Protocol.md` and `Governance_Charter.md` directly for any existing time-bound ratification obligation that could conflict with §III.A.6's "human-attention, not automatic preemption" design note — none found, clean; searched the full file for any other concurrency-permissive language beyond the two already-caught stale references — none found, clean. Verdict: **Pass — Ready for Human Ratification**, with the two stale cross-reference fixes and the Phase 2→Phase 3 authority correction folded in before this Closure Event.
- **Independence attestation:** Grok (Proposer), ChatGPT (two rounds of pre-integration Skeptic passes — Conditional Pass then Pass-with-minor-clarification), and Claude (Verifier, two rounds of independent live-source checks distinct from both agents' review passes) are three different agent instances. Same separated-passes pattern as GMP-010 and GI-004 (`Operations/Gate_01_Intake.md`)/GI-006 (`Operations/Gate_01_Intake.md`).
- **Human ratification:** Not Mandatory under `Admin/Auditor_Protocols.md`'s Unknown Closure Authority (Risk: Medium, not Critical/High) — offered and accepted anyway.
- **Recording location:** this sidecar entry (primary, complete); `Unknowns.md` Active Index entry removed, Audit Trail note added, same pass.
- **Human ratification record:** Ratified by Human Governing Authority, 2026-08-31 ("Let's ratify this. A little cleanup is fine."). Proposer (Grok) and Verifier (Claude) findings both reviewed across multiple rounds; no unresolved objection. Human governing authority noted intent to relay this outcome back to Grok and ChatGPT before further work.

**Resolution:** Closed 2026-08-31 via §III.A Track B Amendment Lifecycle — State Machine, integrated the same day into `Admin/Governance_Migration_Protocol.md`. This closure went through the most extensive multi-round review of any Closure Event to date in this repository: two Grok drafting passes, two ChatGPT Skeptic passes (Conditional Pass, then Pass), and two Claude Verifier passes, each catching genuine issues the prior round had missed (Phase 1 concurrency too strict; unbounded Superseded authority; automatic Phase 1→Phase 2 advancement contradicting the serialization gate; an invented Phase 2→Phase 3 reviewer-advancement authority not actually present in §III; two stale cross-references; a missing corridor-release clarification for Phase 4). Full Closure Event above.

**Residuals:** complete supersession doctrine among unrecorded proposals (deferred, not invented), and operational exercise of the state machine on a live Track B proposal (confidence residual, not a closure blocker) remain Open. GMP-007 (Ratified 2026-09-05 via §III.C) and GMP-008 (Ratified 2026-09-05 via §III.D) have both closed — the full GMP-006/007/008 amendment-lifecycle cluster is now Ratified. Risk and Priority intentionally unchanged.

---

### GMP-007 — Amendment withdrawal procedure undefined

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Ratified — Payment via Specification       |
| Risk          | Low                                        |
| Priority      | Minor                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-19                                 |
| Last Reviewed | 2026-09-05                                 |

**Description:** Track B lacked an explicit withdrawal procedure for a
proposal the proposer or Human Governing Authority wished to terminate
before Recorded. (The §III.A state machine already named a Withdrawn
terminal state and phase-gated authority after GMP-006; full procedure
remained open.)

**Why It Matters:** Without a defined procedure, abandoned proposals
linger ambiguous — neither progressing nor formally closed — and can
interact poorly with serialization.

**Resolution:** §III.C Withdrawal of Pre-Recorded Track B Proposals
(this file, Ratified 2026-09-05). Core rules: Withdrawn is terminal and
**pre-Recorded only**; phase-gated authority (Human-only in Phase 3,
matching §III.A.4's own pre-existing Withdraw rows); logged rationale +
Abandoned Paths entry; corridor release on withdraw from Phase 2/3;
reopen only via new Phase 1 (no partial resumption). Recorded changes
use §III.B, not withdrawal.

**Residuals (do not block Ratified status):**
| ID | Residual | Why left open |
|----|----------|---------------|
| GMP-007-R1 | Live operational exercise of a real withdrawal | No Track B proposal has yet been withdrawn under this procedure; paper closure only |
| GMP-007-R2 | Interaction with GMP-008 expiration timers | Expiration remains a distinct terminal path; both may coexist once GMP-008 closes |
| GMP-007-R3 | Abandoned Paths register format across files | Entry required; exact shared schema deferred if no single register exists yet |

*Surfaced 2026-06-19. Specifiable after GMP-006 (2026-08-31). Specification drafted by Grok 2026-09-05 from the original Resolution Path against live §III.A. Claude ran an independent Skeptic pass 2026-09-05, verifying III.A.3/III.A.4/III.A.5 cross-references directly against source — the withdrawal authority matrix matches III.A.4's own pre-existing Withdraw rows exactly, no invented authority, no blocking findings. Human Governing Authority ratified 2026-09-05.*

---

### GMP-008 — Stale proposal expiration policy undefined

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Ratified — Payment via Specification       |
| Risk          | Low                                        |
| Priority      | Minor                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-06-19                                 |
| Last Reviewed | 2026-09-05                                 |

**Description:** No expiration rule existed for proposals that stall
in Phase 1 or Phase 2. A proposal could theoretically persist indefinitely,
accumulating stale context while blocking serialization (GMP-006).

**Why It Matters:** Future governance cadence is unknown — the appropriate
expiration window depends on audit frequency and operational tempo. At
v0 with very low amendment frequency, this is low risk; at higher tempo
it could become a governance friction point.

**Resolution:** §III.D Expiration of Stalled Pre-Recorded Track B
Proposals (this file, Ratified 2026-09-05). Core rules: Expired is
terminal and **pre-Recorded only**; provisional default is three
consecutive full audit cycles with no qualifying advancement (the
original suggested default, adopted as-is); Phase 3 never auto-expires
(matches §III.A.6's human-attention design note); Human Governing
Authority may extend, early-expire, or change the standing window by
recorded policy without that counting as a Tier 1 Axiom amendment.
Cadence residual (the numeric window's long-term validity) disclosed
honestly rather than inventing a false operational calendar.

**Residuals (do not block Ratified status):**
| ID | Residual | Why left open |
|----|----------|---------------|
| GMP-008-R1 | Binding multi-year cadence calendar | Not created — residual until Trajectories.md's operational tempo milestone is reached; no false calendar invented |
| GMP-008-R2 | Live operational exercise of a real expiration | No Track B proposal has yet stalled long enough to test this; paper closure only |
| GMP-008-R3 | Exact shared definition of "audit cycle" across future tooling | Progress_Log-dated audit heading is the v0 anchor; may need revisiting once automation exists |

*Surfaced 2026-06-19, cross-referencing GMP-006/GMP-007 as one amendment-lifecycle cluster. Specification drafted by Grok 2026-09-05, same day as §III.B/§III.C, completing that cluster. Claude ran an independent Skeptic pass 2026-09-05: verified the "three full audit cycles" default against this entry's own original Resolution Path text (verbatim match, not invented), the §III.A.6 human-attention citation, the pre-existing §III.A.4 Expire authority row, and Trajectories.md's existence — all confirmed accurate, no blocking findings. Human Governing Authority ratified 2026-09-05.*

---

### GMP-009 — Track classification undefined for non-Axiom content changes to the Tier 1 file itself

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Resolved — Discharge via Specification     |
| Risk          | Medium                                     |
| Priority      | Major                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-07-03                                 |
| Last Reviewed | 2026-07-17                                 |

**Description:** The Track identification rule classifies migrations by
whether they touch Tier 1 *Axiom* text, scope, or interpretation. It does
not address a distinct case: a new section added to `Admin/Governance_Charter.md`
itself that is not an Axiom and does not touch Axiom enforcement — procedural
or epistemic content sharing the file with, but not part of, the Protections
and Prohibitions Clauses. Track A's own scope description ("all governance
documents below Tier 1") does not cleanly include this case, since the
target file is Tier 1 by location even though the content is not.

**Why It Matters:** Surfaced by a real proposed amendment (External Design
Lineage Governance, drafted 2026-07-03) that needed classification with no
clean answer in the existing rule. "When in doubt, treat as Track B" is
the stated default, but applying full Track B process (Friction Log,
adversarial Constitutional Capture review, human ratification record) to
non-Axiom procedural content is disproportionate and would likely deter
exactly the kind of housekeeping addition Governance_Charter.md already
contains elsewhere (e.g., the Canonical Verification Gates section).

**Resolved (2026-07-17, human-directed):** not via a third classification
or a Track A sub-case as originally framed here — via recognizing this was
never a separate gap from GMP-005. GMP-005 already established
impact-over-location classification for the downward case (Tier 2 documents
reinterpreting Tier 1). This entry named the missing upward/lateral case
(non-Axiom content within the Tier 1 file itself). Both are the same
principle applied in different directions. GMP-005's resolution generalizes
the rule to be direction-agnostic — see Track A / Track B, above, and
GMP-005's own Resolution field for the adversarial review this pass
included. EDL and GOV-013, both cited below as worked examples, are now
formally classified Track A under the generalized rule.

**Second worked example, 2026-07-16:** `Admin/Governance_Charter.md` GOV-013
(Post-Exit Monitoring Doctrine, Pathway 2/3) is a live second case in the
same unresolved state as EDL — new constitutional content, no Axiom text
touched. Drafted and treated per this entry's own proposed interim minimum
(enforcement-bound confirmation present in that section; human review
recommended, not yet obtained) rather than waiting on this entry's formal
resolution. Both cases resolved to Track A as of this pass — see their
own entries for the classification applied.

---

### GMP-010 — No evidence-sufficiency gate exists between "directed approach" and downstream reliance

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Resolved — Payment via Specification       |
| Risk          | High                                       |
| Priority      | Major                                      |
| Type          | Governance / Epistemic                     |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-07-19                                 |
| Last Reviewed | 2026-08-30                                 |

**Description:** This repository has no defined gate between a human-directed
approach being logged (e.g., `Architecture/Chemistry.md` CE-006's 2026-07-17
directed approach) and other files treating that approach as settled enough
to build on. `Challenges/Closed_Loop_Feedstock.md`'s CLF-004 referenced
CE-006's directed approach as the basis for continuing work before the
underlying mechanism was ever independently verified — and the mechanism
turned out to be wrong (Stage E's KMnO₄ bed does not capture Cl₂; corrected
2026-07-19, see CE-006/CE-007 and `Unknowns_Changelog.md` v4.25). Nothing in
this repository's process would have caught that automatically; it was found
by chance, two days later, via an external model's flag and a manufacturer
datasheet lookup — not by any structural check this repository runs on
itself.

**Why It Matters:** A "directed approach" is explicitly not the same
epistemic weight as ratified, verified doctrine — this repository already
distinguishes those states in principle. But nothing currently prevents a
directed approach from being *treated* as load-bearing by downstream files
before it earns that weight. This is the general failure mode: acceptance
happening because a claim was asserted with authority and went
uncontradicted, not because it was verified. Silence is not confirmation.

**Resolution Path:** Define a lightweight evidence-sufficiency gate for
directed approaches specifically — not full Track A/B ratification process,
which would be disproportionate for a working design decision, but a
minimum bar before other files may cite one as settled: (1) the approach's
core factual/mechanistic claims should be checked against at least one
primary source before downstream files build on it, not just before it's
formally ratified; (2) a directed approach's cross-references in other
files should note its provisional status explicitly (as CE-006's directed
approach note already did — "a directional decision, not a completed
one" — which is why this was recoverable rather than silently wrong
forever) rather than reading as settled fact; (3) consider whether
`Automation/AUDIT_HARNESS.py` could flag cross-references into any file whose
own Status is not yet Verified/Resolved, as a mechanical nudge rather than
relying on someone happening to check.

**Adversarial hardening addendum, 2026-07-19 (human-directed):** the above
resolution path addresses honest error — a directed approach that turns out
wrong despite good-faith effort. A deliberately subversive false claim
exploits the identical structural gap and requires the same fix plus three
specific additions, since "check one primary source" alone is insufficient
against an adversary who can plant or compromise a single source:

1. **Source diversity, not just source primacy.** Extend point (1) above:
   a directed approach's core claims should be checked against more than
   one independent primary source before being treated as settled,
   mirroring the evidence-diversity-over-raw-confidence principle already
   adopted in `Admin/Autonomy_Divergence_Protocol.md` §4 for detection —
   the same logic applies to sourcing generally, not only to subsystem
   monitoring. A single compromised or fabricated source defeats "check a
   primary source" but not "check several independent ones."
2. **No existing doctrine distinguishes wrong-by-accident from
   wrong-by-design.** `Admin/Autonomy_Divergence_Protocol.md` §5 splits
   Capability Anomaly from Governance Concern for *internal* subsystem
   behavior; nothing analogous exists for *external* input — a claim, a
   source, or an AI collaborator's output that is wrong in a way that
   specifically benefits some party, versus wrong through ordinary error.
   Not resolved here — flagged as a genuine, currently-uncovered category,
   candidate for its own future unknown if it recurs rather than solved
   speculatively now.
3. **The multi-agent cross-verification habit that has caught every real
   error this repository has found (CE-006, PC-005, PC-006, UNK-008's
   ownership contradiction) is currently a personal practice, not
   enforced doctrine.** It works because it is done consistently, not
   because anything requires it. Point (3) above — a harness flag on
   cross-references into non-Verified files — is the concrete first step
   toward converting that habit into something the repository enforces
   structurally, so the check still happens on a day no one thinks to do
   it by hand.

*Surfaced during a cross-repo epistemic-logic discussion (human-directed),
grounded in the CE-006 case as a real, not hypothetical, instance of the
failure mode. Logged rather than left as conversational insight, per human
governing authority's direction that this is worth tracking formally.*

**Closure Event (2026-08-30):**
- **Unknown:** GMP-010
- **Proposed status:** Resolved
- **Payment type:** Specification
- **Basis:** §VIII Evidence-Sufficiency Gate (`Admin/Governance_Migration_Protocol.md`, integrated 2026-08-30) lifts the Resolution Path and adversarial-hardening addendum above into dedicated operative doctrine, with amendments beyond the original sidecar text: primary-source definition tightened to exclude peer-reviewed secondary literature from automatically counting as primary; ESG-1's two-source requirement explicitly scoped to externally testable claims where independent primary evidence is reasonably available, with novel/proprietary/repository-generated claims explicitly exempted from the requirement rather than deadlocked by it; "load-bearing" given a concrete three-part operational test; the wrong-by-design category preserved as flagged-not-invented per the original addendum; GMP-010-R1 preserved as the mechanical-enforcement residual. §VI's pre-existing "remains Open pending tooling" sentence rewritten in the same pass so it does not contradict this closure.
- **Proposer:** Grok — Synthesizer, 2026-08-30 (drafted the original integration proposal; produced Revision 1 addressing seven amendments requested in a prior ChatGPT Skeptic pass)
- **Verifier:** Claude — Verifier, 2026-08-30. Independent verification pass performed against the revised text, distinct from ChatGPT's amendment-request review, checking each of the seven requested amendments was actually implemented (not merely claimed) and cross-checking every factual claim in the proposal against live source: §VII/Lessons Learned placement boundary confirmed with no numbering collision; Description/Why It Matters retained verbatim against the pre-closure sidecar; the CE-006 canonical example's dates, mechanism, and "found by chance via manufacturer datasheet" account confirmed exactly against `Architecture/Chemistry.md`'s own record; the `Admin/Autonomy_Divergence_Protocol.md` §4.2 cross-reference confirmed to exist and be correctly titled; the Resolution_Methodology Pattern 6/8 "specification closure is not a de-escalation" citation confirmed accurate and correctly followed (Risk/Priority unchanged, matching the GOV-003/PL-001/WA-002/GR-003 closure precedent); the GMP-013 "same class of residual" claim confirmed consistent with GMP-013's own Resolution Path. Verdict: **Pass — Ready for Human Ratification.** No substantive defect found; all seven ChatGPT-requested amendments confirmed correctly implemented in the revised §VIII text.
- **Independence attestation:** Grok (Proposer), ChatGPT (pre-integration Skeptic pass on the original draft, requested seven amendments), and Claude (Verifier of the revised draft against those seven amendments) are three different agent instances. Per the AP-004 (`Admin/Auditor_Protocols.md`) Closure Event precedent's own stated lesson, the independent-review cycle that produces amendments and the independent-verification cycle that clears the Closure Event are related but distinct passes — ChatGPT's role here was the former, Claude's the latter, kept separate rather than letting one stand in for both.
- **Human ratification:** **Required** — GMP-010 is Risk: High, triggering Mandatory Human Ratification under `Admin/Auditor_Protocols.md`'s Unknown Closure Authority ("Risk = Critical/High").
- **Recording location:** this sidecar entry (primary, complete); `Unknowns.md` Active Index entry removed, Audit Trail note added, same pass.
- **Human ratification record:** Ratified by Human Governing Authority, 2026-08-30 ("I am ready to ratify the amended draft"). Rationale: the amended §VIII correctly incorporates all seven ChatGPT-requested amendments, most importantly resolving the original draft's internal contradiction (a sidecar marked Resolved while the accompanying text said "does not self-close, ready for ratification") and scoping the two-source evidence requirement so it cannot be weaponized against legitimate novel invention. Proposer (Grok) and Verifier (Claude) findings both reviewed; no unresolved objection. Accepted risk: none identified beyond the disclosed GMP-010-R1 residual (mechanical enforcement, Automation scope) and the deliberately-flagged-not-solved wrong-by-design category.

**Resolution:** Closed 2026-08-30 via §VIII Evidence-Sufficiency Gate, integrated the same day into `Admin/Governance_Migration_Protocol.md`. Full Closure Event above: Grok proposed (with a self-produced Revision 1 addressing seven amendments requested by ChatGPT's prior Skeptic pass), Claude independently verified the revision against those seven amendments (Pass, ready for ratification), the Human Governing Authority ratified.

**Residual:** GMP-010-R1 — mechanical harness flag for cross-references into non-Verified / Directed Approach targets remains Open (Automation scope; same class as GMP-013). Risk and Priority fields intentionally unchanged per Resolution_Methodology Pattern 6/8 — specification closure is not a de-escalation.

**Lessons Learned:** This is the first GMP-file unknown closed under the AP-013 (`Admin/Auditor_Protocols.md`) Unknown Closure Authority doctrine, and the first Closure Event where the human governing authority's own ratification message doubled as the trigger for a from-scratch independent Verifier pass rather than a pre-existing one — worth naming, since it confirms the closure discipline holds even when a human has already expressed readiness to ratify: readiness to ratify is not itself the Verifier pass, and the two were kept genuinely separate here rather than treating the human's confidence as a substitute for the missing independent check.

---

### GMP-011 — Track classification dispute resolution undefined — RESOLVED

| Field         | Value                                       |
|---------------|----------------------------------------------|
| Status        | Resolved — Payment via Specification         |
| Risk          | Medium                                       |
| Priority      | Minor                                        |
| Type          | Governance                                   |
| Blocking      | No                                           |
| Owner         | `Admin/Governance_Migration_Protocol.md`     |
| First Logged  | 2026-07-25                                   |
| Last Reviewed | 2026-09-23                                   |

**Description:** GMP-005/GMP-009's constitutional-impact model defines
*how* a change should be classified Track A vs. Track B, and "when in
doubt, Track B" covers genuine uncertainty at classification time. It
does not cover disagreement after a classification has already been
made — if an engineer classifies a change Track A and an auditor
disagrees, no procedure exists for resolving that dispute.

**Why It Matters:** At v0 single-contributor scale this is low-probability
but not zero — multi-agent audit passes already disagree with each other
routinely on other questions (see this file's own GMP-005 resolution,
which took two review rounds to converge). A misclassification dispute
that has no defined resolution path could stall indefinitely or get
settled by whoever argues longest, neither of which is the intended
constitutional discipline.

**Operative Rule (ratified 2026-09-23): Track Classification Dispute
Resolution**

1. **Default.** Any classification that is disputed after it has been
   asserted defaults immediately to Track B for the duration of the
   dispute. No proposal may advance under Track A procedure while the
   dispute remains open.
2. **Logging.** The disputing party (or the first agent to notice the
   conflict) records a one-line entry in the proposal's own Resolution
   Log or in `Admin/Progress_Log.md` under a "Classification Disputes"
   heading: `GMP-011 Dispute | Proposal-ID | Asserted Track | Disputing
   Party | Date | Brief reason`.
3. **Human confirmation.** Resolution requires an explicit Human
   Governing Authority statement of the correct track. That statement
   is appended to the same log entry and is the sole authority that
   lifts the Track-B default.
4. **Genesis Phase holding clause.** While this Forge instance remains
   in Genesis Phase — as declared in `Admin/Governance_Charter.md`
   (Genesis Phase is currently declared entered; no exit pathway has
   yet been satisfied or ratified) — clauses 5 and 6 below are
   suspended:
   - The 14-day timeout in clause 5 does not apply.
   - The repeated-dispute structural-review trigger in clause 6 does
     not apply.
   - Disputes are resolved solely by the default-to-Track-B rule plus
     Human confirmation (clauses 1–3).

   This holding clause tracks Genesis Phase status itself, not any
   single exit pathway — it lifts automatically the moment Human
   Governing Authority records Genesis Phase as exited via *any* of
   the Charter's four ratified pathways (Quorum, Track Record,
   Milestone, or Time-Bounded Review), not only Pathway 1 / GOV-008
   quorum. No separate amendment to this rule is required for the
   holding clause to lift. *(Deliberately not anchored to
   `Governance_Migration_Protocol.md` §VII.5: that section is part of
   §VII, headed "Proposed, Not Ratified," and its own text states that
   nothing in §VII relaxes Genesis Phase rules — using it as the basis
   for a clause that suspends enforcement machinery during Genesis
   Phase would both cite unratified text as load-bearing and invert
   what that text actually says. The Charter's Genesis Phase
   declaration is the ratified, canonical anchor instead.)*
5. **Timeout (applies once Genesis Phase has ended).** If Human
   confirmation has not been received within 14 calendar days of the
   dispute log entry, the proposal is automatically suspended
   (STATE_HOLD equivalent) until confirmation appears. No automatic
   Track-A promotion is ever permitted.
6. **Repeated disputes (applies once Genesis Phase has ended).** Three
   or more disputes on the same proposal *type* (not the same
   individual proposal) within any rolling 90-day window trigger a
   mandatory structural review: the classification criteria themselves
   (GMP-005 / GMP-009) must be examined for ambiguity and, if
   necessary, amended under ordinary Track B procedure. The review is
   logged as a GMP-011-R1 residual and does not itself block the
   original proposals.
7. **No new track or emergency path.** This rule creates neither a
   third track nor an emergency override. It is strictly a temporary
   re-routing to the more conservative procedure already defined.

**Resolution Path:** Closed via the Operative Rule above, which
elevates the 2026-07-31 interim minimum rule to a permanent rule and
resolves all three previously-open design points (dispute logging
format, human-confirmation timeout, repeated-dispute structural-fix
trigger) with the lightest machinery consistent with v0
single-contributor + multi-agent-audit reality, deferring the fuller
timeout/structural-review discipline until Genesis Phase actually ends
rather than making it dead-letter machinery in the meantime.

*Surfaced via external audit review (ChatGPT), checked against this
file's actual Track identification rule and "when in doubt" doctrine
before registration — confirmed the dispute-after-classification case
is genuinely uncovered, not already handled by existing language;
registered by Claude — Synthesizer/Auditor, human-directed, 2026-07-25.
Interim rule adopted 2026-07-31 per Skeptic/Auditor recommendation.
Resolution drafted by Grok (initial + Genesis-phase holding-clause
revision), source-verified by Claude against this file's live §VII.5
text and `Governance_Charter.md`'s Genesis Phase exit-pathway doctrine
— caught and corrected a citation error in the draft (§VII.5 was cited
as supporting a relaxation during Genesis Phase; live text says the
opposite) and a scope error (holding-clause expiry was worded as tied
only to GOV-008 quorum rather than to any of the Charter's four exit
pathways) before filing. Ratified by Human Governing Authority,
2026-09-23.*

---

### GMP-012 — No rollback or repeal doctrine for a ratified Track B amendment

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Ratified — Payment via Specification       |
| Risk          | Medium                                     |
| Priority      | Minor                                      |
| Type          | Governance                                 |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-07-25                                 |
| Last Reviewed | 2026-09-05                                 |

**Description:** Track B's Phase 1–4 procedure defines how a Tier 1
Axiom amendment gets ratified. Nothing defined what happens if a
ratified amendment later proves harmful — is reversal a fresh Track B
amendment reversing the text, a restoration from the pre-amendment
archived state, or does it require a distinct emergency procedure?

**Why It Matters:** Without this, a bad ratification has no defined
exit other than improvising under pressure rather than following a
settled procedure.

**Resolution:** §III.B Repeal and Rollback of Recorded Track B Amendments
(this file, Ratified 2026-09-05). Core rule: repeal/rollback/restore/replace
of a **Recorded** Track B amendment is itself Track B; no emergency
shortcut; Restore vs Replace vs Partial repeal is documented Phase 1
judgment; append-only history preserved; Hard Floor remains out of
scope. Aligns with §III.A invariant that Recorded is terminal and
further change is a new proposal.

**Residuals (do not block Ratified status):**
| ID | Residual | Why left open |
|----|----------|---------------|
| GMP-012-R1 | Live operational exercise of a real repeal | No Recorded Tier 1 amendment has yet been repealed; paper closure only |
| GMP-012-R2 | Full supersession doctrine among *unrecorded* proposals | Still deferred per §III.A.7; distinct from Recorded repeal |
| GMP-012-R3 | Interaction with future GMP-007/008 once those close | Withdrawal/expiration apply only pre-Recorded; boundary already stated in §III.B.6 |

*Surfaced 2026-07-25 (ChatGPT external audit; Claude registered). Specification drafted by Grok 2026-09-05 from the original Resolution Path minimum candidate, expanded into §III.B and checked against live §III.A state machine (Recorded terminal; forbidden Recorded→other; serialization; Hard Floor). Claude ran an independent Skeptic pass 2026-09-05, verifying every §III.A cross-reference and the Hard Floor claim directly against source — all confirmed accurate, no blocking findings. Human Governing Authority ratified 2026-09-05.*

---

### GMP-013 — Epistemic Quorum Doctrine has no tooling or machine-readable metadata

| Field         | Value                                      |
|---------------|--------------------------------------------|
| Status        | Open                                       |
| Risk          | Low                                        |
| Priority      | Minor                                      |
| Type          | Technical / Governance                     |
| Blocking      | No                                         |
| Owner         | `Admin/Governance_Migration_Protocol.md`   |
| First Logged  | 2026-07-26                                 |
| Last Reviewed | 2026-11-13                                 |

**Description:** §VI Epistemic Quorum Doctrine defines quorum
requirements, independence dimensions, and an outcome taxonomy, but
nothing verifies compliance — a Track B proposal could claim
"Qualified Consensus" from a quorum that didn't actually satisfy the
independence dimensions, and nothing would catch it. Multi-agent
proposals during drafting (this file's own recent history included)
suggested machine-readable quorum metadata (participant roles, models,
outcome, dissent flag) that `Automation/AUDIT_HARNESS.py` could
eventually verify.

**Why It Matters:** Low urgency at v0 single-contributor scale, where
quorum composition is currently reviewable by direct read of the
conversation record. Becomes more important as amendment frequency or
contributor count grows and self-reported quorum outcomes become
harder to spot-check.

**Resolution Path:** Deferred via Specification. Not designed here —
this is `Automation/AUDIT_HARNESS.py` implementation scope (see
`Admin/Repository_Integrity_Protocol.md` RIP-002 for the existing
pattern of specification-now, implementation-later for that harness).
A minimal future schema was suggested during drafting (participant
role/model list, outcome value, dissent boolean) as a starting point,
not a commitment. That schema now has a second consumer beyond
point-in-time compliance checking: §VI's Quorum Compliance Trend
subsection (added 2026-07-26) computes a per-cycle conformance rate
from the same fields — no new schema requirement, but the eventual
implementation should account for both uses rather than only the
original spot-check case.

*Surfaced during EQD drafting (external multi-agent synthesis,
human-directed); scoped down from an inline schema draft to a logged
future-tooling gap, consistent with this file's own discipline of not
mixing specification with unbuilt implementation. Registered by
Claude — Synthesizer/Auditor, human-directed, 2026-07-26.*

---

### Resolution Log

- 2026-11-13: **MAINT-141 — A1a consolidated completion pass, owed-review cohort (Decision Brief 2026-11-13 A1a Line 1 RATIFY + Line 3 CARRY, human ruling "Let's take your lean as the direction. Please proceed."; Vibe — Architect line PRIMARY, Repo Custodian secondary; co-author mandate 2026-11-02/04, extended 2026-11-11; non-independent — the same line drafted the brief and executes its remedy; disclosed; human veto window open).** Two of this file's registered open sidecar entries tripped the 90-day owed-review bar at 2026-11-13 (Last Reviewed before 2026-08-15): GMP-003, GMP-013. Each was genuinely re-read against the live body this pass; findings recorded, findings-only — no entry text rewritten, no status changed, no unknown opened or closed: GMP-003 — adversarial review at v0 (Phase 2) remains underspecified for the repository's actual single-contributor context; unchanged since the 2026-09-03 correction pass; GMP-013 — §VI Epistemic Quorum Doctrine remains doctrine text without tooling or machine-readable metadata. Last Reviewed advanced to 2026-11-13 for both. Open Unknowns unchanged at 4 (GMP-002, 003, 004, 013). No doctrine text changed; the trailing Status block stays bare per its standing deliberate-non-update decision; this log stays bare-textured per its own frozen-history scope notes.
- 2026-11-11: **MAINT-130 batch 4e — stale version pin retired (Decision Brief 2026-11-11 Item 5B residue, F-GMP-3; Vibe — Repo Custodian, delegated line under the 2026-11-04 co-author mandate extended 2026-11-11; non-independent — the same line ran Campaign 4; disclosed; human veto window open).** The Relationship section's Security_Protocols bullet pinned the file "at v0.5 (2026-06-19)"; SP has advanced far past v0.5 and the dependency is on SP reaching Provisional Specification, not a frozen version. Pin retired in place with a dated tag, per the PKC-022 pin-retirement precedent. Citation-form-only; no doctrine or gate change; version and Last Audit not advanced (findings-only form, PKC-020 split policy).
- 2026-11-11: **Tail restoration from git (MAINT-130; Decision Brief 2026-11-11 Item 9a).** The file had ended mid-word ("...second consumer of its al") since commit 7a698608 (2026-08-01); the cut point was stable across every later commit. The missing tail — the end of the Version 0.7 Status entry, the Version 0.6, 0.5, 0.4 and 0.3 entries, and the closing "What must remain constant" footer (2,410 characters) — restored verbatim from commit 42e8b4b1 (2026-07-26, the last complete state). Post-truncation commits grew the file only above the cut point, so nothing legitimate was lost in the restored region. Restored text verified escape-free; no other body text touched; version unchanged (restoration, not amendment). Executed under the co-author delegation (2026-11-04 mandate, extended 2026-11-11); non-independent, disclosed; human veto window open.
- 2026-11-05: **MAINT-63 X3 straggler citation pass (mechanical).** 20 bare colliding-prefix citations in §Assumptions and §VII qualified with their owning File.md per PKC-003 — 18 × GOV-008 and 1 × GOV-006 (both → `Admin/Governance_Charter.md`), 1 × CIR-GOV-001 (→ `Admin/CIR_Gov.md`) — on 15 lines (two carry two instances, one carries four), per the enumerated instance list in `Archive/Audits/EXECUTION_2026-11-05_MAINT-63.md` §1 (per-ID grounding: Unknowns active index; CAMPAIGN2_AUDIT_73 N2). Citation-form-only; no content change; frozen history untouched (this log, File State pass-notes and the trailing Status block stay bare). Preserved bare by scope: the PKC-016 dated annotations (×2) and the backticked pre-rename `CIR-001` inside the 2026-08-06 provenance note; remaining bare GOV-008 mentions outside the audit-flagged zones (Scope Boundary, §VIII, Drift Indicators, Auditor Notes and Unknowns entries) are enumerated in the execution record for any future straggler pass. Human-ratified MAINT-62 ruling set §2 Category A. (Vibe — Architect line PRIMARY, Repo Custodian secondary.)

- 2026-10-29: **X3 citation retrofit (mechanical).** 6 bare colliding-prefix citations in operative body text qualified with their owning File.md per PKC-003, per the human-ruled Decision Brief 2026-10-29 item 4A (registry: Kit v1.29 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only; no ID renumbered; frozen history untouched; flagged instances reported to the human (MAINT-11). (Vibe, Repo Custodian — delegated line.)

- 2026-10-28 (later same-day): **Scope Boundary: Fork Reconciliation Track listed (AUDIT_02 F1; Vibe, Repo Custodian — delegated maintenance, human-ratified batch 2026-10-28c).** The DOES-define inventory now names the Fork Reconciliation Track (GOV-018) — the operative procedure skeleton has existed in this file's body since the GOV-018 closure (2026-08-23) but was never listed in the Scope Boundary inventory. No doctrine change; no gate advanced; no unknown opened or closed.

- 2026-10-28: **VG Status-precedence line propagated + pseudo-audit ledger line (Vibe, Repo Custodian — delegated maintenance, human-ratified findings batch 2026-10-28).** (1) The trailing Status section now carries the precedence sentence from `Admin/Verification_Gates.md` (AUDIT_09 F4(a)): the File State header is authoritative if the Status block and it ever disagree. (2) Pseudo-audit, findings only, 2026-10-27; report: Archive/Audits/AUDIT_02_Admin-Governance_Migration_Protocol.md (PKC-020 — the pass itself advanced nothing; this file's Last Audit advance records today's maintenance edit, not the pseudo-audit). No gate advanced; no unknown opened or closed.

- 2026-10-26: **§VII.6 item 1 marked done (PKC-016; no doctrine change).** The near-term action list still described the GMP-011 minimum dispute-resolution rule as "not yet executed" although GMP-011 was resolved 2026-09-23. Item 1 is now struck through with a dated done annotation, mirroring the 2026-10-23 fix in `Admin/Hardware_Diversity_Ladder.md`; the heading now states that items 2–4 remain open. §VII.6 is Candidate-specification text — a completed checklist item was marked complete, nothing rewritten; no ratified or FROZEN text modified. Human-directed. (Related: the dangling "Classification Disputes" heading of PKC-008 was resolved 2026-10-25 in `Admin/Progress_Log.md`; this file was not edited for that.)

- 2026-09-23: **GMP-011 resolved — Track classification dispute rule ratified (Payment via Specification), including the Genesis Phase holding clause on the timeout/structural-review sub-rules.** Drafted by Grok; source-verified by Claude against this file's live §VII.5 and the Charter's Genesis Phase exit-pathway doctrine, which caught and corrected a citation error (§VII.5 had been cited as supporting a Genesis-Phase relaxation; the live text says the opposite) and a scope error (holding-clause expiry was tied only to GOV-008 quorum rather than to any of the Charter's four exit pathways). Ratified by Human Governing Authority. Full closure detail in the GMP-011 sidecar. *(Backfilled 2026-10-23 from the in-file closure statement; this entry was missing when the pass landed.)*

- 2026-09-18: **§VII.2 amended — role rotation across quorum cycles added (permitted, not required); GMP-004 sidecar gained solo-operator residual and scope fences.** Human-directed. §VII.2 remains a Candidate specification, unratified; the amendment states its limitations explicitly (does not satisfy the Diversity/Independence tests by itself, does not touch Hardware/Runtime Diversity). Rotation-assignment authority recorded as an open item in §VII.6. GMP-004's sidecar gained the solo-operator residual and scope fences against GOV-006 and GOV-019. No unknown closed. *(Backfilled 2026-10-23 from in-file dated markers.)*

- 2026-09-05: **§III.B, §III.C and §III.D ratified — repeal/rollback (GMP-012), withdrawal (GMP-007) and expiration (GMP-008) of Track B proposals.** Drafted by Grok; Claude ran Skeptic passes and merge integrity checks on all three; ratified by Human Governing Authority. Closure statements are at the end of each section; sidecar Closure Events carry the detail. *(Backfilled 2026-10-23 from File State and the section closure statements.)*

- 2026-09-03: **Integrity repair (Grok).** FROZEN markers placed on the Track A/B classification rule, the §III.A state machine, §VI EQD core distinctions and §VIII ESG core distinctions. Other changes made in this pass are not itemized in this file; see the Auditor field. *(Backfilled 2026-10-23 from the FROZEN markers and the Auditor field.)*

- 2026-08-31: **§III.A Track B Amendment Lifecycle (state machine) integrated — GMP-006 resolved, Payment via Specification.** Drafted by Grok (Revision 1 addressed a ChatGPT Skeptic pass); independently verified by Claude against live source; ratified by Human Governing Authority. Detail in the GMP-006 Closure Event. *(Backfilled 2026-10-23 from the Closure Event.)*

- 2026-08-07: **§VII.2 and §VII.3.3 tightened — Coupled-orchestration rule and Decision-weight method added, closing ClaudeAudit Class 5 (coupled-orchestration decision-weight for non-executing/advisory roles).** VII.2's four-class taxonomy previously said nothing about sub-agents spawned inside the same runtime/session as another class — nominally distinct instances could remain architecturally coupled while still counting as separate classes. Added: a coupled set now counts as one unit for class counting and decision weight, using the same independence standard §VI and the (Class 9-updated) VII.4 already require. VII.3.3's 50% decision-weight rule previously had no method for weighting non-executing roles against an Executor — added: only roles that can block or authorize carry weight; Skeptic/Auditor roles with no execution or final-authorization power carry zero. Deliberately no fractional weighting scheme — zero-for-advisory is the conservative floor, not a calibrated parameter. Both patches drafted by Grok; both source quotes (the VII.2 cross-reference paragraph, VII.3 item 3) verified exact against this file's live text before applying.

  One claim in Grok's proposed disposition note was not applied: it characterized this as closing "the original three-finding set (Classes 4, 9, and 5)" from the 2026-08-03 cold pass. Checked against that pass's own Resolution Log entry below — it names no "Class 4" anywhere, describes its two acted-on findings by content only, and states explicitly that the ten-class battery "surfaced ten findings; two were acted on." There is no source basis for a specific "Class 4" label, and no claim that only three of the ten findings were ever relevant. What's accurate: together with Class 9 (closed 2026-08-07, same session) and the two content-described findings from 2026-08-03, four total findings from that cold pass have now been acted on. The other six, whatever they were, remain unaddressed and undocumented here — this patch does not claim otherwise.

  No new unknowns opened. No claim that GOV-008 is closer to satisfied — both additions clarify how the existing VII.2/VII.3 counting and weighting rules apply under coupling and non-execution; they don't touch VII.1's quorum requirements or the hardware-substrate gate. Operating as Synthesizer, human-directed.

- 2026-08-07: **§VII.4 tightened — Diversity test and Non-collusion test both gained a "vendor label ≠ epistemic independence" clause, closing ClaudeAudit Class 9 (vendor-diversity vs. epistemic-diversity conflation risk).** The Diversity test previously measured only provider + architecture family; nothing stopped two differently-labeled sessions given identical prompts and shared framing from technically passing it. Added: vendor/architecture label declared necessary but not sufficient, with diversity required along §VI's existing Three Independence Dimensions instead. The Non-collusion test's "to be defined" probes were given an explicit target — detecting identical prompting/shared framing across vendors is now the named failure mode they must catch, not an implicit assumption. No new independence dimension invented; both additions point at §VI's existing three (model/evidence/role), already ratified. Drafted by Grok, verified against this section's actual live text (matched exactly) and against §VI's Three Independence Dimensions (confirmed real, not fabricated) before applying. No claim that GOV-008 is closer to satisfied — this narrows what the Diversity/Non-collusion tests will accept, it doesn't change VII.1–VII.3's quorum requirements or this section's Status (Candidate, Not Ratified). Class 5 (coupled-orchestration decision-weight for advisory/non-executing roles) remains the other open ClaudeAudit finding, intentionally left for a separate patch. Operating as Synthesizer, human-directed.
- 2026-08-06: **§VII.8 added — Registry Data Model & Runtime Gate (Extension, Not Yet Ratified), reconciliation of an independent multi-agent thread against source.** An independent Grok/Copilot thread produced a full parallel GOV-008 definition, quorum checklist, registry spec, and escalation protocol without loading this section, `Unknowns.md`, or `CIR_Gov.md` §8.2. Its patch to insert a second GOV-008 definition directly into `Governance_Charter.md` was rejected: `Unknowns.md`'s canonical entry already owns GOV-008 here, and a second Charter-level definition would recreate the "colliding local GOV-008" incident already corrected 2026-07-28. Its Model/Evidence Independence framing was identified as the repackaged-EQD drafting error this section's own opening paragraph already warns against. The one genuinely additive piece — a concrete registry data schema and runtime pre-check that VII.1–VII.4 describe operationally but never formalize — was preserved as §VII.8, explicitly framed as extending this section, not competing with it. VII.1–VII.4's requirements, VII.5's escalation rule, and this section's Status (Candidate, Not Ratified, Payment via Specification only) are unchanged. Open Unknowns unchanged; GOV-008 remains Open. Operating as Synthesizer, human-directed.
- 2026-08-03: **v0.10 — §VII cold Battery pass integrated (two of
  three findings; the third parked for later).** A Skeptic/Auditor
  cold-session pass against §VII + `Admin/Governance_Charter.md`
  (bundled via the real cold-session tooling, ten-class Adversarial
  Challenge Battery applied, checked exhaustively against source
  before anything was trusted — every specific claim it made verified
  accurate) surfaced ten findings; two were acted on here. (1) VII.1's
  Hardware/Runtime Diversity row previously said logical isolation
  "must be upgraded to physical/logical isolation before v1" — the
  slash was genuinely ambiguous, readable as either "physical is the
  real bar" or "physical OR logical satisfies v1," sitting directly on
  the one requirement this section exists to add beyond §VI. Resolved
  unambiguously: the v1 bar is physical hardware diversity; logical-
  only (Tier 0 in `Admin/Trajectories.md` TR-GOV-001's ladder) does not
  satisfy it regardless of isolation strength. (2) VII.3.4/5's
  ratification-recording requirements inherited GMP-004's already-
  registered, already-unenforced forgery vulnerability without saying
  so — added an explicit cross-reference naming that inheritance,
  without resolving GMP-004 itself. Not yet done: adding §VII to
  `Admin/Auditor_Protocols.md`'s Challenge Class 10 high-coupling
  documents table (the pass's third concrete recommendation) — queued
  as the next action, not forgotten. §VII's ambiguous-decision-weight
  question for coupled orchestration architectures (Class 5) and the
  vendor-diversity-vs-epistemic-diversity conflation risk (Class 9) are
  both logged as genuine open findings, not yet actioned — this file's
  own Open Unknowns count is unaffected since neither was assigned a
  GMP- ID by the cold instance (it correctly declined to, having no
  confirmed sidecar/registry access — same discipline established via
  AP-033/Rule 9 elsewhere this session). §VII remains un-ratified;
  this pass improved the candidate text, it did not clear it for
  ratification.

- 2026-07-31: **v0.9 — Skeptic/Auditor review of §VII integrated.** An
  external review of the v0.8 candidate state was checked against
  source before acceptance: all cited GMP-004/006/007/008/011/012 and
  ASM-002 details confirmed exact, all cited GOV-008 sidecar and §VI
  Non-goal language confirmed exact. The review's central finding —
  that VII.1's Hardware/Runtime Diversity and Non-Simulatability
  requirements are currently declarable, not achieved, since no second
  physical host or independent verification system exists anywhere in
  this repository's actual operating environment — was accepted as
  correct and given prominent placement at the top of VII.6, ahead of
  the routine ratification questions, rather than buried as one item
  among several. Four near-term action items from the review recorded
  verbatim in VII.6. GMP-011 upgraded from a flagged candidate rule to
  an adopted interim rule (disputed classifications default to Track B
  for the dispute's duration, human confirmation required) per the
  review's specific recommendation that leaving a workable minimum
  undesigned had no remaining benefit. A companion hardware-diversity
  implementation ladder (Tier 0 interim logical isolation through Tier
  3 full TMR alignment) was checked against `Operations/Electronics.md`
  source — its silicon/firmware/power-path/thermal/procurement
  diversity claim confirmed as an exact match to that file's own EL-007
  and 2026-05-09 audit entry — and parked at `Admin/Trajectories.md`
  TR-GOV-001 as a reference for future implementation, explicitly not
  as a claim that any of it currently exists. No status change to
  GOV-008 itself resulted from this pass; per the review's own fourth
  recommendation, no progress on GOV-008 may be claimed until a real
  second runtime exists. Operating as Synthesizer per
  Auditor_Protocols.md v0.29, human-directed.

- 2026-07-31: **v0.8 — §VII Bootstrap Quorum Doctrine added as a
  candidate GOV-008 specification**, drafted from an external candidate
  spec and refined after verifying its claims against GOV-008's actual
  sidecar entry (`Archive/Logs/Governance_Charter_Changelog.md`) and
  §VI's own Non-goal clause. Deliberately held to the higher
  governance-independence bar §VI explicitly disclaims meeting — the
  section leads with a restatement of that clause and flags its own
  Hardware/Runtime Diversity requirement as the specific line EQD's
  quorum structurally cannot cross. Explicitly filed Candidate — not
  ratified, does not resolve GOV-008, existence of the section is
  Payment via Specification only. Six subsections: Core Requirements,
  Agent Class Taxonomy, Operational Definition of Quorum Achieved,
  Verification & Independence Criteria, Interim & Escalation Rules,
  Open Items for Ratification Review — plus a Relationship subsection
  noting `Admin/CIR_Gov.md`'s §8.2 already depends on this section
  existing and being ratified. Cross-referenced back into GOV-008's own
  sidecar entry and `Unknowns.md` same-day. Operating as Synthesizer
  per Auditor_Protocols.md v0.29, human-directed.

- 2026-07-26: **v0.7 — Quorum Compliance Trend subsection added to
  §VI EQD**, directly under the existing Resolution-status paragraph.
  Defines a per-cycle conformance rate (qualifying actions whose
  quorum met the Minimum Quorum Matrix's size *and* independence
  requirements, over all qualifying actions that cycle), tracked
  across cycles rather than gated on any single value — 100% is the
  aspiration, not a bar for the doctrine's validity; a 3+ cycle
  declining trend is the actual signal. Explicitly restates the
  Non-goal clause for this new subsection specifically, since a naive
  reading of "compliance trending up" is exactly the kind of claim
  the existing Drift Indicator (added at v0.6) exists to catch if
  mis-cited as GOV-008 progress. GMP-013 updated to note its deferred
  metadata schema now has two consumers (point-in-time compliance
  check, and this trend) rather than designing a second schema.
  Originated from a human question about applying "persistent
  improvement over perfection" to governance quorum — redirected from
  an initial GOV-008-adjacent framing (identified during discussion as
  a near-repeat of the exact conflation error GMP-013/EQD's Non-goal
  clause was written to prevent) to EQD's own conformance instead,
  where incremental improvement is honestly measurable. Human-directed
  throughout; no automation implemented, per GMP-013's existing
  deferral.

- 2026-07-27: **v0.6 — Polish pass on EQD integration, external review
  (Grok, Gemini) checked against source before adoption
  (human-directed).** Six items confirmed real and fixed: (1) Phase 2
  gained an explicit "Subject to §VI EQD" anchor, so the link is
  operational at the point of use, not only referential from EQD's own
  text. (2) GMP-003's Last Reviewed date was still 2026-06-05 despite
  the 2026-07-26 partial-mitigation note being added to it that same
  pass — corrected to 2026-07-26. (3) GMP-003 gained a forward-looking
  sentence recommending first EQD application on the next real or
  simulated Track B proposal, so the entry doesn't sit Open indefinitely
  for lack of a live test case. (4) New Drift Indicator added guarding
  EQD's Non-goal clause specifically — any future amendment citing EQD
  as GOV-008 progress must itself be flagged as a misclassification. (5)
  ASM-002's confidence note updated to reflect EQD as a partial answer
  on the epistemic-quorum half only, GOV-008's governance-quorum half
  unchanged. (6) A mirrored non-resolution note added to GOV-008 itself
  in `Archive/Logs/Governance_Charter_Changelog.md`, so the
  epistemic/governance independence distinction is visible from both
  files rather than only from EQD's side — `Admin/Governance_Charter.md`
  touched for this, Status/Risk/Resolution Path on GOV-008 unchanged.
  One suggested item not adopted: Grok's proposed baseline summary table
  duplicates the File State header's existing fields and was left out
  as redundant rather than added a second time in a different format.
  Open Unknowns unchanged at 10 — no entry added or resolved this pass.

- 2026-07-26: **v0.5 — §VI Epistemic Quorum Doctrine (EQD) added;
  GMP-003 partially mitigated; GMP-013 registered (human-directed,
  four-way external multi-agent synthesis: ChatGPT, Gemini, Grok,
  reviewed against source before adoption).** A proposal to formalize
  multi-agent quorum requirements converged across three external
  agents but initially conflated two different kinds of independence —
  epistemic (independent reasoning/evidence) and governance
  (independent authority capable of enforcement) — and an early draft
  marked GOV-008 "POPULATED" and GMP-003/GMP-010 "RESOLVED" on that
  basis. Checked against `Admin/Governance_Charter.md`'s actual GOV-008
  text before adopting anything: GOV-008 requires hardware diversity
  and "a functional, multi-party enforcement substrate, not a declared
  intention to pursue one" — a quorum of advisory chat sessions
  directed by a single human principal does not meet that bar,
  regardless of model-provider diversity. Adopted instead as EQD,
  scoped explicitly to epistemic review quality via a binding Non-goal
  clause disclaiming any GOV-008/Genesis-Phase relevance — this
  distinction is treated as load-bearing, with an explicit rule that
  any future edit citing EQD as GOV-008 progress is itself a
  misclassification under GMP-005/GMP-009. Three independence
  dimensions (model, evidence, role) adopted, generalizing
  `Admin/Auditor_Protocols.md` AP-017's existing informational-
  independence standard from single review to quorum. Outcome taxonomy
  (Consensus/Qualified Consensus/Split Decision/Failed Review) adopted
  as proposed. Machine-readable quorum metadata for
  `Automation/AUDIT_HARNESS.py` was not drafted into doctrine text —
  logged as **GMP-013** instead, consistent with this repository's
  specification-before-implementation discipline. GMP-003's resolution
  path updated to reference EQD and explicitly correct its own prior
  imprecise claim that quorum "resolves GOV-008 structurally" — status
  remains Open pending a real Track B proposal reviewed under the new
  standard. GOV-008 itself was not edited in this file; a cross-
  reference noting EQD's Non-goal clause is recommended for
  `Admin/Governance_Charter.md`'s GOV-008 entry as a follow-up, not
  done here since that file is owned separately. Open Unknowns 9 → 10
  (GMP-013 added; no entry resolved by this addition alone).

- 2026-07-25: **v0.4 — External audit review triaged (ChatGPT, Grok);
  maintenance fixes and two new unknowns registered (human-directed).**
  Four externally-authored review passes checked against this file's
  actual current text before anything was adopted. Confirmed real and
  fixed: GMP-003's Last Reviewed date preceded its First Logged date
  (typo); Open Unknowns header claimed 8 but the sidecar table actually
  contained 7 Open entries (GMP-001/005/009 are Resolved) — the
  2026-07-19 log entry's own "7 → 8" arithmetic didn't match the table
  it described; Lessons Learned had sat empty since file creation
  despite substantial resolvable history in this Resolution Log;
  Status section was frozen at "Version 0.3" despite GMP-005/009's
  resolution and GMP-010's registration both landing after that entry.
  Two new unknowns registered after checking each was genuinely
  uncovered by existing doctrine: **GMP-011** (classification dispute
  resolution — "when in doubt, Track B" covers uncertainty, not
  disagreement after classification) and **GMP-012** (no rollback/repeal
  doctrine for a ratified amendment that later proves harmful).
  GMP-006/007/008 gained a shared consolidation note pointing at a
  future amendment state machine — flagged, not designed, in this pass.
  GMP-004 gained a cross-reference to existing GPG signing precedent
  already established via `Admin/Repository_Integrity_Protocol.md`
  RIP-001, as a lower-friction lead for `Admin/Security_Protocols.md`'s
  eventual implementation. A separate proposal recommending hardware
  security modules, multi-approver quorum policy, and blockchain
  anchoring was reviewed and explicitly not adopted — assessed as
  disproportionate to a single-contributor v0 project and inconsistent
  with this repository's existing rejection of premature cryptographic
  enforcement (`Admin/Repository_Integrity_Protocol.md` Abandoned Paths).
  Open Unknowns 7 → 9 (corrected baseline, then GMP-011 and GMP-012 added).

- 2026-07-17: **GMP-005 and GMP-009 resolved together; Track A/B
  redefined by constitutional impact, not document location.** Multi-agent
  review (two rounds — a "third track" proposal, then a redefinition
  proposal identifying GMP-005 as already-established precedent) converged
  on: don't add a Track C, generalize the existing rule. Track A and Track
  B, above, now classify by whether a change touches Tier 1 Axiom text,
  enforcement bounds, interpretation, or exceptions — regardless of which
  file — replacing the prior location-based split ("Tiers 2-5" vs. "the
  eight Axioms in Governance_Charter.md") that had no room for non-Axiom
  content added to the Tier 1 file itself. Constitutional Impact Statement
  checklist added to make classification auditable. "When in doubt, Track
  B" and "misclassification is a Constitutional violation" carried forward
  explicitly onto the new axis, not dropped in the rewrite. New paragraph
  distinguishes obligations that add scrutiny (Track A) from changes that
  replace or supersede an enforcement mechanism (Track B), closing a gaming
  vector the review process itself flagged. Adversarial review this pass
  (informal — Semantic Drift, Recursive Justification Loop, Epistemic
  Corruption) documented in GMP-005's entry, including the rule
  classifying its own amendment as Track A. EDL and GOV-013
  (`Admin/Governance_Charter.md`) both formally classified Track A —
  see their entries. GMP-002 (migration doctrine ownership transfer,
  still Open) may be affected by this rewrite; not reviewed this pass.
  Open Unknowns 9 → 7.

- 2026-07-19: **GMP-010 adversarial hardening addendum.** Extended to cover
  deliberate subversion, not just honest error, at human governing
  authority's direction. Three additions: source diversity (not just
  primacy) required for directed-approach claims, mirroring
  `Admin/Autonomy_Divergence_Protocol.md` §4's evidence-diversity
  principle applied to sourcing generally; flagged the absence of any
  wrong-by-accident vs. wrong-by-design classification for external
  input (no action taken — genuinely new category, not solved
  speculatively); named the repository's multi-agent cross-verification
  practice as currently personal habit, not enforced doctrine, and
  pointed at the harness cross-reference flag (already in GMP-010's
  original resolution path) as the concrete first step toward making it
  structural.

- 2026-07-19: **GMP-010 registered.** No evidence-sufficiency gate exists
  between a directed approach being logged and other files treating it as
  settled. Grounded in a real case, not a hypothetical: CE-006's 2026-07-17
  directed approach was cited by CLF-004 as basis for continued work before
  independent verification — the underlying mechanism was wrong, caught by
  chance two days later, not by any structural check. Surfaced during a
  cross-repo epistemic-logic discussion (human-directed). Open Unknowns
  7 → 8.

- 2026-07-16: **GMP-009 cross-referenced to GOV-013.** While drafting
  `Admin/Governance_Charter.md` GOV-013 (Post-Exit Monitoring Doctrine,
  Pathway 2/3), determined it doesn't cleanly fit Track A or Track B —
  it's GMP-009's already-open gap (non-Axiom content added to a Tier 1
  file), not a fresh classification question. Added GOV-013 as a second
  worked example alongside EDL in GMP-009's entry; GMP-009 itself not
  resolved here, left for its own review. Separately: this file's own
  File State Last Audit header was stale against its own body content
  (GMP-005/GMP-009 both dated later than the header) — flagged in the
  header rather than fully re-dated, since establishing the file's true
  last-touch history is a separate task not attempted this pass.

- 2026-06-05: File created (v0.1) — GOV-001 resolution path initiated.
  Two-track migration architecture established. Phase 1–4 Track B procedure
  defined. Hard floor declared for Anti-Weaponization, Ethical Anchor, and
  humanitarian override closure. GMP-001 through GMP-005 logged. Honest v0
  acknowledgment of bootstrap limitations added.
- 2026-06-19: v0.2 — Three-agent audit pass (ChatGPT, Gemini, Grok) plus
  Claude synthesis. Eleven changes: (1) Navigation Anchors added.
  (2) Verification Ref confirmed — `Admin/Verification_Gates.md` is
  correct; session-context false positive from agents working without full
  registry not applied. (3) Ownership transfer dual-truth-state resolved —
  "takes over ownership" replaced with "proposed to assume ownership pending
  Charter update and Gate 4 clearance." (4) Track identification rule
  expanded — now explicitly covers Tier 2/lower document changes that alter
  Tier 1 Axiom enforcement bounds, not only direct text changes. (5) Track A
  authority clause updated — requires explicit confirmation no Tier 1
  enforcement bounds altered. (6) Hard floor section clarified — extra-
  constitutional vs. axiom distinction noted. (7) Phase 3 authentication
  gap note updated — declarative-only status made explicit. (8) ASM-002
  and ASM-004 provenance labels added [Estimated / Internally Derived].
  (9) GMP-001 resolved — GOV-001 In Progress confirmed; Unknowns.md v3.4
  reflects status. (10) GMP-005 In Progress — partial execution via Track
  identification rule expansion; full resolution requires adversarial review
  of expanded rule. (11) GMP-006 logged — concurrent amendment handling
  undefined. (12) GMP-007 logged — amendment withdrawal procedure undefined.
  (13) GMP-008 logged — stale proposal expiration undefined. (14) Ownership
  transfer abandoned path added. (15) Drift Indicators expanded — six new
  entries. Open Unknowns updated to 8 (GMP-001 resolved, GMP-006/007/008
  added).
- 2026-07-03: v0.3 — GMP-009 logged. Surfaced by a real proposed amendment
  (External Design Lineage Governance, drafted in `Admin/Governance_Charter.md`,
  not yet ratified) that the existing Track identification rule could not
  cleanly classify: non-Axiom content added to the Tier 1 file itself.
  Provisional classification applied to the EDL case pending this unknown's
  resolution: treated as Track A with Track A's existing Tier-2 discipline
  (explicit no-enforcement-bound-altered confirmation, human review before
  commit) rather than full Track B. Open Unknowns updated to 9.

---

## Fork Reconciliation Track (GOV-018)
*Operative procedure skeleton. Constitutional principles (fork definition, claim/recognized/ratified lineage states, active constitutional surface, F1–F6) are declared in `Admin/Governance_Charter.md` under Governance Fork Reconciliation — this Track executes them and does not restate them. Payment via Specification — 2026-08-23.*

Track A and Track B above define how a single lineage evolves. This Track is the multi-lineage exception: it applies only when two or more lineages make competing claims of constitutional continuity with the Charter's Tier 1 surface and ordinary single-lineage migration (Track A/B) cannot resolve the competition.

**Entry condition.** A lineage may be treated as recognized for inventory purposes under this Track without that recognition constituting ratification of its legitimacy (Charter: Claim vs legitimacy).

**Steps (minimum).**

1. **Inventory** — For each claimed lineage: Tier 1 text identity/hash, active subordinate governance files, open Critical unknowns, pending ownership claims. Record claims as claims, not as findings.
2. **Classify divergence** —
   - T1-text divergence (Axiom wording differs): stop agent procedure on content; Human Governing Authority only, per Charter F2. Surface-selection still requires F5 if a successor package is later designated.
   - Subordinate-only divergence: continue to step 3.
   - Interpretive drift (collective practical interpretation vs text): open a GOV-015 Interpretation Drift Review in parallel; do not merge past an unresolved drift finding, per Charter F4.
   - Same Axiom text, competing continuity claim: no F2 content merge required; proceed to step 3; F5 still required to designate the active constitutional surface.
3. **Propose successor set** — Subordinate files aligned to a single coherent reading of Tier 1; retire or mark Pending those that cannot align, using the existing Governance Authority Hierarchy and Pending Ownership Declaration Convention.
4. **No automatic preference** for the lineage with more files, more commits, current hosting control, or louder claim, per Charter F1.
5. **Human ratification** of the active constitutional surface — or of an explicit continued-fork decision, per Charter F5. Only after this step does a lineage become a ratified constitutional lineage.
6. **Archive** both prior lineages as citable history, per Charter F6; record the reconciliation event in the appropriate changelog / Resolution Log.

**Explicit non-goals.** Does not define network partition healing (Security_Protocols SEC-001) or key reconciliation (SEC-002). Does not authorize agents to pick a winner under time pressure. Does not treat absence of objection as ratification. Does not grant constitutional standing by self-declaration alone. Does not require independent audit as a precondition for recognizing that a fork condition exists (Charter). This Track is deliberately a minimum skeleton, not a full fork-management manual; templates, checklists, and multi-party (>2) procedure detail are deferred (GOV-018-R1, GOV-018-R2 in the Charter).

**Relationship to existing Tracks.** Track A/B remain the normal, single-lineage path. This Track activates only on genuine multi-lineage competing-continuity conditions, which do not currently exist in this repository — this is anticipatory doctrine, consistent with the repository's practice of specifying institutional response before the triggering condition arises (cf. GOV-021c).

*§GOV-018 operative procedure — Resolved alongside the Charter-level closure above. See `Admin/Governance_Charter.md`'s GOV-018 sidecar note for full closure attribution (Proposer, Skeptic/Verifier passes, Human Ratification).*

---

## Relationship to Existing Documents

- `Admin/Governance_Charter.md` — Tier 1 constitutional source; Governance
  Migration Doctrine section declares the constraints this file executes;
  ownership transfer of migration doctrine is proposed to this file pending
  Gate 4 clearance and Charter table update (GMP-002)
- `Admin/Repository_Integrity_Protocol.md` — prior state preservation
  (Step 1 of both tracks) is defined there; this file references that
  protocol and depends on it being operational
- `Admin/Auditor_Protocols.md` — Tier 2; auditor operational behavior
  during migration review is defined there; Track A engineer-plus-auditor
  authority references this file
- `Admin/Engineer_Protocols.md` — engineer role in Phase 1 proposal
  assembly is defined there; ASM-003 dependency
- `Admin/Ethical_Constraints.md` — co-Tier 1; Anti-Weaponization Doctrine
  is declared outside amendment scope in the Hard Floor section; Ethical
  Anchor string is similarly immutable
- `Admin/Security_Protocols.md` — *(version pin retired 2026-11-11, MAINT-130 batch 4e — SP has advanced far past v0.5; the dependency is on SP reaching Provisional Specification, not a frozen version; per the PKC-022 pin-retirement precedent, F-GMP-3, Decision Brief 2026-11-11 Item 5B)*; Phase 3
  ratification authentication depends on this file reaching Provisional
  Specification; GMP-004 tracks this dependency; SEC-007 is the deepest
  blocker
- `Admin/Forge_Audit_Kit.md` — Tier 3; Verification Maturity Model
  referenced for Gate 4 clearance threshold; GMP- prefix in Sidecar ID
  Reference
- `Unknowns.md` — active GMP rows (currently GMP-002, GMP-003, GMP-004,
  GMP-013) indexed there; Resolved GMP entries are removed from the active
  index per its Size Management Rule 2; cross-module impact of Track B
  amendments to be logged there
- `Discovery.md` — downstream notification tracking during migrations;
  canonical cross-reference resolution source

---

## Status

> *Precedence (added 2026-10-28, delegated maintenance — AUDIT_09 F4(a) propagation): the File State header is authoritative if this block and it ever disagree, per `Admin/Verification_Gates.md`.*

Version 0.9 — Skeptic/Auditor review of §VII integrated: substrate-gap
warning given prominent placement in VII.6 (hardware diversity
currently declarable, not achieved — no second host exists), four
near-term action items recorded, GMP-011 upgraded from flagged
candidate to adopted interim rule, TR-GOV-001 implementation ladder
parked in Trajectories.md with explicit non-claim language. No status
change to GOV-008 resulted. No automation implemented (2026-07-31).

Version 0.8 — §VII Bootstrap Quorum Doctrine added: a candidate
GOV-008 specification (Core Requirements, Agent Class Taxonomy,
Operational Definition of Quorum Achieved, Verification Criteria,
Interim/Escalation Rules, Open Items), explicitly held to the
governance-independence bar §VI's Non-goal clause distinguishes from
EQD's epistemic-independence bar. Candidate only — not ratified, does
not resolve GOV-008. No automation implemented (2026-07-31).

Version 0.7 — Quorum Compliance Trend subsection added to §VI EQD: a
per-cycle conformance rate against the Minimum Quorum Matrix, tracked
across cycles rather than gated on a single value, with the Non-goal
clause explicitly restated for this subsection. GMP-013 updated as a
second consumer of its already-deferred metadata schema. No new
unknowns; no automation implemented (2026-07-26).

Version 0.6 — Polish pass following external review of the v0.5 EQD
addition (Grok, Gemini): Phase 2 now explicitly anchors to EQD; GMP-003
date/forward-looking gaps closed; a new Drift Indicator protects EQD's
Non-goal clause specifically; ASM-002 note updated; a mirrored
non-resolution note added to GOV-008 in `Admin/Governance_Charter.md`
so the epistemic/governance independence distinction is visible from
both files. No unknowns added or resolved (2026-07-27).

Version 0.5 — §VI Epistemic Quorum Doctrine (EQD) added, formalizing
multi-agent review quorum, independence dimensions, and outcome
taxonomy for GMP-003/GMP-010-class review. Adopted from four-way
external multi-agent synthesis, but rescoped before adoption: an
early draft conflated epistemic independence (reasoning/evidence)
with governance independence (enforcement authority) and marked
GOV-008 "resolved" — checked against the Charter's actual GOV-008
text, found not to satisfy it, and corrected with a binding Non-goal
clause before anything was adopted. GMP-013 registered for the
tooling/automation gap this doctrine does not itself close (2026-07-26).

Version 0.4 — External audit review triaged (ChatGPT, Grok): GMP-003
date typo fixed; Open Unknowns count corrected from a stale 8 to the
actual 7 open entries plus two newly registered (GMP-011, GMP-012),
now 9; Lessons Learned populated from existing Resolution Log history
(was empty since file creation); GMP-004 gained a cross-reference to
existing GPG signing precedent (`Admin/Repository_Integrity_Protocol.md`
RIP-001) rather than adopting proposed HSM/blockchain infrastructure,
assessed as disproportionate at v0 scale; GMP-006/007/008 gained a
shared consolidation note pointing at a future amendment state machine,
not designed in this pass (2026-07-25).

Version 0.3 — GMP-009 logged: track classification gap for non-Axiom
content changes to the Tier 1 file (2026-07-03). *(This entry
previously sat as the most recent Status entry despite GMP-005/GMP-009's
resolution and GMP-010's registration both landing afterward — corrected
2026-07-25, no substantive content changed by the correction itself.)*

**What must remain constant:**

**The procedure must exist before the argument arises.**
**Constitutional Capture is guarded against by both text and interpretation.**
