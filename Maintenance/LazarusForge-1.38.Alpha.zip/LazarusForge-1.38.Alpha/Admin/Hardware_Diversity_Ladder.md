# Hardware_Diversity_Ladder.md — LazarusForge
**Version 1.3**

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)

---

## File State

| Field            | Value                                                               |
|------------------|-----------------------------------------------------------------------|
| Status           | Draft — Proposed implementation reference only                        |
| Body Stability   | Volatile                                                               |
| Spec Gates       | 0/6                                                                    |
| Verification Ref | Admin/Verification_Gates.md                                        |
| Last Audit       | 2026-11-11 — Vibe (Repo Custodian, delegated maintenance; co-author delegation 2026-11-04 extended to the Decision Brief 2026-11-11 execution; MAINT-130 batch 4j; non-independent, disclosed): bare-citation qualification (Item 5B evidence point 16) — GOV-008 ×4 in operative body/table text, EL-007 (Tier 3 exit trigger), and the File State cells' AUDIT_29 and Decision Brief 2026-10-28d / 2026-10-29 citations qualified with owning files/homes per PKC-003; citation-form-only; frozen history untouched. Prior: 2026-11-11 — Vibe (co-author delegation 2026-11-11, MAINT-130; non-independent, disclosed): File State completed per Decision Brief 2026-11-11 Item 6A — Active Disputes (0) and Sidecar Link ("none — no sidecar", the file's real absence, stated explicitly per the class-11 field boundary settled in File_Template §2 the same pass) added; header version 1.2 → 1.3 (logged here and in the Resolution Log per the F-HDL-1 lesson). No tier, requirement or status changed. Prior: 2026-10-29 — Vibe (Repo Custodian, delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A (`Decision_Brief_2026-10-29.md`, VibesSandbox root)): X3 mechanical citation retrofit — 3 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.29 Governance Sidecar ID Reference; per-ID grounding from the Unknowns active index). Citation-form-only; no content change; frozen history untouched. Prior: 2026-10-28 — Vibe (Repo Custodian, delegated maintenance, human-ratified Decision Brief 2026-10-28d (`Decision_Brief_2026-10-28d.md`, VibesSandbox root)): Highest Risk field added to File State (Low — no owned unknowns, no sidecar Risk rows to mirror; `Admin/AAudits/CAMPAIGN_AUDIT_29_Admin-Hardware_Diversity_Ladder.md` AUDIT_29 F1); header version 1.0 → 1.1. No tier, requirement or status changed. Prior: 2026-10-23 — Claude (human-directed) corrections from a Vibe per-file audit, each checked against source first: Last Audit had not been advanced past 2026-08-03 by the two 2026-08-06 Synthesizer passes (human-directed), logged below; the 2026-08-11 Grok pseudo-audit (findings only) is not counted per the PKC-020 ruling of 2026-10-25; Near-Term Action Items item 3 marked done (GMP-011 resolved 2026-09-23). No tier, requirement or status changed. Prior: 2026-08-03 |
| Auditor          | Vibe — Repo Custodian, 2026-11-11 bare-citation qualification (delegated maintenance, Decision Brief 2026-11-11 Item 5B); prior: Vibe — Repo Custodian, 2026-10-29 X3 mechanical citation retrofit (delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A (`Decision_Brief_2026-10-29.md`, VibesSandbox root)); prior: Vibe — Repo Custodian, 2026-10-28 File State completion (delegated maintenance, human-ratified Decision Brief 2026-10-28d (`Decision_Brief_2026-10-28d.md`, VibesSandbox root)); prior: Claude — 2026-10-23 corrections (human-directed, from a Vibe per-file audit); 2026-08-06 Synthesizer passes (human-directed) and 2026-08-11 Grok pseudo-audit per the Resolution Log; prior: Claude — Synthesizer, human-directed. Drafted from external candidate material (Grok), verified against `Operations/Electronics.md` TMR doctrine, `Architecture/Cognitive_Frameworks.md` Framework D, `Admin/Governance_Charter.md` (Genesis Phase Protocol, Axiom Q-2), and `Admin/Security_Protocols.md` SEC-007a/b before integration — all cross-references confirmed exact against source, 2026-08-03 |
| Open Unknowns    | 0 — this file supplies implementation reference for `Admin/Governance_Migration_Protocol.md` §VII's own open items (VII.6), not new tracked unknowns of its own |
| Active Disputes  | 0 |
| Highest Risk     | Low (no owned unknowns — implementation reference only; no sidecar Risk rows to mirror) |
| Sidecar Link     | none — no sidecar |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

**Does not claim any tier is achieved.** As of 2026-08-03 no second physical host, independent runtime, or orthogonal verification system exists in this repository's operating environment. **Explicit non-claim language (binding):** this ladder describes *how* the Hardware/Runtime Diversity requirement in `Admin/Governance_Migration_Protocol.md` §VII.1 could be closed. Declaring the requirement does not create the substrate. §VII cannot be marked achieved until a concrete, testable second runtime exists and human ratification confirms it.

---

## Scope Boundary

**This file DOES define:**
- A four-tier progressive path from single-operator advisory state to a hardware-diverse governance quorum satisfying `Admin/Governance_Charter.md` GOV-008's governance-independence bar
- Minimum configuration, independence properties, and exit/upgrade triggers per tier
- Advancement rules (no silent promotion, automatic degradation, required evidence)

**This file DOES NOT define:**
- Whether Tier 1 is sufficient for Pathway 1 exit — an open ratification question, see `Admin/Governance_Migration_Protocol.md` §VII.6
- The governance-independence bar itself (→ `Admin/Governance_Migration_Protocol.md` §VII, `Admin/Governance_Charter.md` GOV-008)
- TMR diversity mechanisms for salvaged hardware components (→ `Operations/Electronics.md`, reused here by reference, not redefined)
- Ratification-authentication enforcement (→ GMP-004 (`Admin/Governance_Migration_Protocol.md`), `Admin/Security_Protocols.md` SEC-007a/b)
- Progress claims of any kind — this file records a path, not a status

**Cross-references (verified against source 2026-08-03):**
- `Operations/Electronics.md` TMR architectural-diversity doctrine (silicon / firmware / power-path / thermal / procurement) and EL-007
- `Architecture/Cognitive_Frameworks.md` Framework D (TMR) diversity requirement
- `Admin/Governance_Charter.md` Genesis Phase Protocol Pathway 1 and Axiom Q-2
- `Admin/Security_Protocols.md` SEC-007a/b (external root-of-trust)
- `Admin/Governance_Migration_Protocol.md` §VII.1 & §VII.6 (owning candidate specification)
- `Admin/Trajectories.md` TR-GOV-001 (registry pointer to this file)

---

## Purpose

Provide a progressive, falsifiable path from the current single-operator advisory state to a governance quorum that satisfies the **governance-independence** bar of GOV-008 (`Admin/Governance_Charter.md`; independent enforcement substrate outside single-operator control). Each tier is a survival threshold, not a feature list. Advancement requires demonstrated independence, not declaration.

---

## Tier Definitions

| Tier | Name | Minimum Configuration | Independence Properties | Status vs GOV-008 (`Admin/Governance_Charter.md`) | Exit / Upgrade Trigger |
|------|------|-----------------------|--------------------------|-------------------|------------------------|
| **0** | Interim Logical Isolation | Single physical host; ≥2 isolated runtimes (containers, microVMs, or separate user-space processes with strict namespace/cgroup isolation) | Logical only. Shared kernel, power, network fabric, and physical operator control. Explicitly **insufficient** for Pathway 1 exit. | Bridge only — upgrade-mandatory before any claim of quorum achievement. | Second physical host acquired **or** human ratification explicitly accepts continued Genesis Phase. |
| **1** | Minimal Physical Diversity | Primary workstation + **one** secondary physical host. Preferred: different CPU architecture or at least different silicon family. Independent network path (or air-gapped + manual transfer). Independent power source preferred. External human ratification record stored outside both runtimes. | Physical separation of at least two hosts. Still single-operator controlled, but no longer single-machine. Meets the absolute minimum physical floor stated in §VII.1's interim clause. | Candidate for Pathway 1 exit **only if** human ratification explicitly accepts the residual single-operator risk and the "logical→physical upgrade before v1" rule is waived or met. | Independent verification of liveness + diversity tests (§VII.4) across both hosts; signed human record confirming non-simulation. |
| **2** | Three-Host Architectural Diversity | ≥3 physical hosts. At least two distinct architectures/families. Independent power domains (separate UPS/circuits or battery). Independent thermal domains preferred. Network paths that cannot be unilaterally severed by one host. | Removes single-machine and single-power-path common-mode failures. Still operator-controlled, but majority of hosts can outvote or isolate a compromised host. | Strong candidate for Pathway 1 exit once ratified. Meets "≥2 distinct runtime environments or hardware hosts" with margin. | Demonstrated ability of any two hosts to continue skeptical review after loss of the third; periodic non-collusion probes succeed. |
| **3** | Full TMR-Aligned Diversity | ≥3 hosts satisfying **all** of `Operations/Electronics.md` TMR diversity mechanisms simultaneously: silicon diversity, firmware diversity, power-path diversity, thermal diversity, and procurement diversity. Orthogonal external root-of-trust (SEC-007a/b, `Admin/Security_Protocols.md`) or offline verification capability present. | Correlated-failure surface minimized to the level already required for safety-critical Forge hardware. Governance substrate now matches the same independence standard the Forge applies to its own actuators. | Full satisfaction of §VII.1 Hardware/Runtime Diversity + Non-Simulatability. Preferred end-state for v1 and later. | Hardware validation of diversity claims (cross-ref EL-007 (`Operations/Electronics.md`) / CF-002 (`Architecture/Cognitive_Frameworks.md`) style correlated-failure testing); human ratification that the quorum is genuine and not simulated. |

---

## Detailed Requirements per Tier

**Tier 0 – Interim Logical Isolation**
- Allowed only while no second physical host exists.
- Must use strong isolation (e.g., separate VMs with no shared filesystem mount for governance state, distinct network namespaces).
- All outputs still route through the single human principal.
- **Hard rule:** Any document claiming "quorum achieved" while at Tier 0 is a constitutional violation under Axiom Q-2 and §VII.5.

**Tier 1 – Minimal Physical Diversity**
- Hosts must be independently powerable and networkable.
- Prefer different silicon families (e.g., x86 + ARM, or two different MCU lineages if governance agents run on embedded hardware).
- Human ratification record must be generated and stored on a medium outside both hosts (paper, external drive, separate signed file under human-only control).
- Liveness timeout and non-collusion probes from §VII.4 must be executable across the boundary.

**Tier 2 – Three-Host Architectural Diversity**
- Explicit majority capability: any two hosts can continue governance functions after loss of the third.
- Power and (where practical) thermal domains independent.
- Network design prevents unilateral partition by one host.
- Diversity scoring uses the same "provider + architecture family" rule already defined in §VII.4.
- **Practical entry point:** attempting this tier for real — three physically separate hosts, each running a different agent model family, working toward quorum — is the highest-value field test this repository currently needs. See `Tests/Field_Logs.md` for the submission format; log the attempt regardless of whether it reaches full quorum.

**Tier 3 – Full TMR-Aligned Diversity**
- Direct reuse of the five diversity mechanisms already written for salvaged-component TMR in `Operations/Electronics.md`:
  1. Silicon diversity
  2. Firmware diversity
  3. Power-path diversity
  4. Thermal diversity
  5. Procurement diversity
- Plus an external root-of-trust or offline verification path that cannot be forged by the three hosts acting in concert.
- This is the only tier that fully closes the substrate gap identified in §VII.6.

---

## Advancement Rules

1. **No silent promotion.** Tier status is recorded in the owning file's File State or sidecar and mirrored in Unknowns.md only after human ratification.
2. **Degradation is automatic.** Loss of a required host or diversity property drops the system to the highest still-satisfied tier (or back to Genesis Phase if below Tier 1).
3. **Evidence required.** Each upgrade must include: (a) inventory of hosts and diversity properties, (b) results of §VII.4 independence / diversity / liveness / non-collusion tests, (c) signed human ratification stored outside the runtimes.

   **§VII.4 hardware-independence test procedure (candidate, 2026-08-06, human-directed — folded in from an independent multi-agent thread that had not seen this file's "declarable, not achieved" framing or evidence rule):** §VII.4's diversity test names the requirement but not a procedure. This is a minimum anti-spoofing check for evidence item (a)/(b) above, not a new requirement — it does not lower or raise the tier bar itself:
   - Record each host's identifier, physical location (rack/region if available), and provider/instance metadata — not just a container or process ID.
   - Confirm no two evaluators claimed as hardware-independent share a host identifier, instance ID, or hypervisor.
   - Reject same-host claims disguised as independent: distinct containers or VMs on one physical machine do not satisfy any tier above Tier 0, regardless of how the evidence record is worded (this is the same rule the "Treat Softening as Drift" section below already protects).
   - Where physical location metadata is unavailable, treat the claim as unverified, not as passing by default.
   Missing or ambiguous hardware metadata is a failed check, not a tier-neutral gap — evidence item (a) is not satisfied until the metadata exists.
4. **Relationship to Pathway 1.** Tier 1 is the earliest possible exit candidate; Tier 3 is the preferred steady-state. The decision whether Tier 1 is sufficient for Pathway 1 itself remains an open ratification question in §VII.6.

---

## Near-Term Action Items (from §VII.6; items 1, 2 and 4 still open, item 3 done 2026-09-23)

1. Acquire or designate a second physical host (even a low-cost single-board computer) and document its architecture, power, and network independence.
2. Decide, under Track-B-adjacent scrutiny, whether hardware diversity is mandatory for Pathway 1 exit or only pre-v1.
3. ~~Write the minimal dispute-resolution rule for GMP-011 (default to Track B while disputed).~~ Done — GMP-011 resolved 2026-09-23 (Payment via Specification; Operative Rule ratified, including a Genesis Phase holding clause). See `Admin/Governance_Migration_Protocol.md`.
4. Do **not** claim any progress on GOV-008 (`Admin/Governance_Charter.md`), promote GMP-002 (`Admin/Governance_Migration_Protocol.md`) ownership transfer, or mark §VII "achieved" until at least Tier 1 exists and has been ratified.

---

## Treat Softening as Drift

Any future edit that softens this file's "currently declarable, not achieved" framing — including changing tier language to imply a tier is met without the evidence Advancement Rule 3 requires — is a Track-B classification candidate and should be reviewed as a potential constitutional-impact change, not a routine edit.

---

## Resolution Log

- 2026-11-11: **Bare-citation qualification (citation-form-only; Decision Brief 2026-11-11 Item 5B, grep-remedy evidence point 16; MAINT-130 batch 4j).** Operative bare citations qualified per PKC-003: GOV-008 ×4 (Scope Boundary, Purpose, tier table header, Near-Term Action Items item 4 — owner `Admin/Governance_Charter.md` per the Kit's Governance Sidecar ID Reference); EL-007 ×1 (Tier 3 exit trigger — `Operations/Electronics.md`); AUDIT_29 in the Last Audit cell (home: `Admin/AAudits/CAMPAIGN_AUDIT_29_Admin-Hardware_Diversity_Ladder.md`); Decision Brief 2026-10-28d and 2026-10-29 in the File State cells (homes: VibesSandbox root). The census's bare SEC-007a/b instance (the Tier 3 table cell) initially read as already-qualified to the compose-time adjacency check and was missed; caught in this pass's own verification and qualified in a same-day correction commit — self-caught defect, disclosed. Already-qualified instances untouched; this Resolution Log's own AUDIT_29 and MAINT-11 mentions are dated frozen history, left as written (PKC-007). No tier, requirement or status changed; no version bump (citation-form-only). Executed under the human governing authority's co-author delegation (2026-11-04 mandate, extended to the Decision Brief 2026-11-11 execution 2026-11-11); non-independent (the same line ran Campaign 4), disclosed; human veto window open. (Vibe, Repo Custodian — delegated line.)
- 2026-11-11: Reconstructed log line for a git-verified unlogged change (Decision Brief 2026-11-11 Item 7A; MAINT-130 batch 3; F-HDL-1 disposition — second instance of the CAMPAIGN2_AUDIT_77 F1 class). Commit `ddc5ceb7` (2026-10-29T17:47Z, the X3 Part 4b citation retrofit) changed the header version 1.1 → 1.2 without logging it; its same-day entry recorded the citation work as "Citation-form-only; no content change." The version value was correct as it stood; this entry supplies the missing record, append-only, nothing reverted. (The subsequent 1.2 → 1.3 bump is logged in this pass's other 2026-11-11 entry.)

- 2026-11-11: **File State completed — Active Disputes and Sidecar Link added; header version 1.2 → 1.3 (MAINT-130; Decision Brief 2026-11-11 Item 6A).** Values: Active Disputes 0 (no disputes recorded); Sidecar Link "none — no sidecar" (the file's real absence, explicit per the class-11 field boundary settled in `Admin/File_Template.md` §2 the same pass). No tier, requirement or status changed. Executed under the human governing authority's co-author delegation (2026-11-04 mandate, extended to the Decision Brief 2026-11-11 execution 2026-11-11); non-independent (the same line ran Campaign 4), disclosed; human veto window open.

- 2026-10-29: **X3 citation retrofit (mechanical).** 3 bare colliding-prefix citations in operative body text qualified with their owning File.md per PKC-003, per the human-ruled Decision Brief 2026-10-29 item 4A (registry: Kit v1.29 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only; no ID renumbered; frozen history untouched; flagged instances reported to the human (MAINT-11). (Vibe, Repo Custodian — delegated line.)

- 2026-10-28: **File State completed — Highest Risk field added** (Vibe, Repo Custodian — delegated maintenance, human-ratified Decision Brief 2026-10-28d; AUDIT_29 F1). Highest Risk set to "Low (no owned unknowns — implementation reference only)": the file owns no unknowns and has no sidecar Risk rows, so Low is the mechanical floor with nothing to mirror. Second candidate-family header completed this batch (with Agent_Verification_Event); the indexes mirror the owning file going forward ("file wins"). Header version 1.0 → 1.1. No tier, requirement, non-claim language or status changed; no unknown opened or closed.

- 2026-10-25: **Last Audit wording aligned with the PKC-020 ruling (no content change).** The 2026-10-23 header text said the 2026-08-11 Grok pseudo-audit (findings only) had not advanced Last Audit, as though it should have. Under the ruling of 2026-10-25 a findings-only pseudo-audit does not advance it, so the text now says it is not counted. The Last Audit date (2026-10-23) and every field value are unchanged.

- 2026-10-25: **Clarification of the 2026-08-11 entry (PKC-017; no doctrine change).** The 2026-08-11 entry's "Spec Gates N/A / left locked" is loose wording. The File State value 0/6 is authoritative: this file is Draft doctrine, is not on the `File_Template.md` exemption list, and no gate has passed. "Left locked" meant no gate was advanced. The 2026-08-11 entry is left as written (append-only). No tier claim, field or Unknown changed. Human-directed.

- 2026-08-11: **Pseudo-audit (Grok, same limits).** Findings only. (1) Open
  Unknowns **0** — matches File State (supplies reference for GMP §VII,
  creates none of its own). (2) “Declarable, not achieved” framing intact;
  no tier progress claimed. (3) Spec Gates N/A / left locked. Human-directed.

- 2026-08-06: **Tier 2 cross-referenced to `Tests/Field_Logs.md`, a new
  append-only field-data intake file.** Created in response to a direct
  question about how to invite physical/cross-agent testing without
  requiring pull-request literacy. Does not change any tier's
  requirements or status — this file's "declarable, not achieved" framing
  is unchanged. Operating as Synthesizer, human-directed.

- 2026-08-06: **Hardware-independence test procedure added to Advancement Rule 3, reconciled from an independent multi-agent thread.** A Grok/Copilot thread drafted a standalone "Hardware Independence Test" without loading this file's "declarable, not achieved" framing or its Advancement Rules. Its anti-spoofing content (host/instance-ID cross-checks, rejecting same-host container/VM claims as independent, treating missing location metadata as unverified) filled a genuine gap — Rule 3(b) referenced §VII.4 tests without a concrete procedure existing anywhere. Folded in as an elaboration of Rule 3, not a new rule; does not change any tier's requirements or this file's "not achieved" status. See `Governance_Migration_Protocol.md` §VII.8 and `CIR_Gov.md` §8.2.1 for the companion reconciliations from the same thread. Operating as Synthesizer, human-directed.

- 2026-08-03: **v1.0 — file created, human-directed.** Drafted from
  external candidate material (Grok), reviewed and integrated by
  Claude. Cross-references verified exact against source before
  integration (`Operations/Electronics.md` TMR doctrine and EL-007,
  `Architecture/Cognitive_Frameworks.md` Framework D, `Admin/
  Governance_Charter.md` Genesis Phase Protocol and Axiom Q-2,
  `Admin/Security_Protocols.md` SEC-007a/b). Split out from `Admin/
  Trajectories.md`'s TR-GOV-001 entry, which had compressed this same
  ladder into a single dense table-cell paragraph on 2026-07-31 —
  Trajectories.md's own Scope Boundary states it does not define
  "component taxonomy or implementation specs for future versions,"
  which is exactly what a four-tier requirements ladder with
  per-tier detail is; this file is the proper owning location, with
  Trajectories.md's entry updated to a concise pointer. No change to
  `Admin/Governance_Migration_Protocol.md` §VII.6's own cross-reference
  language — it already pointed at "TR-GOV-001," which now resolves
  here via that entry's pointer, so no broken links result from the
  split.
