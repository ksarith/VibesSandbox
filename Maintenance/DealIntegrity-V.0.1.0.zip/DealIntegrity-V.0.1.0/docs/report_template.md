# Report Template

Use this structure for every assessment. Lead with the verdict and the drivers; details follow.

---

## Overall Integrity Verdict

**[VERDICT]**  
(e.g. Horrid / Failed, Bad / Poor, Okay / Marginal, Good / Competent, Great / High Quality, Exceptional)

**Primary drivers**  
- List the unmitigated breakers and/or failure predicates that forced the result.  
- If none, state the score-band or classification that set the ceiling.

**Scope**  
- Structural / Negotiation / Both  
- Basis: prospective / retrospective  
- Perspective: acquirer / target_holders / neutral  
- Method version: …

---

## Structural Integrity

**Grade:** Great / Good / Okay / Bad / Horrid

**Breaker summary**  
| ID | Answer | Note |
|----|--------|------|
| B1 | … | … |
| … | … | … |

**Dimension scores**  
| Dimension | Score (0–4) | Weight | Contribution |
|-----------|-------------|--------|--------------|
| D1 Strategic fit | | 2 | |
| D2 Customer & contract | | 2 | |
| D3 Tech & cycle | | 2 | |
| D4 Financial quality | | 2 | |
| D5 Price & structure | | 2 | |
| D6 Synergies | | 1 | |
| D7 Integration | | 1 | |
| D8 Regulatory & geo | | 1 | |
| D9 Maintenance & lifecycle | | 2 | |
| **Weighted total** | | | **/ 60** |

**Maintenance-adjusted figures** (if recorded)  
- Plain EBITDA:  
- Maint-adj EBITDA:  
- Price adj for known costs:  
- Basis / notes:

---

## Negotiation Integrity

**Classification:** Exceptional / High Quality / Competent / Marginal / Poor / Failed

**NQS:** xx.x / 100

**Failure predicates**  
- F1 Epistemic Integrity < 40: yes / no  
- F2 Risk Allocation < 40: yes / no  
- F3 Procedural Legitimacy < 40: yes / no  

**Dimension scores**  
| Dimension | Score (0–100) | Weight |
|-----------|---------------|--------|
| N1 Preparation | | 0.10 |
| N2 Information Discovery | | 0.15 |
| N3 Value Creation | | 0.15 |
| N4 Communication | | 0.10 |
| N5 Value Capture | | 0.10 |
| N6 Objective Alignment | | 0.10 |
| N7 Relationship | | 0.10 |
| N8 Risk Allocation | | 0.08 |
| N9 Epistemic Integrity | | 0.08 |
| N10 Procedural Legitimacy | | 0.04 |

**Strengths**  
- …

**Weaknesses / gaps**  
- …

---

## Evidence summary

List the key sources used, with publication dates and which questions they support. Highlight any contradictions left unresolved.

---

## Recommended next actions (if any)

- What evidence would resolve remaining `U` answers?  
- What process or structural changes would most improve the next negotiation or similar deal?

---

*This report is an analytical opinion under the DealIntegrity method. It is not investment advice.*
