# Schema

Three tables in `data/`, joined by id. A deal is one row; each time a deal is graded is one **assessment**; every answer an assessment gives is backed by **evidence** rows. This lets one deal carry several independent assessments (prospective and retrospective, acquirer and neutral, structural-only or full) without overwriting each other, and lets every answer be audited back to a source.

```
deals.csv (deal_id)  <-  assessments.csv (assessment_id, deal_id)  <-  evidence.csv (evidence_id, assessment_id, question_id)
```

A sector’s pack defines the allowed values for `sector`, `subsector` and `acquirer_role`, and may add fields in its own `ext.csv` keyed by `assessment_id`.

The check tools read this file’s field lists as the source of truth for column names and order.

## deals.csv

One row per deal. Failed, withdrawn and blocked deals go in the same table as closed ones. Deal facts only: no grades, no judgments about the deal.

| Field | Type | Notes |
|-------|------|-------|
| `deal_id` | text | `YYYY-acquirer-target` in lowercase, e.g. `2023-acquirerco-targetco` |
| `acquirer` | text | Legal or common name |
| `acquirer_type` | enum | `strategic`, `pe`, `other` |
| `acquirer_role` | text | Sector detail from the pack (e.g. automotive: `oem`, `tier1`). Blank if no pack or not applicable |
| `acquirer_country` | text | ISO 3166 alpha-2 |
| `target` | text |  |
| `sector` | text | The pack id (e.g. `automotive`), or `general` to grade with the core alone |
| `subsector` | text | Allowed values come from the pack. Blank for `general` |
| `target_country` | text | ISO 3166 alpha-2 |
| `deal_type` | enum | `acquisition`, `merger`, `carve_out`, `minority_stake`, `jv` |
| `announced_date` | date | `YYYY-MM-DD` |
| `closed_date` | date | Blank if not closed |
| `status` | enum | `rumored`, `announced`, `pending`, `closed`, `withdrawn`, `blocked` |
| `status_reason` | text | Why it was withdrawn, blocked, or delayed. Blank if none |
| `value_usd_m` | number | Enterprise value in USD millions. Blank if unknown |
| `value_basis` | enum | `disclosed`, `reported`, `estimated`, `unknown` |
| `ev_revenue` | number | Blank if unknown |
| `ev_ebitda` | number | Plain (unadjusted) multiple. Blank if unknown |
| `multiple_basis` | text | Which period (LTM, forward) and which source |
| `outcome_notes` | text | What actually happened, for backtesting. Blank until known |
| `source_url` | text | Primary source for the deal facts. Separate several with a space |
| `source_type` | enum | `filing`, `press_release`, `regulator`, `news`, `other` |
| `confidence` | enum | `high`, `medium`, `low` |
| `last_verified` | date | `YYYY-MM-DD` |
| `notes` | text | Anything else |

## assessments.csv

One row per assessment of a deal. Structural breaker answers and dimension scores are mandatory when structural scope is active. Negotiation dimensions are mandatory when negotiation scope is active. Computed fields are calculated by `tools/calculate_grade.py` and checked against the recorded values by `tools/validate_data.py`; do not hand-edit them.

### Identity and scope

| Field | Type | Notes |
|-------|------|-------|
| `assessment_id` | text | Unique, e.g. `2023-acquirerco-targetco-prospective-2026-11-19` |
| `deal_id` | text | Foreign key to deals.csv |
| `assessment_date` | date | When this assessment was made |
| `grade_basis` | enum | `prospective`, `retrospective` |
| `information_cutoff` | date | Required for prospective; blank for retrospective |
| `grade_perspective` | enum | `acquirer`, `target_holders`, `neutral` |
| `assessment_scope` | enum | `structural`, `negotiation`, `both` |
| `method_version` | text | e.g. `core-0.1;automotive-0.1` |
| `assessor` | text | Agent or human identifier |
| `notes` | text | Free text |

### Structural breakers (B1–B11)

Each is one of: `Y`, `N`, `U`, `M`.

| Field | Notes |
|-------|-------|
| `b1_regulatory` | |
| `b2_customer_concentration` | |
| `b3_platform_end_of_life` | |
| `b4_liabilities` | |
| `b5_funding` | |
| `b6_unverified_numbers` | |
| `b7_quality_standing` | |
| `b8_labor_blocks` | |
| `b9_ip_supply` | |
| `b10_policy_dependency` | |
| `b11_catchup_capex` | |
| `pack_breakers` | `n/a`, `clear`, `mitigated`, `unmitigated` |
| `breaker_notes` | Required when any `M` or pack mitigated |

### Structural dimensions (0–4)

| Field | Weight |
|-------|--------|
| `d1_strategic_fit` | 2 |
| `d2_customer_contract` | 2 |
| `d3_tech_cycle` | 2 |
| `d4_financial_quality` | 2 |
| `d5_price_structure` | 2 |
| `d6_synergies` | 1 |
| `d7_integration` | 1 |
| `d8_regulatory_geo` | 1 |
| `d9_maintenance_lifecycle` | 2 |

### Maintenance inputs

| Field | Notes |
|-------|-------|
| `ebitda_usd_m` | |
| `maint_capex_usd_m` | |
| `warranty_normalization_usd_m` | |
| `catchup_capex_usd_m` | |
| `known_upcoming_costs_usd_m` | |
| `maint_basis` | `filed`, `estimated`, `unknown` |
| `maint_notes` | |

### Negotiation dimensions (0–100)

Leave blank if `assessment_scope` is `structural`.

| Field | Weight in NQS |
|-------|---------------|
| `n1_preparation` | 0.10 |
| `n2_information_discovery` | 0.15 |
| `n3_value_creation` | 0.15 |
| `n4_communication` | 0.10 |
| `n5_value_capture` | 0.10 |
| `n6_objective_alignment` | 0.10 |
| `n7_relationship` | 0.10 |
| `n8_risk_allocation` | 0.08 |
| `n9_epistemic_integrity` | 0.08 |
| `n10_procedural_legitimacy` | 0.04 |
| `negotiation_notes` | |

### Computed fields (written by the tool — do not hand-edit)

| Field | Notes |
|-------|-------|
| `weighted_score` | Structural |
| `max_score` | Always 60 when structural scored |
| `score_pct` | |
| `breaker_ceiling` | |
| `zero_dimension_ceiling` | |
| `band` | |
| `structural_grade` | great / good / okay / bad / horrid |
| `maint_adj_ebitda_usd_m` | |
| `price_adj_for_known_usd_m` | |
| `nqs` | Negotiation Quality Score 0–100 |
| `negotiation_classification` | exceptional / high_quality / competent / marginal / poor / failed |
| `failure_predicates` | Comma-separated list of F1/F2/F3 that fired, or empty |
| `overall_integrity_verdict` | The worse of the two sides |

## evidence.csv

| Field | Type | Notes |
|-------|------|-------|
| `evidence_id` | text | Unique |
| `assessment_id` | text | Foreign key |
| `question_id` | text | e.g. `B1`, `D5`, `N9`, `maint` |
| `source_url` | text | |
| `source_type` | enum | `filing`, `press_release`, `regulator`, `news`, `interview`, `internal`, `other` |
| `publication_date` | date | Critical for prospective assessments |
| `what_it_establishes` | text | In your own words; never paste long paid content |
| `evidence_type` | enum | `primary`, `secondary`, `estimate`, `negative_finding` |
| `notes` | text | |
