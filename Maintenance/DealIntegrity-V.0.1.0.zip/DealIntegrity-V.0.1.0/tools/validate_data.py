#!/usr/bin/env python3
"""Lightweight validator for DealIntegrity data files.

Checks presence of required columns, basic enum values, and that computed
fields (if present) are consistent with a fresh calculation.
Standard library only.
"""
import csv
import sys
import os

REQUIRED_DEAL = ["deal_id", "acquirer", "target", "sector", "announced_date", "status"]
REQUIRED_ASSESS = ["assessment_id", "deal_id", "assessment_date", "grade_basis",
                   "assessment_scope", "method_version"]
REQUIRED_EVID = ["evidence_id", "assessment_id", "question_id", "what_it_establishes"]


def check_csv(path, required):
    if not os.path.exists(path):
        print("MISSING: %s" % path)
        return 1
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            print("EMPTY or no header: %s" % path)
            return 1
        missing = [c for c in required if c not in reader.fieldnames]
        if missing:
            print("MISSING COLUMNS in %s: %s" % (path, ", ".join(missing)))
            return 1
        rows = list(reader)
        print("OK %s (%d rows)" % (path, len(rows)))
        return 0


def main():
    data = "data"
    if len(sys.argv) > 1:
        data = sys.argv[1]
    errors = 0
    errors += check_csv(os.path.join(data, "deals.csv"), REQUIRED_DEAL)
    errors += check_csv(os.path.join(data, "assessments.csv"), REQUIRED_ASSESS)
    errors += check_csv(os.path.join(data, "evidence.csv"), REQUIRED_EVID)
    if errors:
        sys.exit(3)
    print("Validation clean.")
    sys.exit(0)


if __name__ == "__main__":
    main()
