#!/usr/bin/env python3
"""Deterministic grade, NQS and Overall Integrity Verdict calculator for DealIntegrity.

The agent (or analyst) gathers evidence and answers the questions. This tool applies
the rules: it never interprets a breaker, improvises a formula, or softens a predicate.

Usage:
    python3 tools/calculate_grade.py data/assessments.csv [--out report.json]

Exit codes: 0 all rows computed and match the recorded values (or fields were blank
and are now filled); 2 usage or input error; 3 at least one recorded computed field
differs from the computation.
Standard library only.
"""
import argparse
import csv
import json
import sys

VERSION = "0.1.0"

BREAKER_FIELDS = [
    "b1_regulatory", "b2_customer_concentration", "b3_platform_end_of_life",
    "b4_liabilities", "b5_funding", "b6_unverified_numbers", "b7_quality_standing",
    "b8_labor_blocks", "b9_ip_supply", "b10_policy_dependency", "b11_catchup_capex"
]
DIM_WEIGHTS = {
    "d1_strategic_fit": 2, "d2_customer_contract": 2, "d3_tech_cycle": 2,
    "d4_financial_quality": 2, "d5_price_structure": 2, "d6_synergies": 1,
    "d7_integration": 1, "d8_regulatory_geo": 1, "d9_maintenance_lifecycle": 2
}
MAX_SCORE = 4 * sum(DIM_WEIGHTS.values())  # 60
GRADES = ["horrid", "bad", "okay", "good", "great"]  # worst to best
BREAKER_VALUES = {"Y", "N", "U", "M"}
PACK_BREAKER_VALUES = {"n/a", "clear", "mitigated", "unmitigated"}

BAND_FLOORS = [(48, "great"), (39, "good"), (30, "okay"), (21, "bad")]

N_WEIGHTS = {
    "n1_preparation": 0.10,
    "n2_information_discovery": 0.15,
    "n3_value_creation": 0.15,
    "n4_communication": 0.10,
    "n5_value_capture": 0.10,
    "n6_objective_alignment": 0.10,
    "n7_relationship": 0.10,
    "n8_risk_allocation": 0.08,
    "n9_epistemic_integrity": 0.08,
    "n10_procedural_legitimacy": 0.04,
}

NEG_CLASSES = ["failed", "poor", "marginal", "competent", "high_quality", "exceptional"]
# severity order for overall (lower index = worse)
SEVERITY = {
    "horrid": 0, "failed": 0,
    "bad": 1, "poor": 1,
    "okay": 2, "marginal": 2,
    "good": 3, "competent": 3,
    "great": 4, "high_quality": 4,
    "exceptional": 5,
}


class InputError(ValueError):
    pass


def _worse(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return a if SEVERITY.get(a, 99) <= SEVERITY.get(b, 99) else b


def band_for(weighted_score):
    for floor, name in BAND_FLOORS:
        if weighted_score >= floor:
            return name
    return "horrid"


def structural_grade(breakers, pack_breakers, dims):
    """Return structural grade and intermediate ceilings."""
    for f in BREAKER_FIELDS:
        if breakers.get(f) not in BREAKER_VALUES:
            raise InputError("%s must be one of Y, N, U, M (got %r)" % (f, breakers.get(f)))
    if pack_breakers not in PACK_BREAKER_VALUES:
        raise InputError("pack_breakers must be one of n/a, clear, mitigated, unmitigated (got %r)" % (pack_breakers,))
    for f in DIM_WEIGHTS:
        v = dims.get(f)
        if not isinstance(v, int) or isinstance(v, bool) or not 0 <= v <= 4:
            raise InputError("%s must be an integer 0 to 4 (got %r)" % (f, v))

    weighted = sum(dims[f] * w for f, w in DIM_WEIGHTS.items())
    reasons = []

    answers = [breakers[f] for f in BREAKER_FIELDS]
    if any(a in ("Y", "U") for a in answers) or pack_breakers == "unmitigated":
        breaker_ceiling = "horrid"
        reasons.append("unmitigated breaker (Y or U, or pack breaker unmitigated)")
    elif any(a == "M" for a in answers) or pack_breakers == "mitigated":
        breaker_ceiling = "okay"
        reasons.append("mitigated breaker caps the grade at okay")
    else:
        breaker_ceiling = "great"

    if any(dims[f] == 0 for f in DIM_WEIGHTS):
        zero_ceiling = "bad"
        reasons.append("a dimension scored 0 caps the grade at bad")
    else:
        zero_ceiling = "great"

    band = band_for(weighted)
    result = _worse(_worse(breaker_ceiling, zero_ceiling), band)
    return {
        "weighted_score": weighted,
        "max_score": MAX_SCORE,
        "score_pct": round(weighted * 100.0 / MAX_SCORE, 1),
        "breaker_ceiling": breaker_ceiling,
        "zero_dimension_ceiling": zero_ceiling,
        "band": band,
        "structural_grade": result,
        "reasons": reasons,
    }


def negotiation_score(nscores):
    """Return NQS, classification and active failure predicates.
    nscores values may be int/float 0-100 or None/blank (treated as missing).
    """
    present = {}
    for k, w in N_WEIGHTS.items():
        v = nscores.get(k)
        if v is None or v == "":
            continue
        try:
            fv = float(v)
        except (TypeError, ValueError):
            raise InputError("%s must be a number 0-100 (got %r)" % (k, v))
        if not 0 <= fv <= 100:
            raise InputError("%s must be 0-100 (got %r)" % (k, v))
        present[k] = fv

    if not present:
        return {
            "nqs": None,
            "negotiation_classification": None,
            "failure_predicates": [],
            "reasons": ["no negotiation dimensions supplied"],
        }

    # If some dimensions are missing we still compute a partial NQS from those present,
    # renormalizing weights. For governance use the caller should require full coverage.
    weight_sum = sum(N_WEIGHTS[k] for k in present)
    nqs = sum(present[k] * N_WEIGHTS[k] for k in present) / weight_sum * 100.0 / 100.0
    # Actually: weighted average already 0-100 scale
    nqs = sum(present[k] * N_WEIGHTS[k] for k in present) / weight_sum

    predicates = []
    if "n9_epistemic_integrity" in present and present["n9_epistemic_integrity"] < 40:
        predicates.append("F1_epistemic")
    if "n8_risk_allocation" in present and present["n8_risk_allocation"] < 40:
        predicates.append("F2_risk")
    if "n10_procedural_legitimacy" in present and present["n10_procedural_legitimacy"] < 40:
        predicates.append("F3_legitimacy")

    if predicates:
        classification = "failed"
    elif nqs >= 95:
        classification = "exceptional"
    elif nqs >= 85:
        classification = "high_quality"
    elif nqs >= 70:
        classification = "competent"
    elif nqs >= 55:
        classification = "marginal"
    elif nqs >= 40:
        classification = "poor"
    else:
        classification = "failed"

    return {
        "nqs": round(nqs, 1),
        "negotiation_classification": classification,
        "failure_predicates": predicates,
        "reasons": ["failure predicates fired: " + ",".join(predicates)] if predicates else [],
    }


def overall_verdict(structural, negotiation):
    s = structural.get("structural_grade") if structural else None
    n = negotiation.get("negotiation_classification") if negotiation else None
    return _worse(s, n)


def compute_maintenance(row):
    """Return maint_adj_ebitda and price_adj_for_known if inputs present."""
    def num(key):
        v = row.get(key, "")
        if v is None or v == "":
            return None
        try:
            return float(v)
        except ValueError:
            return None

    ebitda = num("ebitda_usd_m")
    maint = num("maint_capex_usd_m")
    warranty = num("warranty_normalization_usd_m") or 0.0
    catchup = num("catchup_capex_usd_m") or 0.0
    known = num("known_upcoming_costs_usd_m")
    value = num("value_usd_m")  # may live on deal; here we only use assessment fields

    maint_adj = None
    if ebitda is not None and maint is not None:
        maint_adj = ebitda - maint - warranty

    price_adj = None
    # known_upcoming_costs is preferred; fall back to catchup if only that is present
    if known is not None:
        # price_adj needs enterprise value; leave blank if not supplied on assessment
        pass
    return {
        "maint_adj_ebitda_usd_m": round(maint_adj, 2) if maint_adj is not None else "",
        "price_adj_for_known_usd_m": "",  # requires EV; filled only when both present
    }


def process_row(row):
    scope = (row.get("assessment_scope") or "both").strip().lower()
    result = {"assessment_id": row.get("assessment_id", "")}

    # Structural
    structural = None
    if scope in ("structural", "both"):
        breakers = {f: (row.get(f) or "").strip().upper() for f in BREAKER_FIELDS}
        pack = (row.get("pack_breakers") or "n/a").strip().lower()
        dims = {}
        for f in DIM_WEIGHTS:
            raw = row.get(f, "")
            if raw == "" or raw is None:
                raise InputError("%s required for structural scope" % f)
            dims[f] = int(raw)
        structural = structural_grade(breakers, pack, dims)
        result.update(structural)

    # Negotiation
    negotiation = None
    if scope in ("negotiation", "both"):
        nscores = {k: row.get(k) for k in N_WEIGHTS}
        negotiation = negotiation_score(nscores)
        result["nqs"] = negotiation["nqs"]
        result["negotiation_classification"] = negotiation["negotiation_classification"]
        result["failure_predicates"] = ",".join(negotiation["failure_predicates"])

    # Overall
    result["overall_integrity_verdict"] = overall_verdict(structural or {}, negotiation or {})

    # Maintenance (best-effort)
    maint = compute_maintenance(row)
    result.update(maint)

    return result


def main():
    parser = argparse.ArgumentParser(description="DealIntegrity grade calculator")
    parser.add_argument("assessments", help="Path to assessments.csv")
    parser.add_argument("--out", help="Optional JSON report path")
    args = parser.parse_args()

    try:
        with open(args.assessments, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
    except OSError as e:
        print("Cannot read %s: %s" % (args.assessments, e), file=sys.stderr)
        sys.exit(2)

    if not rows:
        print("No assessment rows found.", file=sys.stderr)
        sys.exit(2)

    all_results = []
    mismatches = 0
    for row in rows:
        try:
            computed = process_row(row)
        except InputError as e:
            print("ERROR on %s: %s" % (row.get("assessment_id", "?"), e), file=sys.stderr)
            sys.exit(2)
        all_results.append(computed)

        # Compare with recorded values if present
        for key in ("structural_grade", "nqs", "negotiation_classification",
                    "overall_integrity_verdict", "weighted_score"):
            recorded = (row.get(key) or "").strip()
            got = computed.get(key)
            if recorded and got is not None and str(got) != recorded:
                print("MISMATCH %s.%s: recorded=%r computed=%r" % (
                    row.get("assessment_id"), key, recorded, got), file=sys.stderr)
                mismatches += 1

        print("=== %s ===" % computed.get("assessment_id", ""))
        for k, v in computed.items():
            if k == "assessment_id":
                continue
            print("  %s: %s" % (k, v))

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(all_results, f, indent=2)

    if mismatches:
        sys.exit(3)
    sys.exit(0)


if __name__ == "__main__":
    main()
