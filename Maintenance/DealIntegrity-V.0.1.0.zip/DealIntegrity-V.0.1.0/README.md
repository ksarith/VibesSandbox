# DealIntegrity

**Version 0.1.0** — Unified governance-grade framework for assessing both the structural quality of an M&A deal **and** the integrity of the negotiation that produced it.

This package merges and extends the earlier AcquisitionsAnalysis method with a full Negotiation Quality layer. The result is a single assessment that can answer:

- Is the deal itself sound (or fatally flawed)?
- Was the negotiation conducted with process discipline, strategic alignment, and epistemic/governance integrity?

Most scoring systems collapse outcome, process, and legitimacy. This framework deliberately keeps them separate and applies hard failure predicates so that excellence in one area cannot paper over constitutional failure in another.

## Two complementary gates

| Gate | Focus | Output |
|------|-------|--------|
| **Structural Integrity** | The deal as an asset + terms | Grade: Great / Good / Okay / Bad / Horrid |
| **Negotiation Integrity** | How the deal was negotiated | Classification: Exceptional / High Quality / Competent / Marginal / Poor / Failed |

**Overall Integrity Verdict** = the worse of the two (plus any active failure predicate).

## Core design principles

1. **Questions before numbers.** Scores summarize answers; they do not replace them.
2. **Evidence or unknown.** Every non-unknown answer cites at least one evidence row. “Nothing found” is a finding that requires its own row.
3. **Hard overrides.** Structural breakers and negotiation failure predicates cannot be compensated by high scores elsewhere.
4. **Tool computes; agent judges.** The agent gathers evidence and answers the questions. `tools/calculate_grade.py` applies the arithmetic and precedence rules. Never improvise a formula or threshold.
5. **Prospective vs retrospective.** An assessment is either limited to information available at announcement (or during negotiation) or allowed to use hindsight. They are never mixed in one record.
6. **Sector packs.** The core is sector-neutral. Packs sharpen questions and may add breakers for one industry without changing weights or grade rules.

## Data model

Three tables (same join pattern as the predecessor):

- `data/deals.csv` — facts only about the transaction
- `data/assessments.csv` — one row per grading of a deal (can contain structural answers, negotiation answers, or both)
- `data/evidence.csv` — every answer is backed by one or more evidence rows

## Tools (standard library only)

```bash
python3 tools/calculate_grade.py data/assessments.csv
python3 tools/validate_data.py
python3 -m unittest discover -s tests
```

## Status

v0.1.0 is the first merged release. Structural rules are carried forward from AcquisitionsAnalysis core-0.3 (with no weight or band changes). Negotiation rules are newly formalized from the governance-oriented proposal and have not yet been calibrated on real negotiations. Treat thresholds as starting values.

## Documents

- Full method: [`docs/methodology.md`](docs/methodology.md)
- Field definitions & evidence rules: [`docs/schema.md`](docs/schema.md)
- Agent instructions: [`SKILL.md`](SKILL.md)
- Report format: [`docs/report_template.md`](docs/report_template.md)
- Packs: [`packs/README.md`](packs/README.md)
