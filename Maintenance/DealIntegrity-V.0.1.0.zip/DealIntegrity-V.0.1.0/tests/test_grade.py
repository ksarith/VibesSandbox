#!/usr/bin/env python3
"""Minimal self-check for the grade calculator."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import calculate_grade as cg


class TestStructural(unittest.TestCase):
    def test_clean_high_score(self):
        breakers = {f: "N" for f in cg.BREAKER_FIELDS}
        dims = {f: 4 for f in cg.DIM_WEIGHTS}
        r = cg.structural_grade(breakers, "n/a", dims)
        self.assertEqual(r["structural_grade"], "great")
        self.assertEqual(r["weighted_score"], 60)

    def test_unmitigated_breaker_forces_horrid(self):
        breakers = {f: "N" for f in cg.BREAKER_FIELDS}
        breakers["b1_regulatory"] = "Y"
        dims = {f: 4 for f in cg.DIM_WEIGHTS}
        r = cg.structural_grade(breakers, "n/a", dims)
        self.assertEqual(r["structural_grade"], "horrid")


class TestNegotiation(unittest.TestCase):
    def test_high_nqs(self):
        ns = {k: 90 for k in cg.N_WEIGHTS}
        r = cg.negotiation_score(ns)
        self.assertEqual(r["negotiation_classification"], "high_quality")
        self.assertAlmostEqual(r["nqs"], 90.0, places=1)

    def test_epistemic_failure_predicate(self):
        ns = {k: 90 for k in cg.N_WEIGHTS}
        ns["n9_epistemic_integrity"] = 30
        r = cg.negotiation_score(ns)
        self.assertEqual(r["negotiation_classification"], "failed")
        self.assertIn("F1_epistemic", r["failure_predicates"])


class TestOverall(unittest.TestCase):
    def test_worse_of_two(self):
        self.assertEqual(cg._worse("great", "competent"), "competent")
        self.assertEqual(cg._worse("horrid", "exceptional"), "horrid")
        self.assertEqual(cg._worse(None, "good"), "good")


if __name__ == "__main__":
    unittest.main()
