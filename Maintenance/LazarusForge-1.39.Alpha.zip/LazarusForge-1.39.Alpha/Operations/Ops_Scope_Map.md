# Ops_Scope_Map.md — Operations/

## Navigation Anchors
[README.md](../README.md) | [Discovery.md](../Discovery.md) | [Routing.md](../Routing.md) | [Unknowns.md](../Unknowns.md) | [Admin/Adm_Scope_Map.md](../Admin/Adm_Scope_Map.md) | [Architecture/Arc_Scope_Map.md](../Architecture/Arc_Scope_Map.md)

## File State

| Field            | Value                                                               |
|------------------|----------------------------------------------------------------------|
| Status           | Active — Index                                                      |
| Spec Gates       | N/A — this file is a cross-reference index, not a specification     |
| Open Unknowns    | 0 (surfaces existing unknowns from owning files; creates none)      |
| Owning Domain    | Operations/                                                          |
| Last Reviewed    | 2026-10-27 — Full Does / Does-not re-derivation pass across all 16 entries against their owning files' live Scope Boundaries (PKC-033 resolved: 14 entries updated, 2 — Exception_Evidence, Tooling_Inventory — verified clean; one pre-existing contradiction fixed — the Energy entry claimed the EGL was audited 2026-08-02 while the owning file says not yet audited / not Gate-1 cleared). Prior: 2026-10-27 — Energy entry count updated 5 → 8 (PKC-034: EV-006/EV-007/EV-008 registered in `Operations/Energy.md`). Prior: 2026-10-25 — Status of three entries (Automotive, Robotics, Exception_Evidence) changed from Proposed to Exploration to match their owning files (PKC-031); content refresh still open under PKC-033. Prior: 2026-10-24 — Open Unknowns counts refreshed for eight entries from their owning files' headers (Plastics, Air_Scrubber, Gate_01, 02, 03, 04, 05, 07); Does / Does-not text not re-derived (Progress_Log PKC-033). Prior: 2026-10-10 — Automotive.md + Robotics.md Proposed stubs registered|
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present. |

---

## Purpose

Third folder in the Scope_Map rollout, following `Admin/Adm_Scope_Map.md` (2026-08-07) and `Architecture/Arc_Scope_Map.md` (2026-08-08). Same method throughout: every entry extracted directly from its file's own File State and Scope Boundary sections, not reconstructed from memory. Per instruction from the human governing authority, errors found during this build were fixed in the same pass rather than only cataloged — see Gaps Exposed below for what was found and fixed.

---

## Scope Entries

### `Operations/Air_Scrubber.md`
**Status:** Draft · 3/6 · 6 Open Unknowns · Risk: High
**Does:** Five-stage functional architecture (A-E) plus fractional condensation/chemisorption; wet capture variants (0-4); Saturation/Particulate Blinding/Thermal Fault monitoring; E-Stop interlocks; negative pressure/flashback doctrine; noise hazard acknowledgment and hearing-protection requirements; energy awareness and power-budget estimates; waste as a managed output; Gate 4 Cold Verification Harness; §EC-013 Descent Sequence (Proposed/Placeholder, Blocking for hot runs, filed 2026-09-20); integration hooks to upstream/downstream modules.
**Does not (arrow):** Spin Chamber exhaust heat load (`Gate_05_Separation_Thermal.md`) · Forge power budget (`Energy.md`) · deep-sea compression (`Admin/Trajectories.md`) · contamination routing (`Gate_02_Triage.md`) · noise/PPE standards (`Admin/Safety_Protocols.md` SP-003) · scrubber bootstrap minimum for remote deployment (`Architecture/Geck_forge_seed.md`) · facility siting (`Architecture/Facilities.md` FA-001).


### `Operations/Automotive.md`
**Status:** Exploration · 0/6 · 8 Open Unknowns (AU-002/003/004 Blocking for stated physical work; AU-001–AU-008) · Risk: High (kinetic / HV)
**Does:** Operations-layer home for salvage-aware vehicle systems — hard floors AF-1 to AF-13, functional blocks A–J (thresholds Placeholder), interfaces to Energy/Electronics/Gates/Admin. Workshop and controlled private ground only.
**Does not (arrow):** Road-legality or public-road testing · Energy.md pack chemistry · Electronics.md general firmware trust · Robotics.md (mobile bases share interfaces only) · full autonomy / driver-replacement stacks (at most supervised aids; human authority retained) · Measured range/autonomy claims.
**Upstream:** Energy.md · Electronics.md · Safety_Protocols.md · Environmental_Constraints.md
**Filed:** 2026-10-10 (v0 stub)

### `Operations/Electronics.md`
**Status:** Exploration · 0/6 · 9 Open Unknowns · Risk: High
**Does:** Non-destructive salvage harvesting protocols; firmware trust doctrine (Logic-Zero wipe); PCB fabrication methods; TMR hardware implementation; hardware watchdog doctrine (CF-001); dual-use annotation; counterfeit/remarked component detection; soldering standards; Forge-Standard interface adapter layer; fault response and Support Raft integration; toxic dust and BFR emission profile doctrine.
**Does not (arrow):** TMR as philosophy/framework (`Architecture/Cognitive_Frameworks.md` Framework D) · dual-use ethical escalation (`Admin/Ethical_Constraints.md`) · Air Scrubber specs (`Air_Scrubber.md`) · component taxonomy (`Architecture/Components.md`) · crypto/root-of-trust (unassigned, EL-006) · confidence collapse/split-brain doctrine (`Architecture/Cognitive_Frameworks.md`) · Leviathan mission logic (`Tests/Leviathan_testing.md`) · full autonomous governance law (`Admin/Ethical_Constraints.md`). *(Note 2026-10-27: the previous line's “Forge-Net implementation” item is no longer in the owning file's current Does-not list but was retained — removal is not warranted from a re-derivation alone.)*

### `Operations/Energy.md`
**Status:** Draft · 1/6 · 8 Open Unknowns · Risk: High
**Does:** Incremental energy integration philosophy v0–v1; energy lifecycle progression from external grid reliance to partial thermal/waste recovery; generation interlocks (syngas/biomass); power mode envelopes and voltage sag protocols; battery protection parameters; primary and secondary falsifiable performance metrics; Energy Governance Layer (EGL — Demand/Generation/Arbitration/Thermal models, proposed, drafted 2026-08-01, not yet audited — body still not Gate-1 cleared; *(corrected 2026-10-27 from “audited 2026-08-02, not yet ratified”, which contradicted the owning file's own Scope Boundary)*); Storage Model & Battery Governance; Source Stability & Harmonization Layer; Energy Capability Trajectory (v0→v3); Superconductivity Horizons (SC-H1–H3 → EV-006–EV-008, exploratory only, registered 2026-10-27).
**Does not (arrow):** Deep-environment battery physics (`Tests/Leviathan_testing.md` LT-002) · Leviathan power envelope (`Tests/Leviathan_testing.md` LT-001) · unknown-cell chemistry sorting (`Gate_02_Triage.md`) · crypto/root-of-trust (`Electronics.md` EL-006) · mechanical drawings for battery containment structures · detailed superconductivity materials science (exploratory horizon only) · Spec Gate definitions (`Admin/Verification_Gates.md`).

### `Operations/Gate_01_Intake.md`
**Status:** Exploration · 0/6 · 6 Open Unknowns · Risk: Medium
**Does:** Entry protocol for all items; safety screening (hazard/energetic/biological/chemical/radiological); physical document handling; digital reference lookup doctrine; item tagging/provenance; unknown-item hold-and-inspect; fastener/small-component recovery; parts list generation doctrine for known assemblies; Forge_Net primary-lookup integration; handoff to Triage.
**Does not (arrow):** Triage workflow detail (`Gate_02_Triage.md`) · reference database schema (`Architecture/Forge_Net.md` GI-001) · cognitive save state (`Architecture/Forge_Net.md` FN-005) · energetic material disposal (unassigned, GI-002) · provenance tracking system (`Admin/Ship_of_Theseus.md` grain system) · network sync protocol for intake records (`Architecture/Forge_Net.md`) · contamination handling beyond intake screening (`Architecture/Forge_flow.md` defined terms, `Gate_02_Triage.md`) · air handling during intake screening (`Air_Scrubber.md`) · facility siting (`Architecture/Facilities.md` FA-001).

### `Operations/Gate_02_Triage.md`
**Status:** Draft · 2/6 · 9 Open Unknowns · Risk: High
**Does:** Core triage principles; false-positive tolerance/bootstrap asymmetry; Strategic Recoverability tiers; Gate correspondence table; queue economics; five triage stations; triage Terminal and Oversight State behavior; failure modes and mitigations; data/learning loop requirements; minimum viable triage configuration for Gen-1; human review criteria for Gate_04 Unknown Bulk (pending TS-009); battery chemistry sorting algorithms deferred from Energy (pending TS-010); §XII intelligence/arbitration/capability/maturity extension (proposed, unaudited, explicitly not load-bearing).
**Does not (arrow):** Master gate logic/vocabulary (`Architecture/Forge_flow.md`) · decontamination/air handling (`Air_Scrubber.md` AS-003) · electrical harvesting (`Electronics.md`) · reduction methods (`Gate_03_Reduction.md`) · Anti-Weaponization pattern-matching (`Admin/Ethical_Constraints.md` EC-002) · component taxonomy (`Architecture/Components.md`) · FRT accounting (`Gate_07_Utilization.md`, `Admin/Trajectories.md`) · §XII's constitutional bindingness (explicitly deferred to `Admin/CIR_Gov.md`'s own Binding Status, itself Proposed-Not-Ratified pending GOV-008 — this file cannot promote §XII above that).

### `Operations/Gate_03_Reduction.md`
**Status:** Exploration · 0/6 · 8 Open Unknowns (corrected 2026-08-25 from a stale "8" — GR-003 Resolved 2026-08-24) · Risk: High
**Does:** Reduction permission doctrine and prerequisites; output envelope; prohibited-input catch list; method selection (shredding/cutting/milling); contamination-discovery protocol; dust/fines/particulate handling; emergency shutdown; handoff to Gate_04; bio/chemical waste disposal doctrine (GR-003, Resolved 2026-08-24 — five categories, concrete hold-duration/container values); §EC-013 Descent Sequence (Proposed/Placeholder, Blocking for hot runs, filed 2026-09-21).
**Does not (arrow):** Routing logic into Reduction (`Architecture/Forge_flow.md` Decision Points A–D) · upstream hazard screening (`Gate_01_Intake.md` GI-002) · machine procurement (unassigned, GR-002) · dust collection hardware (`Air_Scrubber.md`) · energy accounting (`Energy.md`) · purification processing of Reduction output (`Gate_04_Separation_Mechanical.md`, `Gate_05_Separation_Thermal.md`) · facility siting (`Architecture/Facilities.md` FA-001). *(Correction 2026-08-25: this line previously listed "bio/chemical waste disposal (unassigned, GR-003)" as something this file does not own — that was a pre-existing self-reference error, since GR-003 has always been this same file's own unknown, not another file's. Moved to the Does line above, where it belongs, and updated to reflect its 2026-08-24 closure.)*

### `Operations/Gate_04_Separation_Mechanical.md`
**Status:** Exploration · 0/6 · 9 Open Unknowns · Risk: Medium
**Does:** Material Separation Gate design intent; v0 physical subsystems (rotor/sensors/collection zones/fail-to-bin); RPM band/stratification; sensor cross-check confidence scoring; output classification (A/B/C/Unknown Bulk/Fail); scaling/replication doctrine; falsifiable performance metrics (Material Diversion Rate, Unknown Bulk Rate); Bootstrap Proxy Mode; lifecycle/failure modes/degraded operation; contamination risk statement and refusal-first rationale.
**Does not (arrow):** Upstream reduction (`Gate_03_Reduction.md`) · thermal processing of Class C (`Gate_05_Separation_Thermal.md`) · triage/human review (`Gate_02_Triage.md`) · air handling (`Air_Scrubber.md`) · energy accounting (`Energy.md`) · marine thermal sink (`Tests/Support_Raft.md`) · biofouling impact (`Tests/Leviathan_testing.md`) · powder feedstock (explicit non-goal, all versions until stated otherwise) · EM field bias for future versions (deferred, `Admin/Trajectories.md`) · detailed sensor specs/spectroscopy hardware (not yet assigned).

### `Operations/Gate_05_Separation_Thermal.md`
**Status:** Exploration · 0/6 · 10 Open Unknowns · Risk: Medium
**Does:** Spin Chamber operating principle/design intent; v0 geometry/scale; crucible/shell materials; rotation drive philosophy; heating strategy; EM field approach; atmosphere control; extraction interfaces including wire extrusion as a planned interface; instrumentation and control philosophy; failure philosophy; role as a material contributor to self-replication; reconciliation of thermal inputs against Gate_04's Class C output (pending SC-010); §EC-013 Descent Sequence (Proposed/Placeholder, Blocking for hot runs, filed 2026-09-20).
**Does not (arrow):** Feedstock prep (`Gate_03_Reduction.md`) · mechanical separation (`Gate_04_Separation_Mechanical.md`) · wire extrusion nozzle design (deferred, `Admin/Trajectories.md`) · welding wire specification/qualification (`Architecture/Geck_forge_seed.md`, UNK-008 — corrected 2026-08-08, was inconsistent with this file's own already-correct Lessons Learned citation) · self-replication architecture (`Architecture/Forge_flow.md`, `Architecture/Geck_forge_seed.md`) · facility siting (FA-001) · drive geometry (SC-005) · MHD auxiliary coil detailed specification.

### `Operations/Gate_06_Fabrication.md`
**Status:** Exploration · 0/6 · 7 Open Unknowns · Risk: Medium
**Does:** Fabrication doctrine/priority order; arc welding as v0 gatekeeper capability; add-to-excess/mill-to-spec philosophy; welding wire feedstock requirements; precision ceiling doctrine; operator safety (PPE/shielding/ventilation); method introduction/qualification criteria; feedback to Component Library; integration with upstream Gate_04/Gate_05 and downstream Utilization; recognition that qualified welding wire enables future WAAM/wire-arc DED processes once the method itself is qualified under Section 6; §EC-013 Descent Sequence (Proposed/Placeholder, Blocking for hot runs, filed 2026-09-21).
**Does not (arrow):** Wire extrusion nozzle/draw speed (`Gate_05_Separation_Thermal.md` SC-004) · welding wire chemical qualification (`Architecture/Geck_forge_seed.md`, UNK-008 — corrected 2026-08-08, was stale since 2026-07-19) · laser/powder welding, casting/pressing/forging (deferred, `Admin/Trajectories.md`) · machining hardware selection (this file's own GF-003, genuinely open — a pending design decision, not an ownership gap) · Component Library spec (`Architecture/Components.md`) · precision ceiling ownership (`Architecture/Precision.md`).

### `Operations/Gate_07_Utilization.md`
**Status:** Exploration · 0/6 · 4 Open Unknowns · Risk: Low
**Does:** After-action review doctrine; performance logging minimums; failure mode capture/routing; maintenance frequency tracking; feedback to Fabrication and Forge-Net; retirement handoff doctrine; FRT per-cycle logging (measurement/reinvestment against `Admin/Trajectories.md`'s floor); part lifecycle termination; feedback path to `Architecture/Forge_flow.md` classification rules (real-world performance improves upstream gate routing).
**Does not (arrow):** Retirement routing decisions (`Gate_02_Triage.md`) · fabrication methods/precision ceiling (`Gate_06_Fabrication.md`) · component taxonomy (`Architecture/Components.md`) · network trust weighting (`Architecture/Forge_Net.md`) · gate logic (`Architecture/Forge_flow.md`) · energy accounting (`Energy.md`) · FRT floor declaration/v1 baseline (`Admin/Economics.md`) · facility siting beyond logging doctrine (`Architecture/Facilities.md` FA-001) · formal quality certification or standards.


### `Operations/Robotics.md`
**Status:** Exploration · 0/6 · 8 Open Unknowns (RB-001–RB-008) · Risk: High (force / human-shared space)
**Does:** Operations-layer home for salvage-aware mobile bases and manipulators — hard floors RF-1 to RF-12, functional blocks A–J (thresholds Placeholder), interfaces to Energy/Electronics/Automotive/Gates/Admin/Ethical_Constraints. Controlled cell / supervised teleoperation only.
**Does not (arrow):** Unsupervised human-shared operation · AGI/embodiment claims · Electronics.md general firmware trust · Automotive.md on-road systems · Weaponized configurations · full ROS/stack architecture as product documentation (only Forge operational constraints and evidence rules).
**Upstream:** Energy.md · Electronics.md · Safety_Protocols.md · Ethical_Constraints.md
**Filed:** 2026-10-10 (v0 stub)

### `Operations/Plastics.md`
**Status:** Exploration · 0/6 · 4 Open Unknowns · Risk: High
**Does:** Salvaged polymer triage routing; low-pressure oxygen-free pyrolysis conceptual framework; batch-fed reaction chamber/condenser array design requirements; off-gas containment boundaries; char/residue handling; Halogenated Polymer Triage Protocol (PL-001, Resolved 2026-08-23 via Payment via Specification — class-split screening for PVC/Cl–Br vs PTFE/fluoropolymer; Blocking retained pending PL-001-R1 empirical validation); §EC-013 Descent Sequence (Proposed/Placeholder, Blocking for hot runs, filed 2026-09-20).
**Does not (arrow):** Per-polymer temperature profiles · custom extrusion/filament-drawing mechanical blueprints · fractional distillation specs · Air Scrubber hardware (`Air_Scrubber.md`) · intake hazard screening (`Gate_01_Intake.md`) · contamination routing (`Gate_02_Triage.md`) · energy accounting (`Energy.md`) · facility siting (FA-001) · operator PPE (`Admin/Safety_Protocols.md`).

### `Operations/Tooling_Inventory.md`
**Status:** Exploration · 0/6 · 1 Open Unknown · Risk: Medium
**Does:** The live operational tooling inventory used by Decision Point B ("within current tooling capability"); ownership and maintenance cadence for that inventory; the conservative default rule when the inventory is stale or incomplete; distinction between this operational inventory and the system-component taxonomy in `Architecture/Components.md`.
**Does not (arrow):** System-level Critical/Useful/Bootstrap component taxonomy (`Architecture/Components.md`) · detailed machine specifications, tolerances, or process parameters · G.E.C.K. consumables and redundancy stock (`Architecture/Geck_forge_seed.md`) · Gate logic itself (`Architecture/Forge_flow.md`) · repair methods or repair heuristics beyond the inventory reference (`Architecture/Forge_flow.md` Decision Point B and `Operations/Gate_02_Triage.md`).
**Note:** Added to this map 2026-09-13 — created 2026-09-08 from the HP-007 skeleton, after this map's prior 2026-08-15 Last Reviewed date; missed by the original build for that reason, not excluded deliberately.

### `Operations/Exception_Evidence.md`
**Status:** Exploration · 0/6 · FL-006-A (structural owner named; population and demonstrated maintenance still open) · Risk: Medium
**Does:** Evidence-control specification and index for Oversight State's exception evidence portfolio — defines evidence classes (episodic packages + standing reference), required fields, deposit and handoff rules, freshness/provenance expectations, and pointers to where authoritative records live. Fills the Operations cell in `Architecture/Forge_flow.md`'s HP-011 Transition Ownership table that was previously blank (FL-006 half A). Carries an explicit anti-policy rule: evidence in or referenced by this file is not a decision, authorization, routing instruction, or policy.
**Does not (arrow):** Store the entire operational evidence universe — episodic packet bodies and standing data live in the operational records this file *points to* · decide want/need policy (stays in `Architecture/Forge_flow.md`) · own routing or Escalate authority (FL-006 half B, separately owned by EC-003) · resolve GOV-006 or GMP-004 · replace `Gate_01_Intake.md` or `Gate_02_Triage.md` procedures.
**Note:** Created 2026-09-18. Upstream gates deposit to this file's control schema; they do not own the Oversight evidence portfolio. Operational maintainer pending (same honesty as `Tooling_Inventory.md` / TI-001). FL-006 remains Open.

### `Operations/Woodworking.md`
**Status:** Draft · 0/6 · 5 Open Unknowns · Risk: High
**Does:** Timber sourcing hierarchy; felling/chainsaw safety; green wood handling/anisotropic behavior/drying; structural woodgrain deployment; power/hand tool milling for irregular stock; CNC/router fixturing; heat treatment/surface modification; joinery/adhesive/finishing doctrine; waste valorization through papermaking; dust and species-specific hazard doctrine (climate-zone variables).
**Does not (arrow):** CNC toolpath/G-code/CAM · full shop dust extraction system design (`Air_Scrubber.md`) · structural load-bearing calculations · commercial lumber grading/industrial forestry · facility siting (FA-001) · hearing conservation/PPE sourcing (`Admin/Safety_Protocols.md`).

---

## EC-013 Descent Sequence Cross-Reference Index

*Discoverability table only — does not alter governance status, close EC-013, or advance any Spec Gates. Index is complete for Cycle 1 only (MAQT-C1-EC013-CROSSREF, 2026-09-22); additional EC-013 descent sequences may be added in future cycles. File location selected per MAQT Cycle 1 Option A ("e.g. in Ops_Scope_Map.md if present") — not a canonical designation. Proposal implemented following Cycle 1 Planner/Skeptic/Auditor review chain; human ratification issued 2026-09-22 outside agent sessions.*

| File | EC-013 section | Status |
|------|----------------|--------|
| `Operations/Plastics.md` | §EC-013 Descent Sequence — Plastics / Pyrolysis | Proposed/Placeholder — Blocking for hot runs — does not close EC-013 |
| `Operations/Air_Scrubber.md` | §EC-013 Descent Sequence — Air Scrubber | Proposed/Placeholder — Blocking for hot runs — does not close EC-013 |
| `Operations/Gate_05_Separation_Thermal.md` | §EC-013 Descent Sequence — Gate_05 Spin Chamber | Proposed/Placeholder — Blocking for hot runs — does not close EC-013 |
| `Operations/Gate_03_Reduction.md` | §EC-013 Descent Sequence — Gate_03 Reduction | Proposed/Placeholder — Blocking for hot runs — does not close EC-013 |
| `Operations/Gate_06_Fabrication.md` | §EC-013 Descent Sequence — Gate_06 Fabrication | Proposed/Placeholder — Blocking for hot runs — does not close EC-013 |

---

## Gaps Exposed By Building This

1. **Same UNK-008 staleness pattern found in two more files, both fixed same-day.** `Gate_06_Fabrication.md`'s Scope Boundary said welding-wire chemical qualification was "not yet assigned — UNK-008" — wrong since 2026-07-19, when ownership moved to `Geck_forge_seed.md`; the file's own body text (lines 682, 879) already cited UNK-008 correctly elsewhere, only the summary line had drifted. `Gate_05_Separation_Thermal.md`'s Scope Boundary said the same thing more vaguely ("downstream — not yet assigned") — also inconsistent with that file's own Lessons Learned table, which already correctly cited the 2026-07-19 reassignment. Both fixed. Combined with `Forge_flow.md`'s identical error found and fixed yesterday, this makes **three separate files** that had drifted on the exact same fact after the same 2026-07-19 ownership change — worth noting as a pattern: a single ownership reassignment can leave stale pointers scattered across a surprising number of files, none of which cross-check each other.

2. **One "not yet assigned" checked and confirmed genuinely correct, not fixed:** `Gate_06_Fabrication.md`'s GF-003 (machining/milling hardware) really is this file's own open unknown — "not yet assigned" means the hardware choice is pending, not that ownership is unclear. Checked against `Unknowns.md` before assuming it was another instance of the same pattern; it isn't.

3. **No missing or non-conforming Scope Boundary sections in this folder** — all 12 files (as of 2026-08-08) have complete, conforming content, same as Architecture/ and unlike Admin/'s two structural gaps.

4. **No new hub pattern found distinct from what's already known** — `Architecture/Forge_flow.md` (gate logic/vocabulary) and `Architecture/Facilities.md` (siting, FA-001) are the two most frequently cross-referenced files from this folder, consistent with their already-established roles from the Architecture/ pass, not a new finding.

Three corrections applied this pass (`Gate_05_Separation_Thermal.md`, `Gate_06_Fabrication.md`), consistent with instruction from the human governing authority to fix errors found along the way rather than only catalog them. No new unknowns registered — all three were stale pointers to an already-existing, already-correct ownership record, not open questions.

---

## Resolution Log

- 2026-10-27: **PKC-033 resolved — full Does / Does-not re-derivation pass** (Vibe, human-authorized autonomous management; same method as the map's own 2026-08-08 build: every entry re-derived from its owning file's live File State and Scope Boundary, nothing reconstructed from memory). 14 entries updated, 2 verified clean (Exception_Evidence, Tooling_Inventory). Largest additions: §EC-013 descent sequences added to the Does lines of five entries (Plastics, Air_Scrubber, Gate_03, Gate_05, Gate_06 — all filed Proposed/Placeholder after the 2026-08-08 build); PL-001 Halogenated Polymer Triage Protocol added to Plastics' Does; TS-009/TS-010 pending items added to Gate_02's Does; SC-010 reconciliation added to Gate_05's Does; WAAM/wire-arc DED recognition added to Gate_06's Does; plus assorted Does-not additions (Gate_01 network sync / contamination beyond screening / air handling; Gate_03 purification of output; Gate_04 EM-field bias / sensor specs; Gate_05 MHD auxiliary coil; Gate_07 siting / quality certification; Electronics split-brain / Leviathan / autonomous-governance-law; Automotive driver-replacement stacks; Robotics ROS stack; Air_Scrubber Geck bootstrap). One contradiction fixed: the Energy entry said the EGL was “audited 2026-08-02, not yet ratified”; the owning file's own Scope Boundary says “proposed, drafted 2026-08-01, not yet audited” and its audit chain notes “EGL body still not Gate-1 cleared” — the entry now matches the source. No header field (Status / Spec Gates / Open Unknowns / Risk) changed anywhere — the 2026-10-24/25/27 count passes had already brought those current. No owning file edited: re-derivation found no defect in any owning file's own Scope Boundary (the Automotive/Robotics/Exception_Evidence missing Highest-Risk row is a pre-known template-normalization item, deferred per the human's low-value-polish disposition). Report-then-fix posture used as the stated default: everything found was fixed in the map, nothing was found that required reporting against an owning file.

- 2026-10-27: Energy entry's Open Unknowns count updated 5 → 8 to match `Operations/Energy.md`'s File State after EV-006, EV-007 and EV-008 were registered there (PKC-034; superconductivity horizons SC-H1–H3, possibilities with low expectations). Count-only change; Does / Does-not text not re-derived (PKC-033). Human-directed.

- 2026-10-25: Status of the Automotive, Robotics and Exception_Evidence entries changed from "Proposed" to "Exploration", matching their owning files after the PKC-031 ruling (found by the Vibe baseline pull). The EC-013 "Proposed/Placeholder" labels on five other entries describe a descent-sequence role, not a file Status, and were left. No Does / Does-not text, count or Unknown changed. Human-directed.

- 2026-10-24: Open Unknowns counts refreshed for eight entries (human-directed, from a Vibe per-file audit; each finding checked against source first): Plastics 5→4, Air_Scrubber 4→6, Gate_01 7→6, Gate_02 7→9, Gate_03 7→8, Gate_04 8→9, Gate_05 9→10, Gate_07 5→4, each taken from the owning file's current File State header. The Does / Does-not text of those entries was not re-derived (parked as Progress_Log PKC-033). The "all 12 files" claim in the Gaps section is now date-stamped 2026-08-08. Registration of `Exception_Evidence.md` (the entry carries "Created 2026-09-18") was never logged here; the date it was added to this map is not recorded.

- 2026-10-10: Registered `Operations/Automotive.md` and `Operations/Robotics.md` (Proposed v0 stubs). Human-directed.

- 2026-10-10: Safety review: floors AF-9 to AF-13 and RF-9 to RF-12 added; AU-002/003/004 and RB-002/003/007 changed to scoped Blocking and indexed in Unknowns.md v5.59. Human-directed.

- 2026-09-13: **Content-accuracy pass run against all 13 files' live Scope
  Boundary sections, as a follow-up to the coverage fix below.** Found and
  fixed one further issue: this map's own `Tooling_Inventory.md` entry (added
  earlier the same day) had missed a 5th Does-not bullet — repair methods
  beyond the inventory reference — present in the file's actual Scope
  Boundary. All 12 other entries checked clean against source; Operations/
  entries already carried their own prior correction annotations
  (Gate_03/Gate_05/Gate_06) and none had drifted further. Human-directed.

- 2026-09-13: **Coverage gap found and fixed — `Tooling_Inventory.md` had no entry.**
  Found during a folder-wide file-vs-scope-map cross-reference (all five
  `*_Scope_Map.md` files checked against their folders' actual contents).
  The file was created 2026-09-08 from the HP-007 skeleton, after this
  map's prior 2026-08-15 build — genuinely missed, not deliberately
  excluded. Entry added (alphabetically after `Plastics.md`), extracted
  from the file's own Scope Boundary. No other Operations/ file found
  missing. Full Does/Does-not content-accuracy pass (checking every
  existing entry against its target's live Scope Boundary text, not
  just coverage) not yet run. Human-directed.

- 2026-08-15: **Re-checked against a full day of Operations edits (Gate_02,
  Gate_03, Gate_06, Air_Scrubber) — one small drift found and fixed.**
  Applying `Admin/Resolution_Methodology.md` Pattern 5 for real (a prior
  citation of it in that file's Applied Case sections had mislabeled a
  different step — corrected there too). `Gate_02_Triage.md`'s Scope
  Boundary claimed Air_Scrubber owned "decontamination protocols" outright
  — in tension with TS-002's own disposition-workflow content now living
  in that file. Corrected to distinguish mechanism (Air_Scrubber) from
  workflow (Gate_02). `Gate_03_Reduction.md`'s Scope Boundary checked
  clean — already correctly claimed contamination-discovery doctrine
  before GR-003's new content existed. Smaller-scale instance of the same
  class of finding as the 2026-08-08 UNK-008 catches below, not a new
  failure mode. Human-directed.

- 2026-08-08: **File created — third folder in the Scope_Map rollout**,
  following `Admin/Adm_Scope_Map.md` (2026-08-07) and
  `Architecture/Arc_Scope_Map.md` (2026-08-08). All 12 Operations/ files'
  Status/Spec Gates/Open Unknowns/Risk and full Scope Boundary content
  extracted directly from source, same method as both prior folders. Two
  more instances of the exact UNK-008 staleness pattern found in
  `Architecture/Forge_flow.md` yesterday were found here
  (`Gate_05_Separation_Thermal.md`, `Gate_06_Fabrication.md`) and fixed
  in the same pass, per direct instruction. One look-alike
  ("not yet assigned" on GF-003) was checked against `Unknowns.md` and
  confirmed genuinely correct, not fixed. No missing Scope Boundary
  sections in this folder, unlike Admin/. No new unknowns registered.
  Human-directed.
