# Lazarus Forge — Operational Tooling Inventory (v0)

---

## Navigation Anchors
* **Context Core:** [Discovery.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Discovery.md)
* **Network Routing:** [Routing.md](https://raw.githubusercontent.com/ksarith/LazarusForge/refs/heads/main/Routing.md)
* **Decision Point B reference:** [Architecture/Forge_flow.md](../Architecture/Forge_flow.md) — ASM-003, Defined Term “Within tooling capability”, FL-004

---

## File State

| Field            | Value                                                               |
|------------------|---------------------------------------------------------------------|
| Status           | Exploration                                                         |
| Body Stability   | Transitional                                                        |
| Spec Gates       | 0/6                                                                 |
| Verification Ref | Admin/Verification_Gates.md                                         |
| Last Audit       | 2026-10-30 — Vibe (Repo Custodian, delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A): X3 mechanical citation retrofit (Operations pass) — 4 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.30 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only; no ID renumbered; frozen history untouched; no gate advanced; Open Unknowns unchanged. Prior: 2026-10-25 — Claude (human-directed, PKC-032) added the Drift Indicators section; no content review. Prior: 2026-09-08 (Claude review — added missing Lessons Learned/Active Disputes sections; prior: file created from HP-007 skeleton) |
| Auditor          | Vibe — Repo Custodian, 2026-10-30 X3 mechanical citation retrofit (Operations pass; delegated maintenance, human-ruled Decision Brief 2026-10-29 item 4A); prior: —                                                                   |
| Open Unknowns    | 1                                                                   |
| Active Disputes  | 0                                                                   |
| Highest Risk     | Medium                                                              |
| Sidecar Link     | #auditor-notes--unknowns                                            |
| Ethical Anchor   | Attempt to do no harm. Defer to Ethical_Constraints.md if present.  |

---

## Scope Boundary

**This file DOES define:**
- The live operational tooling inventory used by Decision Point B (“within current tooling capability”)
- Ownership and maintenance cadence for that inventory
- The conservative default rule when the inventory is stale or incomplete
- Distinction between this operational inventory and the system-component taxonomy in Architecture/Components.md

**This file DOES NOT define:**
- System-level Critical / Useful / Bootstrap component taxonomy
  (→ Architecture/Components.md)
- Detailed machine specifications, tolerances, or process parameters
- G.E.C.K. consumables and redundancy stock
  (→ Architecture/Geck_forge_seed.md)
- Gate logic itself
  (→ Architecture/Forge_flow.md)
- Repair methods or repair heuristics beyond the inventory reference
  (→ Architecture/Forge_flow.md Decision Point B and Operations/Gate_02_Triage.md)

---

## File Purpose

Decision Point B in Forge_flow.md evaluates whether a failure is “within current tooling capability.” That evaluation is only deterministic if a known, maintained list of tools actually available to operators exists. This file is that list and its governing rules.

It is deliberately narrow: a living operational reference, not an architecture document. It exists to satisfy `Architecture/Forge_flow.md` ASM-003 and FL-004 (`Architecture/Forge_flow.md`) (not this file's own ASM-003 below).

Without this file, Decision Point B decisions remain operator-dependent mental models and the conservative degraded-mode rule (“if inventory is stale → Decision Point B = NO”) has nothing concrete to check against.

**This file is per-deployment, not canonical.** This repository is
shared and forked across independent Forge builds. Whatever gets
populated into the Current Inventory tables below reflects one
deployment's actual tools — never treat a populated copy as a
reference example, a default loadout, or a global answer for what
"current Forge capability" means. Every Forge instance maintains its
own copy of this file against its own tools. Divergence between
sites is expected and correct, not a defect to converge away. This
file follows `Admin/Governance_Charter.md`'s Deployment Localization
Doctrine (2026-09-08), which generalizes the Reference Deployment
Context pattern `Architecture/Facilities.md` established for the
same problem: the Current Inventory tables below are this file's
substitution mechanism, equivalent to that file's Site
Initialization Checklist.

---

## Assumptions

| ID      | Assumption                                                                 | Basis                          | Confidence | Expiry Trigger                                      |
|---------|----------------------------------------------------------------------------|--------------------------------|------------|-----------------------------------------------------|
| ASM-001 | The inventory below is the sole reference Decision Point B may use                   | Forge_flow.md ASM-003 / FL-004 | High       | Inventory ownership reassigned or doctrine changed  |
| ASM-002 | Operators will update the inventory when tools are added, lost, or fail    | Maintenance cadence (below)    | Medium     | First operational cycle shows update failures       |
| ASM-003 | Absence of a tool from this list is treated as “not available”             | Conservative default rule      | High       | Explicit override doctrine adopted                  |

---

## Governing Rules

1. **Sole reference**  
   Decision Point B decisions use only the inventory in this file. Projected, planned, or “we could buy” tools are invisible to Decision Point B.

2. **Conservative default**  
   If the inventory is known to be stale, incomplete, or under dispute, Decision Point B evaluates to **NO** (item routes to Decision Point C). See Forge_flow.md degraded-operation doctrine and `Architecture/Forge_flow.md` ASM-003 (distinct from this file's own ASM-003).

3. **Update cadence**  
   - After any tool is added, removed, fails, or is taken out of service → update within one operational shift.  
   - Full review at least once per calendar month or before any Specification-stage gate promotion, whichever comes first.  
   - Owner: [to be assigned — Operations lead or designated technician].

4. **Relationship to Components.md**  
   Architecture/Components.md defines system-level Critical/Useful/Bootstrap components (shredder, metrology, atmosphere control, etc.).  
   This file lists the concrete tools and machines that operators actually have on hand for repair and triage decisions.  
   The two documents are complementary, not interchangeable.

5. **Relationship to Decision Point B secondary test**  
   When Decision Point B’s secondary “justified effort” test is applied, the “within current tooling capability” clause is evaluated exclusively against this inventory.

---

## Current Inventory (v0 — First Population Pending)

*Populate with actual tools present at the deployment site. Categories are suggestions only; add or remove rows as needed. Status values: Available / Degraded / Out of Service / Missing.*

*Empty tables are intentional at file creation. First physical inventory and population should occur before any claim that Decision Point B is fully deterministic. See TI-001.*

### Hand Tools & Bench
| Tool / Item                         | Qty | Status     | Notes / Last Verified |
|-------------------------------------|-----|------------|-----------------------|
| Adjustable wrenches                 |     |            |                       |
| Socket set                          |     |            |                       |
| Screwdriver set (flat / Phillips)   |     |            |                       |
| Pliers / cutters / strippers        |     |            |                       |
| Torque wrench                       |     |            |                       |
| Hammer / mallet set                 |     |            |                       |
| Utility knives / scrapers           |     |            |                       |
| Files / deburring tools             |     |            |                       |
| …                                   |     |            |                       |

### Machine Tools & Workholding
| Tool / Item                         | Qty | Status     | Notes / Last Verified |
|-------------------------------------|-----|------------|-----------------------|
| Bench vise                          |     |            |                       |
| Drill press                         |     |            |                       |
| Angle grinder                       |     |            |                       |
| Band saw / cut-off saw              |     |            |                       |
| …                                   |     |            |                       |

### Measurement & Metrology (operational)
| Tool / Item                         | Qty | Status     | Notes / Last Verified |
|-------------------------------------|-----|------------|-----------------------|
| Digital calipers                    |     |            |                       |
| Micrometer                          |     |            |                       |
| Steel rule / tape                   |     |            |                       |
| Multimeter                          |     |            |                       |
| …                                   |     |            |                       |

### Soldering / Electronics Support
| Tool / Item                         | Qty | Status     | Notes / Last Verified |
|-------------------------------------|-----|------------|-----------------------|
| Soldering station                   |     |            |                       |
| Desoldering tools                   |     |            |                       |
| …                                   |     |            |                       |

### Power & Safety Support
| Tool / Item                         | Qty | Status     | Notes / Last Verified |
|-------------------------------------|-----|------------|-----------------------|
| PPE (gloves, eye protection, etc.)  |     |            |                       |
| Fire extinguisher / suppression     |     |            |                       |
| …                                   |     |            |                       |

---

## Lessons Learned

| Date | Evidence Type | What Was Tried | What Failed | What Was Learned | Confidence | Revalidation Needed |
|------|---------------|----------------|-------------|-------------------|------------|----------------------|
| —    | —             | —              | —           | No entries yet — file created 2026-09-08, no physical inventory or operational cycle has occurred | — | — |

---

## Active Disputes

| ID | Dispute Summary    | Positions in Conflict | Risk | Status | Owner |
|----|---------------------|-------------------------|------|--------|-------|
| —  | No active disputes | —                       | —    | —      | —     |

---

## Drift Indicators

Each of these restates a rule this file already states; none is new doctrine. The template's Mandatory Re-Audit Conditions (`Admin/File_Template.md` Section 11) also apply.

- A tool is added, removed, fails or is taken out of service and the inventory is not updated within one operational shift (Governing Rule 3)
- No full review within a calendar month, or a Specification-stage gate promotion proceeds without one (Governing Rule 3)
- Decision Point B counts a projected, planned or "could buy" tool, or evaluates the tooling-capability clause against anything other than this inventory (Governing Rules 1 and 5)
- The inventory is known to be stale, incomplete or under dispute and Decision Point B does not evaluate to NO (Governing Rule 2)
- A tool absent from the list is treated as available (ASM-003)

---

## Auditor Notes & Unknowns

### TI-001 — Initial population and ownership assignment pending

| Field         | Value                                            |
|---------------|--------------------------------------------------|
| Status        | Open                                             |
| Risk          | Medium                                           |
| Priority      | Major                                            |
| Type          | Operational                                      |
| Blocking      | No (but blocks full FL-001 (`Architecture/Forge_flow.md`) / Decision Point B determinism) |
| Owner         | Operations/Tooling_Inventory.md                  |
| First Logged  | 2026-09-08                                       |
| Last Reviewed | 2026-09-08                                       |

**Description:** The inventory tables above are structural placeholders. No actual tool list has been populated and no human owner has been assigned.

**Why It Matters:** Until the list is real and owned, ASM-003 in Forge_flow.md and FL-004 (`Architecture/Forge_flow.md`) remain open assumptions. Decision Point B cannot claim full determinism.

**Resolution Path (per deployment):**
- This is closed once, locally, by each Forge instance — never once
  globally on this repository's behalf. A populated inventory from
  one build/session/agent does not resolve TI-001 for any other
  deployment; it only resolves it for that one instance's own copy
  of this file.
- Assign a named owner.
- Perform a first physical inventory at that site and populate the
  tables.
- Record the date of first population in the Resolution Log below.
- Notify Architecture/Forge_flow.md so ASM-003 Expiry Trigger and FL-004 (`Architecture/Forge_flow.md`) can be updated — for that instance's own fork/copy.
- Add the short cross-reference note to Architecture/Components.md Scope Boundary or Bootstrap Doctrine section, if not already present.

---

## Resolution Log

- 2026-10-30: **X3 mechanical citation retrofit (Operations pass).** 4 bare colliding-prefix citations qualified with their owning File.md per PKC-003 (Kit v1.30 Governance Sidecar ID Reference; per-ID grounding: Unknowns active index). Citation-form-only: no ID renumbered, no Unknown opened or closed, no Spec Gate advanced, frozen history untouched. Out-of-whitelist bare IDs were left bare and reported to the human. (Vibe, Repo Custodian — delegated maintenance per Decision Brief 2026-10-29 item 4A.)

- 2026-10-25: **Drift Indicators section added (PKC-032 ruling, human-directed; no doctrine changed).** Drafted only from rules this file already states (Governing Rules 1 to 3 and 5, ASM-003). No content review was done, and no Unknown, assumption or Status changed. Wording for human review.

- 2026-10-24: ASM-003 citations disambiguated (human-directed, from a Vibe per-file audit; each finding checked against source first): two bare mentions now name Forge_flow's ASM-003 so they cannot be confused with this file's own ASM-003 (absence of a tool is treated as not available). No inventory, rule or Unknown changed.

- 2026-09-08 (third follow-up): Cross-referenced this file's File
  Purpose to the new Deployment Localization Doctrine in
  `Admin/Governance_Charter.md`, generalized from
  `Architecture/Facilities.md`'s Reference Deployment Context
  pattern. This file's Current Inventory tables are now explicitly
  named as this file's substitution mechanism under that doctrine.
  Human-directed.

- 2026-09-08 (second follow-up): Added explicit per-deployment /
  non-canonical language to File Purpose and to TI-001's Resolution
  Path, per human-raised concern that this repository is shared
  across independent Forge builds and no single site's data (James's
  own included) should be treated as a reference example or global
  answer. Wording only — no structural change. Human-directed.

- 2026-09-08 (Claude review pass): Reviewed the Grok-created file
  against `Architecture/Forge_flow.md` (clean — only this file was
  new, nothing else in the repo touched) and against
  `Admin/File_Template.md`. Found and fixed two gaps: missing
  Lessons Learned section (template requires it present with a
  placeholder row even for brand-new files, per the Minimal Valid
  File Example) and missing Active Disputes section (template
  explicitly requires the header and empty table even with zero
  disputes). Added both. Applied the cross-reference stub to
  `Architecture/Components.md`'s Scope Boundary that this file's own
  prior entry had prepared but not applied. Updated
  `Architecture/Forge_flow.md`'s FL-004 to reflect this file's
  existence and HP-007 to Done. Mirrored TI-001 into `Unknowns.md`
  v5.05. Human-directed.

- 2026-09-08: File created from the HP-007 held skeleton to satisfy FL-004 / ASM-003 ownership gap. Inventory tables left empty pending first physical count (TI-001). Cross-reference language for Components.md and Forge_flow.md prepared but not yet applied to those files. Human-directed.
